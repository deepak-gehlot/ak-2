﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NewAPGApplication.Models
{
    public class MenuUrl
    {
        // --- Admin Menu Setting

        public static string Adm_DeshBoard_controller = "Admin";
        public static string Adm_DeshBoard_ActionResult = "AdminIndex";
        public static string Adm_DeshBoard_Parameters = "";

        public static string Adm_Patient_controller = "Admin";
        public static string Adm_Patient_ActionResult = "Index";
        public static string Adm_Patient_Parameters = "param=User Patient";

        public static string Adm_Womac_controller = "Admin";
        public static string Adm_Womac_ActionResult = "Index";
        public static string Adm_Womac_Parameters = "param=User Womac";

        public static string Adm_Report_controller = "Admin";
        public static string Adm_Report_ActionResult = "Index";
        public static string Adm_Report_Parameters =  "param=User Reports"; 

        public static string Adm_Alert_controller = "Admin";
        public static string Adm_Alert_ActionResult = "Index";
        public static string Adm_Alert_Parameters = "param=User Alert";

        public static string Adm_Facility_controller = "Admin";
        public static string Adm_Facility_ActionResult = "Index";
        public static string Adm_Facility_Parameters = "param=User Facility";

        // --- Patient Menu Setting

        public static string Patient_DeshBoard_controller = "PatientDeshboard";
        public static string Patient_DeshBoard_ActionResult = "PatientIndex";

        public static string Patient_Injection_controller = "PatientDeshboard";
        public static string Patient_Injection_ActionResult = "PatientIndex";

        public static string Patient_Womac_controller = "Womac";
        public static string Patient_Womac_ActionResult = "SelectWomacKnee";

        public static string Patient_Bmi_controller = "Admin";
        public static string Patient_Bmi_ActionResult = "PatientBMIList";

        public static string Patient_Alert_controller = "";
        public static string Patient_Alert_ActionResult = "";
              
    }
}