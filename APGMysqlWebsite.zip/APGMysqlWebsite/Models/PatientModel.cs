﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace NewAPGApplication.Models
{
    public class PatientModel
    {
    }

    public class PatientRegistration
    {
        public int ButtonType { get; set; }
        public string PatientId { get; set; }
        public string UserNameId { get; set; }
        public Int16 UserRoleId { get; set; }
        public string FacilityId { get; set; }
        public string FacilityName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
        public DateTime DateOfBirth { get; set; }
        public DateTime DateOfBirths { get; set; }
        public string EmailId { get; set; }
        
        public string OldPassword { get; set; }

        public string Password { get; set; }

        public string ConformPassword { get; set; }

        public string Address { get; set; }
        public string CityId { get; set; }
        public string StateId { get; set; }
        public string ZipCode { get; set; }
        public string MailingAddress { get; set; }
        public string MailingCity { get; set; }
        public string MailingState { get; set; }
        public string MailingZipcode { get; set; }
        public string EthnicityId { get; set; }
        public string MobileNo { get; set; }
        public string OtherContactNo { get; set; }
        public string Soc_Security { get; set; }

        public string U_Image { get; set; }
        public DateTime CreatedDate { get; set; }

        public int IsActive { get; set; }

        public string DigitalSignURL { get; set; }
        public string ForgetPasswordString { get; set; }

        public string BirthDate { get; set; }
      //  public DateTime birthdate { get; set; }

        public string NickName { get; set; }
        public string Occuption { get; set; }
        public string Employer { get; set; }
        public string EmpStreet { get; set; }
        public string EmpCityId { get; set; }
        public string EmpStateId { get; set; }
        public string EmpZipCode { get; set; }
        public string EmpContactNo { get; set; }
        public string EduId { get; set; }

        public Int16? PIN { get ; set ; }
        public Int16? ConfirmPIN { get; set; }


        public string WorkType { get; set; }
        public string Height { get; set; }
        public Int16? Weight { get; set; }
        public float? BMI { get; set; }
        public string WheelChair { get; set; }
        public string ContactAtWork { get; set; }

        public string KnowAboutUs { get; set; }


        public bool HaveChiropracticPhysician { get; set; }
        public string ChiroPhysicianName { get; set; }
        public bool PrimaryPhysician { get; set; }
        public string PrimPhysicianName { get; set; }

        public string EthnicityName { get; set; }

        public Int16 IsDelete { get; set; }
        public Int16 IsReactive { get; set; }

        //----------------------------------------------

        //public string LoginEmail { get; set; }
        //public string LoginPassword { get; set; }

        //---------------------------------------------

        public Int16 ReferralId { get; set; }

        public string CityName { get; set; }

        //--------------------------------------------

        public Int16 HeightFeet { get; set; }
        public Int16 HeightInch { get; set; }
        
        //-------------------------------------------

        public DateTime InjectionDate { get; set; }
        public string InjDate { get; set; }
        public string AgeOnDate { get; set; }

        //-----------------------------------------

        public string Knee { get; set; }
        public string Phy_Therapy { get; set; }
        public string PhysicianId { get; set; }
        public string PhysicalTherapistId { get; set; }

    
    }
    public class patientloginmodel
    {
        public string LoginEmail { get; set; }
        public string LoginPassword { get; set; }
    }

    public class CreatePatinetBMI
    {
        public string UserNameId { get; set; }
        public string PatientId { get; set; }
        public string FirstName { get; set; }
        public string Height { get; set; }
        public string Weight { get; set; }
        public string BMI { get; set; }
    }
    public class Insurance
    {
        public string PatientId { get; set; }
        public Int16 InsId { get; set; }
        public string UserNameId { get; set; }
        public Int16 Rid { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string CityId { get; set; }
        public string StateId { get; set; }
        public string ZipCode { get; set; }
        public string Policy { get; set; }
        public string InsureName { get; set; }
        public string Relation { get; set; }
        public string Soc_Security { get; set; }
        public string BirthDate { get; set; }
        public string GroupNo { get; set; }
        public string EmployerName { get; set; }

        public string I_Name { get; set; }
        public string I_Address { get; set; }
        public string I_CityId { get; set; }
        public string I_StateId { get; set; }
        public string I_ZipCode { get; set; }
        public string I_Policy { get; set; }
        public string I_InsureName { get; set; }
        public string I_Relation { get; set; }
        public string I_Soc_Security { get; set; }
        public string I_BirthDate { get; set; }
        public string I_groupNo { get; set; }
        public string I_EmployerName { get; set; }


    }

    public class UploadCsvFile
    {
        public string errormessage { get; set; }
        public string UId { get; set; }
        public int RId { get; set; }
        public string FacilityId { get; set; }
        public string NickName { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
        public string Gender { get; set; }
        public string Dob { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }
        public string Address { get; set; }
        public int CityId { get; set; }
        public int StateId { get; set; }
        public int Zipcode { get; set; }
        public string MailingAddress { get; set; }
        public string MailingCity { get; set; }
        public string MailingState { get; set; }
        public int MailingZipcode { get; set; }
        public int EthnicityId { get; set; }
        public string MobileNo { get; set; }

        public string OtherContactNo { get; set; }

        public string SocSecurity { get; set; }

        public string UImage { get; set; }
        public string CreatedDate { get; set; }
        public int IsActive { get; set; }
        public string DigitalSignUrl { get; set; }
        public string ForgetPasswordString {get;  set; }
        public int IsReactive { get; set; }
        public int Height { get; set; }
        public int Weight { get; set; }
        public float BMI { get; set; }
        public int IsDeactive { get; set; }
        public int IsDeleted { get; set; }
        public int Inactive { get; set; }
        public string  InactiveDate { get; set; }
     

    
    
    }

    public class PatientQuestionnaire
    {
        public string PatientId { get; set; }
        public string Name { get; set; }
        public string DOB { get; set; }
        public string UserNameId { get; set; }
        public string SubmittedOn { get; set; }

        public string SignatureValue { get; set; }
        public string PatientSignature { get; set; }

        public string MedicalValues { get; set; }
        public string Treatments { get; set; }
        public string Review { get; set; }
        public string MedicationAllergy { get; set; }
        public string FoodAllergy { get; set; }
        public string Allergies { get; set; }



        //-----------------Surgeries

        public string SurgeriesValues { get; set; }
        public string MonthNm { get; set; }
        public string YearNm { get; set; }

        //-----------------Social History

        public bool Smoke { get; set; }
        public string PacksInday { get; set; }
        public bool Alcohol { get; set; }
        public string PacksperDay { get; set; }
        public bool Drug { get; set; }
        public string DrugName { get; set; }
        public bool AbuseVictim { get; set; }
        public string AbuseVictimDetail { get; set; }
        public bool ClaimOrLawsuit { get; set; }
        public bool Compensation { get; set; }
        public bool InjuryOrInsurance { get; set; }
        public string Other { get; set; }
        public bool Disability { get; set; }

        //-----------------Procedure Pre



        //- X-Rays


        public string XraysDate { get; set; }
        public string XraysLocation { get; set; }
        public string XraysForWhat { get; set; }


        //- CT / MrI

        public string CtMriDate { get; set; }
        public string CtMriLocation { get; set; }
        public string CtMriForWhat { get; set; }

        //- Myelogram

        public string MyelogramDate { get; set; }
        public string MyelogramLocation { get; set; }
        public string MyelogramForWhat { get; set; }

        //- Ultrasound

        public string UltrasoundDate { get; set; }
        public string UltrasoundLocation { get; set; }
        public string UltrasoundForWhat { get; set; }

        //- EMG

        public string EMGDate { get; set; }
        public string EMGLocation { get; set; }
        public string EMGForWhat { get; set; }

        //- Treat Another Physician

        public string TAPhysicianDate { get; set; }
        public string TAPhysicianLocation { get; set; }
        public string AnotherPhysicianForWhat { get; set; }



        //-----------------Current Madication

        public string CurrentMedications { get; set; }
        public string Strength { get; set; }
        public string NoOfDose { get; set; }

        //-----------------Family History

        public string FamilyHistory { get; set; }
        public string PersonName { get; set; }

        //------------------- Family History

        public string HeartPerson { get; set; }
        public string EpilepsyPerson { get; set; }
        public string HypertensionPerson { get; set; }
        public string GlaucomaPerson { get; set; }
        public string StrokePerson { get; set; }
        public string BleedingPerson { get; set; }
        public string CancerPerson { get; set; }
        public string KidneyPerson { get; set; }
        public string DiabetesPerson { get; set; }
        public string ThyroidPerson { get; set; }

    }

    public class ReActivation
    {
        public string PatientId { get; set; }
        public string AgeOnReActivation { get; set; }
        public string ReferringPhysician { get; set; }
        public string PrimaryPhysician { get; set; }
        public string Pharmacy { get; set; }
        public string CityState { get; set; }
        public string PainHistoryOne { get; set; }
        public string PainHistoryTwo { get; set; }
        public string RightPainArea { get; set; }
        public string BackPainArea { get; set; }
        public string FrontPainArea { get; set; }
        public string LeftPainArea { get; set; }
        public string PainDescription { get; set; }
        public string LastInjectionDate { get; set; }
        public string TypeOfInjection { get; set; }
        public string Helpful { get; set; }
        public string PercentRelief { get; set; }
        public string HowLong { get; set; }
        public string MedicationsPrescription { get; set; }
        public string MedicationsPrescriptionDetail { get; set; }
        public string MedicalConditions { get; set; }
        public string Surgeries { get; set; }
        public string CurrentMedications { get; set; }
        public string ALLERGIESMedications { get; set; }
        public string ALLERGIESFood { get; set; }
        public string ALLERGIES { get; set; }
        public string REVIEWList { get; set; }
        public string PatientSignature { get; set; }
        public string SignatureDate { get; set; }
    }

    public class BodyTest
    {
        public string PatientId { get; set; }
        public string UserNameId { get; set; }
        public string PainHistory { get; set; }
        public string FrontPainArea { get; set; }
        public string BackPainArea { get; set; }
        public string RightPainArea { get; set; }
        public string LeftPainArea { get; set; }
        public string PainDescription { get; set; }

        public string SubmittedOnDate { get; set; }
        public string SignaturePatient { get; set; }
        public string PhysicianSignature { get; set; }
        public string NurseSignature { get; set; }

               
        public string CanPregnant { get; set; }
        public string Pregnant { get; set; }
        public string LastPeriodNormal { get; set; }
        public string LastPeriodOn { get; set; }
        public string LastMammogramNormal { get; set; }
        public string LastMammogramOn { get; set; }
        public string LastPepSmearNormal { get; set; }
        public string LastPepSmearOn { get; set; }
        public string Signature1 { get; set; }
    }

    public class WomacAlert
    {
        public int ProgrssWomacDue { get; set; }
        public int FinalWomacDue { get; set; }
    }

    public class Notification
    {
        public int _45DayesNotification { get; set; }
        public int _90DayesNotification { get; set; }
        public int _120DayesNotification { get; set; }
    }

    public class PatientList
    {
        public List<PatientDetail> patientList { get; set; }
    }
    public class alertlist
    {
        public List<PatientAlertList> patientalertlistt { get; set; }
        public List<patientalertlist1> patientalertlistt1 { get; set; }
    }

    public class PatientAlertList
    {
        public int SrNo { get; set; }
        public string PatientId { get; set; }
        public string Email { get; set; }
        public string Patient { get; set; }
        public int alertid { get; set; }
        public string PrimaryContactNo { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string ScheduleDay { get; set; }
        public string  firstalert { get; set; }
        public string  secondalert { get; set; }
        public string  thirdalert { get; set; }
        public string status { get; set; }
        public string note { get; set; }
      
       
    }
    public class patientalertlist1
    {
        public string allertid { get; set; }
        public string note { get; set; }
        public int alertid { get; set; }
        public string  alertdate { get; set; }
    }

    public class PatientDetail
    {
        public string Pid { get; set; }
        public int SrNo { get; set; }
        public string PatientId { get; set; }
        public string Email { get; set; }
        public string Patient { get; set; }
   
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string NickName { get; set; }
        public string status { get; set; }
        public string PrimaryContactNo { get; set; }
        public string Edit { get; set; }
        public string Delete { get; set; }
        public string firstalert { get; set; }
        public string secondalert { get; set; }
        public string thirdalert { get; set; }
        public string ScheduleDay { get; set; }
        public string mailbody { get; set; }
    }

    public class PatientWomacReportList
    {
        public List<PatientWomacReport> PatientWomacRepotList { get; set; }
    }

    public class PatientWomacReport
    {
        public int SrNo { get; set; }
        public string PatientId { get; set; }
        public string PatientName { get; set; }
        public string Knee { get; set; }
        public string Womac1 { get; set; }
        public string Womac2 { get; set; }
        public string Womac3 { get; set; }
        public string WomacId { get; set; }
        public string WomacListType { get; set; }
        public string Save { get; set; }
        public string Delete { get; set; }
        public string Edit { get; set; }
    }

    public class PatientInjectionReport
    {
        public string PatientId { get; set; }
        public string PatientName { get; set; }
        public string InjectionNo { get; set; }
        public string InjectionDate { get; set; }
        public string Knee { get; set; }
    }

    public class PatientInjectionReportList
    {
        public List<PatientInjectionReport> patientInjectionRepotList { get; set; }
    }

    public class PatientBMIList
    {
        public List<PatientBMI> patientBMIList { get; set; }
    }

    public class PatientBMI
    {
        public int SrNo { get; set; }
        public string PatientId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Height { get; set; }
        public int HeightFeet { get; set; }
        public int HeightInch { get; set; }
        public double Weight { get; set; }
        public double BMI { get; set; }
        public string BMIDate { get; set; }
    }


    public class NewPatientCompliant
    {
        public string PatientId { get; set; }
        public int NewComplaintId { get; set; }
        public string NewInjuryDate { get; set; }
        public string Cause { get; set; }
        public string NewInjuryDescription { get; set; }
        public string LastCheckUp { get; set; }
        public string LastCheckUpDetail { get; set; }
        public string FrontPainArea { get; set; }
        public string BackPainArea { get; set; }
        public string PainScale { get; set; }
        public string PainDescription { get; set; }
        public string CurrentMobility { get; set; }
        public string CurrentEmployeement { get; set; }
        public string WokingStatus { get; set; }
        public string LastFullDayWork { get; set; }
    }

    public class MedicalInformation
    {
        public string PatientId { get; set; }
        public string PatientName { get; set; }
        public string DOB { get; set; }
        public string Street { get; set; }
        public string SocSec { get; set; }
        public string City { get; set; }
        public string ContactNo { get; set; }
        public string ReleaseTo { get; set; }
        public string ObtainFrom { get; set; }
        public string OrgName { get; set; }
        public string OrgAddress { get; set; }
        public string OrgContactNo { get; set; }
        public string AppliesTo { get; set; }
        public string ValidTill { get; set; }
        public string Signature { get; set; }
        public string SignDate { get; set; }
    }
}