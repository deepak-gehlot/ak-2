﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Globalization;
using System.Web.Security;

namespace NewAPGApplication.Models
{
    public class UsersContext : DbContext
    {
        public UsersContext()
            : base("DefaultConnection")
        {
        }
    }

    public class LoginModel
    {
        [Required]
        [DataType(DataType.EmailAddress)]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Emailaddress { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [Display(Name = "Remember me?")]
        public bool RememberMe { get; set; }

    }

    public class FormAuthentication
    {
        public List<UserFormAuthentication> FormList { get; set; }
    }

    public class UserFormAuthentication
    {
        public int UserRoleId { get; set; }
        public int FormId { get; set; }
        public string FormName { get; set; }
        public string ImageURL { get; set; }
        public string DisplayValue { get; set; }
    }

    public class Menu
    {
        public Menu()
        {
            MenuItems = new List<MenuItem>();
        }
        public int Id { get; set; }
        public string Name { get; set; }
        public IList<MenuItem> MenuItems { get; set; }
    }

    public class MenuItem
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ActionName { get; set; }
        public string ControllerName { get; set; }
        public string Url { get; set; }
        public string ParameterList { get; set; }
    }

    public class UserLevelList
    {
        public List<UserLevel> userLevelList { get; set; }
    }

    public class UserLevel
    {
        public int SrNo { get; set; }
        public int UserTypeId { get; set; }
        public string UserType { get; set; }
        public string Edit { get; set; }
        public string Delete { get; set; }
    }

    public class UserLevelAouthenticationList
    {
        public List<UserLevelAouthentication> userLevelAouthenticationlList { get; set; }
    }

    public class UserLevelAouthentication
    {
        public string R_id { get; set; }
        public int FormId { get; set; }
        public string Displayvalue { get; set; }
        public IEnumerable<bool> Showform1 { get; set; }
        public int Showform { get; set; }
        public int Saveform { get; set; }
        public int UpdateForm { get; set; }
        public int DeleteForm { get; set; }
        public int printFrom { get; set; }

    }

    public class UserLevelViewAouthenticationList
    {
        public List<UserLevelViewAouthentication> userLevelViewAouthenticationlList { get; set; }
    }

    public class UserLevelViewAouthentication
    {
        public int FormId { get; set; }
       // public string ControllerName { get; set; }
        //public string ActionName { get; set; }
        //public string ImageURL { get; set; }
        public string Displayvalue { get; set; }
        public IEnumerable<bool> Showform1 { get; set; }
        public int Showform { get; set; }
        public int Saveform { get; set; }
        public int UpdateForm { get; set; }
        public int DeleteForm { get; set; }
        public int printFrom { get; set; }
        public string MainMenu { get; set; }
       
    }
    
    public class Connection
    {
        public static string LoginUserId = "0";
        public static int LoginUserTypeId = 0;
        public static string Email = null;
        public static string Pass = null;
        public static string UserId = "0";
        public static int FormId = 0;
        public static string AllowShow = null;
        public static string AllowSave = null;
        public static string AllowUpdate = string.Empty;
        public static string AllowDelete = null;
        public static string AllowPrint = null;
        public static string UserType = null;

        public static int PainScore = 0;
        public static int Stiffness = 0;
        public static int PhysicalFunction = 0;
        public static int WomacTestId = 0;
        public static int FacilityId = 0;
        public static string FacilityName = "";
        public static DateTime LoginDate;
        public static string BirthDate;
        public static string LoginYear;
        public static int DiseaseId = 0;
        public static int DiseaseTypeId = 0;
        public static string PatientId = "0";
        public static string UserIsActive = null;
        public static string PatientIsActive = "False";

        public static string BmiPatientId = "";
        public static string height = "";
        public static Int32 weight = 0;
        public static double BMI = 0;


    }

    public class PatientAcknowledgement
    {
        public string PatientId { get; set; }
        public string AkgDate { get; set; }
        public string Signature { get; set; }
    }

    public class AgeGraphReportOne
    {
        public double TotalMale { get; set; }
        public double TotalFemale { get; set; }
        public double Age24 { get; set; }
        public double Age45 { get; set; }
        public double Age66 { get; set; }
        public double Age87 { get; set; }
        public int TotalPatient { get; set; }
        public string FacilityName { get; set; }
        public int FacilityId { get; set; }
        public List<Ethnicity> Ethnicities { set; get; }
        public AgeGraphReportOne()
        {
            Ethnicities = new List<Ethnicity>();
        }
    }

    public class Ethnicity
    {
        public int EthnicityId { get; set; }
        public string EthnicityName { get; set; }
        public double EthnicityPercentage { get; set; }
    
    }
 
    public class Report
    {
        public string FacilityId { get; set; }
    }

    public class ChartData
    {
        public int TotalWomacTest { get; set; }
        public int CompletedWomacTest { get; set; }
        public int NotCompletesd { get; set; }
    }
    public class FacilityLogList
    {
        public List<FacilityLogDetails> facilityloglist { get; set; }
        public List<FacilityLogDetails1> facilityloglist1 { get; set; }
        public List<FacilityOperationNameList> facilitylist { get; set; }
        public List<FacilityList2> FacilityList2 { get; set; }
        public string OperationName { get; set; }
        public string FacilityId { get; set; }
        public string FacilityName { get; set; }
    }

    public class FacilityLogDetails
    {
        public int SrNo { get; set; }
        public string FacilityId { get; set; }
        public string  UserName { get; set; }
        public string  Email { get; set; }
        public string  UserType { get; set; }
       
    
    }

    //public class FacilityLogList1
    //{
    //    public List<FacilityLogDetails1> facilityloglist { get; set; }
    //}

    public class FacilityLogDetails1
    {
        public int SrNo { get; set; }
        public string FacilityId { get; set; }
        public string OperationName { get; set; }

        public string Email { get; set; }
        public string  LoginOn { get; set; }
        public int RId { get; set; }
        public string LogTime { get; set; }
        public string SystemIp { get; set; }
        public string ModifiedRecord { get; set; }
        public string Details { get; set; }

    }
     public class FacilityList
    {
        public List<Facility> facilityList { get; set; }
    }

    public class Facility
    {
        public int FacilityId { get; set; }
        public string LocationName { get; set; }
        public string Address { get; set; }
        public string CityName { get; set; }

        public int StateId { get; set; }
        public int CityId { get; set; }

        public string State { get; set; }
        public string City { get; set; }
        public string U_Id { get; set; }

        public string Zipcode { get; set; }
        public string PhoneNumber { get; set; }
        public string FaxNumber { get; set; }
        public string Manager { get; set; }
        public string EmailAddress { get; set; }
        public string Edit { get; set; }
        public string Delete { get; set; }
        public int SerialNo { get; set; }
        public string LogDetail { get; set; }
       
    }
    public class FacilityOperationNameList
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }
    public class FacilityList2
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }


    public class FacilityList1
    {
        public string Text { get; set; }
        public int Value { get; set; }
    }
    public class UserList
    {
        public List<UserDetail> userList { get; set; }
        public int FacilityID { get; set; }
        public List<FacilityList1> FacilityList { get; set; }
        public List<FacilityList2> FacilityList2 { get; set; }
    }

    public class UserDetail
    {
        public int SNo { get; set; }
        public string UserId { get; set; }
        public int UserTypeId { get; set; }
        public string UserType { get; set; }
        public string LocationId { get; set; }
        public string LocationName { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneNo { get; set; }
        public string MobileNo { get; set; }
        public string Edit { get; set; }
        public string Delete { get; set; }
    }   

    public class UserLogDetailList
    {
        public List<UserLogDetail> userLogDetailList { get; set; }
    }

    public class UserLogDetail
    {
        public int SrNo { get; set; }
        public long Sno { get; set; }
        public long UserTypeId { get; set; }
        public string UserId { get; set; }
        public string UserEmailId { get; set; }
        public string Date { get; set; }
        public string Time { get; set; }
        public string ViewName { get; set; }
        public string OperationName { get; set; }
        public string Detail { get; set; }
        public string SystemName { get; set; }
        public string SystemIP { get; set; }
        public string ModifiedRecord { get; set; }
        public string DetailForUserView { get; set; }
        public string DateFrom { get; set; }
        public string DateTo { get; set; }
        public string logTime { get; set; }
    }

    public class Referral
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Edit { get; set; }
        public string Delete { get; set; }
    }

    public class ReferralList
    {
        public List<ReferralDetail> referralDetail { get; set; }
        public int ReferralId { get; set; }
        public string ReferralName { get; set; }
        public string ReferralDescription { get; set; }
    }

    public class ReferralDetail
    {
        public int SrNo { get; set; }
        public int ReferralId { get; set; }
        public string ReferralName { get; set; }
        public string ReferralDescription { get; set; }
        public string Edit { get; set; }
        public string Delete { get; set; }
    }

    public class ShowUserDetailsModel
    {
        public string Pid { get; set; }
        public string Alertid { get; set; }
        public List<ShowUserDetailsModelList> UserList { get; set; }
        public string usertype { get; set; }
        public List<SecurityRemindetr> SecurityList { get; set; }
        public string SecuritySub { get; set; }
        public string SecurityBody { get; set; }
        public string Status { get; set; }
        public string SecurityID { get; set; }
        public string AssignUser { get; set; }
        public string AdminSearch { get; set; }
        public string NoofDays { get; set; }
        public string AlertTo { get; set; }
        public string mailbody { get; set; }
        public string PatientId { get; set; }
      
       

        public string ToEmailID { get; set; }
        public string CCmail { get; set; }
        public string AlertFor { get; set; }
        public List<alertRoleList> RoleList { get; set; }
        public List<EmailIDList> EmailIDList1 { get; set; }
    }

    public class ShowUserDetailsModelList
    {
        public int UserId { get; set; }
        public string FullName { get; set; }
        public string Address { get; set; }
        public string EmailAddress { get; set; }
        public string NumberofEmployee { get; set; }
        public string NumberofPhycisian { get; set; }
        public string UserRole { get; set; }
        public string RegisterBy { get; set; }
        public string AccountCreateDate { get; set; }
        public string AccountRenewDate { get; set; }
        public string LastLoginDate { get; set; }
        public string TaskStatus { get; set; }
        public string UserComment { get; set; }
    }

    public class SecurityRemindetr
    {
        public int srno { get; set; }
        public int ReminderId { get; set; }
        public string AssignUser { get; set; }
        public string AlertFor { get; set; }
        public string ReminderSubject { get; set; }
        public string ReminderBody { get; set; }
        public string ReminderCreateDate { get; set; }
        public string ReminderModifyDate { get; set; }
        public Boolean IsActive { get; set; }
        public int NoofDays { get; set; }
    }

    public class alertRoleList
    {
        public int UserTypeId { get; set; }
        public string UserType { get; set; }
        public Boolean IsActive { get; set; }
    }

    public class EmailIDList
    {
        public int ID { get; set; }
        public string TypeID { get; set; }
        public string EmailID { get; set; }
    }
}
