﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NewAPGApplication.Models
{
    public class UserModel
    {
       public int UserType{get;set;}
       public int Flag { get; set; }
    }
}