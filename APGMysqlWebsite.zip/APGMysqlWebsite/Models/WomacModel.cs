﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Globalization;
using System.Web.Security;
using System.Data;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace NewAPGApplication.Models
{
    public class WomacModel
    {
    }
    public class Question
    {
        public int ID { set; get; }
        public string QuestionValue { set; get; }
        public List<Answer> Answers { set; get; }
        public string SelectedAnswer { set; get; }
        public Question()
        {
            Answers = new List<Answer>();
        }
    }

    public class Answer
    {
        public string ID { set; get; }
        public string AnswerText { set; get; }
        public int AnswerValue { set; get; }
        public bool IsChecked { get; set; }
        public bool Disabled { get; set; }
    }

    public class WomacTest
    {
        public int ID { set; get; }
        public int QuestionTypeId { set; get; }
        public string QuestionValue { set; get; }
        public List<Answer> Answers { set; get; }
        public string SelectedAnswer { set; get; }
        public WomacTest()
        {
            Answers = new List<Answer>();
        }
    }

    public class WomacTestBoth
    {
        public int ID { set; get; }
        public int QuestionTypeId { set; get; }
        public string QuestionValue { set; get; }
        public List<Answer> Answers1 { set; get; }
        public List<Answer> Answers2 { set; get; }
        public string SelectedAnswer1 { set; get; }
        public string SelectedAnswer2 { set; get; }
        public WomacTestBoth()
        {
            Answers1 = new List<Answer>();
            Answers2 = new List<Answer>();
        }
    }

    public class WomacBoth
    {
        public List<WomacTestBoth> WomacTests { set; get; }
        public List<WomacTestBoth> WomacTests1 { set; get; }
        public List<WomacTestBoth> WomacTests2 { set; get; }
        public List<WomacTestBoth> WomacTests3 { set; get; }
        public List<FacilityListSelection> facility { set; get; }

        public string Knee { get; set; }
        public string PatientId { get; set; }
        public string PatientName { get; set; }
        public int FacilityId { get; set; }
        public string FacilityName { get; set; }

        public string City { get; set; }
        public string DOB { get; set; }
        public string OsteoarthritisFirstKnee { get; set; }
        public string OsteoarthritisSecondKnee { get; set; }
        public string WomacDate { get; set; }

        public WomacBoth()
        {
            WomacTests = new List<WomacTestBoth>();
            WomacTests1 = new List<WomacTestBoth>();
            WomacTests2 = new List<WomacTestBoth>();
            WomacTests3 = new List<WomacTestBoth>();
            facility = new List<FacilityListSelection>();
        }

    }

    public class Womac1
    {
        public List<WomacTest> WomacTests { set; get; }
        public List<WomacTest> WomacTests1 { set; get; }
        public List<WomacTest> WomacTests2 { set; get; }
        public List<WomacTest> WomacTests3 { set; get; }
        public List<FacilityListSelection> facility { set; get; }
        public List<Physicain> physicain { set; get; }
        public string Knee { get; set; }
        public string PatientId { get; set; }
        public string PatientName { get; set; }

        public string FacilityName { get; set; }
        public int FacilityId { get; set; }

        public string City { get; set; }
        public string DOB { get; set; }
        public string Osteoarthritis { get; set; }
        public string WomacDate { get; set; }

        public Womac1()
        {
            WomacTests = new List<WomacTest>();
            WomacTests1 = new List<WomacTest>();
            WomacTests2 = new List<WomacTest>();
            WomacTests3 = new List<WomacTest>();
            facility = new List<FacilityListSelection>();
            physicain = new List<Physicain>();
        }
    }

    public class Physicain
    {
        public int PhysicainID { set; get; }
        public string PhysicainName { set; get; }
    }


    public class DiseaseList
    {
        public List<Disease> diseaseList { get; set; }
    }

    public class Disease
    {
        public int DiseaseTypeId { get; set; }
        public string DiseaseTypeName { get; set; }
    }

    public class DiseaseQuestionList
    {
        public List<DiseaseQuestion> DiseaseList { get; set; }
        public int DiseaseTypeID { get; set; }
    }

    public class DiseaseQuestion
    {
        public int SrNo {get; set;}
        public int DiseaseTypeId { get; set; }
        public int DiseaseId { get; set; }
        public string DiseaseName { get; set; }
        public string DiseaseTypeName { get; set; }
        public string Edit { get; set; }
        public string Delete { get; set; }
    }


    public class FacilityListSelection
    {
        public string FacilityID { set; get; }
        public string FacilityName { set; get; }
    }
    

    public class PhysicalTherapyDetail
    {
       
        public string PatientId { get; set; }
        public int WomacTestId { get; set; }
        public string Knee { get; set; }
        public int FacilityId { get; set; }
        public string PhysicianName { get; set; }
        public string Phy_TherapistName { get; set; }
        public string Phy_Therapy { get; set; }
        public string Phy_Therapy_Date { get; set; }
        public string AgeOnDate { get; set; }
        public string Injected { get; set; }
        public string InjectionNomber { get; set; }
        public string OsteoarthritisFirstKnee { get; set; }
        public string OsteoarthritisSecondKnee { get; set; }
    }

    public class Physician
    {
        public int PhysicainId { get; set; }
        public int FacilityId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string MobileNo { get; set; }
    }

    public class PhysicalTherapist
    {
        public int PhysicalTherapistId { get; set; }
        public int FacilityId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string MobileNo { get; set; }
    }

}