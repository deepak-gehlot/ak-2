﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.BussinessLayer;
using NewAPGApplication.Models;

namespace NewAPGApplication.BussinessLayer
{
    public class UserPermission
    {
        static DbConnection obj = new DbConnection();
              
        public static List<UserFormAuthentication> UserPlatForm(string tempemail, string MainMenu, string tempUserLoginType, string tempUserNameId)
        {
            List<UserFormAuthentication> formList = new List<UserFormAuthentication>();
            try
            {                
                int UserTypeID = 0;

                MySqlCommand cmd1 = new MySqlCommand("SELECT IFNULL(U_Id, '') AS U_Id,IFNULL(R_Id, '') AS R_Id,IFNULL(FacilityId, '') AS FacilityId,IFNULL(F_Name, '') AS F_Name,IFNULL(L_Name, '') AS L_Name,IFNULL(EmailId, '') AS EmailId,IsActive FROM userregister WHERE U_Id='" + SecurityManager.Encrypt(tempUserNameId) + "'", obj.con);                
                MySqlDataAdapter da1 = new MySqlDataAdapter(cmd1);
                DataTable dt1 = new DataTable();
                da1.Fill(dt1);
                if (dt1.Rows.Count > 0)
                {
                    UserTypeID = Convert.ToInt32(dt1.Rows[0][1].ToString());
                    if (UserTypeID == 10)
                    {
                        Connection.PatientIsActive = dt1.Rows[0]["IsActive"].ToString();
                    }

                    Connection.UserIsActive = dt1.Rows[0]["IsActive"].ToString();

                    string Query = "select distinct t1.R_id, t3.MenuName, t1.FormShow,t1.ImageUrl,t1.SectionId,t2.SectionName,t1.SelectAll,t1.Update,t1.Delete,t1.View,t1.Save ,t1.Print FROM userauthentication t1 INNER JOIN viewsections t2 ON t1.SectionId=t2.SectionId INNER JOIN mainmenu t3 ON t1.MenuId=t3.MenuId  where t1.R_id='" + UserTypeID + "' AND t3.MenuName='" + MainMenu + "' order by t1.SectionId";
                    //string Query = "SELECT distinct IFNULL(t1.R_id, '') AS R_id,IFNULL(t3.MenuName, '') AS MenuName,IFNULL(t1.FormShow, '') AS FormShow,IFNULL(t1.ImageUrl, '') AS ImageUrl,IFNULL(t1.SectionId, '') AS SectionId,IFNULL(t2.SectionName, '') AS SectionName,t1.SelectAll,t1.Update,t1.Delete,t1.Save ,t1.Print FROM userauthentication t1 INNER JOIN viewsections t2 ON t1.SectionId=t2.SectionId INNER JOIN mainmenu t3 ON t1.MenuId=t3.MenuId  where t1.R_id='" + UserTypeID + "' AND t3.MenuName='" + MainMenu + "' order by t1.SectionId";
                    MySqlCommand cmd = new MySqlCommand(Query, obj.con); 
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            if(dt.Rows[i]["View"].ToString()=="1")
                            {
                            formList.Add(new UserFormAuthentication
                            {
                                FormId = Convert.ToInt32(dt.Rows[i]["SectionId"].ToString()),
                                UserRoleId = Convert.ToInt32(dt.Rows[i]["R_id"].ToString()),
                                FormName = dt.Rows[i]["FormShow"].ToString(),
                                ImageURL = dt.Rows[i]["ImageUrl"].ToString(),
                                DisplayValue = dt.Rows[i]["SectionName"].ToString()
                            });
                          }
                        }
                    }
                    return formList;
                }
            }
            catch (Exception e)
            {
                return formList;
            }
            return formList;
        }

        public static int UserFormAuthenticationDetail(int UserTypeId, int FormId)
        {
            int Allowed = 0;
            MySqlCommand cmd = new MySqlCommand("select IFNULL(AuthenticationId, '') AS AuthenticationId , IFNULL( MenuId, '0') AS MenuId, IFNULL( SectionId, '0') AS SectionId , IFNULL( R_id, '0') AS R_id, IFNULL( FormShow, '0') AS FormShow, IFNULL( ImageUrl, '0') AS ImageUrl,  SelectAll,  view,  `Update`,  `Delete`, `Save` ,  Print from userauthentication where R_id=@R_id and SectionId=@SectionId", obj.con);
            cmd.Parameters.AddWithValue("@R_id", UserTypeId);
            cmd.Parameters.AddWithValue("@SectionId", FormId);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);           
           // cmd.CommandType = CommandType.StoredProcedure;
            DataSet ds = new DataSet();
            da.Fill(ds);

            if (ds.Tables[0].Rows.Count != 0)
            {
                Connection.AllowShow = ds.Tables[0].Rows[0]["view"].ToString();
                Allowed= Convert.ToInt16(ds.Tables[0].Rows[0]["view"].ToString());
                Connection.AllowSave = ds.Tables[0].Rows[0]["Save"].ToString();
                Connection.AllowUpdate=ds.Tables[0].Rows[0]["Update"].ToString();
                Connection.AllowDelete = ds.Tables[0].Rows[0]["Delete"].ToString();
                Connection.AllowPrint = ds.Tables[0].Rows[0]["Print"].ToString();
            }
            else
            {
                Connection.AllowShow = "0";
                Allowed=0;
                Connection.AllowSave = "0";
                Connection.AllowUpdate = "0";
                Connection.AllowDelete = "0";
                Connection.AllowPrint = "0";
            }
            return Allowed;
        }

        public static FacilityList GetFacilityList()
        {
            DbConnection obj = new DbConnection();

            FacilityList model = new FacilityList();
            try
            {
                List<Facility> facilityDetail = new List<Facility>();

                MySqlCommand cmd = new MySqlCommand("select IFNULL(t1.FacilityId, '') AS FacilityId,IFNULL(t1.Location, '') AS Location,IFNULL(t1.Street, '') AS Street,IFNULL(t2.S_Name, '') AS S_Name,IFNULL(t1.Zipcode, '') AS Zipcode,IFNULL(t1.ContactNo, '') AS ContactNo,IFNULL(t1.FaxNo, '') AS FaxNo, IFNULL(U.F_Name, '') AS F_Name, IFNULL(U.L_Name, '') AS L_Name ,IFNULL(t1.EmailId, '') AS EmailId,IFNULL(t3.C_Name, '') AS C_Name from facility t1 LEFT   JOIN  userregister AS U ON t1.ManagerId = U.U_Id  INNER JOIN state t2  on t1.StateId = t2.StateId INNER JOIN city t3 on t1.CityId =t3.CityId ", obj.con);
                          
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {   
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        int No = i + 1;
                        string managerName = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                        string EmailID = SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString());

                        facilityDetail.Add(new Facility
                        {
                            FacilityId = Convert.ToInt32(dt.Rows[i]["FacilityId"].ToString()),
                            LocationName = dt.Rows[i]["Location"].ToString(),
                            Address = dt.Rows[i]["Street"].ToString(),
                            City = dt.Rows[i]["C_Name"].ToString(),
                            State = dt.Rows[i]["S_Name"].ToString(),
                            Zipcode = dt.Rows[i]["Zipcode"].ToString(),
                            PhoneNumber = dt.Rows[i]["ContactNo"].ToString(),
                            FaxNumber = dt.Rows[i]["FaxNo"].ToString(),
                            Manager = managerName,
                            EmailAddress = EmailID,
                            Edit = Connection.AllowUpdate,
                            Delete = Connection.AllowDelete,
                            SerialNo=No
                        });
                    }
                }
                model.facilityList = facilityDetail;
            }
            catch (Exception)
            {
            }
            return model;
        }

        public static FacilityList GetFacilityList_Search(string locationname)
        {

            int No=0;
            var location = locationname.Trim();
            DbConnection obj = new DbConnection();

            FacilityList model = new FacilityList();
            try
            {
                List<Facility> facilityDetail = new List<Facility>();

                MySqlCommand cmd = new MySqlCommand("select IFNULL(t1.FacilityId, '') AS FacilityId,IFNULL(t1.Location, '') AS Location,IFNULL(t1.Street, '') AS Street,IFNULL(t2.S_Name, '') AS S_Name,IFNULL(t1.Zipcode, '') AS Zipcode,IFNULL(t1.ContactNo, '') AS ContactNo,IFNULL(t1.FaxNo, '') AS FaxNo, IFNULL(t1.ManagerId, '') AS ManagerId, IFNULL(U.F_Name, '') AS F_Name, IFNULL(U.L_Name, '') AS L_Name ,IFNULL(t1.EmailId, '') AS EmailId,IFNULL(t3.C_Name, '') AS C_Name from facility t1 LEFT   JOIN  userregister AS U ON t1.ManagerId = U.U_Id  INNER JOIN state t2  on t1.StateId = t2.StateId INNER JOIN city t3 on t1.CityId =t3.CityId ", obj.con);

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        No = No + 1;
                        string LName = SecurityManager.Decrypt(dt.Rows[i]["Location"].ToString());
                        string managerName = SecurityManager.Decrypt(dt.Rows[i]["ManagerId"].ToString());
                        string EmailID = SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString());
                       
                    var LN = dt.Rows[i]["Location"].ToString();
                    var nm = LName.Substring(0, location.Length);

                    if (nm.Length == location.Length)
                     {
                         if (nm.ToLower() == location.ToLower())
                         {

                        if (LName.Contains(location))
                             {

                                 facilityDetail.Add(new Facility
                                {
                                    SerialNo = No,
                                    FacilityId = Convert.ToInt32(dt.Rows[i]["FacilityId"].ToString()),
                                    LocationName = dt.Rows[i]["Location"].ToString(),
                                    Address = dt.Rows[i]["Street"].ToString(),
                                    City = dt.Rows[i]["C_Name"].ToString(),
                                    State = dt.Rows[i]["S_Name"].ToString(),
                                    Zipcode = dt.Rows[i]["Zipcode"].ToString(),
                                    PhoneNumber = dt.Rows[i]["ContactNo"].ToString(),
                                    FaxNumber = dt.Rows[i]["FaxNo"].ToString(),
                                    Manager = managerName,
                                    EmailAddress = EmailID,
                                    Edit = Connection.AllowUpdate,
                                    Delete = Connection.AllowDelete
                                });
                             }
                         }
                     }
                    }
                }
                    
                
                model.facilityList = facilityDetail;
           }
            catch (Exception)
            {
            }
            return model;
        
        }
        
    }
}