﻿using System;
using System.Collections.Generic;
using System.Data;
using MySql.Data.MySqlClient;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using PagedList;
using PagedList.Mvc;
using NewAPGApplication.Models;

using System.ComponentModel;
using System.Configuration;
using NewAPGApplication.Controllers;

namespace APGWebsite.BussinessLayer
{
    public class APGBussinessAdmin
    {
        public static MySqlConnection ConnectionState()
        {
            MySqlConnection con = new MySqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ToString());
            return con;
        }

        #region SaveCSVFile Start       
        public static DataTable ProcessCSV(string fileName)
        {
            StreamReader sr = new StreamReader(fileName);
            DataTable dt = new DataTable();
            DataTable dt1 = new DataTable();
            try
            {
                string Feedback = string.Empty;
                string line = string.Empty;
                DataRow row;
                int i = 0;
                Regex r = new Regex(",(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))");
                while ((line = sr.ReadLine()) != null)
                {
                    string[] data = line.Split(',');
                    if (data.Length > 0)
                    {
                        if (i == 0)
                        {
                            foreach (var item in data)
                            {
                                dt.Columns.Add(new DataColumn());
                            }
                            i++;
                        }
                        row = dt.NewRow();
                        row.ItemArray = data;
                        dt.Rows.Add(row);
                    }
                }
                dt1.Columns.Add("SerialNo", typeof(String));
                for (int k = 0; k <= dt.Columns.Count - 1; k++)
                {
                    dt1.Columns.Add(dt.Rows[0][k].ToString(), typeof(String));
                }
               // MySqlCommand cmd=new MySqlCommand()
                for (int k = 1; k <= dt.Rows.Count - 1; k++)
                {
                    DataRow dr = dt1.NewRow();
                    for (int j = 0; j <= dt.Columns.Count - 1; j++)
                    {
                        dr[j + 1] = dt.Rows[k][j].ToString();
                    }
                    dt1.Rows.Add(dr);
                }
            }
            catch (Exception e)
            {
            }
            sr.Dispose();
            return dt1;
        }

        public static String ProcessBulkCopy(DataTable dt)
        {
            string Feedback = string.Empty;

            MySqlConnection con = APGBussinessAdmin.ConnectionState();
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string FirstName = dt.Rows[i][1].ToString();
                    string LastName = dt.Rows[i][2].ToString();
                    string Address = dt.Rows[i][3].ToString();
                    string City = dt.Rows[i][4].ToString();
                    string State = dt.Rows[i][5].ToString();
                    string ZipCode = dt.Rows[i][6].ToString();
                    string PhoneNo = dt.Rows[i][7].ToString();
                    string EmailAddress = dt.Rows[i][8].ToString();
                    string DateofLastInjection = dt.Rows[i][9].ToString();
                    string LastContactDate = dt.Rows[i][10].ToString();
                    string NextContactDate = dt.Rows[i][11].ToString();
                    string Notes = dt.Rows[i][12].ToString();
                    string LastAPGAppointment = dt.Rows[i][13].ToString();
                    string PatientNumber = dt.Rows[i][14].ToString();
                    string ReferralSource = dt.Rows[i][15].ToString();

                }
            }
                //{
                //    using (var copy = new MySqlBulkCopy(con))
                //    {
                //        con.Open();
                //        copy.DestinationTableName = "tblPatientUploadDetail";
                //        copy.BatchSize = dt.Rows.Count;
                //        try
                //        {
                //            copy.WriteToServer(dt);
                //            Feedback = "Upload complete";
                //        }
                //        catch (Exception ex)
                //        {
                //            Feedback = ex.Message;
                //        }
                //    }
                //}
                return Feedback;
        }
        #endregion

     

    }
}