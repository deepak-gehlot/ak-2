﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Net;
using System.Net.Mail;


namespace NewAPGApplication.BussinessLayer
{
    public class MailHelper
    {
        public string SendEmail(string MailTo, string Subject, String Body)
        {
            try
            {

                //System.Net.Mail.MailMessage message = new System.Net.Mail.MailMessage();

                //var FromAddress = "apps.feedback@widevisiontechnologies.com";
                //var Password = "$CfU$tU9z6Vh";
                //SmtpClient Smtp = new SmtpClient();
                //Smtp.Host = "smtp.gmail.com";
                //Smtp.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
                //Smtp.Credentials = new NetworkCredential(FromAddress.ToString(), Password.ToString());
                //message.From = new MailAddress(FromAddress);
                //message.To.Add(MailTo);
                //message.Subject = Subject;
                //message.Body = Body;
                //message.IsBodyHtml = true;
                //Smtp.Send(message);               

                //MailMessage mail = new MailMessage();
                //SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
                string FromAddress = "apgforgatpass123456@gmail.com";
                string Password = "apg123456";
          
                var smtp = new SmtpClient
                {
                    Host = "smtp.gmail.com",
                    Port = 587,
                    EnableSsl = true,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = false,
                    Credentials = new NetworkCredential(FromAddress, Password),
                    Timeout = 20000
                };
                using (var message = new MailMessage(FromAddress, MailTo)
                {
                    Subject = Subject,
                    Body = Body,
                  //  IsBodyHtml = true,

                })
                {


                    smtp.Send(message);
                }


            }
            catch (Exception e)
            {
                return e.Message;
            }
            return "Mail Sent Successfully";
        }

        public string SendEmailWithCC(string MailTo, string Subject, String Body, string CCValue)
        {
            try
            {
                MailMessage message = new MailMessage();
                var FromAddress = "apgportal@associatedphysicians.com";
                var Password = "P0rt@l@cce555!";
                SmtpClient Smtp = new SmtpClient();
                Smtp.Host = "mail.associatedphysicians.com";
                Smtp.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
                Smtp.Credentials = new NetworkCredential(FromAddress, Password);
                message.From = new MailAddress(FromAddress);
                message.To.Add(MailTo);
                message.CC.Add(CCValue);
                message.Subject = Subject;
                message.Body = Body;
                message.IsBodyHtml = true;
                //Smtp.Send(message); 
                Smtp.Port = 25;
                Smtp.EnableSsl = true;
                Smtp.Timeout = 20000;
                Smtp.Send(message);
                //Smtp.Send(FromAddress, MailTo, Subject, Body);
                return "Mail Sent Successfully";
            }
            catch (Exception e)
            {
                return "Error!";
            }
        }

        public string SendEmailForTest(string MailTo, string Subject, String Body)
        {
            try
            {
                MailMessage message = new MailMessage();
                var FromAddress = "abhishek.kaushal1988@gmail.com";
                var Password = "";
                //var FromAddress = "apg.demo7@gmail.com";
                //var Password = "success@1111";               
                SmtpClient Smtp = new SmtpClient();
                Smtp.Host = "smtp.gmail.com";
                Smtp.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
                Smtp.Credentials = new NetworkCredential(FromAddress, Password);
                message.From = new MailAddress(FromAddress);
                message.To.Add(MailTo);
                message.Subject = Subject;
                message.Body = Body;
                message.IsBodyHtml = true;
                //Smtp.Send(message);  
                Smtp.Port = 587;
                Smtp.EnableSsl = true;
                Smtp.Timeout = 20000;
                Smtp.Send(message);
                //Smtp.Send(FromAddress, MailTo, Subject, Body);
                message = null;
                return "Mail Sent Successfully";
            }
            catch (Exception e)
            {
                return "Error!";
            }
        }
    }
}