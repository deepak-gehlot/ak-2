﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.BussinessLayer;
using NewAPGApplication.Models;

namespace NewAPGApplication.BussinessLayer
{
    public class GraphicReport
    {
        static DbConnection obj = new DbConnection();
        // static double TotalEhthnicity, EthPerc;

        public static int GetFacilityId(string UserNameId)
        {
            int FacilityId = 0;

            MySqlCommand cmd = new MySqlCommand("select  FacilityId from userregister where U_Id='" + SecurityManager.Encrypt(UserNameId) + "'", obj.con);
            MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            asd.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                FacilityId = Convert.ToInt16(dt.Rows[0]["FacilityId"].ToString());
            }
            else
            {
                FacilityId = 0;
            }

            return FacilityId;
        }

        public static double GetGenderWise(string Query)
        {
            double GenderData = 0;

            MySqlCommand cmd = new MySqlCommand(Query, obj.con);
            MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            asd.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                obj.OpenDbConnection();
                GenderData = Convert.ToInt16(cmd.ExecuteScalar());
                obj.CloseDbConnection();
            }
            else
            {
                GenderData = 0;
            }

            return GenderData;
        }

        public static DataSet GetEthnicityWise(string Query)
        {
            double EthnicityData = 0;

            MySqlCommand cmd = new MySqlCommand(Query, obj.con);
            MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            asd.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                obj.OpenDbConnection();
                EthnicityData = Convert.ToInt16(cmd.ExecuteScalar());
                obj.CloseDbConnection();
            }
            else
            {
                EthnicityData = 0;
            }

            return ds;
        }

        public static double GetAgeWise(string Query)
        {
            double AgeData = 0;

            MySqlCommand cmd = new MySqlCommand(Query, obj.con);
            MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            asd.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                obj.OpenDbConnection();
                AgeData = Convert.ToInt16(cmd.ExecuteScalar());
                obj.CloseDbConnection();
            }
            else
            {
                AgeData = 0;
            }

            return AgeData;
        }

        public static AgeGraphReportOne AgeGraphicReporting(int FacilityId)
        {
            double TotalEhthnicity, EthPerc;
            int Eid = 0,Active=1;
            AgeGraphReportOne model = new AgeGraphReportOne();
            try
            {
                // ------------- Gender Report 
                string MaleQuery = "SELECT COUNT( Gender) FROM userregister WHERE R_Id ='" + 10 + "' AND Gender ='" + "Male" + "' AND FacilityId ='" + FacilityId + "' AND IsActive ='" + Active + "'";
                //string MaleQuery = "SELECT count(Gender) FROM userregister where R_Id='" + "10" + "' and Gender='" + "Male" + "'and FacilityId='" + FacilityId + "' and IsActive='" + Active + "'";
                //string FeMaleQuery = "SELECT count(Gender) FROM userregister where R_Id='" + "10" + "' and Gender='" + "FeMale" + "'and FacilityId='" + FacilityId + "' and IsActive='" + Active + "'";
                string FeMaleQuery = "SELECT COUNT( Gender) FROM userregister WHERE R_Id ='" + 10 + "' AND Gender ='" + "Female" + "' AND FacilityId ='" + FacilityId + "' AND IsActive ='" + Active + "'";
              
                double Male = GetGenderWise(MaleQuery);
                double FeMale = GetGenderWise(FeMaleQuery);
                double TotalGander = Male + FeMale;
                if (TotalGander != 0.0)
                {
                    model.TotalPatient = Convert.ToInt16(TotalGander);
                    model.TotalMale =  Math.Round((Male * 100) / TotalGander,2);
                    model.TotalFemale =  Math.Round((FeMale * 100) / TotalGander,2);
                }
                else
                {
                    model.TotalPatient = 0;
                    model.TotalMale = 0;
                    model.TotalFemale = 0;
                }
                // ------------- Ethnicity Report

                string QueryCaucasian = "SELECT count(t1.EthnicityId),t1.EthnicityId,t2.Ethnicity_Name FROM userregister t1 INNER JOIN ethnicity t2 ON t2.EthnicityId = t1.EthnicityId where t1.EthnicityId='" + "1" + "' and t1.FacilityId='" + FacilityId + "'and t1.R_Id='" + "10" + "' and t1.IsActive='" + Active + "'";
                string QueryAfricanAmerican = "SELECT count(t1.EthnicityId),t1.EthnicityId,t2.Ethnicity_Name FROM userregister t1 INNER JOIN ethnicity t2 ON t2.EthnicityId = t1.EthnicityId where t1.EthnicityId='" + "2" + "' and t1.FacilityId='" + FacilityId + "'and t1.R_Id='" + "10" + "' and t1.IsActive='" + Active + "'";
                string QueryAsian = "SELECT count(t1.EthnicityId),t1.EthnicityId,t2.Ethnicity_Name FROM userregister t1 INNER JOIN ethnicity t2 ON t2.EthnicityId = t1.EthnicityId where t1.EthnicityId='" + "3" + "' and t1.FacilityId='" + FacilityId + "' and t1.R_Id='" + "10" + "' and t1.IsActive='" + Active + "'";
                string QueryAsianIndian = "SELECT count(t1.EthnicityId),t1.EthnicityId,t2.Ethnicity_Name FROM userregister t1 INNER JOIN ethnicity t2 ON t2.EthnicityId = t1.EthnicityId where t1.EthnicityId='" + "4" + "' and t1.FacilityId='" + FacilityId + "' and t1.R_Id='" + "10" + "' and t1.IsActive='" + Active + "'";
                string QueryNativeAmerican = "SELECT count(t1.EthnicityId),t1.EthnicityId,t2.Ethnicity_Name FROM userregister t1 INNER JOIN ethnicity t2 ON t2.EthnicityId = t1.EthnicityId where t1.EthnicityId='" + "5" + "' and t1.FacilityId='" + FacilityId + "' and t1.R_Id='" + "10" + "' and t1.IsActive='" + Active + "' ";
                string QueryHispenicLatino = "SELECT count(t1.EthnicityId),t1.EthnicityId,t2.Ethnicity_Name FROM userregister t1 INNER JOIN ethnicity t2 ON t2.EthnicityId = t1.EthnicityId where t1.EthnicityId='" + "6" + "' and t1.FacilityId='" + FacilityId + "' and t1.R_Id='" + "10" + "' and t1.IsActive='" + Active + "'";
                string QueryHawaiianPacific = "SELECT count(t1.EthnicityId),t1.EthnicityId,t2.Ethnicity_Name FROM userregister t1 INNER JOIN ethnicity t2 ON t2.EthnicityId = t1.EthnicityId where t1.EthnicityId='" + "7" + "' and t1.FacilityId='" + FacilityId + "' and t1.R_Id='" + "10" + "' and t1.IsActive='" + Active + "'";
                string QueryOther = "SELECT count(t1.EthnicityId),t1.EthnicityId,t2.Ethnicity_Name FROM userregister t1 INNER JOIN ethnicity t2 ON t2.EthnicityId = t1.EthnicityId where t1.EthnicityId='" + "8" + "' and t1.FacilityId='" + FacilityId + "' and t1.R_Id='" + "10" + "' and t1.IsActive='" + Active + "'";

                string Query1 = "SELECT count(EthnicityId) FROM userregister where R_Id='" + "10" + "' and FacilityId='" + FacilityId + "'and IsActive='" + Active + "'";
                TotalEhthnicity = GetGenderWise(Query1);

                DataSet Ds_Caucasian = GetEthnicityWise(QueryCaucasian);
                DataSet Ds_AfricanAmerican = GetEthnicityWise(QueryAfricanAmerican);
                DataSet Ds_Asian = GetEthnicityWise(QueryAsian);
                DataSet Ds_AsianIndian = GetEthnicityWise(QueryAsianIndian);
                DataSet Ds_NativeAmerican = GetEthnicityWise(QueryNativeAmerican);
                DataSet Ds_HispenicLatino = GetEthnicityWise(QueryHispenicLatino);
                DataSet Ds_HawaiianPacific = GetEthnicityWise(QueryHawaiianPacific);
                DataSet Ds_Other = GetEthnicityWise(QueryOther);

                DataSet ds = new DataSet();
                if (Ds_Caucasian.Tables[0].Rows.Count != 0)
                {
                    ds.Merge(Ds_Caucasian);
                } 

                if (Ds_AfricanAmerican.Tables[0].Rows.Count != 0)
                {
                    ds.Merge(Ds_AfricanAmerican);
                }

                if (Ds_Asian.Tables[0].Rows.Count != 0)
                {
                    ds.Merge(Ds_Asian);
                }

                if (Ds_AsianIndian.Tables[0].Rows.Count != 0)
                {
                    ds.Merge(Ds_AsianIndian);
                }

                if (Ds_NativeAmerican.Tables[0].Rows.Count != 0)
                {
                    ds.Merge(Ds_NativeAmerican);
                }

                if (Ds_HispenicLatino.Tables[0].Rows.Count != 0)
                {
                    ds.Merge(Ds_HispenicLatino);
                }

                if (Ds_HawaiianPacific.Tables[0].Rows.Count != 0)
                {
                    ds.Merge(Ds_HawaiianPacific);
                }

                if (Ds_Other.Tables[0].Rows.Count != 0)
                {
                    ds.Merge(Ds_Other);
                }

                //------------- Age Wise Reports

                DateTime Age24 = DateTime.Parse(DateTime.Now.AddYears(-24).ToShortDateString());
                DateTime Age44 = DateTime.Parse(DateTime.Now.AddYears(-44).ToShortDateString());

                DateTime Age45 = DateTime.Parse(DateTime.Now.AddYears(-45).ToShortDateString());
                DateTime Age65 = DateTime.Parse(DateTime.Now.AddYears(-65).ToShortDateString());

                DateTime Age66 = DateTime.Parse(DateTime.Now.AddYears(-66).ToShortDateString());
                DateTime Age86 = DateTime.Parse(DateTime.Now.AddYears(-86).ToShortDateString());

                DateTime Age87 = DateTime.Parse(DateTime.Now.AddYears(-87).ToShortDateString());
                DateTime Age99 = DateTime.Parse(DateTime.Now.AddYears(-99).ToShortDateString());

                //string Query24_44 = "select count(U_Id) from userregister where  DOB between '" + Age44.ToString("yyyy-MM-dd") + "' and '" + Age24.ToString("yyyy-MM-dd") + "' and FacilityId='" + FacilityId + "' and R_Id='" + "10" + "' and IsActive='" + Active + "'";
                //string Query45_65 = "select count(U_Id) from userregister where  DOB between '" + Age65.ToString("yyyy-MM-dd") + "' and '" + Age45.ToString("yyyy-MM-dd") + "'  and FacilityId='" + FacilityId + "' and R_Id='" + "10" + "' and IsActive='" + Active + "'";
                //string Query66_86 = "select count(U_Id) from userregister where  DOB between '" + Age86.ToString("yyyy-MM-dd") + "' and '" + Age66.ToString("yyyy-MM-dd") + "'  and FacilityId='" + FacilityId + "' and R_Id='" + "10" + "' and IsActive='" + Active + "'";
                //string Query87_99 = "select count(U_Id) from userregister where  DOB between '" + Age99.ToString("yyyy-MM-dd") + "' and '" + Age87.ToString("yyyy-MM-dd") + "'  and FacilityId='" + FacilityId + "' and R_Id='" + "10" + "' and IsActive='" + Active + "'";


                string Query24_44 = "select count(U_Id) from userregister where  YEAR(DOB) >= YEAR('" + Age44.ToString("yyyy-MM-dd") + "') and YEAR(DOB) <=YEAR('" + Age24.ToString("yyyy-MM-dd") + "') and FacilityId='" + FacilityId + "' and R_Id='" + "10" + "' and IsActive='" + Active + "'";
                string Query45_65 = "select count(U_Id) from userregister where  YEAR(DOB) >= YEAR('" + Age65.ToString("yyyy-MM-dd") + "') and YEAR(DOB) <=YEAR('" + Age45.ToString("yyyy-MM-dd") + "') and FacilityId='" + FacilityId + "' and R_Id='" + "10" + "' and IsActive='" + Active + "'";
                string Query66_86 = "select count(U_Id) from userregister where  YEAR(DOB) >= YEAR('" + Age86.ToString("yyyy-MM-dd") + "') and YEAR(DOB) <=YEAR('" + Age66.ToString("yyyy-MM-dd") + "') and FacilityId='" + FacilityId + "' and R_Id='" + "10" + "' and IsActive='" + Active + "'";
                string Query87_99 = "select count(U_Id) from userregister where  YEAR(DOB) >= YEAR('" + Age99.ToString("yyyy-MM-dd") + "') and YEAR(DOB) <=YEAR('" + Age87.ToString("yyyy-MM-dd") + "') and FacilityId='" + FacilityId + "' and R_Id='" + "10" + "' and IsActive='" + Active + "'";

                double Age_24 = GetAgeWise(Query24_44);
                double Age_45 = GetAgeWise(Query45_65);
                double Age_66 = GetAgeWise(Query66_86);
                double Age_87 = GetAgeWise(Query87_99);

                double totalPt = Age_24 + Age_45 + Age_66 + Age_87;

                if (totalPt != 0.0)
                {
                    model.Age24 = Math.Round((Age_24 * 100) / totalPt, 2);
                    model.Age45 = Math.Round((Age_45 * 100) / totalPt, 2);
                    model.Age66 = Math.Round((Age_66 * 100) / totalPt, 2);
                    model.Age87 = Math.Round((Age_87 * 100) / totalPt, 2);
                }
                else
                {
                    model.Age24 = 0;
                    model.Age45 = 0;
                    model.Age66 = 0;
                    model.Age87 = 0;
                }
                List<Ethnicity> ethnicity = new List<Ethnicity>();

                if (ds.Tables[0].Rows.Count != 0)
                {
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        if (TotalEhthnicity != 0.0)
                        {
                            EthPerc = Convert.ToDouble(ds.Tables[0].Rows[i][0].ToString()) * 100 / TotalEhthnicity;
                        }
                        else
                        {
                            EthPerc = 0;
                        }
                        Eid = Convert.ToInt32(ds.Tables[0].Rows[i][1].ToString() != "" ? Convert.ToInt32(ds.Tables[0].Rows[i][1].ToString()) : 0);

                        ethnicity.Add(new Ethnicity
                        {
                            EthnicityId = Eid,
                            EthnicityName = ds.Tables[0].Rows[i][2].ToString(),
                            EthnicityPercentage = Math.Round(EthPerc, 2)
                        });
                    }
                }

                model.Ethnicities = ethnicity;
                return model;
            }
            catch (Exception e)
            {
                return model;
            }
        }

        public static ChartData ChartReportData(int FId)
        {
            ChartData model = new ChartData();
            try
            {
                int Pno = GetNoOfPatient(FId);

               // int Bothkneewomac = GetNoOfWomacBothKnee(FId);

                int kneewomac = GetNoOfWomacSingleKnee(FId);

                model.TotalWomacTest = Pno;

                //int w2 = Bothkneewomac / 6;
                //int w1 = kneewomac / 3;


                model.CompletedWomacTest = kneewomac;

                model.NotCompletesd = model.TotalWomacTest - model.CompletedWomacTest;

                return model;
            }
            catch (Exception e)
            {
                return model;
            }
        }

        public static int GetNoOfPatient(int FId)
        {

            
            int Count = 0;
            MySqlCommand cmd = new MySqlCommand("SELECT distinct (t1.U_Id)  FROM userregister t1 INNER JOIN  womac_test t2 ON t2.PatientId = t1.U_Id where t1.IsActive = '" + 1 + "' and t1.R_Id ='"+10+"'", obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if(dt.Rows.Count!=0)
            {
                Count = dt.Rows.Count;
            }

            return Count;
        }

        public static int GetNoOfWomacBothKnee(int FId)
        {
            int Count = 0;
            string knee = "Left Knee,Right Knee";
            MySqlCommand cmd = new MySqlCommand("SELECT count(t2.WOMAC_Name) FROM  userregister t1 INNER JOIN womac_test t2 ON t2.PatientId = t1.U_Id where t1.IsActive='" + 1 + "' and t2.Knee='" + knee + "'", obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count != 0)
            {
                Count = Convert.ToInt32(dt.Rows[0][0].ToString());
            }

            return Count;
        }

        public static int GetNoOfWomacKnee(int FId)
        {
            int Count = 0;
            string knee = "Left Knee,Right Knee";
            MySqlCommand cmd = new MySqlCommand("SELECT count(t2.WOMAC_Name) FROM  userregister t1 INNER JOIN womac_test t2 ON t2.PatientId = t1.U_Id where t1.IsActive='" + 1 + "' and t2.Knee='" + knee + "'", obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count != 0)
            {
                Count = Convert.ToInt32(dt.Rows[0][0].ToString());
            }

            return Count;
        }

        public static int GetNoOfWomacSingleKnee(int FId)
        {
            int Count = 0;
            string knee = "Left Knee,Right Knee";
            MySqlCommand cmd = new MySqlCommand("SELECT distinct t1.U_Id  FROM userregister t1 INNER JOIN  womac_test t2 ON t2.PatientId = t1.U_Id where t1.IsActive = '"+1+"' and t1.R_Id ='"+10+"' and (t2.WOMAC_Name='3' and t2.Complete= 'True')", obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count != 0)
            {
                //Count = Convert.ToInt32(dt.Rows[0][0].ToString());
                Count = dt.Rows.Count;
            }

            return Count;
        }
    }
}