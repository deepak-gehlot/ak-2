﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.BussinessLayer;
using NewAPGApplication.Models;

namespace NewAPGApplication.BussinessLayer
{
    public class GetFilterRecord
    {
        static DbConnection obj = new DbConnection();

        public static string ErrorMessage = null;

        public static PatientList GetPatientList(int FacilitiId,string FName)       // --------------------------------- Get Patient List
        {

            int No = 0;
            string fname = FName.Trim().ToLower();
           
            DbConnection obj = new DbConnection();

            PatientList model = new PatientList();
            List<PatientDetail> patientDetail = new List<PatientDetail>();
            try
            {
              //  MySqlDataAdapter das = new MySqlDataAdapter("select t1.U_Id,t1.F_Name,t1.L_Name,t1.EmailId,t1.MobileNo from userregister t1 INNER JOIN patient_otherinfo t2 on t1.U_Id=t2.PatientId  where t1.FacilityId='" + FacilitiId + "' and t1.IsActive='" + 1 + "' and t1.R_Id='" + 10 + "'", obj.con);
                MySqlDataAdapter das = new MySqlDataAdapter("select IFNULL(t1.U_Id, '') AS U_Id,t1.FacilityId, IFNULL(t1.F_Name, '') AS F_Name, IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t1.EmailId, '') AS EmailId, IFNULL(t1.MobileNo, '') AS MobileNo,t1.IsActive,t1.Inactive, t1.Is_Reactive,IFNULL(t2.IsDeactive, '0') AS IsDeactive,IFNULL(t2.Info_Id, '0') AS  Info_Id , IFNULL(t1.CreatedDate, '') AS CreatedDate from userregister t1  LEFT JOIN patient_otherinfo t2 on t1.U_Id=t2.PatientId where t1.Is_Reactive=1 and t1.R_Id= '10' Union select  IFNULL(t1.U_Id, '') AS U_Id,t1.FacilityId, IFNULL(t1.F_Name, '') AS F_Name, IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t1.EmailId, '') AS EmailId, IFNULL(t1.MobileNo, '') AS MobileNo,t1.IsActive,t1.Inactive,t1.Is_Reactive,IFNULL(t2.IsDeactive, '0') AS IsDeactive, IFNULL(t2.Info_Id, '0') AS  Info_Id ,  IFNULL(t1.CreatedDate, '') AS CreatedDate  from userregister t1  LEFT JOIN patient_otherinfo t2 on t1.U_Id=t2.PatientId  where t2.IsDeactive =1  and t1.R_Id= '10'  UNION select  IFNULL(t1.U_Id, '') AS U_Id,t1.FacilityId, IFNULL(t1.F_Name, '') AS F_Name, IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t1.EmailId, '') AS EmailId, IFNULL(t1.MobileNo, '') AS MobileNo,t1.IsActive,t1.Inactive,t1.Is_Reactive,IFNULL(t2.IsDeactive, '0') AS IsDeactive, IFNULL(t2.Info_Id, '0') AS  Info_Id , IFNULL(t1.CreatedDate, '') AS CreatedDate from userregister t1  LEFT JOIN patient_otherinfo t2 on t1.U_Id=t2.PatientId  where t1.IsActive=1 and t1.R_Id= '10'  Order by CreatedDate Desc ", obj.con);
                DataTable dts = new DataTable();
                das.Fill(dts);
                if (dts.Rows.Count > 0)
                {
                    for (int i = 0; i < dts.Rows.Count; i++)
                    {
                        No = No + 1;

                        string PN = SecurityManager.Decrypt(dts.Rows[i]["F_Name"].ToString());
                        string LN = SecurityManager.Decrypt(dts.Rows[i]["L_Name"].ToString());
                        //if ((PN.Length < fname.Length) || (LN.Length < fname.Length))
                        //{

                        //}
                        //else
                        //{
                        string nm = null, ln = null;
                        if (PN.Length >= fname.Length)
                        {
                            nm = PN.Substring(0, fname.Length);
                        }
                        else
                        {
                            nm = PN;
                        }
                        if (LN.Length >= fname.Length)
                        {
                            ln = LN.Substring(0, fname.Length);
                        }
                        else
                        {
                            ln = LN;
                        }
                        if ((nm != null) || (ln != null))
                        {
                            var lnm = ln.ToLower();
                            var nmm = nm.ToLower();
                          
                            if ((nmm.Length == fname.Length) || (lnm.Length == fname.Length))
                                {
                                    //if (fname == nmm)
                                    //{
                                        // No++;
                                        string strr = "";
                                        int strReactive = Convert.ToInt32(dts.Rows[i]["Is_Reactive"].ToString());
                                        int strInActive = Convert.ToInt16(dts.Rows[i]["Inactive"].ToString());
                                        int strDeactive = Convert.ToInt32(dts.Rows[i]["IsDeactive"].ToString());
                                        int strActiv = Convert.ToInt32(dts.Rows[i]["IsActive"].ToString());
                                        if (strInActive == 1 && strActiv == 1)
                                        {
                                            strr = "Inactive";
                                        }
                                        else if (strInActive == 0 && strDeactive == 1 && strActiv == 0)
                                        {
                                            strr = "Deactivated";
                                        }
                                        else if ((strInActive == 0 && strDeactive == 0 && strActiv == 1))
                                        {
                                            strr = "Active";
                                        }
                                        else
                                        { }


                                        if (nmm.Contains(fname) || lnm.Contains(fname))
                                        {
                                            patientDetail.Add(new PatientDetail
                                            {

                                                //PatientId = SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                                SrNo = No,
                                                PatientId =SecurityManager.Decrypt(dts.Rows[i]["U_Id"].ToString()),
                                                Email = SecurityManager.Decrypt(dts.Rows[i]["EmailId"].ToString() != "" ? SecurityManager.Decrypt(dts.Rows[i]["EmailId"].ToString()) : "NA"),
                                                Patient = PN+" "+LN,
                                                Pid = SecurityManager.Decrypt(dts.Rows[i]["U_Id"].ToString()),
                                                status = strr.ToString(),
                                                PrimaryContactNo = SecurityManager.Decrypt(dts.Rows[i]["MobileNo"].ToString()),
                                                Edit = Connection.AllowUpdate,
                                                Delete = Connection.AllowDelete,

                                            });
                                        }
                                    }
                               // }
                            
                        }
                    }
                    model.patientList = patientDetail;
                    
                   
                   // model.patientList["FirstName"].ToString();


                }

             
               
            }
            catch (Exception e)
            {


            }
            return model;
        }

        public static alertlist GetPatientAllAlertList(int facilityid, string name)
        {
            List<PatientAlertList> patientalertdetail = new List<PatientAlertList>();
            alertlist model = new alertlist();
            string Name=name.ToLower().Trim();
            string query = "SELECT  IFNULL(U_Id, '') AS U_Id,IFNULL(F_Name, '') AS F_Name,IFNULL(L_Name, '') AS L_Name,IFNULL(EmailId, 'NA') AS EmailId,IFNULL(MobileNo, '') AS MobileNo, CreatedDate,IsActive,Inactive  FROM userregister where R_Id=10 and Inactive=1";
            MySqlCommand cmd = new MySqlCommand(query, obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString());
                    string LN = SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                    string Emailid = SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString()).Trim();
                    if (Emailid == "")
                    {
                        Emailid = "NA";
                    }
                    //if ((PN.Length < Name.Length) || (LN.Length < Name.Length))
                    //{

                    //}
                    //else
                    //{

                    string nm = null, ln = null;
                    if (PN.Length >= Name.Length)
                    {
                        nm = PN.Substring(0, Name.Length);
                    }
                    else
                    {
                        nm = PN;
                    }
                    if (LN.Length >= Name.Length)
                    {
                        ln = LN.Substring(0, Name.Length);
                    }
                    else
                    {
                        ln = LN;
                    }
                    if ((nm != null) || (ln != null))
                    { 

                        var nmm = nm.ToLower();
                        var lnm = ln.ToLower();
                        if ((nmm.Length == Name.Length) || (lnm.Length == Name.Length))
                        {
                            int srno = i + 1;
                            DateTime createddate = Convert.ToDateTime(dt.Rows[i]["CreatedDate"].ToString());
                            string firstalerts = createddate.AddDays(45).ToString("dd-MM-yyyy");
                            string secondalerts = createddate.AddDays(90).ToString("dd-MM-yyyy");
                            string thirdalerts = createddate.AddDays(120).ToString("dd-MM-yyyy");
                            int status = Convert.ToInt16(dt.Rows[i]["Inactive"]);
                            string statuss = "";
                            if (status == 0)
                            {
                                statuss = "Deactive";
                            }
                            else if (status == 1)
                            {
                                statuss = "Inactive";
                            }
                         //   string patientname = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                            if (nmm.Contains(Name) || lnm.Contains(Name))
                            {
                                patientalertdetail.Add(new PatientAlertList
                                {
                                    SrNo = srno,
                                    FirstName = PN + " " + LN,
                                    Email = Emailid,
                                    PrimaryContactNo = dt.Rows[i]["MobileNo"].ToString(),
                                    firstalert = firstalerts,
                                    PatientId = SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                    secondalert = secondalerts,
                                    thirdalert = thirdalerts,
                                    status = statuss
                                });
                            }
                        }
                    }
                }
                model.patientalertlistt = patientalertdetail;
            }
            return model;
        }

        public static alertlist GetPatientfirstAlertList(string name,int alertid)
        {
            List<PatientAlertList> patientalertdetail = new List<PatientAlertList>();
            alertlist model = new alertlist();
            string Name=name.ToLower().Trim();
            try
            {
                string query = "SELECT  IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t1.EmailId, 'NA') AS EmailId,IFNULL(t1.MobileNo, '') AS MobileNo,t1.CreatedDate,t1.InactiveDate,t1.IsActive,t1.Inactive  FROM  userregister as t1 inner join alert_complete_tbl as t2 on t1.U_Id=t2.patient_id where t1.R_Id=10 and t1.Inactive=1 and t2. 	alert_day_id='" + alertid + "' and t2.status!='" + "True" + "' and t2.IsDeleted!='" + "True" + "'";
                MySqlCommand cmd = new MySqlCommand(query, obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                         string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString());
                         string LN = SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                         string Emailid = SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString()).Trim();
                        
                        if (Emailid == "")
                         {
                             Emailid = "NA";
                         }
                        //if ((PN.Length < Name.Length) || (LN.Length < Name.Length))
                        //{

                        //}
                        //else
                        //{

                        string nm = null, lnm = null;
                        if (PN.Length >= Name.Length)
                        {
                            nm = PN.Substring(0, Name.Length);
                        }
                        else
                        {
                            nm = PN;
                        }
                        if (LN.Length >= Name.Length)
                        {
                            lnm = LN.Substring(0, Name.Length);
                        }
                        else
                        {
                            lnm = LN;
                        }
                        if ((nm != null) || (lnm != null))
                        { 

                              var nmm = nm.ToLower();
                             var lnmm = lnm.ToLower();
                             if ((nmm.Length == Name.Length) || (lnmm.Length == Name.Length))
                             {
                               int srno = i + 1;
                               string patientid = dt.Rows[i]["U_Id"].ToString();
                               DateTime createddate = Convert.ToDateTime(dt.Rows[i]["InactiveDate"].ToString());
                               string firstalerts = null;
                               // firstalerts = GetPatientInformation.firstalertstatus(patientid,1);
                                       if (firstalerts == null)
                                       {
                                            firstalerts = createddate.AddDays(45).ToString("MM/dd/yyyy");
                                       }
                                       int status = Convert.ToInt16(dt.Rows[i]["Inactive"]);
                                       string statuss = "";
                                       if (status == 0)
                                       {
                                          statuss = "Deactive";
                                       }
                                       else if (status == 1)
                                       {
                                         statuss = "Inactive";
                                       }
                                        string patientname = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                                        if (nmm.Contains(Name) || lnmm.Contains(Name))
                                         {
                                                patientalertdetail.Add(new PatientAlertList
                                                {
                                                SrNo = srno,
                                                FirstName = patientname,
                                                Email = Emailid,
                                                PrimaryContactNo = dt.Rows[i]["MobileNo"].ToString(),
                                                firstalert = firstalerts,
                                                PatientId = SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                                status = statuss
                                               });
                                         }
                              }
                             model.patientalertlistt = patientalertdetail;
                         }
                    }
               }
            }
            catch
            {

            }
            return model;
        }


        public static PatientList GetPatientListForActive(string Name, int FormId, int tempFacilityId, int LUTypeId)
        {
            int No = 0;
            PatientList model = new PatientList();

            try
            {

                if (tempFacilityId != 0)
                {
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    if (Allowed == 1)
                    {
                        List<PatientDetail> patientDetail = new List<PatientDetail>();

                       // MySqlCommand cmd = new MySqlCommand("SELECT t1.U_Id,t1.EmailId,t1.F_Name,t1.L_Name,t1.MobileNo FROM userregister t1 INNER JOIN patient_otherinfo t2 ON t2.PatientId = t1.U_Id  where t1.F_Name ='" + Name + "' and t1.FacilityId='" + tempFacilityId + "' and t1.R_Id='" + 10 + "' and t1.IsActive='" + 0 + "' and t2.IsDeactive='" + 0 + "' and t2.IsDeleted='" + 0 + "'", obj.con);
                        MySqlCommand cmd = new MySqlCommand("SELECT IFNULL(t1.U_Id, '') AS U_Id, IFNULL(t1.EmailId, '') AS EmailId, IFNULL(t1.F_Name, '') AS F_Name, IFNULL(t1.L_Name, '') AS L_Name , IFNULL(t1.MobileNo, '') AS MobileNo FROM userregister t1 INNER JOIN patient_otherinfo t2 ON t2.PatientId = t1.U_Id  where t1.R_Id='" + 10 + "' and t1.IsActive='" + 0 + "' and t2.IsDeactive='" + 0 + "' and t1.Is_Reactive='" + 0 + "'", obj.con);
                        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                        string FName = Name.Trim();
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                No = No + 1;
                                string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                                if (PN.Length < FName.Length)
                                {

                                }
                                else
                                {
                                    var nm = PN.Substring(0, FName.Length);
                                    if (FName.Length == nm.Length)
                                    {
                                        if (FName.ToLower() == nm.ToLower())
                                        {
                                            patientDetail.Add(new PatientDetail
                                            {
                                                SrNo = No,
                                                PatientId =SecurityManager.Decrypt( dt.Rows[i]["U_Id"].ToString()),
                                                Email = SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString()),
                                                FirstName = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()),
                                                LastName = SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString()),
                                                PrimaryContactNo = dt.Rows[i]["MobileNo"].ToString(),
                                                Edit = Connection.AllowUpdate,
                                                Delete = Connection.AllowDelete
                                            });
                                        }
                                    }
                                }
                            }
                        }
                        model.patientList = patientDetail;
                    }
                }
            }
            catch (Exception e)
            {
            }
            return model;
        }

        public static PatientList GetDeactivePatientList(string Name, int FacilityID)       // ---------------  DeActive PAtient LIst 
        {
            int No = 0;
            DbConnection obj = new DbConnection();
            PatientList model = new PatientList();
            var fname = Name.ToLower().Trim();
           //  string strname = SecurityManager.Encrypt(Name);
            try
            {
                Connection.FacilityId = FacilityID;
                if (Connection.FacilityId != 0)
                {
                    List<PatientDetail> patientDetail = new List<PatientDetail>();
                    string query = "select distinct  IFNULL(t1.U_Id, '') AS U_Id, IFNULL(t1.EmailId, '') AS EmailId, IFNULL(t1.F_Name, '') AS F_Name, IFNULL(t1.L_Name, '') AS L_Name, IFNULL(t2.NickName, '') AS NickName, IFNULL(t1.MobileNo, '') AS MobileNo from userregister t1 INNER JOIN patient_otherinfo t2 on t1.U_Id=t2.PatientId  where  t2.IsDeactive='" + 1 + "' and t1.R_Id='" + 10 + "' order by t2.Info_Id desc";
                    MySqlCommand cmd = new MySqlCommand(query, obj.con);
                    //MySqlCommand cmd = new MySqlCommand("SELECT t1.U_Id,t1.EmailId,t1.F_Name,t1.L_Name,t2.NickName,t1.MobileNo FROM userregister t1 INNER JOIN patient_otherinfo t2 ON t2.PatientId = t1.U_Id  where t1.FacilityId='" + FacilityID + "' and t1.R_Id='" + 10 + "' and t2.IsDeactive='" + 1 + "' and t1.IsActive='" + 0 + "' and t1.F_Name='" + Name + "' order by t2.Info_Id", obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            No = No + 1;
                            string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString());
                            string LN = SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                            //if ((PN.Length < fname.Length) || (LN.Length < fname.Length))
                            //{

                            //}
                            //else
                            //{

                            string nm = null, lnm = null;
                            if (PN.Length >= fname.Length)
                            {
                                nm = PN.Substring(0, fname.Length);
                            }
                            else
                            {
                                nm = PN;
                            }
                            if (LN.Length >= fname.Length)
                            {
                                lnm = LN.Substring(0, fname.Length);
                            }
                            else
                            {
                                lnm = LN;
                            }
                            if ((nm != null) || (lnm != null))
                            { 
                                var nmm = nm.ToLower();
                                var lnmm = lnm.ToLower();
                                if ((nmm.Length == fname.Length) || (lnmm.Length == fname.Length))
                                {
                                    if (nmm.Contains(fname) || lnmm.Contains(fname))
                                    {
                                        patientDetail.Add(new PatientDetail
                                        {
                                            SrNo = No,
                                            PatientId =SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                            Email = dt.Rows[i]["EmailId"].ToString() != "" ? SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString()) : "NA",
                                            FirstName = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString()),
                                            //FirstName= SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()),
                                            NickName = SecurityManager.Decrypt(dt.Rows[i]["NickName"].ToString()),
                                            PrimaryContactNo = dt.Rows[i]["MobileNo"].ToString(),
                                            Edit = Connection.AllowUpdate,
                                            Delete = Connection.AllowDelete
                                        });
                                    }
                                }
                            }
                        }
                    } 
                    model.patientList = patientDetail;
                }
            }
            catch (Exception e)
            {
            }
            return model;
        }


        public static FacilityLogList GetFacilityList(string facilityid)
        {
            FacilityLogList model = new FacilityLogList();
            try
            {
                List<FacilityLogDetails> facilityloglist = new List<FacilityLogDetails>();
                List<FacilityOperationNameList> facilitylist = new List<FacilityOperationNameList>();
                List<FacilityLogDetails1> facilityloglist1 = new List<FacilityLogDetails1>();
                //  int LoggedFacilityId = Session["LoggedInFacilityId"].ToString() != "0" ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;

                if (facilityid != "0")
                {
                    string query = "SELECT IFNULL(t1.U_Id, '') AS U_Id ,IFNULL(t1.R_Id, '') AS R_Id ,IFNULL(t1.FacilityId, '') AS FacilityId ,IFNULL(t1.F_Name, '') AS F_Name ,IFNULL(t1.L_Name, '') AS L_Name ,IFNULL(t1.EmailId, '') AS EmailId ,IFNULL(t2.R_name, '') AS R_name  FROM userregister as t1 inner join userrole as t2 on t1.R_Id=t2.R_id where FacilityId='" + facilityid + "' and t1.R_Id !='" + 10 + "'";
                    MySqlCommand cmd = new MySqlCommand(query, obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            int srno = i + 1;
                            string name = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                            string email = SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString());
                            string usertype = SecurityManager.Decrypt(dt.Rows[i]["R_name"].ToString());

                            facilityloglist.Add(new FacilityLogDetails
                            {
                                SrNo = srno,
                                UserName = name,
                                Email = email,
                                UserType = usertype,
                                FacilityId = dt.Rows[i]["FacilityId"].ToString()
                            });
                        }
                        model.facilityloglist = facilityloglist;
                    }

                    string query1 = "SELECT  IFNULL(t1.`U_Id`, '') AS U_Id ,IFNULL(t1.`FacilityId`, '') AS FacilityId ,IFNULL(t1.`EmailId`, '') AS EmailId ,IFNULL(t2.OperationName, '') AS OperationName ,IFNULL(t2.LoginOn, '') AS LoginOn ,IFNULL(t2.LogTime, '') AS LogTime ,IFNULL(t2.System_IP, '') AS System_IP ,IFNULL(t2.ModifiedRecord, '') AS ModifiedRecord ,IFNULL(t2.Detail, '') AS Detail FROM `userregister` as t1 inner join userlogdetails as t2 on t1.`U_Id`=t2.U_Id where t1.`FacilityId`='" + facilityid + "'";

                    MySqlCommand cmd1 = new MySqlCommand(query1, obj.con);
                    MySqlDataAdapter da1 = new MySqlDataAdapter(cmd1);
                    DataTable dt1 = new DataTable();
                    da1.Fill(dt1);
                    if (dt1.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt1.Rows.Count; i++)
                        {
                            int srno = i + 1;
                            string email = SecurityManager.Decrypt(dt1.Rows[i]["EmailId"].ToString());
                            DateTime logdate= Convert.ToDateTime(dt1.Rows[i]["LoginOn"].ToString());
                            string  logindate=logdate.ToShortDateString();
                            facilityloglist1.Add(new FacilityLogDetails1
                            {
                                SrNo = srno,
                                Email = email,
                                OperationName = dt1.Rows[i]["OperationName"].ToString(),
                                LoginOn = logindate,
                                LogTime = dt1.Rows[i]["LogTime"].ToString(),
                                SystemIp = dt1.Rows[i]["System_IP"].ToString(),
                                ModifiedRecord = SecurityManager.Decrypt(dt1.Rows[i]["ModifiedRecord"].ToString()),
                                Details = dt1.Rows[i]["Detail"].ToString()

                            });

                        }
                        model.facilityloglist1 = facilityloglist1;
                    }
                  
                   // model.facilitylist = facilitylist;
                    model.FacilityId = facilityid.ToString();
                    string facilityname = null;
                    MySqlCommand cmd4 = new MySqlCommand("select IFNULL(FacilityId, 'NA') AS FacilityId, IFNULL(Location, 'NA') AS Location from facility where FacilityId='" + facilityid + "' ", obj.con);
                    MySqlDataAdapter da4 = new MySqlDataAdapter(cmd4);
                    DataTable dt4 = new DataTable();
                    da4.Fill(dt4);
                    if (dt4.Rows.Count > 0)
                    {
                        facilityname = dt4.Rows[0]["Location"].ToString();
                    }
                    model.FacilityName = facilityname.ToString();
                }
            }
            catch (Exception ex)
            { 
            
            }
            return model;
        
        }

        public static FacilityLogList GetFilterFacilityList(string facilityid,string OperationName ,string  DateFrom,string DateTo)
        {

            FacilityLogList model = new FacilityLogList();
            try
            {
                string Operation_Name = OperationName;
               
                List<FacilityLogDetails> facilityloglist = new List<FacilityLogDetails>();
                List<FacilityOperationNameList> facilitylist = new List<FacilityOperationNameList>();
                List<FacilityLogDetails1> facilityloglist1 = new List<FacilityLogDetails1>();

                if (facilityid != null)
                {
                    string query = "SELECT IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.R_Id, '') AS R_Id,IFNULL(t1.FacilityId, '') AS FacilityId,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t1.EmailId, '') AS EmailId,IFNULL(t2.R_name, '') AS R_name FROM userregister as t1 inner join userrole as t2 on t1.R_Id=t2.R_id where FacilityId='" + facilityid + "' and t1.R_Id !='" + 10 + "'";
                    MySqlCommand cmd = new MySqlCommand(query, obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            int srno = i + 1;
                            string name = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                            string email = SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString());
                            string usertype = SecurityManager.Decrypt(dt.Rows[i]["R_name"].ToString());

                            facilityloglist.Add(new FacilityLogDetails
                            {
                                SrNo = srno,
                                UserName = name,
                                Email = email,
                                UserType = usertype,
                                FacilityId = dt.Rows[i]["FacilityId"].ToString()
                            });
                        }
                        model.facilityloglist = facilityloglist;
                    }
                    string query2 = "";
                    if ((!String.IsNullOrEmpty(DateFrom) && !String.IsNullOrEmpty(DateTo)) && (!String.IsNullOrEmpty(Operation_Name)))
                    {
                        query2 = "SELECT  IFNULL(t1.`U_Id`, '') AS U_Id,IFNULL(t1.`FacilityId`, '') AS FacilityId,IFNULL(t1.`EmailId`, '') AS EmailId,IFNULL(t2.OperationName, '') AS OperationName,t2.LoginOn,t2.LogTime,IFNULL(t2.System_IP, '') AS System_IP,IFNULL(t2.ModifiedRecord, '') AS ModifiedRecord,IFNULL(t2.Detail, '') AS Detail FROM `userregister` as t1 inner join userlogdetails as t2 on t1.`U_Id`=t2.U_Id where t1.`FacilityId`='" + facilityid + "' and t2.`LoginOn` between '" + DateFrom + "' and '" + DateTo + "' and t2.OperationName='" + Operation_Name + "'";                   
                
                     }
                    else  if (!String.IsNullOrEmpty(DateFrom) && !String.IsNullOrEmpty(DateTo))
                    {
                        query2 = "SELECT  IFNULL(t1.`U_Id`, '') AS U_Id,IFNULL(t1.`FacilityId`, '') AS FacilityId,IFNULL(t1.`EmailId`, '') AS EmailId,IFNULL(t2.OperationName, '') AS OperationName,t2.LoginOn,t2.LogTime,IFNULL(t2.System_IP, '') AS System_IP,IFNULL(t2.ModifiedRecord, '') AS ModifiedRecord,IFNULL(t2.Detail, '') AS Detail FROM `userregister` as t1 inner join userlogdetails as t2 on t1.`U_Id`=t2.U_Id where t1.`FacilityId`='" + facilityid + "' and t2.`LoginOn` between '" + DateFrom + "' and '" + DateTo + "'";                   
                
                    }
                    else  
                    {
                        query2 = "SELECT  IFNULL(t1.`U_Id`, '') AS U_Id,IFNULL(t1.`FacilityId`, '') AS FacilityId,IFNULL(t1.`EmailId`, '') AS EmailId,IFNULL(t2.OperationName, '') AS OperationName,t2.LoginOn,t2.LogTime,IFNULL(t2.System_IP, '') AS System_IP,IFNULL(t2.ModifiedRecord, '') AS ModifiedRecord,IFNULL(t2.Detail, '') AS Detail FROM `userregister` as t1 inner join userlogdetails as t2 on t1.`U_Id`=t2.U_Id where t1.`FacilityId`='" + facilityid + "' and t2.OperationName='" + Operation_Name + "' ";
                 
                     }
                
                    MySqlCommand cmd2 = new MySqlCommand(query2, obj.con);
                    MySqlDataAdapter da2 = new MySqlDataAdapter(cmd2);
                    DataTable dt2 = new DataTable();
                    da2.Fill(dt2);
                    if (dt2.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt2.Rows.Count; i++)
                        {
                            int srno = i + 1;
                            string email = SecurityManager.Decrypt(dt2.Rows[i]["EmailId"].ToString());
                           // string logindate=dt2.Rows[i]["LoginOn"].ToString();
                            DateTime logdate=Convert.ToDateTime(dt2.Rows[i]["LoginOn"].ToString());
                            string logindate=logdate.ToShortDateString();
                    
                            facilityloglist1.Add(new FacilityLogDetails1
                            {
                                SrNo = srno,
                                Email = email,
                                OperationName = dt2.Rows[i]["OperationName"].ToString(),
                                LoginOn = logindate,
                                LogTime = dt2.Rows[i]["LogTime"].ToString(),
                                SystemIp = dt2.Rows[i]["System_IP"].ToString(),
                                ModifiedRecord = SecurityManager.Decrypt(dt2.Rows[i]["ModifiedRecord"].ToString()),
                                Details = dt2.Rows[i]["Detail"].ToString()
                            });

                        }

                    }
                    model.facilityloglist1 = facilityloglist1;

                    model.FacilityId = facilityid.ToString();
                    string facilityname = null;
                    MySqlCommand cmd4 = new MySqlCommand("select IFNULL(FacilityId, 'NA') AS FacilityId, IFNULL(Location, 'NA') AS Location from facility where FacilityId='" + facilityid + "' ", obj.con);
                    MySqlDataAdapter da4 = new MySqlDataAdapter(cmd4);
                    DataTable dt4 = new DataTable();
                    da4.Fill(dt4);
                    if (dt4.Rows.Count > 0)
                    {
                        facilityname = dt4.Rows[0]["Location"].ToString();
                    }
                    model.FacilityName = facilityname.ToString();
                }
               // return model;
            }
            catch (Exception ex)
            {
               
            }
            return model;
        }
        public static PatientList GetPatientListForNewComplain(string Name, int FacilityID)
        {
            int No = 0;
            var name = Name.ToLower().Trim();
            DbConnection obj = new DbConnection();
            PatientList model = new PatientList();
            List<PatientDetail> patientDetail = new List<PatientDetail>();
                  
            try
            {
                Connection.FacilityId = FacilityID;
                if (Connection.FacilityId != 0)
                {
                     //SELECT * FROM Contacts WHERE Name like @person + '%'
                    MySqlCommand cmd = new MySqlCommand("SELECT IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.EmailId, '') AS EmailId,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.NickName, '') AS NickName,IFNULL(t1.MobileNo, '') AS MobileNo FROM userregister t1 LEFT JOIN patient_otherinfo t2 ON t2.PatientId = t1.U_Id  where t1.R_Id='" + 10 + "' and t1.IsActive='" + 1 + "' order by t2.Info_Id", obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString());
                            string LN = SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                            //if ((PN.Length < name.Length) || (LN.Length < name.Length))
                            //{

                            //}
                            //else
                            //{

                            string nm = null, ln = null;
                            if (PN.Length >= name.Length)
                            {
                                nm = PN.Substring(0, name.Length);
                            }
                            else
                            {
                                nm = PN;
                            }
                            if (LN.Length >= name.Length)
                            {
                                ln = LN.Substring(0, name.Length);
                            }
                            else
                            {
                                ln = LN;
                            }
                            if ((nm != null) || (ln != null))
                            { 


                                No = No + 1;
                            
                                var nmm = nm.ToLower();
                                var lnm = ln.ToLower();

                                if ((nmm.Length == name.Length) || (lnm.Length == name.Length))
                                {
                                        if (nmm.Contains(name)||lnm.Contains(name))
                                        {
                                            patientDetail.Add(new PatientDetail
                                            {
                                                SrNo = No,
                                                PatientId =SecurityManager.Decrypt( dt.Rows[i]["U_Id"].ToString()),
                                                Email = dt.Rows[i]["EmailId"].ToString() != "" ? SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString()) : "NA",
                                                FirstName = PN+" "+LN,
                                                NickName = SecurityManager.Decrypt(dt.Rows[i]["NickName"].ToString()),
                                                PrimaryContactNo = dt.Rows[i]["MobileNo"].ToString(),
                                                Edit = Connection.AllowUpdate,
                                                Delete = Connection.AllowDelete
                                            });
                                        }
                                    }
                                }
                            }
                        }
                    }
                    model.patientList = patientDetail;
                }
            
            catch (Exception e)
            {
            }
            return model;
        }

        public static PatientList GetReActivePatientList(string name, int FacilityID)       // ---------------  Re-Active PAtient LIst 
        {
            int No = 0;
            DbConnection obj = new DbConnection();
            string fname = name.ToLower().Trim();
            PatientList model = new PatientList();
            try
            {
                Connection.FacilityId = FacilityID;

                if (Connection.FacilityId != 0)
                {
                    List<PatientDetail> patientDetail = new List<PatientDetail>();
                    MySqlCommand cmd = new MySqlCommand("SELECT IFNULL(t1.U_Id, '') AS U_Id, IFNULL(t1.EmailId, '') AS EmailId, IFNULL(t1.F_Name, '') AS F_Name, IFNULL(t1.L_Name, '') AS L_Name, IFNULL(t2.NickName, '') AS NickName, IFNULL(t1.MobileNo, '') AS MobileNo,t1.InactiveDate,t1.Inactive,t1.Is_Reactive FROM userregister t1 INNER JOIN patient_otherinfo t2 ON t2.PatientId = t1.U_Id  where  t1.R_Id='" + 10 + "' and t1.IsActive='" + 1 + "' and t1.Is_Reactive='" + 1 + "' order by t2.Info_Id", obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {

                            //int reactive = 0;
                            //string Status = "Inactive";
                          //  string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                            No = No + 1;
                            string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString());
                            string LN = SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());

                            string Emailid = SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString()).Trim();
                            if (Emailid == "")
                            {
                                Emailid = "NA";
                            }

                            string nm = null, lnm = null;
                            if (PN.Length >= fname.Length)
                            {
                                nm = PN.Substring(0, fname.Length);
                            }
                            else
                            {
                                nm = PN;
                            }
                            if (LN.Length >= fname.Length)
                            {
                                lnm = LN.Substring(0, fname.Length);
                            }
                            else
                            {
                                lnm = LN;
                            }
                            if ((nm != null) || (lnm != null))
                            {
                                var nmm = nm.ToLower();
                                var lnmm = lnm.ToLower();
                                if ((nmm.Length == fname.Length) || (lnmm.Length == fname.Length))
                                {
                                    if (nmm.Contains(fname) || lnmm.Contains(fname))
                                    {
                                        patientDetail.Add(new PatientDetail
                                        {
                                            SrNo = No,
                                            PatientId =SecurityManager.Decrypt( dt.Rows[i]["U_Id"].ToString()),
                                            Email = Emailid,
                                            FirstName = PN +" "+ LN,
                                            NickName = SecurityManager.Decrypt(dt.Rows[i]["NickName"].ToString()),
                                            PrimaryContactNo = dt.Rows[i]["MobileNo"].ToString(),
                                            Edit = Connection.AllowUpdate,
                                            Delete = Connection.AllowDelete
                                            //firstalert = firstalerts,
                                            //secondalert = secondalerts,
                                            //thirdalert = thirdalerts,
                                            //status = Status
                                        });
                                    }
                                }
                            }
                        }
                    }
                    model.patientList = patientDetail;
                }
            }
            catch (Exception e)
            {
            }
            return model;
        }

        public static PatientList GetWomacPatientList(string Name, int FacilitiId)       // --------------------------------- Get Womac Patient List
        {
            int No = 0;
            var name = Name.Trim().ToLower();
            DbConnection obj = new DbConnection();

            PatientList model = new PatientList();
            try
            {
                List<PatientDetail> patientDetail = new List<PatientDetail>();
                string SqlQuery = @"SELECT IFNULL(U_Id, '') AS U_Id ,IFNULL(F_Name, '') AS F_Name,IFNULL(L_Name, '') AS L_Name,IFNULL(EmailId, '') AS EmailId, IFNULL(MobileNo, '') AS MobileNo FROM userregister WHERE U_Id NOT IN (SELECT IFNULL(PatientId, '') AS PatientId FROM womac_test) and R_Id='" + 10 + "' and IsActive='" + 1 + "'";
               // string SqlQuery = @"SELECT t2.Info_Id,t1.U_Id,t1.F_Name,t1.L_Name,t1.EmailId,t1.MobileNo FROM userregister t1 INNER JOIN patient_otherinfo t2 on t1.U_Id=t2.PatientId where U_Id not in (SELECT PatientId FROM womac_test) and t1.FacilityId='" + FacilitiId + "' and t1.IsActive='" + 1 + "' and t1.R_Id='" + 10 + "' and t1.F_Name='"+Name+"' order by t2.Info_Id ";
                // MySqlCommand cmd = new MySqlCommand("select t1.U_Id,t1.F_Name,t1.L_Name,t1.EmailId,t1.MobileNo from userregister t1 INNER JOIN patient_otherinfo t2 on t1.U_Id=t2.PatientId  where t1.FacilityId='" + FacilitiId + "' and t1.IsActive='" + 1 + "' and t1.R_Id='" + 10 + "' order by t2.Info_Id", obj.con);
                MySqlCommand cmd = new MySqlCommand(SqlQuery, obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                       
                        No++;
                        string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString());
                        string LN = SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                        //if ((PN.Length < name.Length) || (LN.Length < name.Length))
                        //{
                        //}
                        //else
                        //{

                        string nm = null, lnm = null;
                        if (PN.Length >= name.Length)
                        {
                            nm = PN.Substring(0, name.Length);
                        }
                        else
                        {
                            nm = PN;
                        }
                        if (LN.Length >= name.Length)
                        {
                            lnm = LN.Substring(0, name.Length);
                        }
                        else
                        {
                            lnm = LN;
                        }
                        if ((nm != null) || (lnm != null))
                        {
                            var nlm = nm.ToLower();
                            var lnlm = lnm.ToLower();
                            if ((nlm.Length == name.Length) || (lnlm.Length == name.Length))
                            {
                                if (nlm.Contains(name) || lnlm.Contains(name))
                                {
                                    patientDetail.Add(new PatientDetail
                                    {
                                        SrNo = No,
                                        //PatientId = SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                        PatientId =SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                        Email = dt.Rows[i]["EmailId"].ToString() != "" ? SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString()) : "NA",
                                        FirstName = PN+" "+LN,
                                        PrimaryContactNo = SecurityManager.Decrypt(dt.Rows[i]["MobileNo"].ToString()),
                                        Edit = Connection.AllowUpdate,
                                        Delete = Connection.AllowDelete
                                    });
                                
                                }
                            }
                        }
                    }
                }
                model.patientList = patientDetail;
            }
            catch (Exception e)
            {
            }
            return model;
        }

        public static PatientWomacReportList GetWomacList(string Name, int LoggedFacilityId,int update=0)
        {
            int No = 0;
            var name = Name.Trim().ToLower();
            PatientWomacReportList model = new PatientWomacReportList();
            try
            {
                if (LoggedFacilityId != 0)
                {
                    List<PatientWomacReport> PatientWomacReportDetail = new List<PatientWomacReport>();
                    string query = "";
                    if (update == 1)
                    {
                        query = "SELECT IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.FacilityId, '') AS FacilityId,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee,IFNULL(WOMAC_TestOn, '') AS WOMAC_TestOn, IFNULL(WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,max(case when t2.WOMAC_Name = '1' then t2.Complete else ' 'end) as '1', max(case when t2.WOMAC_Name = '2' then t2.Complete else ' 'end) as '2',max(case when t2.WOMAC_Name = '3' then t2.Complete else ' 'end) as '3' FROM userregister t1 INNER JOIN  womac_test t2 ON t2.PatientId = t1.U_Id where t1.IsActive = 1 and t1.R_Id =10 group by  t1.U_Id  order by WOMAC_TestOn desc";
                    }
                    else
                    {
                        query = "SELECT IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.FacilityId, '') AS FacilityId,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee,IFNULL(WOMAC_TestOn, '') AS WOMAC_TestOn, IFNULL(WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,max(case when t2.WOMAC_Name = '1' then t2.Complete else ' 'end) as '1', max(case when t2.WOMAC_Name = '2' then t2.Complete else ' 'end) as '2',max(case when t2.WOMAC_Name = '3' then t2.Complete else ' 'end) as '3' FROM userregister t1 INNER JOIN  womac_test t2 ON t2.PatientId = t1.U_Id where t1.IsActive = 1 and t1.Inactive=0 and t1.R_Id =10 group by  t1.U_Id  order by WOMAC_TestOn desc";
                    }
                  //  MySqlCommand cmd = new MySqlCommand("SELECT distinct IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee FROM userregister t1 INNER JOIN womac_test t2 ON t2.PatientId = t1.U_Id  where t1.FacilityId='" + LoggedFacilityId + "' and t1.R_Id='" + 10 + "' and t1.IsActive='" + 1 + "' ", obj.con);
                    MySqlCommand cmd = new MySqlCommand(query, obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);

                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            No++;
                            string PatientID = dt.Rows[i]["U_Id"].ToString();

                            string Kneevalue = dt.Rows[i]["Knee"].ToString() == "Left Knee,Right Knee" ? "Left Knee,Right Knee" : dt.Rows[i]["Knee"].ToString();

                            string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString());
                            string LN = SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());

                            string nm = null, ln = null;
                            if (PN.Length >= name.Length)
                            {
                                nm = PN.Substring(0, name.Length);
                            }
                            else
                            {
                                nm = PN;
                            }
                            if (LN.Length >= name.Length)
                            {
                                ln = LN.Substring(0, name.Length);
                            }
                            else
                            {
                                ln = LN;
                            }
                            if ((nm != null) || (ln != null))
                            {

                                var lowernm = nm.ToLower();
                                var lowerln = ln.ToLower();
                                if ((lowernm.Length == name.Length) || (lowerln.Length == name.Length))
                                {
                                    if (lowernm.Contains(name) || lowerln.Contains(name))
                                    {
                                        string WomacTestDate1 = null, WomacTestDate2 = null, WomacTestDate3 = null, IsComplete2 = null, IsComplete3 = null;

                                        DataTable Dtw1 = WomacCalender.GetWomacNo(PatientID, 1, Convert.ToInt16(LoggedFacilityId));
                                        DataTable Dtw2 = WomacCalender.GetWomacNo(PatientID, 2, Convert.ToInt16(LoggedFacilityId));
                                        DataTable Dtw3 = WomacCalender.GetWomacNo(PatientID, 3, Convert.ToInt16(LoggedFacilityId));

                                        int WomacNo = 0;

                                        if (Dtw3.Rows.Count > 0)
                                        {
                                            WomacNo = Convert.ToInt16(Dtw3.Rows[0]["WOMAC_Name"].ToString());
                                        }
                                        else if (Dtw2.Rows.Count > 0)
                                        {
                                            WomacNo = Convert.ToInt16(Dtw2.Rows[0]["WOMAC_Name"].ToString());
                                        }
                                        else if (Dtw1.Rows.Count > 0)
                                        {
                                            WomacNo = Convert.ToInt16(Dtw1.Rows[0]["WOMAC_Name"].ToString());
                                        }

                                        if (WomacNo == 1)
                                        {

                                            WomacTestDate1 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw1.Rows[0]["Complete"].ToString());
                                            WomacTestDate2 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_NexttestOn"].ToString().Replace("12:00:00 AM", " "), IsComplete2);
                                            WomacTestDate3 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_NexttestOn"].ToString().Replace("12:00:00 AM", " "), IsComplete3);


                                        }
                                        else if (WomacNo == 2)
                                        {
                                            WomacTestDate1 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw1.Rows[0]["Complete"].ToString());
                                            WomacTestDate2 = WomacCalender.WoMacTestDate(Dtw2.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw2.Rows[0]["Complete"].ToString());
                                            WomacTestDate3 = WomacCalender.WoMacTestDate(Dtw2.Rows[0]["WOMAC_NexttestOn"].ToString().Replace("12:00:00 AM", " "), IsComplete3);
                                        }
                                        else if (WomacNo == 3)
                                        {
                                            WomacTestDate1 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw1.Rows[0]["Complete"].ToString());
                                            WomacTestDate2 = WomacCalender.WoMacTestDate(Dtw2.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw2.Rows[0]["Complete"].ToString());
                                            WomacTestDate3 = WomacCalender.WoMacTestDate(Dtw3.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw3.Rows[0]["Complete"].ToString());
                                        }
                                        if (WomacTestDate1 == "Completed" || WomacTestDate1 == "Due Date")
                                        {
                                            if (WomacTestDate1 == "Due Date")
                                            {
                                                WomacTestDate2 = "-";
                                                WomacTestDate3 = "-";
                                            }
                                            if (WomacTestDate2 == "")
                                            {
                                                WomacTestDate2 = "-";
                                                WomacTestDate3 = "-";
                                            }

                                        }
                                        PatientWomacReportDetail.Add(new PatientWomacReport
                                        {
                                            SrNo = No,
                                            PatientId = SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                            PatientName = PN + " " + LN,
                                            Knee = Kneevalue,
                                            Womac1 = WomacTestDate1,
                                            Womac2 = WomacTestDate2,
                                            Womac3 = WomacTestDate3
                                        });

                                    }
                                }
                            }
                        }
                    }
                    model.PatientWomacRepotList = PatientWomacReportDetail;
                }
            }
            catch (Exception e)
            {
            }
            return model;
        }

      

    }
}