﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.Models;

namespace NewAPGApplication.BussinessLayer
{
    public class PatientInfoPut
    {
        DbConnection obj = new DbConnection();
        string Success = null, result = null;
        string UserID;
        int RoleId = 10;


        public string PatientInfoData(PatientRegistration PR)
        {
            string Success = "0", UserID, EmailID=null;
            string patientemail = null;
            try
            {
                if (!String.IsNullOrEmpty(PR.UserNameId))
                {
                    UserID = PR.UserNameId;
                    Success = "1";
                }
                else
                {
                    UserID = "";
                }
                string query1 = "select EmailId from userregister where U_Id='" +SecurityManager.Encrypt(PR.UserNameId) + "'";
                MySqlCommand cmd3 = new MySqlCommand(query1, obj.con);
                MySqlDataAdapter da2 = new MySqlDataAdapter(cmd3);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);
                if (dt2.Rows.Count > 0)
                {
                    patientemail =SecurityManager.Decrypt(dt2.Rows[0]["EmailId"].ToString());
                }
                else
                {

                }

                 if (patientemail == PR.EmailId)
                    {
                        EmailID = SecurityManager.Encrypt(patientemail);
                        Success = "2";
                    }
                    else
                    {
                        if (PR.EmailId != null)
                        {
                            MySqlCommand cmdd = new MySqlCommand("select IFNULL(EmailId, '') AS EmailId from userregister where EmailId ='" + SecurityManager.Encrypt(PR.EmailId) + "'", obj.con);
                            MySqlDataAdapter dda = new MySqlDataAdapter(cmdd);
                            DataTable dtt = new DataTable();
                            dda.Fill(dtt);
                            if (dtt.Rows.Count > 0)
                            {
                                if (!String.IsNullOrEmpty(patientemail))
                                {
                                    EmailID = SecurityManager.Encrypt(patientemail);
                                    Success = "2";
                                }
                                else
                                {
                                    EmailID = "";
                                }

                            }
                            else
                            {
                                if (!String.IsNullOrEmpty(PR.EmailId))
                                {
                                    EmailID = SecurityManager.Encrypt(PR.EmailId);
                                    Success = "2";
                                }
                                else
                                {
                                    EmailID = "";
                                }
                            }
                        }
                }
               
                //double BMI = 703.0 * PR.Weight / Convert.ToInt32(PR.Height) / Convert.ToInt32(PR.Height); // BMI Calculate 
                double BMI = 703.0 * Convert.ToInt32(PR.Weight) / Convert.ToInt32(PR.Height) / Convert.ToInt32(PR.Height); 
                double BMIValue = Math.Round(BMI, 2, MidpointRounding.AwayFromZero);

                string Birthdate = null;
                DateTime birthdate = Convert.ToDateTime(PR.DateOfBirth);
                Birthdate = Convert.ToDateTime(birthdate).ToString("yyyy-MM-dd");
                string Query1 = @"update userregister set FacilityId='" + PR.FacilityId + "',F_Name='" + SecurityManager.Encrypt(PR.FirstName) + "',L_Name='" + SecurityManager.Encrypt(PR.LastName) + "', Zipcode='" + PR.PIN + "',Gender='" + PR.Gender + "',DOB='" + Birthdate + "',EmailId='" + EmailID + "',EthnicityId='" + PR.EthnicityId + "',MobileNo='" + PR.MobileNo + "',OtherContactNo='" + PR.OtherContactNo + "' where U_Id='" + SecurityManager.Encrypt(PR.UserNameId) + "'";

                string Query2 = @"update patient_otherinfo set PINNO = '" + PR.PIN + "',Height= '" + PR.Height + "',Weight= '" + PR.Weight + "',Emp_Zipcode='" + PR.EmpZipCode + "' where PatientId= '" + SecurityManager.Encrypt(PR.UserNameId) + "'";

                //string Query3 = @"update patient_otherinfo set Emp_Street='" + PR.EmpStreet + "', Edu_Id='" + PR.EduId + "' ,WheelChair='" + PR.WheelChair + "',ContactAtWork='" + PR.ContactAtWork + "',KnowAbtUs='" + PR.KnowAboutUs + "',HaveChiropracticPhysician='" + PR.HaveChiropracticPhysician + "',Chiro_PhysicianName='" + PR.ChiroPhysicianName + "',PrimaryPhysician='" + PR.PrimaryPhysician + "',Prim_PhysicianName='" + PR.PrimPhysicianName + "' where PatientId='" + SecurityManager.Encrypt(PR.UserNameId) + "'";
              
                //string Query4 = @"update userregister set CityId='" + PR.CityId + "',StateId='" + PR.StateId + "',MailingCity='" + PR.MailingCity + "',MailingState='" + PR.MailingState + "' where U_Id='" + SecurityManager.Encrypt(PR.UserNameId) + "'";

                //string Query5 = @"update patient_otherinfo set Emp_CityId='" + PR.EmpCityId + "',Emp_StateId='" + PR.EmpStateId + "' where PatientId='" + SecurityManager.Encrypt(PR.UserNameId) + "'";
               
                MySqlCommand cmd1 = new MySqlCommand(Query1, obj.con);
                MySqlCommand cmd2 = new MySqlCommand(Query2, obj.con);
                //MySqlCommand cmd3 = new MySqlCommand(Query3, obj.con);
                //MySqlCommand cmd4 = new MySqlCommand(Query4, obj.con);
                //MySqlCommand cmd5 = new MySqlCommand(Query5, obj.con);
                                
                obj.OpenDbConnection();             
                Success = cmd1.ExecuteNonQuery().ToString();
                Success = cmd2.ExecuteNonQuery().ToString(); 
                //Success = cmd3.ExecuteNonQuery().ToString();
                //Success = cmd4.ExecuteNonQuery().ToString();
                //Success = cmd5.ExecuteNonQuery().ToString(); 
                obj.CloseDbConnection();


                //if (!String.IsNullOrEmpty(PR.ReferralId.ToString()))
                //{
                //    MySqlCommand cmdd1 = new MySqlCommand("select * from referraluser where U_Id=@U_Id", obj.con);
                //    cmdd1.Parameters.AddWithValue("@U_Id", SecurityManager.Encrypt(PR.UserNameId));
                //    MySqlDataAdapter asd1 = new MySqlDataAdapter(cmdd1);
                //    DataTable ddt = new DataTable();
                //    asd1.Fill(ddt);
                //    if (ddt.Rows.Count > 0)
                //    {
                //        MySqlCommand cmdd = new MySqlCommand("update referraluser set  ReferralId =@ReferralId where U_Id= @U_Id", obj.con);
                //        cmdd.Parameters.AddWithValue("@ReferralId", PR.ReferralId);
                //        cmdd.Parameters.AddWithValue("@U_Id", SecurityManager.Encrypt(PR.UserNameId));
                //        obj.OpenDbConnection();
                //        cmdd.ExecuteNonQuery();
                //        obj.CloseDbConnection();
                //    }
                //    else
                //    {
                //        MySqlCommand cmdd = new MySqlCommand("insert into referraluser (ReferralId,U_Id) values (@ReferralId,@U_Id)", obj.con);
                //        cmdd.Parameters.AddWithValue("@ReferralId", PR.ReferralId);
                //        cmdd.Parameters.AddWithValue("@U_Id", SecurityManager.Encrypt(PR.UserNameId));
                //        obj.OpenDbConnection();
                //        cmdd.ExecuteNonQuery();
                //        obj.CloseDbConnection();
                //    }
                //}

                return Success;

            }
            catch (Exception)
            {
                return Success;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }

        public string PutPatientInsurance(Insurance PR)
        {
            string Success = "0", UserID, InsId = "0";
            try
            {
                if (!String.IsNullOrEmpty(PR.UserNameId))
                {
                    UserID = PR.UserNameId;
                    Success = "1";
                }
                else
                {
                    UserID = "";
                }
                String InsType = "InsType1";

                MySqlCommand mscmd = new MySqlCommand("select * from insurance where UserId='" + SecurityManager.Encrypt(PR.UserNameId) + "'", obj.con);
                MySqlDataAdapter msasd = new MySqlDataAdapter(mscmd);
                DataTable Tb = new DataTable();
                msasd.Fill(Tb);
                if (Tb.Rows.Count > 0)
                {
                    string Query = "update insurance set R_id='" + RoleId + "' ,PolicyNo='" + PR.Policy + "' ,Ins_Name='" + PR.InsureName + "',GroupNo='" + PR.GroupNo + "',EmployerName='" + PR.EmployerName + "',Relation='" + PR.Relation + "' where UserId= '" + SecurityManager.Encrypt(PR.UserNameId) + "'";
                    MySqlCommand cmd = new MySqlCommand(Query, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }
                else
                {
                    string Query = "insert into insurance (UserId,R_id,PolicyNo,Ins_Name,GroupNo,EmployerName,Relation) values ('" + SecurityManager.Encrypt(PR.UserNameId) + "','" + RoleId + "','" + PR.Policy + "','" + PR.InsureName + "','" + PR.GroupNo + "','" + PR.EmployerName + "','" + PR.Relation + "')";
                    MySqlCommand cmd = new MySqlCommand(Query, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }

                MySqlCommand cmd1 = new MySqlCommand("select * from insurance where UserId = @UserId", obj.con);
                cmd1.Parameters.AddWithValue("@UserId", SecurityManager.Encrypt(PR.UserNameId));
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd1);
                DataTable dt = new DataTable();
                asd.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    InsId = dt.Rows[0]["Ins_Id"].ToString();

                    MySqlCommand Mcmd1 = new MySqlCommand("select * from insur_second_payer where Ins_Id = '" + InsId + "'", obj.con);                   
                    MySqlDataAdapter Masd = new MySqlDataAdapter(Mcmd1);
                    DataTable Mdt = new DataTable();
                    Masd.Fill(Mdt);
                    if (Mdt.Rows.Count > 0)
                    {
                        string Query = "update insur_second_payer set Name='" + PR.I_Name + "' ,Address='" + PR.I_Address + "' ,CityId='" + PR.I_CityId + "' ,StateId='" + PR.I_StateId + "' ,Zipcode='" + PR.I_ZipCode + "' ,SocialSecurity='" + PR.I_Soc_Security + "' ,Relation= '" + PR.I_Relation + "',DOB= '" + PR.I_BirthDate + "',EmployerName= '" + PR.I_EmployerName + "' where Ins_Id='" + InsId + "' ";
                        MySqlCommand cmd2 = new MySqlCommand(Query, obj.con);
                        obj.OpenDbConnection();
                        cmd2.ExecuteNonQuery();
                        obj.CloseDbConnection();
                    }
                    else
                    {
                        string Query = "insert into insur_second_payer (Ins_Id,Name,Address,CityId,StateId,Zipcode,SocialSecurity,Relation,DOB,EmployerName) values ('" + InsId + "','" + PR.I_Name + "','" + PR.I_Address + "','" + PR.I_CityId + "','" + PR.I_StateId + "','" + PR.I_ZipCode + "','" + PR.I_Soc_Security + "','" + PR.I_Relation + "','" + PR.I_BirthDate + "','" + PR.I_EmployerName + "')";
                        MySqlCommand cmd2 = new MySqlCommand(Query, obj.con);
                        obj.OpenDbConnection();
                        cmd2.ExecuteNonQuery();
                        obj.CloseDbConnection();
                    }
                }


                return Success;
            }
            catch (Exception)
            {
                return Success;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }

        public string PutPatientBMI(PatientRegistration PR)
        {
            MySqlCommand cmdd = new MySqlCommand("insert into  bmi_record (U_Id,Height,Weight,CreatedOn,BMI) values ( @U_Id,@Height,@Weight,@CreatedOn,@BMI)", obj.con);
            cmdd.Parameters.AddWithValue("@U_Id", SecurityManager.Encrypt(PR.UserNameId));
            cmdd.Parameters.AddWithValue("@Height", PR.Height);
            cmdd.Parameters.AddWithValue("@Weight", PR.Weight);
            cmdd.Parameters.AddWithValue("@CreatedOn", Convert.ToDateTime(DateTime.Now.ToString()));

            double BMI = 703.0 * Convert.ToInt32(PR.Weight) / Convert.ToInt32(PR.Height) / Convert.ToInt32(PR.Height); // BMI Calculate
            double BMIValue = Math.Round(BMI, 2, MidpointRounding.AwayFromZero);

            cmdd.Parameters.AddWithValue("@BMI", BMIValue);
            obj.OpenDbConnection();
            cmdd.ExecuteNonQuery();
            obj.CloseDbConnection();

            return result;
        }



        public string PutPatientBMII(string patietid, string createddatee, int Weight, int Height, double BMIvalue)
        {
            string Pid = null;
            if (!String.IsNullOrEmpty(patietid))
            {
                Pid = SecurityManager.Encrypt(patietid).ToString();
            }
            MySqlCommand cmdd = new MySqlCommand("insert into  bmi_record (U_Id,Height,Weight,CreatedOn,BMI) values ( @U_Id,@Height,@Weight,@CreatedOn,@BMI)", obj.con);
            cmdd.Parameters.AddWithValue("@U_Id", Pid);
            cmdd.Parameters.AddWithValue("@Height", Height);
            cmdd.Parameters.AddWithValue("@Weight", Weight);
            cmdd.Parameters.AddWithValue("@CreatedOn", createddatee);

            //double BMI = 703.0 * Convert.ToInt32(PR.Weight) / Convert.ToInt32(PR.Height) / Convert.ToInt32(PR.Height); // BMI Calculate
            //double BMIValue = Math.Round(BMI, 2, MidpointRounding.AwayFromZero);

            cmdd.Parameters.AddWithValue("@BMI", BMIvalue);
            obj.OpenDbConnection();
            cmdd.ExecuteNonQuery();
            obj.CloseDbConnection();

            return result;
        }
        
        public string PatientQuestionnaire(PatientQuestionnaire PR)
        {
            string Success = "0";
            try
            {
                string strquary = @"insert into patient_medicalinfo (PatientId,MedicalCondition,Prev_Treatment,SystemReview ,Medication_Allergy,Food_Allergy,AllApplied_Check,SubmittedOn,PatientSignature) values ('" + SecurityManager.Encrypt(PR.UserNameId) + "','" + PR.MedicalValues + "','" + PR.Treatments + "' ,'" + PR.Review + "' ,'" + PR.MedicationAllergy + "','" + PR.FoodAllergy + "','" + PR.Allergies + "','" + Convert.ToDateTime(PR.SubmittedOn).ToString("yyyy-MM-dd") + "','" + PR.PatientSignature + "')";
                MySqlCommand cmd1 = new MySqlCommand(strquary, obj.con);
                obj.OpenDbConnection();
                Success = cmd1.ExecuteNonQuery().ToString();
                obj.CloseDbConnection();

                
                //-----------------------------------------------------------------------------

                if ((PR.XraysDate != null) && (PR.XraysLocation != null) && (PR.XraysForWhat != null))
                {
                   
                    string Xray = "X-rays";
                    string strquary1 = @"insert into patient_prevprocedure (PatientId,ProcedureName,Date,Location,ForWhat) values ('" + SecurityManager.Encrypt(PR.UserNameId) + "','" + Xray + "','" + Convert.ToDateTime(PR.XraysDate).ToString("yyyy-MM-dd") + "','" + PR.XraysLocation + "','" + PR.XraysForWhat + "')";
                    MySqlCommand cmd2 = new MySqlCommand(strquary1, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd2.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }

                if ((PR.CtMriDate != null) && (PR.CtMriLocation != null) && (PR.CtMriForWhat != null))
                {
                    string CtMRI = "C.T./MRI";
                    string strquary1 = @"insert into patient_prevprocedure (PatientId,ProcedureName,Date,Location,ForWhat) values ('" + SecurityManager.Encrypt(PR.UserNameId) + "','" + CtMRI + "','" + Convert.ToDateTime(PR.CtMriDate).ToString("yyyy-MM-dd") + "','" + PR.CtMriLocation + "','" + PR.CtMriForWhat + "')";
                    MySqlCommand cmd2 = new MySqlCommand(strquary1, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd2.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }

                if ((PR.MyelogramDate != null) && (PR.MyelogramLocation != null) && (PR.MyelogramForWhat != null))
                {
                    string Myelogram = "Myelogram";
                    string strquary1 = @"insert into patient_prevprocedure (PatientId,ProcedureName,Date,Location,ForWhat) values ('" + SecurityManager.Encrypt(PR.UserNameId) + "','" + Myelogram + "','" + Convert.ToDateTime(PR.MyelogramDate).ToString("yyyy-MM-dd") + "','" + PR.MyelogramLocation + "','" + PR.MyelogramForWhat + "')";
                    MySqlCommand cmd2 = new MySqlCommand(strquary1, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd2.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }

                if ((PR.UltrasoundDate != null) && (PR.UltrasoundLocation != null) && (PR.UltrasoundForWhat != null))
                {
                    string Ultrasound = "Ultrasound";
                    string strquary1 = @"insert into patient_prevprocedure (PatientId,ProcedureName,Date,Location,ForWhat) values ('" + SecurityManager.Encrypt(PR.UserNameId) + "','" + Ultrasound + "','" + Convert.ToDateTime(PR.UltrasoundDate).ToString("yyyy-MM-dd") + "','" + PR.UltrasoundLocation + "','" + PR.UltrasoundForWhat + "')";
                    MySqlCommand cmd2 = new MySqlCommand(strquary1, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd2.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }

                if ((PR.EMGDate != null) && (PR.EMGLocation != null) && (PR.EMGForWhat != null))
                {
                    string EMG = "E.M.G";
                    string strquary1 = @"insert into patient_prevprocedure (PatientId,ProcedureName,Date,Location,ForWhat) values ('" + SecurityManager.Encrypt(PR.UserNameId) + "','" + EMG + "','" + Convert.ToDateTime(PR.EMGDate).ToString("yyyy-MM-dd") + "','" + PR.EMGLocation + "','" + PR.EMGForWhat + "')";
                    MySqlCommand cmd2 = new MySqlCommand(strquary1, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd2.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }
                
                if ((PR.TAPhysicianDate != null) && (PR.TAPhysicianLocation != null) && (PR.AnotherPhysicianForWhat != null))
                {
                    string TreatbyAnotherPhys = "Treatment by Another Physician";
                    string strquary1 = @"insert into patient_prevprocedure (PatientId,ProcedureName,Date,Location,ForWhat) values ('" + SecurityManager.Encrypt(PR.UserNameId) + "','" + TreatbyAnotherPhys + "','" + Convert.ToDateTime(PR.TAPhysicianDate).ToString("yyyy-MM-dd") + "','" + PR.TAPhysicianLocation + "','" + PR.AnotherPhysicianForWhat + "')";
                    MySqlCommand cmd2 = new MySqlCommand(strquary1, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd2.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }

                //-----------------------------------------------------------------------------

                string strquary2 = @"insert into patient_socialhistory (PatientId,Smoke,PacksInday,Alcohol,PacksIperDay,Drug,DrugName,AbuseVictim,Abuse_VictimDetail,ClaimOrLawsuit,Compensation,InjuryOrInsurance,Other,Disability) values 
                  ('" + SecurityManager.Encrypt(PR.UserNameId) + "','" + PR.Smoke + "','" + PR.PacksInday + "','" + PR.Alcohol + "','" + PR.PacksperDay + "','" + PR.Drug + "','" + PR.DrugName + "','" + PR.AbuseVictim + "','" + PR.AbuseVictimDetail + "','" + PR.ClaimOrLawsuit + "','" + PR.Compensation + "','" + PR.InjuryOrInsurance + "','" + PR.Other + "','" + PR.Disability + "')";

                MySqlCommand cmd3 = new MySqlCommand(strquary2, obj.con);

                obj.OpenDbConnection();
                Success = cmd3.ExecuteNonQuery().ToString();
                obj.CloseDbConnection();


                //-----------------------------------------------------------------------------
                if ((PR.HeartPerson != null))
                {
                    string strquary3 = @"insert into  patient_familyhisroty (PatientId,FamilyDisease,PersonName) values ('" + SecurityManager.Encrypt(PR.UserNameId)  + "','" + "Heart Disease" + "','" + PR.HeartPerson + "')";
                    MySqlCommand cmd5 = new MySqlCommand(strquary3, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd5.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }
                if ((PR.EpilepsyPerson != null))
                {
                    string strquary3 = @"insert into  patient_familyhisroty (PatientId,FamilyDisease,PersonName) values ('" + SecurityManager.Encrypt(PR.UserNameId) + "','" + "Epilepsy" + "','" + PR.EpilepsyPerson + "')";
                    MySqlCommand cmd5 = new MySqlCommand(strquary3, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd5.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }
                if ((PR.HypertensionPerson != null))
                {
                    string strquary3 = @"insert into  patient_familyhisroty (PatientId,FamilyDisease,PersonName) values ('" + SecurityManager.Encrypt(PR.UserNameId) + "','" + "Hypertension" + "','" + PR.HypertensionPerson + "')";
                    MySqlCommand cmd5 = new MySqlCommand(strquary3, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd5.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }
                if ((PR.GlaucomaPerson != null))
                {
                    string strquary3 = @"insert into  patient_familyhisroty (PatientId,FamilyDisease,PersonName) values ('" + SecurityManager.Encrypt(PR.UserNameId) + "','" + "Glaucoma" + "','" + PR.GlaucomaPerson + "')";
                    MySqlCommand cmd5 = new MySqlCommand(strquary3, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd5.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }
                if ((PR.StrokePerson != null))
                {
                    string strquary3 = @"insert into  patient_familyhisroty (PatientId,FamilyDisease,PersonName) values ('" + SecurityManager.Encrypt(PR.UserNameId) + "','" + "Stroke" + "','" + PR.StrokePerson + "')";
                    MySqlCommand cmd5 = new MySqlCommand(strquary3, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd5.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }
                if ((PR.BleedingPerson != null))
                {
                    string strquary3 = @"insert into  patient_familyhisroty (U_Id,FamilyDisease,PersonName) values ('" + SecurityManager.Encrypt(PR.UserNameId) + "','" + "Bleeding Disorders" + "','" + PR.BleedingPerson + "')";
                    MySqlCommand cmd5 = new MySqlCommand(strquary3, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd5.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }
                if ((PR.CancerPerson != null))
                {
                    string strquary3 = @"insert into  patient_familyhisroty (PatientId,FamilyDisease,PersonName) values ('" + SecurityManager.Encrypt(PR.UserNameId) + "','" + "Cancer" + "','" + PR.CancerPerson + "')";
                    MySqlCommand cmd5 = new MySqlCommand(strquary3, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd5.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }
                if ((PR.KidneyPerson != null))
                {
                    string strquary3 = @"insert into  patient_familyhisroty (PatientId,FamilyDisease,PersonName) values ('" + SecurityManager.Encrypt(PR.UserNameId)  + "','" + "Kidney Disease" + "','" + PR.KidneyPerson + "')";
                    MySqlCommand cmd5 = new MySqlCommand(strquary3, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd5.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }
                if ((PR.DiabetesPerson != null))
                {
                    string strquary3 = @"insert into  patient_familyhisroty (U_Id,FamilyDisease,PersonName) values ('" + SecurityManager.Encrypt(PR.UserNameId) + "','" + "Diabetes" + "','" + PR.DiabetesPerson + "')";
                    MySqlCommand cmd5 = new MySqlCommand(strquary3, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd5.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }
                if ((PR.ThyroidPerson != null))
                {
                    string strquary3 = @"insert into  patient_familyhisroty (PatientId,FamilyDisease,PersonName) values ('" + SecurityManager.Encrypt(PR.UserNameId) + "','" + "Thyroid Disease" + "','" + PR.ThyroidPerson + "')";
                    MySqlCommand cmd5 = new MySqlCommand(strquary3, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd5.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }
                //-----------------------------------------------------------------------------

                string strquary4 = @"insert into  current_medications (PatientId,MedicationName,Strength,NoOfDose) values  ('" + SecurityManager.Encrypt(PR.UserNameId) + "','" + PR.CurrentMedications + "','" + PR.Strength + "','" + PR.NoOfDose + "')";
                MySqlCommand cmd6 = new MySqlCommand(strquary4, obj.con);
                obj.OpenDbConnection();
                Success = cmd6.ExecuteNonQuery().ToString();
                obj.CloseDbConnection();

                //-----------------------------------------------------------------------------

                //string strquary3 = @"insert into patient_surgeries (PatientId,SurgeryName,Month,Year) values ('" +  SecurityManager.Encrypt(PR.UserNameId) + "','" + Xray + "','" + PR.XraysDate + "','" + PR.XraysDate + "','" + PR.XraysLocation + "')";

                //MySqlCommand cmd4 = new MySqlCommand("insert into patient_surgeries (PatientId,SurgeryName,Month,Year) values (@PatientId,@SurgeryName,@Month,@Year)", obj.con);
                //cmd4.Parameters.AddWithValue("@PatientId",  SecurityManager.Encrypt(PR.UserNameId));
                //cmd4.Parameters.AddWithValue("@SurgeryName", PR.SurgeriesValues);
                //cmd4.Parameters.AddWithValue("@Month", PR.MonthNm);
                //cmd4.Parameters.AddWithValue("@Year", PR.YearNm);
                //obj.OpenDbConnection();
                //Success = cmd4.ExecuteNonQuery().ToString();
                //obj.OpenDbConnection();
                
                return Success;

            }
            catch (Exception)
            {
                return Success;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }

        public static string NewCompliantDetail(NewPatientCompliant model, string PatientId) //----------------- Insert Patient New Complaint 
        {
            try
            {
                DbConnection obj = new DbConnection();
                string SuccessId = "0";

                MySqlCommand cmd = new MySqlCommand("select PatientId,InjuryDate,InjuryCause,lastTreatment,TreatmentDetail,FrontPainArea,BackPainArea from new_complaint where PatientId='" + PatientId + "'", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count == 0)
                {
                    string Query = "insert into new_complaint (PatientId,InjuryDate,InjuryCause,lastTreatment,TreatmentDetail,FrontPainArea,BackPainArea,PainDetail,CurrentMobility,Employement,LastworkedOn) values ('" + PatientId + "','" + model.NewInjuryDate + "','" + model.Cause + "','" + model.LastCheckUp + "','" + model.LastCheckUpDetail + "','" + model.FrontPainArea + "','" + model.BackPainArea + "','" + model.PainDescription + "','" + model.CurrentMobility + "','" + model.CurrentEmployeement + "','" + model.LastFullDayWork+ "')";

                    MySqlCommand cmd1 = new MySqlCommand(Query, obj.con);                    
                    obj.OpenDbConnection();
                    SuccessId = cmd1.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                  //  GetPatientInformation.ErrorMessage = "New user '" + model.PatientId + "' is Added Successfully";
                    return SuccessId;
                }
                else
                {
                    return "1";
                }
            }
            catch (Exception e)
            {
                GetPatientInformation.ErrorMessage = e.Message;
                GetPatientInformation.ErrorMessage = "Some thing is not right Please Contact with Developer Team";
                return "0";
            }
        }

        public static string MedicalInformationDetail(MedicalInformation model, string PatientId)  //----------------- Insert Madical Information 
        {
            DbConnection obj = new DbConnection();
            try
            {
                string SuccessId = "0";
                MySqlCommand cmd = new MySqlCommand("select * from patient_medicalreport where PatientId='" + SecurityManager.Encrypt(PatientId) + "'", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);                
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    string Query = "insert into patient_medicalreport (PatientId,ReleaseTo,Obtain,OrgName,OrgAddress,orgPhone,AppliedOn,ValidUntill,SignatureOn,PatientSign) values ('" + SecurityManager.Encrypt(PatientId) + "','" + model.ReleaseTo + "','" + model.ObtainFrom + "','" + model.OrgName + "','" + model.OrgAddress + "','" + model.OrgContactNo + "','" + model.AppliesTo + "','" + model.ValidTill + "','" + Convert.ToDateTime(model.SignDate).ToString("yyyy-MM-dd") + "','" + model.Signature + "')"; // 
                    MySqlCommand cmd1 = new MySqlCommand(Query, obj.con);                  
                    obj.OpenDbConnection();
                    SuccessId = cmd1.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();                  
                    return SuccessId;
                }
                else
                {
                    return SuccessId;
                }
            }
            catch (Exception e)
            {
                GetPatientInformation.ErrorMessage = e.Message;
                GetPatientInformation.ErrorMessage = "Some thing is not right Please Contact with Developer Team";
                return "0";
            }
        }

        public static string PatientAcknowledgementDetail(PatientAcknowledgement model, string PatientId)
        {
            DbConnection obj = new DbConnection();
            try
            {
                string SuccessId = "0";

                MySqlCommand cmd = new MySqlCommand("select * from patient_acknowledgementreport where PatientId='"+SecurityManager.Encrypt(PatientId)+"'", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    string Query = "insert into patient_acknowledgementreport (PatientId,PatientSignature,Date) values ('" + SecurityManager.Encrypt(PatientId) + "','" + model.Signature + "','" + Convert.ToDateTime(model.AkgDate).ToString("yyyy-MM-dd") + "')";
                    MySqlCommand cmd1 = new MySqlCommand(Query, obj.con);                 
                    obj.OpenDbConnection();
                    SuccessId = cmd1.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();                  
                    return SuccessId;
                }
                else
                {
                    return "1";
                }
            }
            catch (Exception e)
            {
                GetPatientInformation.ErrorMessage = e.Message;
                GetPatientInformation.ErrorMessage = "Some thing is not right Please Contact with Developer Team";
                return "0";
            }
        }
    }
}