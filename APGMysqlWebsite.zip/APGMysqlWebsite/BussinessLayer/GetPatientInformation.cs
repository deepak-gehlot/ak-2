﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.BussinessLayer;
using NewAPGApplication.Models;


namespace NewAPGApplication.BussinessLayer
{
    public class GetPatientInformation
    {
        MySqlDataAdapter asd;


        static DbConnection obj = new DbConnection();

        public static string ErrorMessage = null;


        public DataSet GetUserData(string id)  // --------------------------------- Get User Data
        {
            DataSet ds = new DataSet();


            string idd = SecurityManager.Encrypt(id);
            try
            {
                //obj.OpenDbConnection();
                MySqlCommand cmd = new MySqlCommand("select  IFNULL(R_Id, '') AS R_Id,IFNULL(U_Id, '') AS U_Id, IFNULL(EthnicityId, '') AS EthnicityId,IFNULL(Soc_Security, '') AS Soc_Security, IFNULL(DOB, '1990-01-01') AS DOB,IFNULL(EmailId, '') AS EmailId,	IFNULL(FacilityId, '') AS FacilityId, 	IFNULL(F_Name, '') AS F_Name, 	IFNULL(L_Name, '') AS L_Name, IFNULL(MobileNo, '') AS MobileNo,IFNULL(Zipcode, '') AS Zipcode,IFNULL(Gender, '') AS Gender from userregister Where U_Id='" +SecurityManager.Encrypt(id)+ "'", obj.con);
                //  cmd.Parameters.AddWithValue("@U_Id", id);
                asd = new MySqlDataAdapter(cmd);
                ds = new DataSet();
                asd.Fill(ds);
                return ds;
            }
            catch (Exception)
            {
                return ds;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }

        public DataSet GetPatientInfo(string id)    // --------------------------------- Get Patient Data
        {
            DataSet dss = null;
            try
            {
                obj.OpenDbConnection();
              MySqlCommand cmd = new MySqlCommand("select IFNULL(PatientId, '') AS PatientId, IFNULL(NickName, '') AS NickName, IFNULL(R_id, '') AS R_id, IFNULL(Height, '') AS Height, IFNULL(Weight, '') AS Weight, IFNULL(BMI, '') AS BMI, IFNULL(Edu_Id, '') AS Edu_Id, IFNULL(WorkType, '') AS WorkType, IFNULL(WheelChair, '') AS WheelChair, IFNULL(ContactAtWork, '') AS ContactAtWork, IFNULL(PINNO, '') AS PINNO, IFNULL(Employer, '') AS Employer, IFNULL(Occupation, '') AS Occupation, IFNULL(Emp_Street, '') AS Emp_Street, IFNULL(Emp_CityId, '') AS Emp_CityId, IFNULL(Emp_StateId, '') AS Emp_StateId, IFNULL(Emp_Zipcode, '') AS Emp_Zipcode, IFNULL(Emp_ContactNo, '') AS Emp_ContactNo, IFNULL(WheelChair, '') AS WheelChair, IFNULL(ContactAtWork, '') AS ContactAtWork, IFNULL(KnowAbtUs, '') AS KnowAbtUs, HaveChiropracticPhysician, IFNULL(Chiro_PhysicianName, '') AS Chiro_PhysicianName,  PrimaryPhysician, IFNULL(Prim_PhysicianName, '') AS Prim_PhysicianName from patient_otherinfo Where PatientId=@PatientId", obj.con);
               // MySqlCommand cmd = new MySqlCommand("select IFNULL(Height, '0') AS Height,IFNULL(Weight, '0') AS Weight, IFNULL(Edu_Id, '') AS Edu_Id, IFNULL(WorkType, '') AS WorkType, IFNULL(BMI, '') AS BMI,IFNULL(WheelChair, '') AS WheelChair from patient_otherinfo Where PatientId=@PatientId", obj.con);
                cmd.Parameters.AddWithValue("@PatientId",SecurityManager.Encrypt(id));
                var se = SecurityManager.Encrypt(id);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                dss = new DataSet();
                asd.Fill(dss);
                return dss;
            }
            catch (Exception)
            {
                return dss;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }

        public static alertlist GetPatientAllAlertList(int facilityid)
        {
         List<PatientAlertList> patientalertdetail = new List<PatientAlertList>();
         alertlist model = new alertlist();
         try
         {
             string query = "SELECT IFNULL(U_Id, '') AS U_Id,IFNULL(F_Name, '') AS F_Name,IFNULL(L_Name, '') AS L_Name,IFNULL(EmailId, 'NA') AS EmailId,IFNULL(MobileNo, '') AS MobileNo,CreatedDate,InactiveDate,IsActive,Inactive  FROM userregister where R_Id=10 and Inactive=1";
             MySqlCommand cmd = new MySqlCommand(query, obj.con);
             MySqlDataAdapter da = new MySqlDataAdapter(cmd);
             DataTable dt = new DataTable();
             da.Fill(dt);
             if (dt.Rows.Count > 0)
             {
                 for (int i = 0; i < dt.Rows.Count; i++)
                 {
                     int srno = i + 1;
                     string Emailid = SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString()).Trim();
                     if (Emailid == "")
                     {
                         Emailid = "NA";
                     }
                     string patientid = dt.Rows[i]["U_Id"].ToString();
                     DateTime createddate = Convert.ToDateTime(dt.Rows[i]["InactiveDate"].ToString());
                     string firstalerts = null, secondalerts = null, thirdalerts = null;
                     firstalerts = GetPatientInformation.firstalertstatus(patientid,1);
                     secondalerts = GetPatientInformation.firstalertstatus(patientid,2);
                     thirdalerts = GetPatientInformation.firstalertstatus(patientid,3);
                     if (firstalerts == null)
                     {
                         firstalerts = createddate.AddDays(45).ToString("MM/dd/yyyy");
                     }
                     if (secondalerts == null)
                     {
                         secondalerts = createddate.AddDays(90).ToString("MM/dd/yyyy");
                     }
                     if (thirdalerts == null)
                     {
                         thirdalerts = createddate.AddDays(120).ToString("MM/dd/yyyy");
                     }
                     int status = Convert.ToInt16(dt.Rows[i]["Inactive"]);
                     string statuss = "";
                     if (status == 0)
                     {
                         statuss = "Deactive";
                     }
                     else if (status == 1)
                     {
                         statuss = "Inactive";
                     }
                     string patientname = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());

                     patientalertdetail.Add(new PatientAlertList
                     {
                         SrNo = srno,
                         FirstName = patientname,
                         Email = Emailid,
                         PrimaryContactNo = dt.Rows[i]["MobileNo"].ToString(),
                         firstalert = firstalerts,
                         PatientId = SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                         secondalert = secondalerts,
                         thirdalert = thirdalerts,
                         status = statuss


                     });
                 }
                 model.patientalertlistt = patientalertdetail;
             }
         }
         catch
         { 
         
         }
        
         return model;
        }

        public static string firstalertstatus(string patientid, int alertid)
        { 
            string status=null;
            try {
                string query = "select patient_id,alert_day_id ,status,IsDeleted from  alert_complete_tbl where patient_id='" + patientid + "' and alert_day_id='" + alertid + "' and IsDeleted!='"+"True"+"'";
                MySqlCommand cmd = new MySqlCommand(query, obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (dt.Rows[0]["status"].ToString() == "True")
                    {
                        status = "Completed";
                    }
                  
                }
            }
            catch(Exception es)
            {
            
            }

            return status;
        }
        public static string secondalertstatus(string patientid, int alertid)
        {
            string status = null;
            try
            {
                string query = "select patient_id,alert_day_id,status from  alert_complete_tbl where patient_id='" + patientid + "' and alert_day_id='" + alertid + "'";
                MySqlCommand cmd = new MySqlCommand(query, obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (dt.Rows[0]["status"].ToString() == "True")
                    {
                        status = "Completed";
                    }
                }
            }
            catch (Exception es)
            {

            }
            return status;
        }
        public static string thirdalertstatus(string patientid, int alertid)
        {
            string status = null;

            try
            {
                string query = "select patient_id,alert_day_id,status  from  alert_complete_tbl where patient_id='" + patientid + "' and alert_day_id='" + alertid + "'";
                MySqlCommand cmd = new MySqlCommand(query, obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (dt.Rows[0]["status"].ToString() == "True")
                    {
                        status = "Completed";
                    }
                }
            }
            catch (Exception es)
            {

            }
            return status;
        }
       
        public DataSet GetOperator(string id)     // --------------------------------- Get Operator Data
        {
            DataSet dss = null;
            try
            {
                obj.OpenDbConnection();
                MySqlCommand cmd = new MySqlCommand("select	IFNULL(Info_Id, '') AS Info_Id,IFNULL(PatientId, '') AS PatientId,IFNULL(R_id, '') AS R_id,IFNULL(NickName, '') AS NickName, IFNULL(Occupation, '') AS Occupation,IFNULL(Employer, '') AS Employer,IFNULL(Emp_Street, '') AS Emp_Street,IFNULL(Emp_CityId, '') AS Emp_CityId,IFNULL( Emp_StateId, '') AS Emp_StateId,IFNULL(Emp_Zipcode, '') AS Emp_Zipcode,IFNULL(Emp_ContactNo, '') AS Emp_ContactNo,IFNULL(Edu_Id , '') AS Edu_Id,IFNULL(PINNO, '') AS PINNO, IFNULL(WorkType, '') AS WorkType,IFNULL(Height , '0') AS Height,IFNULL(Weight , '') AS Weight,IFNULL(BMI, '') AS BMI,IFNULL(CreatedOn, '') AS CreatedOn,IFNULL(WheelChair, '') AS WheelChair,IFNULL(ContactAtWork, '') AS ContactAtWork,IFNULL(KnowAbtUs , '') AS KnowAbtUs,IFNULL(HaveChiropracticPhysician, '') AS HaveChiropracticPhysician,IFNULL(Chiro_PhysicianName, '') AS Chiro_PhysicianName,IFNULL(PrimaryPhysician , '') AS PrimaryPhysician,IFNULL(Prim_PhysicianName, '') AS Prim_PhysicianName,IFNULL(IsDeactive , '') AS IsDeactive,IFNULL(IsDeleted, '') AS IsDeleted,	IFNULL(IsReactive , '') AS IsReactive,IFNULL(ActivatedOn, '') AS ActivatedOn,IFNULL(Count_Mail, '') AS Count_Mail from patient_otherinfo Where U_Id=@U_Id", obj.con);
                cmd.Parameters.AddWithValue("@U_Id", id);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                dss = new DataSet();
                asd.Fill(dss);
                return dss;
            }
            catch (Exception)
            {
                return dss;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }
        public DataSet GetPhysicainList()      // --------------------------------- Get PhysicainList Data
        {
            //---single knee
            DataSet ds = null;
            try
            {
                obj.OpenDbConnection();
                MySqlCommand cmd = new MySqlCommand("select IFNULL( `U_Id`, '') AS `U_Id` ,  IFNULL( `R_Id`, '') AS  `R_Id`, IFNULL(`FacilityId` , '') AS `FacilityId` , IFNULL(`F_Name` , '') AS  `F_Name`, IFNULL( `L_Name`, '') AS  `L_Name`, IFNULL(`Gender` , '') AS `Gender` , IFNULL(`DOB` , '') AS `DOB` , IFNULL(`EmailId` , '') AS `EmailId` , IFNULL( `Password`, '') AS `Password` , IFNULL(`Address` , '') AS `Address` ,  IFNULL(`CityId` , '') AS  `CityId`, IFNULL( `StateId`, '') AS  `StateId`, IFNULL(`Zipcode` , '') AS  `Zipcode`, IFNULL( `MailingAddress`, '') AS  `MailingAddress`, IFNULL(`MailingCity` , '') AS `MailingCity` , IFNULL( `MailingState`, '') AS `MailingState` , IFNULL(`MailingZipcode` , '') AS `MailingZipcode` , IFNULL( `EthnicityId`, '') AS `EthnicityId` , IFNULL(`MobileNo` , '') AS `MobileNo` ,  IFNULL( `OtherContactNo`, '') AS `OtherContactNo` , IFNULL( `Soc_Security`, '') AS `Soc_Security` , IFNULL(`U_Image` , '') AS `U_Image` , IFNULL(`CreatedDate` , '') AS `CreatedDate` , `IsActive`  , IFNULL(`Digital_SignURL` , '') AS  `Digital_SignURL`, IFNULL(`ForgetPasswordString` , '') AS  `ForgetPasswordString`,`Is_Reactive` from userregister where R_Id='" + 6 + "' and IsActive='"+1+"'", obj.con);      //  6 Is Physician Role ID         
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                ds = new DataSet();
                asd.Fill(ds);
                return ds;
            }
            catch (Exception)
            {
                return ds;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }


        public DataSet GetPhysicainListNew()
       {
            DataSet ds = null;
            try
            {
                obj.OpenDbConnection();
                MySqlCommand cmd = new MySqlCommand("SELECT  `U_Id` , `F_Name`,`R_Id` , `L_Name` FROM `userregister` where (R_Id='6' or Flag='" + 1 + "') and  `R_Id`!='10' and IsActive='" + 1 + "'", obj.con);      //  6 Is Physician Role ID         
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                ds = new DataSet();
                asd.Fill(ds);
                return ds;
            }
            catch (Exception)
            {
                return ds;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }
        
        public DataSet GetPhysicianTherapist() // --------------------------------- Get Physicain Therepist Data
        {
            //----single knee
            DataSet ds = null;
            try
            {
                obj.OpenDbConnection();
                MySqlCommand cmd = new MySqlCommand("select  IFNULL( `U_Id`, '') AS `U_Id` ,  IFNULL( `R_Id`, '') AS  `R_Id`, IFNULL(`FacilityId` , '') AS `FacilityId` , IFNULL(`F_Name` , '') AS  `F_Name`, IFNULL( `L_Name`, '') AS  `L_Name`, IFNULL(`Gender` , '') AS `Gender` , IFNULL(`DOB` , '') AS `DOB` , IFNULL(`EmailId` , '') AS `EmailId` , IFNULL( `Password`, '') AS `Password` , IFNULL(`Address` , '') AS `Address` ,  IFNULL(`CityId` , '') AS  `CityId`, IFNULL( `StateId`, '') AS  `StateId`, IFNULL(`Zipcode` , '') AS  `Zipcode`, IFNULL( `MailingAddress`, '') AS  `MailingAddress`, IFNULL(`MailingCity` , '') AS `MailingCity` , IFNULL( `MailingState`, '') AS `MailingState` , IFNULL(`MailingZipcode` , '') AS `MailingZipcode` , IFNULL( `EthnicityId`, '') AS `EthnicityId` , IFNULL(`MobileNo` , '') AS `MobileNo` ,  IFNULL( `OtherContactNo`, '') AS `OtherContactNo` , IFNULL( `Soc_Security`, '') AS `Soc_Security` , IFNULL(`U_Image` , '') AS `U_Image` , IFNULL(`CreatedDate` , '') AS `CreatedDate` , `IsActive`  , IFNULL(`Digital_SignURL` , '') AS  `Digital_SignURL`, IFNULL(`ForgetPasswordString` , '') AS  `ForgetPasswordString`,`Is_Reactive` from userregister where R_Id='" + 7 + "' and IsActive='" + 1 + "'", obj.con);   //  7 Is Physician Therapist Role ID                  
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                ds = new DataSet();
                asd.Fill(ds);
                return ds;
            }
            catch (Exception)
            {
                return ds;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }

        public DataSet GetPhysicianTherapistNew()
         {
            DataSet ds = null;
            try
            {
                obj.OpenDbConnection();
                MySqlCommand cmd = new MySqlCommand("SELECT  `U_Id` , `F_Name`,`R_Id` , `L_Name` FROM `userregister` where (R_Id='7' or Flag='" + 2 + "') and  `R_Id`!='10' and IsActive='" + 1 + "'", obj.con);   //  7 Is Physician Therapist Role ID                  
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                ds = new DataSet();
                asd.Fill(ds);
                return ds;
            }
            catch (Exception)
            {
                return ds;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        } 

        public DataTable GetInsuranceData(string id)  // --------------------------------- Get PAtient Insurace Data
        {
            DataTable dt = null;
            try
            {
                obj.OpenDbConnection();
                MySqlCommand cmd = new MySqlCommand("select IFNULL(Ins_Id, '') AS Ins_Id,IFNULL(UserId, '') AS UserId,IFNULL(R_id, '') AS R_id,IFNULL(PolicyNo, '') AS PolicyNo,IFNULL(Ins_Type, '') AS Ins_Type,IFNULL(Ins_Name, '') AS Ins_Name,IFNULL(GroupNo, '') AS GroupNo,IFNULL(EmployerName, '') AS EmployerName,IFNULL(Relation, '') AS Relation from insurance Where UserId ='" + id + "'", obj.con);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                dt = new DataTable();
                asd.Fill(dt);
                return dt;
            }
            catch (Exception)
            {
                return dt;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }


        public DataTable GetSecondaryInsuranceData(int id)  // --------------------------------- Get PAtient Secondery Insurace Data
        {
            DataTable dt = null;
            try
            {
                obj.OpenDbConnection();
                MySqlCommand cmd = new MySqlCommand("select * from  insur_second_payer Where Ins_Id ='" + id + "'", obj.con);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                dt = new DataTable();
                asd.Fill(dt);
                return dt;
            }
            catch (Exception)
            {
                return dt;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }


        public DataSet GetFacilityName(string id)       // --------------------------------- Get Facility Data
        {
            DataSet ds1 = null;
            try
            {
                obj.OpenDbConnection();
                MySqlCommand cmd = new MySqlCommand("select IFNULL(`FacilityId`, '') AS FacilityId , IFNULL(`Location`, '') AS  Location, IFNULL(`Street`, '') AS  Street, IFNULL(`StateId`, '') AS StateId , IFNULL(`Zipcode`, '') AS  Zipcode, IFNULL(`ContactNo`, '') AS  ContactNo, IFNULL(`FaxNo`, '') AS FaxNo , IFNULL(`ManagerId`, '') AS  ManagerId, IFNULL(`EmailId`, '') AS  EmailId,`IsActive`,  IFNULL(`CityId`, '') AS  CityId from  facility Where FacilityId=@FacilityId and IsActive='" + 1 + "'", obj.con);
                cmd.Parameters.AddWithValue("@FacilityId", id);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                ds1 = new DataSet();
                asd.Fill(ds1);
                return ds1;
            }
            catch (Exception)
            {
                return ds1;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }

        public DataSet GetEthnicityName(int id)        // --------------------------------- Get Ethnicity Data
        {
            DataSet ds1 = null;
            try
            {
                obj.OpenDbConnection();
                MySqlCommand cmd = new MySqlCommand("select * from  ethnicity Where EthnicityId=@EthnicityId", obj.con);
                cmd.Parameters.AddWithValue("@EthnicityId", id);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                ds1 = new DataSet();
                asd.Fill(ds1);
                return ds1;
            }
            catch (Exception)
            {
                return ds1;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }

        public DataSet GetWomacList(string id, int WomacId)           // --------------------------------- Get Womac List Data
        {
            DataSet ds1 = null;
            try
            {
                obj.OpenDbConnection();
                string query = null;
                string idd = "10";
                var Usertypeid = HttpContext.Current.Session["UserTypeId"].ToString();
                if (Usertypeid != null)
                {

                    if (Usertypeid == idd)
                    {
                        query = "select IFNULL(DieaseId, '') AS DiseaseId,IFNULL(Disease_DetailId, '') AS Disease_DetailId,IFNULL(Answer, '') AS Answer,IFNULL(WOMAC_Id, '') AS WOMAC_Id,IFNULL(PatientId, '') AS PatientId,IFNULL(FacilityId, '') AS FacilityId,IFNULL(TotalScore, '') AS TotalScore,IFNULL(Knee, '') AS Knee,IFNULL(KneeTestTo, '') AS KneeTestTo,IFNULL(WOMAC_TestOn, '') AS WOMAC_TestOn,IFNULL(WOMAC_Name, '') AS WOMAC_Name,IFNULL(WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,IFNULL(Complete, '') AS Complete from  womac_test Where PatientId=@PatientId and WOMAC_Name=@WOMAC_Name and Complete='" + "True" + "'";
                    }
                    else
                    {
                        query = "select IFNULL(DieaseId, '') AS DiseaseId,IFNULL(Disease_DetailId, '') AS Disease_DetailId,IFNULL(Answer, '') AS Answer,IFNULL(WOMAC_Id, '') AS WOMAC_Id,IFNULL(PatientId, '') AS PatientId,IFNULL(FacilityId, '') AS FacilityId,IFNULL(TotalScore, '') AS TotalScore,IFNULL(Knee, '') AS Knee,IFNULL(KneeTestTo, '') AS KneeTestTo,IFNULL(WOMAC_TestOn, '') AS WOMAC_TestOn,IFNULL(WOMAC_Name, '') AS WOMAC_Name,IFNULL(WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,IFNULL(Complete, '') AS Complete from  womac_test Where PatientId=@PatientId and WOMAC_Name=@WOMAC_Name";
                    }

                }
                MySqlCommand cmd = new MySqlCommand(query, obj.con);
                cmd.Parameters.AddWithValue("@PatientId",SecurityManager.Encrypt(id));
                cmd.Parameters.AddWithValue("@WOMAC_Name", WomacId);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                ds1 = new DataSet();
                asd.Fill(ds1);
                return ds1;
            }
            catch (Exception)
            {
                return ds1;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }
        #region Patient
        //public DataSet GetDiseaseList(string id)            // --------------------------------- Get Disease List Data
        //{
        //    DataSet ds1 = null;
        //    try
        //    {
        //        obj.OpenDbConnection();
        //        MySqlCommand cmd = new MySqlCommand("select * from  diseaselist Where Disease_DetailId=@Disease_DetailId", obj.con);
        //        cmd.Parameters.AddWithValue("@Disease_DetailId", id);
        //        MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
        //        ds1 = new DataSet();
        //        asd.Fill(ds1);
        //        return ds1;
        //    }
        //    catch (Exception)
        //    {
        //        return ds1;
        //    }
        //    finally
        //    {
        //        obj.CloseDbConnection();
        //    }
        //}
        #endregion

        public DataSet GetAllDiseaseList()   // --------------------------------- Get All Disease List Data
        {
            DataSet ds2 = null;
            try
            {
                obj.OpenDbConnection();

                MySqlCommand cmd = new MySqlCommand("SELECT IFNULL(t2.DiseaseId, '') AS DiseaseId,IFNULL(t1.DiseasesType, '') AS DiseasesType,IFNULL(t2.Disease_DetailId, '') AS Disease_DetailId,IFNULL(t2.DiseaseName, '') AS DiseaseName FROM diseasetype t1 INNER JOIN  diseaselist t2 ON t1.DiseaseId=t2.DiseaseId where IsActive='" + 1 + "'", obj.con);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                ds2 = new DataSet();
                asd.Fill(ds2);
                return ds2;
            }
            catch (Exception)
            {
                return ds2;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }

        public DataSet GetDiseaseName(string id)       // --------------------------------- Get Disease Name Data
        {
            DataSet ds1 = null;
            try
            {
                obj.OpenDbConnection();
                MySqlCommand cmd = new MySqlCommand("select IFNULL(DiseaseId, '') AS DiseaseId,IFNULL(DiseasesType, '') AS DiseasesType from  diseasetype Where DiseaseId=@DiseaseId", obj.con);
                cmd.Parameters.AddWithValue("@DiseaseId", id);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                ds1 = new DataSet();
                asd.Fill(ds1);
                return ds1;
            }
            catch (Exception)
            {
                return ds1;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }

        public int GetQuestionId(int ID)        // --------------------------------- Get Question ID Data
        {
            DataTable dt = null;
            int Qid = 0;
            try
            {
                obj.OpenDbConnection();
                MySqlCommand cmd = new MySqlCommand("select IFNULL(DiseaseId, '') AS DiseaseId from  diseaselist Where Disease_DetailId=@Disease_DetailId", obj.con);
                cmd.Parameters.AddWithValue("@Disease_DetailId", ID);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                dt = new DataTable();
                asd.Fill(dt);
                Qid = int.Parse(dt.Rows[0]["DiseaseId"].ToString());
                return Qid;
            }
            catch (Exception)
            {
                return Qid;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }

        public DataTable GetFacilityLocationName(int id)  // --------------------------------- Get Facility NAme Data
        {
            DataTable dt = null;
            try
            {
                obj.OpenDbConnection();
                MySqlCommand cmd = new MySqlCommand("select IFNULL(FacilityId, '') AS FacilityId , IFNULL(`Location`, '') AS  Location, IFNULL(`Street`, '') AS  Street, IFNULL(`StateId`, '') AS StateId , IFNULL(`Zipcode`, '') AS  Zipcode, IFNULL(`ContactNo`, '') AS  ContactNo, IFNULL(`FaxNo`, '') AS FaxNo , IFNULL(`ManagerId`, '') AS  ManagerId, IFNULL(`EmailId`, '') AS  EmailId,`IsActive`,  IFNULL(`CityId`, '') AS  CityId from  facility Where FacilityId=@FacilityId and IsActive='" + 1 + "'", obj.con);
                cmd.Parameters.AddWithValue("@FacilityId", id);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                dt = new DataTable();
                asd.Fill(dt);
                return dt;
            }
            catch (Exception)
            {
                return dt;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }

        public DataTable GetPatientTheripyDetail(string PatientId, int WomacId, string Knee)             // --------------------------------- Get Patient Theripy Detail Data
        {
            DataTable dt = null;
            try
            {
                obj.OpenDbConnection();
                MySqlCommand cmd = new MySqlCommand("select IFNULL(InjectionId, '') AS InjectionId,IFNULL(PatientId, '') AS PatientId,IFNULL(WOMAC_Name, '') AS WOMAC_Name,IFNULL(PhysicianTherapist, '') AS PhysicianTherapist, IFNULL(Physician, '') AS Physician, IFNULL(IsPhysicalTherapist, '') AS IsPhysicalTherapist,IFNULL(Kellgren_gread, '') AS Kellgren_gread,IFNULL(Knee, '') AS Knee,IFNULL(Injected, '') AS Injected, 	IFNULL(InjectionNumber, '') AS InjectionNumber,IFNULL(TheraphyOn, '') AS TheraphyOn from  injectiondetails Where PatientId='" + SecurityManager.Encrypt(PatientId) + "' and WOMAC_Name='" + WomacId + "' and Knee= '" + Knee + "'", obj.con);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                dt = new DataTable();
                asd.Fill(dt);
                return dt;
            }
            catch (Exception)
            {
                return dt;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }

        public int GetInjectionNo(string PatientName, int WomacNo, string Knee)     // --------------------------------- Get Injection Data
        {
            DataTable dt = null;
            int InjNo = 0;
            try
            {
                obj.OpenDbConnection();
                MySqlCommand cmd = new MySqlCommand("select IFNULL(InjectionNumber, '') AS InjectionNumber from injectiondetails where PatientId='" + PatientName + "' and WOMAC_Name='" + WomacNo + "' and Knee='" + Knee + "'", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    InjNo = 1 + int.Parse(dt.Rows[0]["InjectionNumber"].ToString());
                }
                else
                {
                    InjNo = 1;
                };
                return InjNo;
            }
            catch (Exception)
            {
                return InjNo;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }

        public static string GetCityName(int CityId)      // --------------------------------- Get City NAme Data
        {
            DataTable dt = null;
            DbConnection ob = new DbConnection();
            string CityName = null;
            try
            {
                ob.OpenDbConnection();
                MySqlCommand cmd = new MySqlCommand("select IFNULL(C_Name, '') AS C_Name,IFNULL(StateId, '') AS StateId from city where CityId='" + CityId + "'", ob.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    CityName = dt.Rows[0]["C_Name"].ToString();
                }
                else
                {
                    CityName = null;
                };
                return CityName;
            }
            catch (Exception)
            {
                return CityName;
            }
            finally
            {
                ob.CloseDbConnection();
            }
        }

        public string AgeCalculator(DateTime Dob)         //  --------------------------------- Get Age 
        {
            DateTime Now = DateTime.Now;
            int Years = new DateTime(DateTime.Now.Subtract(Dob).Ticks).Year - 1;
            DateTime PastYearDate = Dob.AddYears(Years);
            int Months = 0;
            for (int i = 1; i <= 12; i++)
            {
                if (PastYearDate.AddMonths(i) == Now)
                {
                    Months = i;
                    break;
                }
                else if (PastYearDate.AddMonths(i) >= Now)
                {
                    Months = i - 1;
                    break;
                }
            }
            int Days = Now.Subtract(PastYearDate.AddMonths(Months)).Days;
            int Hours = Now.Subtract(PastYearDate).Hours;
            int Minutes = Now.Subtract(PastYearDate).Minutes;
            int Seconds = Now.Subtract(PastYearDate).Seconds;
            return String.Format("{0}", Years);
        }

        public DataTable GetAlertMail(string email)
        {
            DataTable dt = new DataTable();
            try
            {
               
                if (email != null)
                {
                    MySqlCommand cmd = new MySqlCommand("select IFNULL(ScheduleDay, '') AS ScheduleDay,IFNULL(Mail_Body, '') AS Mail_Body from alert_mail where AlertTo='" + email + "'", obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    da.Fill(dt);
                }
              
            }
            catch(Exception ex)
            {

            }
            return dt;
              
        }


        public static PatientList GetPatientList(int FacilitiId)       // --------------------------------- Get Patient List
        {
            int No = 0;
            DbConnection obj = new DbConnection();

            PatientList model = new PatientList();
            try
            {
                // t1.IsActive,t2.IsReactive,
                List<PatientDetail> patientDetail = new List<PatientDetail>();
                //MySqlCommand cmd = new MySqlCommand("select t1.U_Id,t1.F_Name,t1.L_Name,t1.EmailId,t1.MobileNo from userregister t1 INNER JOIN patient_otherinfo t2 on t1.U_Id=t2.PatientId  where t1.FacilityId='" + FacilitiId + "' and t1.IsActive='" + 1 + "' and t1.R_Id='" + 10 + "' order by t2.Info_Id desc", obj.con);
                MySqlCommand cmd = new MySqlCommand("select IFNULL(t1.U_Id, '') AS U_Id,t1.FacilityId, IFNULL(t1.F_Name, '') AS F_Name, IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t1.EmailId, '') AS EmailId, IFNULL(t1.MobileNo, '') AS MobileNo,t1.IsActive,t1.Is_Reactive,IFNULL(t2.IsDeactive, '0') AS IsDeactive,t1.Inactive, IFNULL(t2.Info_Id, '0') AS  Info_Id , IFNULL(t1.CreatedDate, '') AS CreatedDate from userregister t1  LEFT JOIN patient_otherinfo t2 on t1.U_Id=t2.PatientId where t1.Is_Reactive=1 and t1.R_Id= '10' Union select  IFNULL(t1.U_Id, '') AS U_Id,t1.FacilityId, IFNULL(t1.F_Name, '') AS F_Name, IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t1.EmailId, '') AS EmailId, IFNULL(t1.MobileNo, '') AS MobileNo,t1.IsActive,t1.Is_Reactive,IFNULL(t2.IsDeactive, '0') AS IsDeactive,t1.Inactive, IFNULL(t2.Info_Id, '0') AS  Info_Id ,  IFNULL(t1.CreatedDate, '') AS CreatedDate  from userregister t1  LEFT JOIN patient_otherinfo t2 on t1.U_Id=t2.PatientId  where t2.IsDeactive =1  and t1.R_Id= '10'  UNION select  IFNULL(t1.U_Id, '') AS U_Id,t1.FacilityId, IFNULL(t1.F_Name, '') AS F_Name, IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t1.EmailId, '') AS EmailId, IFNULL(t1.MobileNo, '') AS MobileNo,t1.IsActive,t1.Is_Reactive,IFNULL(t2.IsDeactive, '0') AS IsDeactive,t1.Inactive, IFNULL(t2.Info_Id, '0') AS  Info_Id , IFNULL(t1.CreatedDate, '') AS CreatedDate from userregister t1  LEFT JOIN patient_otherinfo t2 on t1.U_Id=t2.PatientId  where t1.IsActive=1 and t1.R_Id= '10'  Order by CreatedDate Desc ", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {

                        No = i;
                        No++;
                        string strr = "";
                        int strReactive = Convert.ToInt32(dt.Rows[i]["Is_Reactive"].ToString());
                        int strInActive = Convert.ToInt16(dt.Rows[i]["Inactive"].ToString());
                        int strDeactive = Convert.ToInt32(dt.Rows[i]["IsDeactive"].ToString());
                        int strActiv = Convert.ToInt32(dt.Rows[i]["IsActive"].ToString());
                        if (strInActive == 1 && strActiv == 1)
                        {
                            strr = "Inactive";
                        }
                        else if (strInActive == 0 && strDeactive == 1 && strActiv == 0)
                        {
                            strr = "Deactivated";
                        }
                        else if ((strInActive == 0 && strDeactive == 0 && strActiv == 1))
                        {
                            strr = "Active";
                        }
                        else
                        { }

                        string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                        patientDetail.Add(new PatientDetail
                        {
                            //PatientId = SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                            SrNo = No,
                            PatientId =SecurityManager.Decrypt( dt.Rows[i]["U_Id"].ToString()),
                            Pid=SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                            Email = SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString() != "" ? SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString()) : "NA"),
                            Patient = PN,
                            status = strr.ToString(),
                            PrimaryContactNo = SecurityManager.Decrypt(dt.Rows[i]["MobileNo"].ToString()),
                            Edit = Connection.AllowUpdate,
                            Delete = Connection.AllowDelete,

                        });
                    }
                }
                model.patientList = patientDetail;
            }
            catch (Exception e)
            {
            }
            return model;
        }

        public static PatientList GetPatientListForActive(int FormId, int tempFacilityId, int LUTypeId)
        {
            int No = 0;
            PatientList model = new PatientList();

            try
            {

                if (tempFacilityId != 0)
                {
                        List<PatientDetail> patientDetail = new List<PatientDetail>();

                        //   MySqlCommand cmd = new MySqlCommand("SELECT t1.U_Id,t1.EmailId,t1.F_Name,t1.L_Name,t1.MobileNo FROM userregister t1 INNER JOIN patient_otherinfo t2 ON t2.PatientId = t1.U_Id  where t1.FacilityId='" + tempFacilityId + "' and t1.R_Id='" + 10 + "' and t1.IsActive='" + 0 + "' and t2.IsDeactive='" + 0 + "' and t2.IsDeleted='" + 0 + "'", obj.con);
                        MySqlCommand cmd = new MySqlCommand("SELECT IFNULL(t1.U_Id, '') AS U_Id, IFNULL(t1.EmailId, '') AS EmailId, IFNULL(t1.F_Name, '') AS F_Name, IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t1.CreatedDate, '') AS CreatedDate,IFNULL(t1.MobileNo, '') AS MobileNo FROM userregister t1 INNER JOIN patient_otherinfo t2 ON t2.PatientId = t1.U_Id  where  t1.R_Id='" + 10 + "' and t1.IsActive='" + 0 + "' and t2.IsDeactive='" + 0 + "' and t1.Is_Reactive='" + 0 + "' order by CreatedDate desc", obj.con);

                        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                        //  string FName = Name;
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                No = No + 1;
                                patientDetail.Add(new PatientDetail
                                {
                                    SrNo = No,
                                    PatientId =SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                    Email = SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString()),
                                    FirstName = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()),
                                    LastName = SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString()),
                                    PrimaryContactNo = dt.Rows[i]["MobileNo"].ToString(),
                                    Edit = Connection.AllowUpdate,
                                    Delete = Connection.AllowDelete
                                });
                            }
                        }
                        model.patientList = patientDetail;
                    }
                else
                {
                    //ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                   // return RedirectToAction("AdminIndex", "Admin");
                }

            }
            catch (Exception e)
            {
            }
            return model;
        }

        public static PatientList GetWomacPatientList(int FacilitiId)       // --------------------------------- Get Womac Patient List
        {
            int No = 0;
            DbConnection obj = new DbConnection();

            PatientList model = new PatientList();
            try
            {
                List<PatientDetail> patientDetail = new List<PatientDetail>();
                string SqlQuery = @"SELECT distinct IFNULL(U_Id, '') AS U_Id,IFNULL(F_Name, '') AS F_Name,IFNULL(L_Name, '') AS L_Name,IFNULL(EmailId, '') AS EmailId,IFNULL(MobileNo, '') AS MobileNo  FROM userregister WHERE U_Id not in (SELECT IFNULL(PatientId, '') AS PatientId  FROM womac_test)  and R_Id = 10 and IsActive='" + 1 + "'";
                // string SqlQuery = @"SELECT distinct U_Id ,F_Name,L_Name,EmailId,MobileNo FROM userregister WHERE U_Id NOT IN (SELECT PatientId FROM womac_test) and IsActive='" + 1 + "'";
                //MySqlCommand cmd = new MySqlCommand("select t1.U_Id,t1.F_Name,t1.L_Name,t1.EmailId,t1.MobileNo from userregister t1 INNER JOIN patient_otherinfo t2 on t1.U_Id=t2.PatientId  where t1.FacilityId='" + FacilitiId + "' and t1.IsActive='" + 1 + "' and t1.R_Id='" + 10 + "' order by t2.Info_Id", obj.con);
                MySqlCommand cmd = new MySqlCommand(SqlQuery, obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        No++;
                        string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                        patientDetail.Add(new PatientDetail
                        {
                            SrNo = No,
                            //PatientId = SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                            PatientId =SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                            Email = dt.Rows[i]["EmailId"].ToString() != "" ? SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString()) : "NA",
                            FirstName = PN,
                            PrimaryContactNo = SecurityManager.Decrypt(dt.Rows[i]["MobileNo"].ToString()),
                            Edit = Connection.AllowUpdate,
                            Delete = Connection.AllowDelete
                        });
                    }
                }
                model.patientList = patientDetail;
            }
            catch (Exception e)
            {
            }
            return model;
        }

        public static int PatientBMIDetail(PatientRegistration model)  // --------------------------------- Post Patient BMI Data
        {
            DbConnection obj = new DbConnection();
            try
            {

                int Result = 0;
                DateTime BmiDate = DateTime.Parse(DateTime.Now.ToString());

                int Feet = model.HeightFeet;
                int Inch = model.HeightInch;

                int HeightInInch = Convert.ToInt16(model.Height);
                double BMIValue = HeightInInch * HeightInInch;

                BMIValue = 703.0 * Convert.ToInt32(model.Weight) / Convert.ToInt32(model.Height) / Convert.ToInt32(model.Height); // BMI Calculate 
                double BMI = Math.Round(BMIValue, 2, MidpointRounding.AwayFromZero);

                //Connection.BmiPatientId = model.PatientId;
                Connection.BmiPatientId = model.PatientId;

                Connection.height = model.Height;
                Connection.weight = Convert.ToInt32(model.Weight);
                Connection.BMI = Convert.ToDouble(BMI);

                MySqlCommand cmd = new MySqlCommand("select * from bmi_record where U_Id=@U_Id and Height=@Height and Weight=@Weight", obj.con);

                cmd.Parameters.AddWithValue("@U_Id", model.PatientId);
                cmd.Parameters.AddWithValue("@Height", model.Height);
                cmd.Parameters.AddWithValue("@Weight", model.Weight);

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count == 0)
                {
                    string Query1 = "Insert into bmi_record (U_Id,Height,Weight,CreatedOn,BMI) values ('" + model.PatientId + "','" + model.Height + "','" + model.Weight + "','" + Convert.ToDateTime(BmiDate).ToString("yyyy-MM-dd H:mm:ss") + "','" + BMI + "')";
                    MySqlCommand cmd1 = new MySqlCommand(Query1, obj.con);
                    obj.OpenDbConnection();
                    Result = cmd1.ExecuteNonQuery();
                    obj.CloseDbConnection();

                    string Query = "update patient_otherinfo set Height='" + model.Height + "',Weight='" + model.Weight + "',BMI='" + BMI + "' where PatientId='" + model.PatientId + "'";
                    MySqlCommand cmd12 = new MySqlCommand(Query, obj.con);
                    obj.OpenDbConnection();
                    cmd12.ExecuteNonQuery();
                    obj.CloseDbConnection();

                }
                else
                {
                    //----Update Height And Width In Patient Registration 

                    //string Query2 = "update patient_otherinfo set  Height='" + model.Height + "',Weight='" + model.Weight + "',BMI='" + BMI + "' where PatientId='" + model.PatientId + "'";
                    //MySqlCommand cmd2 = new MySqlCommand(Query2, obj.con);
                    //obj.OpenDbConnection();
                    //cmd2.ExecuteNonQuery();
                    //obj.CloseDbConnection();
                    //ErrorMessage = "New user '" + model.PatientId + "' is Added Successfully";
                    Result = 2;
                }
                return Result;
            }
            catch
            {
                ErrorMessage = "Some thing is not right Please Contact with Developer Team";
                return 0;
            }
        }

        public static int SavePhysicalTherapyDetail(PhysicalTherapyDetail model)    // --------------------------------- Post Physical Theripy Detail Data
        {
            DbConnection obj = new DbConnection();
            try
            {
                DateTime InjDate = DateTime.Parse(DateTime.Now.ToString());
                int SuccessId = 0, InjNo = 0, WomacNo = 0;
                MySqlCommand cmd = new MySqlCommand("select IFNULL(Max(InjectionNumber), '0') AS InjectionNumber,IFNULL(WOMAC_Name, '') AS WOMAC_Name from injectiondetails where PatientId='" + model.PatientId + "' and Knee='" + model.Knee + "'", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count != 0)
                {
                    //model.WomacTestId = dt.Rows[0]["WOMAC_Name"].ToString()!= 0 : Convert.ToInt32(dt.Rows[0]["WOMAC_Name"].ToString()):null;
                    string WomacId = dt.Rows[0]["WOMAC_Name"].ToString();
                    WomacId = WomacId != "" ? WomacId : "1";
                    model.WomacTestId = Convert.ToInt16(WomacId.ToString());
                    InjNo = Convert.ToInt32(dt.Rows[0]["InjectionNumber"]) + 1;
                }
                else
                {
                    InjNo = 1;
                }

                string Query = "insert into injectiondetails (PatientId,WOMAC_Name,PhysicianTherapist,Physician,IsPhysicalTherapist,Knee,Injected,InjectionNumber,TheraphyOn) values ('" + model.PatientId + "','" + model.WomacTestId + "','" + SecurityManager.Encrypt(model.Phy_TherapistName) + "','" + SecurityManager.Encrypt(model.PhysicianName) + "','" + model.Phy_Therapy + "','" + model.Knee + "','" + model.Injected + "','" + InjNo + "','" + Convert.ToDateTime(InjDate).ToString("yyyy-MM-dd") + "')";

                MySqlCommand cmd1 = new MySqlCommand(Query, obj.con);

                obj.OpenDbConnection();
                SuccessId = cmd1.ExecuteNonQuery();
                obj.CloseDbConnection();
                ErrorMessage = "Physical Therapy Detail save Successfully";
                return SuccessId;
            }
            catch (Exception e)
            {
                ErrorMessage = e.ToString();
                ErrorMessage = "Some thing is not right Please Contact with Developer Team";
                return 0;
            }
        }

        public static int PatientDeactive(string PatientID)                        // ---------------   Patient Deactive
        {
            DbConnection obj = new DbConnection();
            int result = 0;

            MySqlCommand cmd1 = new MySqlCommand("update `userregister` set `IsActive`=" + 0 + " where `U_Id`='" + PatientID + "'", obj.con);
            MySqlCommand cmd2 = new MySqlCommand("update patient_otherinfo set IsDeactive='" + 1 + "' where PatientId='" + PatientID + "'", obj.con);
            obj.OpenDbConnection();
            result = cmd1.ExecuteNonQuery();
            result = cmd2.ExecuteNonQuery();
            obj.CloseDbConnection();
            return result;
        }

        public static int PatientDelete(string PatientID)                        // ---------------   Patient Deactive
        {
            DbConnection obj = new DbConnection();
            int result = 0;

            MySqlCommand cmd1 = new MySqlCommand("update `userregister` set `IsActive`=" + 0 + " where `U_Id`='" + PatientID + "'", obj.con);
            MySqlCommand cmd2 = new MySqlCommand("update patient_otherinfo set IsDeactive='" + 0 + "' ,	IsDeleted='" + 1 + "' where PatientId='" + PatientID + "'", obj.con);
            obj.OpenDbConnection();
            result = cmd1.ExecuteNonQuery();
            result = cmd2.ExecuteNonQuery();
            obj.CloseDbConnection();
            return result;
        }

        public static PatientList GetDeactivePatientList(int FacilityID)       // ---------------  DeActive PAtient LIst 
        {
            int No = 0;
            DbConnection obj = new DbConnection();

            PatientList model = new PatientList();
            try
            {
                Connection.FacilityId = FacilityID;
                if (Connection.FacilityId != 0)
                {
                    List<PatientDetail> patientDetail = new List<PatientDetail>();
                    //MySqlCommand cmd = new MySqlCommand("SELECT t1.U_Id,t1.EmailId,t1.F_Name,t1.L_Name,t2.NickName,t1.MobileNo FROM userregister t1 INNER JOIN patient_otherinfo t2 ON t2.PatientId = t1.U_Id  where t1.FacilityId='" + FacilityID + "' and t1.R_Id='" + 10 + "' and t1.IsActive='" + 0 + "' order by t2.Info_Id", obj.con);
                    MySqlCommand cmd = new MySqlCommand("select distinct  IFNULL(t1.U_Id, '') AS U_Id ,t1.Is_Reactive,t1.Inactive,t1.IsActive,t2.IsDeactive, IFNULL(t1.EmailId, '') AS EmailId , IFNULL(t1.F_Name, '') AS F_Name , IFNULL(t1.L_Name, '') AS L_Name , IFNULL(t2.NickName, '') AS NickName , IFNULL(t1.MobileNo, '') AS MobileNo  from userregister t1 INNER JOIN patient_otherinfo t2 on t1.U_Id=t2.PatientId  where  t2.IsDeactive='" + 1 + "' and t1.R_Id='" + 10 + "' order by t2.Info_Id desc", obj.con);

                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            No = No + 1;
                            string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                          
                            patientDetail.Add(new PatientDetail
                            {
                                SrNo = No,
                                PatientId =SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                Email = dt.Rows[i]["EmailId"].ToString() != "" ? SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString()) : "NA",
                                FirstName = PN,
                                NickName = SecurityManager.Decrypt(dt.Rows[i]["NickName"].ToString()),
                                PrimaryContactNo = dt.Rows[i]["MobileNo"].ToString(),
                                Edit = Connection.AllowUpdate,
                                Delete = Connection.AllowDelete
                            });
                        }
                    }
                    model.patientList = patientDetail;
                }
            }
            catch (Exception e)
            {
            }
            return model;
        }

        public static PatientRegistration GetPatientDetail(string SelectedUserId)    // --------------- Active PAtion Data fatch
        {
            DbConnection obj = new DbConnection();
            GetPatientInformation ob = new GetPatientInformation();
            PatientRegistration PR = new Models.PatientRegistration();
            try
            {
                // MySqlCommand cmd = new MySqlCommand("SELECT t1.FacilityId,t1.U_Id,t1.F_Name,t1.L_Name,t1.EmailId,t1.Gender,t1.DOB,t2.Height,t2.Weight,t1.Address,t1.CityId,t1.StateId,t1.Zipcode,t1.MailingAddress,t1.MailingCity,t1.MailingState,t1.MailingZipcode,t1.EthnicityId,t1.MobileNo,t1.OtherContactNo,t1.Soc_Security,t2.NickName,t2.Occupation,t2.Employer,	t2.Emp_Street,t2.Emp_CityId,t2.Emp_StateId,t2.Emp_Zipcode,t2.Emp_ContactNo,t2.Edu_Id,t2.PINNO,t2.WorkType,t2.WheelChair,t2.ContactAtWork,t2.KnowAbtUs,t2.HaveChiropracticPhysician,t2.Chiro_PhysicianName,t2.PrimaryPhysician,t2.Prim_PhysicianName FROM userregister t1 INNER JOIN  patient_otherinfo t2 ON t1.U_Id=t2.PatientId WHERE t1.U_Id='" + SecurityManager.Encrypt(SelectedUserId) + "'", obj.con);

                MySqlCommand cmd = new MySqlCommand("SELECT IFNULL(t1.FacilityId, '') AS FacilityId,IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t1.EmailId, '') AS EmailId,IFNULL(t1.Gender, '') AS Gender,IFNULL(t1.DOB, '') AS DOB,IFNULL(t2.Height, '') AS Height,IFNULL(t2.Weight, '') AS Weight,IFNULL(t1.Address, '') AS Address,IFNULL(t1.CityId, '') AS CityId,IFNULL(t1.StateId, '') AS StateId FROM userregister t1 INNER JOIN  patient_otherinfo t2 ON t1.U_Id=t2.PatientId WHERE t1.U_Id='" + SelectedUserId + "'", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    PR.PatientId = SelectedUserId;
                    PR.UserNameId = SecurityManager.Decrypt(dt.Rows[0]["U_Id"].ToString());
                    PR.FacilityId = dt.Rows[0]["FacilityId"].ToString();
                    PR.FirstName = SecurityManager.Decrypt(dt.Rows[0]["F_Name"].ToString());
                    PR.LastName = SecurityManager.Decrypt(dt.Rows[0]["L_Name"].ToString());
                    PR.Gender = dt.Rows[0]["Gender"].ToString().Trim();

                    if (!String.IsNullOrEmpty(dt.Rows[0]["DOB"].ToString()))
                    {
                        PR.BirthDate = Convert.ToDateTime(dt.Rows[0]["DOB"].ToString()).ToString("MMMM-dd-yyyy");
                        PR.AgeOnDate = ob.AgeCalculator(Convert.ToDateTime(dt.Rows[0]["DOB"].ToString()));
                    }
                    else { PR.BirthDate = ""; PR.AgeOnDate = ""; }

                    PR.Height = String.IsNullOrEmpty(dt.Rows[0]["Height"].ToString()) ? "0" : dt.Rows[0]["Height"].ToString();

                    Int16 TempHeight = Convert.ToInt16(PR.Height);

                    PR.HeightFeet = Convert.ToInt16(TempHeight / 12);
                    PR.HeightInch = Convert.ToInt16(TempHeight % 12);

                    PR.Weight = Convert.ToInt16(dt.Rows[0]["Weight"].ToString());
                    PR.EmpStreet = dt.Rows[0]["Address"].ToString();
                    PR.CityId = dt.Rows[0]["CityId"].ToString() == "" ? "0" : dt.Rows[0]["CityId"].ToString();
                    PR.StateId = dt.Rows[0]["StateId"].ToString() == "" ? "0" : dt.Rows[0]["StateId"].ToString();
                   // PR.ZipCode = dt.Rows[0]["Zipcode"].ToString() == "" ? "" : dt.Rows[0]["Zipcode"].ToString();
                    PR.EmailId = SecurityManager.Decrypt(dt.Rows[0]["EmailId"].ToString());
                }
                return PR;
            }
            catch (Exception e)
            {
                return PR;
            }
        }

        public static alertlist GetPatientFirstAlertList(int alertid)     //fatch patient in 45 days alert
        {
         List<PatientAlertList> patientalertdetail = new List<PatientAlertList>();
         alertlist model = new alertlist();
         try
         {
             string query = "SELECT  IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t1.EmailId, 'NA') AS EmailId,IFNULL(t1.MobileNo, '') AS MobileNo,t1.CreatedDate,t1.InactiveDate,t1.IsActive,t1.Inactive  FROM  userregister as t1 inner join alert_complete_tbl as t2 on t1.U_Id=t2.patient_id where t1.R_Id=10 and t1.Inactive=1 and t2.alert_day_id='" + alertid + "' and t2.status!='" + "True" + "' and t2.IsDeleted!='" + "True" + "'";
             MySqlCommand cmd = new MySqlCommand(query, obj.con);
             MySqlDataAdapter da = new MySqlDataAdapter(cmd);
             DataTable dt = new DataTable();
             da.Fill(dt);
             if (dt.Rows.Count > 0)
             {
                 for (int i = 0; i < dt.Rows.Count; i++)
                 {
                     int srno = i + 1;
                     string patientid = dt.Rows[i]["U_Id"].ToString();
                     string Emailid = SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString()).Trim();
                     if (Emailid == "")
                     {
                         Emailid = "NA";
                     }

                     DateTime createddate = Convert.ToDateTime(dt.Rows[i]["InactiveDate"].ToString());
                     string firstalerts = null; string secondalerts = null; string thirdalert = null;
                    // firstalerts = GetPatientInformation.firstalertstatus(patientid,1);
                  
                     if (firstalerts == null)
                     {
                         firstalerts = createddate.AddDays(45).ToString("MM/dd/yyyy");
                     }
                     if (secondalerts == null) 
                     {
                         secondalerts = createddate.AddDays(90).ToString("MM/dd/yyyy");
                     }
                     if (thirdalert == null)
                     {
                         thirdalert = createddate.AddDays(120).ToString("MM/dd/yyyy");
                     }
                   
                     int status = Convert.ToInt16(dt.Rows[i]["Inactive"]);
                     string statuss = "";
                     if (status == 0)
                     {
                         statuss = "Deactive";
                     }
                     else if (status == 1)
                     {
                         statuss = "Inactive";
                     }
                     string patientname = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());

                     patientalertdetail.Add(new PatientAlertList
                     {
                         SrNo = srno,
                         FirstName = patientname,
                         Email = Emailid,
                         PrimaryContactNo = dt.Rows[i]["MobileNo"].ToString(),
                         firstalert = firstalerts,
                         secondalert = secondalerts,
                         thirdalert = thirdalert,
                         PatientId = SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                      
                         status = statuss


                     });
                 }
                 model.patientalertlistt = patientalertdetail;
             }
         }
         catch
         { 
         
         }
        
         return model;
        }
        



        public static PatientList GetReActivePatientList(int FacilityID)       // ---------------  Re-Active PAtient LIst 
        {
            int No = 0;
            DbConnection obj = new DbConnection();

            PatientList model = new PatientList();
            try
            {
                Connection.FacilityId = FacilityID;

                if (Connection.FacilityId != 0)
                {
                    List<PatientDetail> patientDetail = new List<PatientDetail>();
                    MySqlCommand cmd = new MySqlCommand("SELECT IFNULL(t1.U_Id, '') AS U_Id, IFNULL(t1.EmailId, '') AS EmailId, IFNULL(t1.F_Name, '') AS F_Name, IFNULL(t1.L_Name, '') AS L_Name, IFNULL(t2.NickName, '') AS NickName, IFNULL(t1.MobileNo, '') AS MobileNo,t1.InactiveDate,t1.Inactive,t1.Is_Reactive FROM userregister t1 INNER JOIN patient_otherinfo t2 ON t2.PatientId = t1.U_Id  where  t1.R_Id='" + 10 + "' and t1.IsActive='" + 1 + "' and t1.Is_Reactive='" + 1 + "'  order by t2.Info_Id", obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            No = No + 1;
                         
                            string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                            string Emailid = SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString()).Trim();
                            if (Emailid == "")
                            {
                                Emailid = "NA";
                            }

                           
                            patientDetail.Add(new PatientDetail
                            {
                                SrNo = No,
                                PatientId =SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                Email = Emailid,
                                FirstName = PN,
                                NickName = SecurityManager.Decrypt(dt.Rows[i]["NickName"].ToString()),
                                PrimaryContactNo = dt.Rows[i]["MobileNo"].ToString(),
                                Edit = Connection.AllowUpdate,
                                Delete = Connection.AllowDelete
                                //firstalert=firstalerts,
                                //secondalert=secondalerts,
                                //thirdalert=thirdalerts,
                                //status=Status

                            });
                        }
                    }
                    model.patientList = patientDetail;
                }
            }
            catch (Exception e)
            {
            }
            return model;
        }

        public static PatientList GetPatientListForNewComplain(int FacilityID)
        {
            int No = 0;
            DbConnection obj = new DbConnection();
            PatientList model = new PatientList();
            try
            {
                Connection.FacilityId = FacilityID;
                if (Connection.FacilityId != 0)
                {
                    List<PatientDetail> patientDetail = new List<PatientDetail>();

                    MySqlCommand cmd = new MySqlCommand("SELECT IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.EmailId, '') AS EmailId,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.NickName, '') AS NickName,IFNULL(t1.MobileNo, '') AS MobileNo FROM userregister t1 LEFT JOIN patient_otherinfo t2 ON t2.PatientId = t1.U_Id  where t1.R_Id='" + 10 + "' and t1.IsActive='" + 1 + "' order by t2.Info_Id", obj.con);

                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {

                            string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                            No = No + 1;
                            patientDetail.Add(new PatientDetail
                            {
                                SrNo = No,
                                PatientId =SecurityManager.Decrypt( dt.Rows[i]["U_Id"].ToString()),
                                Email = dt.Rows[i]["EmailId"].ToString() != "" ? SecurityManager.Decrypt(dt.Rows[i]["EmailId"].ToString()) : "NA",
                                FirstName = PN,
                                NickName = SecurityManager.Decrypt(dt.Rows[i]["NickName"].ToString()),
                                PrimaryContactNo = dt.Rows[i]["MobileNo"].ToString(),
                                Edit = Connection.AllowUpdate,
                                Delete = Connection.AllowDelete
                            });
                        }
                    }
                    model.patientList = patientDetail;
                }
            }
            catch (Exception e)
            {
            }
            return model;
        }


        public static int PatientReactive(string PatientID)                        // ---------------   Patient Deactive
        {
            DbConnection obj = new DbConnection();
            int result = 0;

            MySqlCommand cmd1 = new MySqlCommand("update `userregister` set `IsActive`=" + 1 + " where `U_Id`='" + PatientID + "'", obj.con);
            MySqlCommand cmd2 = new MySqlCommand("update patient_otherinfo set IsDeactive='" + 0 + "' and IsReactive ='" + 1 + "' where PatientId='" + PatientID + "'", obj.con);
            obj.OpenDbConnection();
            result = cmd1.ExecuteNonQuery();
            result = cmd2.ExecuteNonQuery();
            obj.CloseDbConnection();
            return result;
        }

        // All PAtient Womac List

        public static PatientWomacReportList GetWomacList(int LoggedFacilityId,int update=0)
         {

            int No = 0;
            PatientWomacReportList model = new PatientWomacReportList();
            try
            {
                if (LoggedFacilityId != 0)
                {
                    List<PatientWomacReport> PatientWomacReportDetail = new List<PatientWomacReport>();
                    string query = "";
                    if (update == 1)
                    {
                        query = "SELECT IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.FacilityId, '') AS FacilityId,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee,IFNULL(WOMAC_TestOn, '') AS WOMAC_TestOn, IFNULL(WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,max(case when t2.WOMAC_Name = '1' then t2.Complete else ' 'end) as '1', max(case when t2.WOMAC_Name = '2' then t2.Complete else ' 'end) as '2',max(case when t2.WOMAC_Name = '3' then t2.Complete else ' 'end) as '3' FROM userregister t1 INNER JOIN  womac_test t2 ON t2.PatientId = t1.U_Id where t1.IsActive = 1 and t1.R_Id =10 group by  t1.U_Id  order by WOMAC_TestOn desc";
                    }
                    else {
                        query = "SELECT IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.FacilityId, '') AS FacilityId,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee,IFNULL(WOMAC_TestOn, '') AS WOMAC_TestOn, IFNULL(WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,max(case when t2.WOMAC_Name = '1' then t2.Complete else ' 'end) as '1', max(case when t2.WOMAC_Name = '2' then t2.Complete else ' 'end) as '2',max(case when t2.WOMAC_Name = '3' then t2.Complete else ' 'end) as '3' FROM userregister t1 INNER JOIN  womac_test t2 ON t2.PatientId = t1.U_Id where t1.IsActive = 1 and  t1.Inactive=0 and t1.R_Id =10 group by  t1.U_Id  order by WOMAC_TestOn desc";
                    }

                    MySqlCommand cmd = new MySqlCommand(query, obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);

                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            No = No + 1;
                            string PatientID = dt.Rows[i]["U_Id"].ToString();

                            string Kneevalue = dt.Rows[i]["Knee"].ToString() == "Left Knee,Right Knee" ? "Left Knee,Right Knee" : dt.Rows[i]["Knee"].ToString();

                            string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());

                            string WomacTestDate1 = null, WomacTestDate2 = null, WomacTestDate3 = null, IsComplete2 = null, IsComplete3 = null;

                            DataTable Dtw1 = WomacCalender.GetWomacNo(PatientID, 1, Convert.ToInt16(LoggedFacilityId));
                            DataTable Dtw2 = WomacCalender.GetWomacNo(PatientID, 2, Convert.ToInt16(LoggedFacilityId));
                            DataTable Dtw3 = WomacCalender.GetWomacNo(PatientID, 3, Convert.ToInt16(LoggedFacilityId));
                            DataTable Dtw = WomacCalender.GetAllWomac(PatientID, Convert.ToInt16(LoggedFacilityId));

                            if (Dtw.Rows.Count >= 2)
                            {

                                for (int j = 0; j < Dtw.Rows.Count; j++)
                                {
                                    No = No + j;
                                    Kneevalue = null;
                                    Kneevalue = Dtw.Rows[j]["Knee"].ToString();

                                    WomacTestDate1 = WomacCalender.WoMacTestDate(Dtw.Rows[j]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw.Rows[j]["1"].ToString());
                                    if (Dtw2.Rows.Count != 0)
                                    {
                                        WomacTestDate2 = WomacCalender.WoMacTestDate(Dtw.Rows[j]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw.Rows[j]["2"].ToString());
                                    }
                                    if (Dtw3.Rows.Count != 0)
                                    {
                                        WomacTestDate3 = WomacCalender.WoMacTestDate(Dtw.Rows[j]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw.Rows[j]["3"].ToString());
                                    }

                                    if (WomacTestDate2 == null || WomacTestDate2 == "")
                                    {
                                        WomacTestDate2 = Convert.ToDateTime(Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " ")).AddDays(15).ToString("MMM-dd-yyyy");

                                    }
                                    if (WomacTestDate3 == null || WomacTestDate3 == "")
                                    {
                                        if (WomacTestDate2 == "Complete")
                                        {
                                            WomacTestDate3 = Convert.ToDateTime(WomacTestDate2).AddDays(15).ToString("MMM-dd-yyyy");
                                        }
                                        if (WomacTestDate2 == "Due Date")
                                        {
                                            WomacTestDate3 = "-";
                                        }
                                    }

                                    if (WomacTestDate1 == "Due Date")
                                    {
                                        WomacTestDate2 = "-";
                                        WomacTestDate3 = "-";
                                    }

                                    if (WomacTestDate2 == "Due Date")
                                    {
                                        WomacTestDate3 = "-";

                                    }

                                    PatientWomacReportDetail.Add(new PatientWomacReport
                                    {
                                        SrNo = No,
                                        PatientId =SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                        PatientName = PN,
                                        Knee = Kneevalue,
                                        Womac1 = WomacTestDate1,
                                        Womac2 = WomacTestDate2,
                                        Womac3 = WomacTestDate3
                                    });
                                }
                            }
                            else
                            {

                                int WomacNo = 0;

                                if (Dtw3.Rows.Count > 0)
                                {
                                    WomacNo = Convert.ToInt16(Dtw3.Rows[0]["WOMAC_Name"].ToString());
                                }
                                else if (Dtw2.Rows.Count > 0)
                                {
                                    WomacNo = Convert.ToInt16(Dtw2.Rows[0]["WOMAC_Name"].ToString());
                                }
                                else if (Dtw1.Rows.Count > 0)
                                {
                                    WomacNo = Convert.ToInt16(Dtw1.Rows[0]["WOMAC_Name"].ToString());
                                }

                                if (WomacNo == 1)
                                {

                                    WomacTestDate1 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw1.Rows[0]["Complete"].ToString());
                                    WomacTestDate2 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_NexttestOn"].ToString(), IsComplete2);
                                    WomacTestDate3 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_NexttestOn"].ToString(), IsComplete3);

                                    if ((WomacTestDate2 == WomacTestDate3) && (WomacTestDate2 != "" && WomacTestDate3 != "") && (WomacTestDate2 != null && WomacTestDate3 != null))
                                    {
                                        WomacTestDate3 = Convert.ToDateTime(WomacTestDate2).AddDays(15).ToString("MMM-dd-yyyy");
                                    }
                                }
                                else if (WomacNo == 2)
                                {
                                    WomacTestDate1 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw1.Rows[0]["Complete"].ToString());
                                    WomacTestDate2 = WomacCalender.WoMacTestDate(Dtw2.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw2.Rows[0]["Complete"].ToString());
                                    WomacTestDate3 = WomacCalender.WoMacTestDate(Dtw2.Rows[0]["WOMAC_NexttestOn"].ToString(), IsComplete3);
                                    if (WomacTestDate3 == "" && WomacTestDate2 == "Completed")
                                    {

                                        WomacTestDate3 = Convert.ToDateTime(Dtw2.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " ")).AddDays(15).ToString("MMM-dd-yyyy");
                                        // WomacTestDate3 = "-";
                                    }

                                }
                                else if (WomacNo == 3)
                                {
                                    WomacTestDate1 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw1.Rows[0]["Complete"].ToString());
                                    if (Dtw2.Rows.Count != 0)
                                    {
                                        WomacTestDate2 = WomacCalender.WoMacTestDate(Dtw2.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw2.Rows[0]["Complete"].ToString());
                                    }
                                    if (Dtw3.Rows.Count != 0)
                                    {
                                        WomacTestDate3 = WomacCalender.WoMacTestDate(Dtw3.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw3.Rows[0]["Complete"].ToString());
                                    }
                                }
                                if (WomacTestDate2 == null || WomacTestDate2 == "")
                                {
                                    if (WomacTestDate1 == "Completed")
                                    {
                                        WomacTestDate2 = Convert.ToDateTime(Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " ")).AddDays(15).ToString("MMM-dd-yyyy");
                                    }
                                    else if (WomacTestDate1 == "Due Date")
                                    {
                                        WomacTestDate2 = "-";
                                    }
                                    if (WomacTestDate2 != "")
                                    {
                                        if (WomacTestDate2 == "-" || WomacTestDate2 == "Due Date")
                                        {
                                            WomacTestDate3 = "-";
                                        }
                                        else
                                        {
                                            WomacTestDate3 = Convert.ToDateTime(WomacTestDate2).AddDays(15).ToString("MMM-dd-yyyy");
                                        }
                                    }

                                }
                                if (WomacTestDate3 == null || WomacTestDate3 == "")
                                {
                                    if (WomacTestDate2 == "Completed")
                                    {
                                        WomacTestDate3 = Convert.ToDateTime(WomacTestDate2).AddDays(15).ToString("MMM-dd-yyyy");
                                    }
                                    else if (WomacTestDate2 == "Due Date")
                                    {
                                        WomacTestDate3 = "-";
                                    }
                                    else if (WomacTestDate2 == "" || WomacTestDate2 == null)
                                    {
                                        WomacTestDate3 = "-";
                                    }
                                }
                                if (WomacTestDate1 == "Due Date")
                                {
                                    WomacTestDate2 = "-";
                                    WomacTestDate3 = "-";
                                }

                                if (WomacTestDate2 == "Due Date")
                                {
                                    WomacTestDate3 = "-";

                                }

                                PatientWomacReportDetail.Add(new PatientWomacReport
                                {
                                    SrNo = No,
                                    PatientId =SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                    PatientName = PN,
                                    Knee = Kneevalue,
                                    Womac1 = WomacTestDate1,
                                    Womac2 = WomacTestDate2,
                                    Womac3 = WomacTestDate3
                                    
                                });

                            }
                        }
                    }
                    model.PatientWomacRepotList = PatientWomacReportDetail;
                }
            }
            catch (Exception e)
            {
            }
            return model;
        }
    }
}