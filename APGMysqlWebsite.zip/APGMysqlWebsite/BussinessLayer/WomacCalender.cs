﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.BussinessLayer;
using NewAPGApplication.Models;

namespace NewAPGApplication.BussinessLayer
{
    public class WomacCalender
    {
        static DbConnection obj = new DbConnection();

        public static string WoMacTestDate(string Womacdate1, string Complete)
        {
            string WomacTestDate = "";
            if (Womacdate1 != "" && Womacdate1 != null)
            {
               // DateTime TodayDate = DateTime.Parse(DateTime.Now.Date.ToString("yyyy-MM-dd HH':'mm':'ss"));
                DateTime TodayDate = DateTime.Now;
                string str = String.Format("{0:00}-{1:00}-{2:0000} {3:00}:{4:00}:{5:00}", TodayDate.Month, TodayDate.Day, TodayDate.Year, TodayDate.Hour, TodayDate.Minute, TodayDate.Second);
                string tDate = TodayDate.ToString().Replace("12:00:00 AM", " ");
                 DateTime WomacDate = new DateTime();
                try
                {
                    WomacDate = DateTime.Parse(Womacdate1.ToString());
                }
                catch(Exception ex)
                {
                
                }

            int result = DateTime.Compare(TodayDate, WomacDate);
            int result1 = DateTime.Compare(WomacDate, TodayDate);

            if ((WomacDate <= TodayDate))
            {
                if (Complete == "True")
                {
                    WomacTestDate = "Completed";
                }
                else
                {
                    if (Complete == "False")
                    {
                        WomacTestDate = "Due Date";
                    }
                    
                }
            }
            else
            {
                if ((WomacDate <= TodayDate))
                {
                    WomacTestDate = "Due Date";
                }
                else
                {
                    WomacTestDate = WomacDate.ToString("MMM-dd-yyyy");
                }
            }

        }
            return WomacTestDate;
        }

        public static string WoMacTestDate_III(string Womacdate1, string Complete)
        {
            string WomacTestDate = null;

            string MonthName;

            int Fdate;

            int Date, month, year, DayOfMonth, WDate;

            DateTime TodayDate = DateTime.Parse(DateTime.Now.ToString());
            DateTime WomacDate = new DateTime();
            try
            {
               WomacDate = DateTime.Parse(Womacdate1.ToString());
            }
            catch(Exception ex){
            
            }
           

            Date = WomacDate.Day;
            month = WomacDate.Month;
            year = WomacDate.Year;

            WomacDate=WomacDate.AddDays(15);
          //  WDate = Date + 15;
            WDate = WomacDate.Day;
            Date = WomacDate.Day;
            month = WomacDate.Month;
            year = WomacDate.Year;

            DayOfMonth = DateTime.DaysInMonth(year, month);
            if (WDate > DayOfMonth)
            {
                int OverDay = WDate - DayOfMonth;
                Fdate = OverDay;
                month = month + 1;
            }
            else
            {
                Fdate = WDate;
            }

            if (month == 1)
            {
                MonthName = "Jan";
                WomacTestDate = Convert.ToString(MonthName) + "-" + Fdate + "-" + year + "";
            }
            else if (month == 2)
            {
                MonthName = "Feb";
                WomacTestDate = Convert.ToString(MonthName) + "-" + Fdate + "-" + year + "";
            }
            else if (month == 3)
            {
                MonthName = "March";
                WomacTestDate = Convert.ToString(MonthName) + "-" + Fdate + "-" + year + "";
            }
            else if (month == 4)
            {
                MonthName = "April";
                WomacTestDate = Convert.ToString(MonthName) + "-" + Fdate + "-" + year + "";
            }
            else if (month == 5)
            {
                MonthName = "May";
                WomacTestDate = Convert.ToString(MonthName) + "-" + Fdate + "-" + year + "";
            }
            else if (month == 6)
            {
                MonthName = "Jun";
                WomacTestDate = Convert.ToString(MonthName) + "-" + Fdate + "-" + year + "";
            }
            else if (month == 7)
            {
                MonthName = "July";
                WomacTestDate = Convert.ToString(MonthName) + "-" + Fdate + "-" + year + "";
            }
            else if (month == 8)
            {
                MonthName = "Aug";
                WomacTestDate = Convert.ToString(MonthName) + "-" + Fdate + "-" + year + "";
            }
            else if (month == 9)
            {
                MonthName = "Sept";
                WomacTestDate = Convert.ToString(MonthName) + "-" + Fdate + "-" + year + "";
            }
            else if (month == 10)
            {
                MonthName = "Oct";
                WomacTestDate = Convert.ToString(MonthName) + "-" + Fdate + "-" + year + "";
            }
            else if (month == 11)
            {
                MonthName = "Nov";
                WomacTestDate = Convert.ToString(MonthName) + "-" + Fdate + "-" + year + "";
            }
            else if (month == 12)
            {
                MonthName = "Dec";
                WomacTestDate = Convert.ToString(MonthName) + "-" + Fdate + "-" + year + "";
            }

            return WomacTestDate;
        }

        public static string CheckInjectionTestDate(string LastInjectionDate, int Dayes)
        {
            string InjectiondateDate = null;
            DateTime WomacDate = Convert.ToDateTime(LastInjectionDate);
            DateTime CDate = DateTime.Parse(DateTime.Now.Date.ToShortDateString());

            DateTime NextDate = WomacDate.AddDays(Dayes);
            if (NextDate <= CDate)
            {
                InjectiondateDate = "Date Due";
            }
            else
            {
                InjectiondateDate = NextDate.ToString("MMM-dd-yyyy");
            }
            return InjectiondateDate;
        }


        public static DataTable GetWomacNo(string PatientId, int WomacNo, Int16 FacilityId)
        {
            string qry = "";


            qry = "SELECT distinct IFNULL(t2.PatientId, '') AS PatientId,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee,IFNULL(t2.WOMAC_TestOn, '') AS WOMAC_TestOn,IFNULL(t2.WOMAC_Name, '') AS WOMAC_Name,IFNULL(t2.WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,IFNULL(t2.Complete, '') AS Complete FROM userregister t1 INNER JOIN  womac_test t2 ON t1.U_Id=t2.PatientId where t1.U_Id='" + PatientId + "' and t2.WOMAC_Name='" + WomacNo + "' and t1.R_Id='" + 10 + "' and t1.IsActive='" + 1 + "' group by t2.Knee";
            
           
            MySqlCommand cmd1 = new MySqlCommand(qry, obj.con);

            MySqlDataAdapter ada = new MySqlDataAdapter(cmd1);

            DataTable dtt = new DataTable();
            ada.Fill(dtt);
            
            return dtt;
        }

        public static DataTable GetAllWomac(string PatientId, Int16 FacilityId)
        {
            string qry = "";

            qry = "SELECT IFNULL(t2.PatientId, '') AS PatientId,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee,IFNULL(t2.WOMAC_TestOn, '') AS WOMAC_TestOn,IFNULL(t2.WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,max(case when t2.WOMAC_Name = '1' then t2.Complete else ' 'end) as '1',max(case when t2.WOMAC_Name = '2' then t2.Complete else ' 'end) as '2',max(case when t2.WOMAC_Name = '3' then t2.Complete else ' 'end) as '3'  FROM userregister t1 INNER JOIN  womac_test t2 ON t1.U_Id=t2.PatientId where t1.U_Id= '" + PatientId + "' and t1.R_Id= 10  and t1.IsActive= 1";
            // qry = "SELECT distinct IFNULL(t2.PatientId, '') AS PatientId,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee,IFNULL(t2.WOMAC_TestOn, '') AS WOMAC_TestOn,IFNULL(t2.WOMAC_Name, '') AS WOMAC_Name,IFNULL(t2.WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,IFNULL(t2.Complete, '') AS Complete FROM userregister t1 INNER JOIN  womac_test t2 ON t1.U_Id=t2.PatientId where t1.U_Id='" + PatientId + "' and t1.R_Id='" + 10 + "' and t1.IsActive='" + 1 + "'";


            MySqlCommand cmd1 = new MySqlCommand(qry, obj.con);

            MySqlDataAdapter ada = new MySqlDataAdapter(cmd1);

            DataTable dtt = new DataTable();
            ada.Fill(dtt);

            return dtt;

        }


        public static DataTable GetPatientWomacNo(string PatientId, int WomacNo)
        {
            MySqlCommand cmd1 = new MySqlCommand("SELECT distinct IFNULL(t2.PatientId, '') AS PatientId,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee,IFNULL(t2.WOMAC_TestOn, '') AS WOMAC_TestOn,IFNULL(t2.WOMAC_Name, '') AS WOMAC_Name,IFNULL(t2.WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,IFNULL(t2.Complete, '') AS Complete FROM userregister t1 INNER JOIN  womac_test t2 ON t1.U_Id=t2.PatientId where t1.U_Id='" + PatientId + "' and t2.WOMAC_Name='" + WomacNo + "' and t1.R_Id='" + 10 + "' and t1.IsActive='" + 1 + "'", obj.con);

            MySqlDataAdapter ada = new MySqlDataAdapter(cmd1);

            DataTable dtt = new DataTable();
            ada.Fill(dtt);

            return dtt;
        }

        public static DataSet GetPatientWomacScore(string PatientId ,int Womacno)
        {
            MySqlCommand cmd = new MySqlCommand("SELECT distinct IFNULL(t2.PatientId, '') AS PatientId,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee,IFNULL(t2.TotalScore, '') AS TotalScore,IFNULL(t2.WOMAC_TestOn, '') AS WOMAC_TestOn,IFNULL(t2.WOMAC_Name, '') AS WOMAC_Name,IFNULL(t2.WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,IFNULL(t2.Complete, '') AS Complete FROM userregister t1 INNER JOIN  womac_test t2 ON t1.U_Id=t2.PatientId where t1.U_Id='" + PatientId + "' and t2.WOMAC_Name='" + Womacno + "' and t1.IsActive='" + 1 + "'", obj.con);

            MySqlDataAdapter ada = new MySqlDataAdapter(cmd);
            DataSet dset = new DataSet();
            ada.Fill(dset);
            return dset;
        }
    }
}