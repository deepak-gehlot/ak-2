﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.Models;

namespace NewAPGApplication.BussinessLayer
{
    public class CheckSession
    {
        public static int SessionCheck(int CheckNo)
        {
            int returnValue = 0;
            if (CheckNo == 1)
            {
                //if (Session["UserIdentityForLayOut"] != null)
                //{
                //    if (Session["LoginUserId"] != null)
                //    {
                //        returnValue = 1;
                //    }
                //}
            }
            if (CheckNo == 2)
            {
                //if (Session["UserIdentityForLayOut"] != null)
                //{
                //    if (Session["UserTypeId"] != null)
                //    {
                //        returnValue = 1;
                //    }
                //}
            }
            return returnValue;
        }
    }
}