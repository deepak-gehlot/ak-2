﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.BussinessLayer;
using NewAPGApplication.Models;
using System.Net;
using System.Globalization;


namespace NewAPGApplication.BussinessLayer
{
    public class AdminClass
    {
        static DbConnection obj = new DbConnection();
        static DateTime LoginDate = DateTime.Parse(DateTime.Now.ToString());
        static string mobileformat = null;
        public static DataTable GetInjKneeDetail(string PatientId)
        {
            DataTable dt = null;

            MySqlCommand cmd = new MySqlCommand("select IFNULL((InjectionId), '') AS InjectionId,IFNULL(PatientId, '') AS PatientId,IFNULL(PhysicianTherapist, '') AS PhysicianTherapist,IFNULL(Physician, '') AS Physician,IFNULL(Knee, '') AS Knee,IFNULL(Injected, '') AS Injected from injectiondetails where PatientId= '" +SecurityManager.Encrypt( PatientId) + "'", obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);    
            return dt;
        }

        public static string GetKneeType(string PatientId)
        {
            string KneeType = "";

            MySqlCommand cmd = new MySqlCommand("select IFNULL(PatientId, '') AS PatientId,IFNULL(Knee, '') AS Knee from  womac_test where PatientId= '" + PatientId + "'", obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count != 0)
            {
                KneeType = dt.Rows[0]["Knee"].ToString();
            }
            return KneeType;
        }
        public static List<patientalertlist1> GetNotes(string id, int alertid)
        {
            List<patientalertlist1> patientalertlist1 = new List<patientalertlist1>();
            //patientalertlist1 patient1 = new patientalertlist1();
            string query = null;
            if (alertid == 2)
            {
                query = "select note,alert_day_id,Update_Date from alert_complete_tbl where patient_id='" + SecurityManager.Encrypt(id) + "' and	alert_day_id=1 ";
            }
            else if (alertid == 3)
            {
                query = "select note,alert_day_id,Update_Date from alert_complete_tbl where patient_id='" + SecurityManager.Encrypt(id) + "' and	alert_day_id=2 ";
         
            }
                MySqlCommand cmd = new MySqlCommand(query,obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                string alertday = null;
                int alertidd = Convert.ToInt16(dt.Rows[0]["alert_day_id"].ToString());

                if (alertidd == 1)
                {
                    alertday = "45 Day Alert";
                }
                else if (alertidd == 2)
                {
                    alertday = "90 Day Alert";
                }
              
                DateTime adddate =Convert.ToDateTime(dt.Rows[0]["Update_Date"].ToString());
                string ddate = adddate.ToString("MM/dd/yyyy");
                patientalertlist1.Add(new patientalertlist1
                {
                    note = dt.Rows[0]["note"].ToString(),
                    alertdate = ddate,
                    allertid = alertday

                });
            } 
            return patientalertlist1;
        
        }
        public static int Insertalertstatus(ShowUserDetailsModel model)
        {
            int success=0;
            try
            {
               // string patientid = SecurityManager.Encrypt(model.).ToString();
                string query1 = "select * from alert_complete_tbl where patient_id='" +SecurityManager.Encrypt( model.Pid) + "' and alert_day_id='" +model.Alertid + "'";
                MySqlCommand cmd1 = new MySqlCommand(query1, obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd1);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    string query = "update alert_complete_tbl set `note`='" + model.mailbody + "',Update_Date=@updatedate where patient_id='" +SecurityManager.Encrypt(model.Pid) + "' and alert_day_id='" +model.Alertid + "'";
                    MySqlCommand cmd = new MySqlCommand(query, obj.con);
                    cmd.Parameters.AddWithValue("@updatedate", Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss tt")));
                    if (obj.con.State == ConnectionState.Closed)
                    {
                        obj.OpenDbConnection();
                    }
                    success = cmd.ExecuteNonQuery();

                }
                else
                {
                    string query = "insert into `alert_complete_tbl`(`patient_id`,`alert_day_id`,`note`,Update_Date)values('" +SecurityManager.Encrypt( model.Pid )+ "','" + model.Alertid + "','" + model.mailbody + "',@updatedate)";
                    MySqlCommand cmd = new MySqlCommand(query, obj.con);
                    cmd.Parameters.AddWithValue("@updatedate", Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss tt")));
                    if (obj.con.State == ConnectionState.Closed)
                    {
                        obj.OpenDbConnection();
                    }
                    success = cmd.ExecuteNonQuery();
                }
            }
            catch
            {

            }
            finally
            {
                obj.CloseDbConnection();
            }
            return success;
        }

        public static int UserLogDetail(UserLogDetail ULD)
        {
            try
            {
                int SuccessId = 0;
                string hostName = Dns.GetHostName();
                string SystemIP = Dns.GetHostByName(hostName).AddressList[0].ToString();

                string time = DateTime.Now.ToString("H:mm tt").ToString();
                //Convert.ToDateTime(LoginDate).ToString("yyyy-MM-dd")
                string Query = "INSERT INTO userlogdetails(R_id,U_Id,LoginOn,LogTime,System_IP, ViewName, OperationName, Detail, ModifiedRecord, DetailForUserView) VALUES ('" + ULD.UserTypeId + "','" + ULD.UserId + "','" + Convert.ToDateTime(LoginDate).ToString("yyyy-MM-dd") + "','" + DateTime.Now.ToString("H:mm tt").ToString() + "','" + SystemIP + "','" + ULD.ViewName + "','" + ULD.OperationName + "','" + ULD.Detail + "','" + ULD.ModifiedRecord + "','" + ULD.DetailForUserView + "')";
                MySqlCommand cmd = new MySqlCommand(Query, obj.con);
                obj.OpenDbConnection();
                SuccessId = cmd.ExecuteNonQuery();
                obj.CloseDbConnection();
                return SuccessId;
            }
            catch (Exception)
            {
                GetPatientInformation.ErrorMessage = "Some thing is not right Please Contact with Developer Team";
                return 0;
            }
        }

        public static UserList Getfilteruserlist(string Location,string Name)
        {
                   UserList model=new UserList();
                 
                    List<UserDetail> userDetail = new List<UserDetail>();
                    MySqlCommand cmd = null;
                    int No = 0;
                        if (!String.IsNullOrEmpty(Name)&& Location!="0")
                        {
                            var ename = Name.ToLower().Trim();

                        //    cmd = new MySqlCommand("select t1.U_Id,t1.F_Name,t1.L_Name,t1.EmailId,t1.MobileNo,t1.OtherContactNo,t3.Location,t2.R_id,t2.R_name from userregister t1 inner join userrole t2 on t1.R_id=t2.R_id inner join facility t3 on t1.FacilityId=t3.FacilityId where t1.FacilityId='" + Location + "' and t1.R_id!='" + 10 + "'  and t1.IsActive=1", obj.con);
                            //cmd = new MySqlCommand("select t1.U_Id,t1.F_Name,t1.L_Name,t1.EmailId,t1.MobileNo,t1.OtherContactNo,t3.Location,t2.R_id,t2.R_name from userregister t1 inner join userrole t2 on t1.R_id=t2.R_id inner join facility t3 on t1.FacilityId=t3.FacilityId where t3.FacilityId='" + Location + "' and t1.IsActive=1 and t1.R_id !='" + 10 + "'", obj.con);
                            cmd = new MySqlCommand("select t1.U_Id,t1.F_Name,t1.L_Name,t1.EmailId,t1.MobileNo,t1.OtherContactNo,t3.Location,t2.R_id,t2.R_name,t1.FacilityId from userregister t1 inner join userrole t2 on t1.R_id=t2.R_id inner join facility t3 on t1.FacilityId=t3.FacilityId where  t1.IsActive=1 and t1.R_id !='" + 10 + "'", obj.con);
                         
                            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                            DataSet ds1 = new DataSet();
                            da.Fill(ds1);
                            if (ds1.Tables[0].Rows.Count > 0)
                            {
                                for (int i = 0; i < ds1.Tables[0].Rows.Count; i++)
                                {
                                    No = No + 1;
                                    string UN = SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["F_Name"].ToString());
                                    string ULN =SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["L_Name"].ToString());

                                    //if ((UN.Length < ename.Length) || ULN.Length < ename.Length)
                                    //{

                                    //}
                                    //else
                                    //{
                                    string nm = null, ln = null;
                                    if (UN.Length >= ename.Length)
                                    {
                                        nm = UN.Substring(0, ename.Length);
                                    }
                                    else
                                    {
                                        nm = UN;
                                    }
                                    if (ULN.Length >= ename.Length)
                                    {
                                        ln = ULN.Substring(0, ename.Length);
                                    }
                                    else
                                    {
                                        ln = ULN;
                                    }
                                    if ((nm != null) || (ln != null))
                                    { 
                                        if (ds1.Tables[0].Rows[i]["FacilityId"].ToString() == Location)
                                        {
                                           nm = UN.Substring(0, ename.Length);
                                            ln = ULN.Substring(0, ename.Length);
                                            var nmm = nm.ToLower();
                                            var lln = ln.ToLower();
                                            if ((nmm == ename) || (lln == ename))
                                            {
                                                if ((nmm.Length == ename.Length) || (lln.Length == ename.Length))
                                                {
                                                    if ((nmm.Contains(ename)) || lln.Contains(ename))
                                                    {
                                                        userDetail.Add(new UserDetail
                                                        {
                                                            SNo = No,
                                                            UserId = SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["U_Id"].ToString()),
                                                            UserTypeId = Convert.ToInt32(ds1.Tables[0].Rows[i]["R_id"].ToString()),
                                                            UserType = ds1.Tables[0].Rows[i]["R_name"].ToString(),
                                                            Email = SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["EmailId"].ToString()),
                                                            FirstName = UN + " " + ULN,
                                                            LocationName = ds1.Tables[0].Rows[i]["Location"].ToString(),
                                                            PhoneNo = ds1.Tables[0].Rows[i]["OtherContactNo"].ToString(),
                                                            MobileNo = ds1.Tables[0].Rows[i]["MobileNo"].ToString(),
                                                            Edit = Connection.AllowUpdate,
                                                            Delete = Connection.AllowDelete
                                                        });
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else if (!String.IsNullOrEmpty(Name))
                        {
                            string ename = Name.ToLower().Trim();

                            cmd = new MySqlCommand("select t1.U_Id,t1.F_Name,t1.L_Name,t1.EmailId,t1.MobileNo,t1.OtherContactNo,t3.Location,t2.R_id,t2.R_name from userregister t1 inner join userrole t2 on t1.R_id=t2.R_id inner join facility t3 on t1.FacilityId=t3.FacilityId where t1.R_id!='" + 10 + "'  and t1.IsActive=1", obj.con);                          
                            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                            DataSet ds1 = new DataSet();
                            da.Fill(ds1);
                            if (ds1.Tables[0].Rows.Count > 0)
                            {
                                for (int i = 0; i < ds1.Tables[0].Rows.Count; i++)
                                {
                                    No = No + 1;
                                    string UN = SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["F_Name"].ToString());
                                    string ULN = SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["L_Name"].ToString());

                                    //if ((UN.Length < ename.Length) || (ULN.Length < ename.Length))
                                    //{ }
                                    //else
                                   // {
                                    string nm=null,lnm=null;
                                    if (UN.Length >= ename.Length)
                                    {
                                        nm = UN.Substring(0, ename.Length);
                                    }
                                    else {
                                        nm = UN;
                                    }
                                    if (ULN.Length >= ename.Length)
                                    {
                                        lnm = ULN.Substring(0, ename.Length);
                                    }
                                    else
                                    {
                                        lnm = ULN;
                                    }
                                    if((nm !=null) || (lnm!=null))
                                    { 
                                        var nmm = nm.ToLower();
                                        var lnmm = lnm.ToLower();
                                        if ((nmm == ename) || (lnmm == ename))
                                        {
                                            if ((nmm.Length == ename.Length) || (lnmm.Length == ename.Length))
                                            {
                                                if ((nmm.Contains(ename)) || lnmm.Contains(ename))
                                                {
                                                   userDetail.Add(new UserDetail
                                                    {
                                                        SNo = No,
                                                        UserId = SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["U_Id"].ToString()),
                                                        UserTypeId = Convert.ToInt32(ds1.Tables[0].Rows[i]["R_id"].ToString()),
                                                        UserType = ds1.Tables[0].Rows[i]["R_name"].ToString(),
                                                        Email = SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["EmailId"].ToString()),
                                                        FirstName = UN + " " + ULN,
                                                        LocationName = ds1.Tables[0].Rows[i]["Location"].ToString(),
                                                        PhoneNo = ds1.Tables[0].Rows[i]["OtherContactNo"].ToString(),
                                                        MobileNo = ds1.Tables[0].Rows[i]["MobileNo"].ToString(),
                                                        Edit = Connection.AllowUpdate,
                                                        Delete = Connection.AllowDelete
                                                    });
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else if (!String.IsNullOrEmpty(Location))
                        {
                            //cmd = new MySqlCommand("select t1.U_Id,t1.F_Name,t1.L_Name,t1.EmailId,t1.MobileNo,t1.OtherContactNo,t3.Location,t2.R_id,t2.R_name from userregister t1 inner join userrole t2 on t1.R_id=t2.R_id inner join facility t3 on t1.FacilityId=t3.FacilityId where t1.FacilityId='" + Location + "' and t1.R_id!='" + 10 + "'  and t1.IsActive=1", obj.con); 
                            cmd = new MySqlCommand("select t1.U_Id,t1.F_Name,t1.L_Name,t1.EmailId,t1.FacilityId,t1.MobileNo,t1.OtherContactNo,t3.Location,t2.R_id,t2.R_name from userregister t1 inner join userrole t2 on t1.R_id=t2.R_id inner join facility t3 on t1.FacilityId=t3.FacilityId where t1.R_id!='" + 10 + "'  and t1.IsActive=1", obj.con); 
                          
                            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                            DataSet ds1 = new DataSet();
                            da.Fill(ds1);
                            if (ds1.Tables[0].Rows.Count > 0)
                            {
                                for (int i = 0; i < ds1.Tables[0].Rows.Count; i++)
                                {
                                    No = No + 1;
                                    string UN = SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["L_Name"].ToString());
                                    if (ds1.Tables[0].Rows[i]["FacilityId"].ToString() == Location)
                                    {
                                        userDetail.Add(new UserDetail
                                        {
                                            SNo = No,
                                            UserId = SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["U_Id"].ToString()),
                                            UserTypeId = Convert.ToInt32(ds1.Tables[0].Rows[i]["R_id"].ToString()),
                                            UserType = ds1.Tables[0].Rows[i]["R_name"].ToString(),
                                            Email = SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["EmailId"].ToString()),
                                            FirstName = UN,
                                            LocationName = ds1.Tables[0].Rows[i]["Location"].ToString(),
                                            PhoneNo = ds1.Tables[0].Rows[i]["OtherContactNo"].ToString(),
                                            MobileNo = ds1.Tables[0].Rows[i]["MobileNo"].ToString(),
                                            Edit = Connection.AllowUpdate,
                                            Delete = Connection.AllowDelete
                                        });
                                    }
                                }
                            }
                        }
                        model.userList = userDetail;
                        return model;
        }

        public static UserList Getalluserlist()
        {
                   UserList model=new UserList();
                    List<UserDetail> userDetail = new List<UserDetail>();
                    MySqlCommand cmd = null;
                    int No =0;
             // cmd = new MySqlCommand("select t1.U_Id,t1.F_Name,t1.L_Name,t1.EmailId,t1.MobileNo,t1.OtherContactNo,t3.Location,t2.R_id,t2.R_name from userregister t1 inner join userrole t2 on t1.R_id=t2.R_id inner join facility t3 on t1.FacilityId=t3.FacilityId where t1.FacilityId='" + LoggedFacilityId + "' and t1.R_id!='" + "10" + "' and t1.IsActive=1", obj.con);
                            cmd = new MySqlCommand("select t1.U_Id,t1.F_Name,t1.L_Name,t1.EmailId,t1.MobileNo,t1.OtherContactNo,t3.Location,t2.R_id,t2.R_name from userregister t1 inner join userrole t2 on t1.R_id=t2.R_id inner join facility t3 on t1.FacilityId=t3.FacilityId where  t1.IsActive=1 and t1.R_id !='" + 10 + "'", obj.con);
                            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                            DataSet ds1 = new DataSet();
                            da.Fill(ds1);
                            if (ds1.Tables[0].Rows.Count > 0)
                            {
                                for (int i = 0; i < ds1.Tables[0].Rows.Count; i++)
                                {
                                    No = No + 1;
                                    string UN = SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["L_Name"].ToString());
                                    userDetail.Add(new UserDetail
                                    {
                                        SNo = No,
                                        UserId = SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["U_Id"].ToString()),
                                        UserTypeId = Convert.ToInt32(ds1.Tables[0].Rows[i]["R_id"].ToString()),
                                        UserType = ds1.Tables[0].Rows[i]["R_name"].ToString(),
                                        Email = SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["EmailId"].ToString()),
                                        FirstName = UN,
                                        LocationName = ds1.Tables[0].Rows[i]["Location"].ToString(),
                                        PhoneNo = ds1.Tables[0].Rows[i]["OtherContactNo"].ToString(),
                                        MobileNo = ds1.Tables[0].Rows[i]["MobileNo"].ToString(),
                                        Edit = Connection.AllowUpdate,
                                        Delete = Connection.AllowDelete
                                    });
                                }
                            }
                            model.userList = userDetail;


                  return model;
       }
        public List<UploadCsvFile> UploadPatientRecord(List<UploadCsvFile> model)
        {
            int success = 0, Rollid = 10, facilityid = 1, EthnicityId=1,Weight=145,Height = 70;
            string Fname="",Lname="";
            double BMIvalue = 0;
            int j = 0;
            bool Active = false, Reactive = false, Inactive = false,Isdeactive=true;
            var ssn="";
            string  mobileno =null;
            List<UploadCsvFile> errormodel = new List<UploadCsvFile>();
            for (int i = 0; i < model.Count; i++)
            {
                try                
                {
                    var Gender="";
                    var gen1=model[i].Gender.Trim();
                    var gender = gen1.ToLower();
                    if(gender=="m")
                    {
                    Gender="Male";
                    }
                    else if(gender=="f")
                    {
                    Gender="Female";
                    }
                    else if(gender=="male")
                    {
                     Gender="Male";
                    }
                    else if(gender=="female")
                    {
                       Gender="Female";
                    }
                    else{
                        if (model[i].Gender.Contains('f') || model[i].Gender.Contains('F'))
                        {
                            Gender = "Female";
                        }
                        else {
                            Gender = "Male";
                        }
                    }

                   
                    if (model[i].MobileNo.Length>0)
                    {
                        if(model[i].MobileNo.Contains('('))
                        {
                        mobileno=model[i].MobileNo;
                        }
                        else{
                         
                            mobileno = String.Format("{0:(###)###-####}", Convert.ToInt64(model[i].MobileNo));

                        }
                       
                       
                    }
                  
                   // createddatee = Convert.ToDateTime(model[i].InactiveDate).ToString("yyyy-MM-dd");
                 string    createddate = model[i].InactiveDate;
                 var datearry = createddate.Split('/');
                 string yy = datearry[2];
                 string MM = datearry[1];
                 string DD = datearry[0];
                 string finaldate = yy + "-" + MM + "-" + DD;

                 string DOB = model[i].Dob;
                 var dobdate = DOB.Split('/');
                 string dobmm=dobdate[1];
                 string dobdd = dobdate[0];
                 string dobyy = dobdate[2];
                 string dataofbirth = dobyy + "-" + dobmm + "-" + dobdd;

                
                    double BMI = 703.0 * Convert.ToInt32(Weight) / Convert.ToInt32(Height) / Convert.ToInt32(Height); // BMI Calculate 
                    BMIvalue = Math.Round(BMI, 2, MidpointRounding.AwayFromZero);


                    int EmailExits = 0;
                    //-----------Save into UserRegister table
                    var patientinfo = model[i].FName;
                    var Emailid="";
                    if (!String.IsNullOrEmpty(model[i].EmailId))
                    {
                        Emailid = model[i].EmailId.ToString();
                    }
                    if(!String.IsNullOrEmpty(model[i].SocSecurity))
                    {
                    ssn=SecurityManager.Encrypt(model[i].SocSecurity);
                    }
                    if(!String.IsNullOrEmpty(model[i].FName))
                        Fname=SecurityManager.Encrypt(model[i].FName);
                    if(!String.IsNullOrEmpty(model[i].LName))
                        Lname=SecurityManager.Encrypt(model[i].LName);

                    if (!String.IsNullOrEmpty(Emailid))
                    {
                        string query1 = "select IFNULL(EmailId, '') as EmailId from userregister where EmailId='"+Emailid+"'";
                        MySqlCommand cmdd = new MySqlCommand(query1,obj.con);
                        MySqlDataAdapter da = new MySqlDataAdapter(cmdd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            EmailExits = 1;
                        }
                    }
                    if (EmailExits == 0)
                    {
                       // string query = "insert into userregister(U_Id,R_Id,FacilityId,F_Name,L_Name,Gender,	DOB,EmailId,Password,Address,CityId,StateId,Zipcode,MailingAddress,MailingCity,MailingState,MailingZipcode,	EthnicityId,MobileNo,OtherContactNo,Soc_Security,U_Image,CreatedDate,IsActive ,Digital_SignURL,	ForgetPasswordString ,Is_Reactive,Inactive,InactiveDate)values(@U_Id,@R_Id,@FacilityId,@F_Name,@L_Name,@Gender,@DOB,@EmailId,@Password,@Address,@CityId,@StateId,@Zipcode,@MailingAddress,@MailingCity,@MailingState,@MailingZipcode,	@EthnicityId,@MobileNo,@OtherContactNo,@Soc_Security,@U_Image,@CreatedDate,@IsActive ,@Digital_SignURL,	@ForgetPasswordString ,@Is_Reactive,@Inactive,@InactiveDate)";
                        string query = "insert into userregister(U_Id,R_Id,FacilityId,F_Name,L_Name,Gender,	DOB,Address,CityId,StateId,Zipcode,EthnicityId,MobileNo,Soc_Security,CreatedDate,IsActive,Is_Reactive,Inactive,InactiveDate)values(@U_Id,@R_Id,@FacilityId,@F_Name,@L_Name,@Gender,@DOB,@Address,@CityId,@StateId,@Zipcode,@EthnicityId,@MobileNo,@Soc_Security,@CreatedDate,@IsActive,@Is_Reactive,@Inactive,@InactiveDate)";
                        MySqlCommand cmd = new MySqlCommand(query, obj.con);
                        cmd.Parameters.AddWithValue("@U_Id", ssn);
                        cmd.Parameters.AddWithValue("@R_Id", Rollid);
                        cmd.Parameters.AddWithValue("@FacilityId", facilityid);
                        cmd.Parameters.AddWithValue("@F_Name", Fname);
                        cmd.Parameters.AddWithValue("@L_Name", Lname);
                        cmd.Parameters.AddWithValue("@Gender", Gender);
                        cmd.Parameters.AddWithValue("@DOB", dataofbirth);
                        //cmd.Parameters.AddWithValue("@EmailId", Emailid);
                        //cmd.Parameters.AddWithValue("@Password", model[i].Password);
                        cmd.Parameters.AddWithValue("@Address", model[i].Address);
                        cmd.Parameters.AddWithValue("@CityId", model[i].CityId);
                        cmd.Parameters.AddWithValue("@StateId", model[i].StateId);
                        cmd.Parameters.AddWithValue("@Zipcode", model[i].Zipcode);
                      //  cmd.Parameters.AddWithValue("@MailingAddress", model[i].MailingAddress);
                       // cmd.Parameters.AddWithValue("@MailingCity", model[i].MailingCity);
                        //cmd.Parameters.AddWithValue("@MailingState", model[i].MailingState);
                        //cmd.Parameters.AddWithValue("@MailingZipcode", model[i].MailingZipcode);
                        cmd.Parameters.AddWithValue("@EthnicityId", EthnicityId);
                        cmd.Parameters.AddWithValue("@MobileNo", mobileno);
                        //cmd.Parameters.AddWithValue("@OtherContactNo", model[i].OtherContactNo);
                        cmd.Parameters.AddWithValue("@Soc_Security", model[i].SocSecurity);
                       // cmd.Parameters.AddWithValue("@U_Image", model[i].UImage);
                        cmd.Parameters.AddWithValue("@CreatedDate", finaldate);
                        cmd.Parameters.AddWithValue("@IsActive",Active);
                       // cmd.Parameters.AddWithValue("@Digital_SignURL", model[i].DigitalSignUrl);
                        //cmd.Parameters.AddWithValue("@ForgetPasswordString", model[i].ForgetPasswordString);
                        cmd.Parameters.AddWithValue("@Is_Reactive",Reactive);
                        cmd.Parameters.AddWithValue("@Inactive",Inactive);
                        cmd.Parameters.AddWithValue("@InactiveDate", finaldate);

                        //------------save into Patient_otherinfo tbl

                        MySqlCommand cmd1 = new MySqlCommand("insert into  patient_otherinfo (PatientId,R_Id,PINNO,Height,Weight,BMI,CreatedOn,IsDeactive,IsDeleted,IsReactive) values ( @PatientId,@R_Id,@PINNO,@Height,@Weight,@BMI,@CreatedOn,@IsDeactive,@IsDeleted,@IsReactive)", obj.con);
                        cmd1.Parameters.AddWithValue("@PatientId", ssn);
                      //  cmd1.Parameters.AddWithValue("@NickName", model[i].NickName);
                        cmd1.Parameters.AddWithValue("@R_Id", Rollid);
                        cmd1.Parameters.AddWithValue("@PINNO", model[i].Zipcode);
                        cmd1.Parameters.AddWithValue("@Height",Height);
                        cmd1.Parameters.AddWithValue("@Weight",Weight);
                        cmd1.Parameters.AddWithValue("@BMI", BMIvalue);
                        cmd1.Parameters.AddWithValue("@CreatedOn", finaldate);
                        cmd1.Parameters.AddWithValue("@IsDeactive",Isdeactive);  // objp.IsActive =0
                        cmd1.Parameters.AddWithValue("@IsDeleted", Inactive);  // objp.IsActive =0
                        cmd1.Parameters.AddWithValue("@IsReactive",Inactive); // objp.IsActive =0


                        obj.OpenDbConnection();
                        try
                        {
                            success = cmd.ExecuteNonQuery();
                            success = cmd1.ExecuteNonQuery();

                            PatientInfoPut ob = new PatientInfoPut();
                            //string createddate = model[i].InactiveDate;
                            string  createddatee = finaldate;
                            string patietid = model[i].SocSecurity;
                            string result = ob.PutPatientBMII(patietid, createddatee, Weight, Height, BMIvalue);
                 


                        }
                        catch (Exception ex)
                        {
                            errormodel.Add(new UploadCsvFile
                            {
                                UId = model[i].SocSecurity,
                                RId = model[i].RId,
                                FacilityId = model[i].FacilityId,
                                FName = model[i].FName,
                                LName = model[i].LName,
                                Gender = model[i].Gender,
                                Dob = model[i].Dob,
                               // EmailId = Emailid,
                               // Password = model[i].Password,
                                Address = model[i].Address,
                                CityId = model[i].CityId,
                                StateId = model[i].StateId,
                                Zipcode = model[i].Zipcode,
                               // MailingAddress = model[i].MailingAddress,
                               // MailingCity = model[i].MailingCity,
                               // MailingState = model[i].MailingState,
                               // MailingZipcode = model[i].MailingZipcode,
                                EthnicityId = model[i].EthnicityId,
                                MobileNo = model[i].MobileNo,
                               // OtherContactNo = model[i].OtherContactNo,
                                SocSecurity = model[i].SocSecurity,
                               // UImage = model[i].UImage,
                                CreatedDate = model[i].CreatedDate,
                                IsActive = model[i].IsActive,
                               // DigitalSignUrl = model[i].DigitalSignUrl,
                               // ForgetPasswordString = model[i].ForgetPasswordString,
                                IsReactive = model[i].IsReactive,
                               // NickName = model[i].NickName,
                                Height = model[i].Height,
                                Weight = model[i].Weight,
                                BMI = model[i].BMI,
                                IsDeactive = model[i].IsDeactive,
                                IsDeleted = model[i].IsDeleted,
                                Inactive = model[i].Inactive,
                                InactiveDate = model[i].InactiveDate,
                                // errormessage=ex.Message
                                errormessage = "Duplicate SSN Number OR Required Field(s) is Empty."
                            });
                        }
                        obj.CloseDbConnection();
                    }
                    else { 
                    errormodel.Add(new UploadCsvFile
                            {
                                FName = model[i].FName,
                                errormessage = "Duplicate EmailId."
                            });
                    }
                }
                catch (Exception ex)
                { 
                
                }
            }
            return errormodel;
        }

        public static int completealertstatus(PatientDetail model)
        {
            int success = 0;

            try
            {
                string patientid = SecurityManager.Encrypt(model.PatientId).ToString();
                string query1 = "select * from alert_complete_tbl where patient_id='" + patientid + "' and alert_day_id='" + model.ScheduleDay + "' and IsDeleted!='"+"True"+"'";
                MySqlCommand cmd1 = new MySqlCommand(query1, obj.con);
                MySqlDataAdapter da=new MySqlDataAdapter(cmd1);
                DataTable dt=new DataTable();
                da.Fill(dt);
                if(dt.Rows.Count>0)
                {
                string query = "update alert_complete_tbl set `note`='" + model.mailbody + "', status='" + "True" + "',Update_Date=@updatedate where patient_id='" + SecurityManager.Encrypt(model.PatientId) + "' and alert_day_id='" + model.ScheduleDay + "' and id='"+dt.Rows[0][0]+"'";
                MySqlCommand cmd = new MySqlCommand(query, obj.con);
                cmd.Parameters.AddWithValue("@updatedate", Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss tt")));
                if (obj.con.State == ConnectionState.Closed)
                {
                    obj.OpenDbConnection();
                }
                  success = cmd.ExecuteNonQuery();
                }
                else
                {
                string query = "insert into `alert_complete_tbl`(`patient_id`,`alert_day_id`,`note`,status,Update_Date)values('" + SecurityManager.Encrypt(model.PatientId) + "','" + model.ScheduleDay + "','" + model.mailbody + "','" + "True" + "',@updatedate)";
                MySqlCommand cmd = new MySqlCommand(query, obj.con);
                cmd.Parameters.AddWithValue("@updatedate", Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss tt")));
                if (obj.con.State == ConnectionState.Closed)
                {
                    obj.OpenDbConnection();
                }
                success = cmd.ExecuteNonQuery();
                }
            }
            catch
            {

            }
            finally
            {
                obj.CloseDbConnection();
            }
            return success;
        }
        public static int Updatealertstatus(PatientDetail model)
        {
            int success = 0;

            try
            {
                string patientid = SecurityManager.Encrypt(model.PatientId).ToString();
                string query1 = "select * from alert_complete_tbl where patient_id='" + patientid + "' and alert_day_id='" + model.ScheduleDay + "' and IsDeleted!='"+"True"+"'";
                MySqlCommand cmd1 = new MySqlCommand(query1, obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd1);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    string query = "update alert_complete_tbl set `note`='" + model.mailbody + "', Update_Date=@updatedate where patient_id='" + SecurityManager.Encrypt(model.PatientId) + "' and alert_day_id='" + model.ScheduleDay + "' and id='"+dt.Rows[0][0]+"'";
                    MySqlCommand cmd = new MySqlCommand(query, obj.con);
                    cmd.Parameters.AddWithValue("@updatedate", Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss tt")));
                    if (obj.con.State == ConnectionState.Closed)
                    {
                        obj.OpenDbConnection();
                    }
                    success = cmd.ExecuteNonQuery();
                }
                else
                { 
                 string query = "insert into `alert_complete_tbl`(`patient_id`,`alert_day_id`,`note`,Update_Date)values('" + SecurityManager.Encrypt(model.PatientId) + "','" + model.ScheduleDay + "','" + model.mailbody + "',@updatedate)";
                MySqlCommand cmd = new MySqlCommand(query, obj.con);
                cmd.Parameters.AddWithValue("@updatedate", Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss tt")));
                if (obj.con.State == ConnectionState.Closed)
                {
                    obj.OpenDbConnection();
                }
                success = cmd.ExecuteNonQuery();
                }
            }
            catch
            { }

            return success;
        }



        public static int UpdatePatientNote(string patientid, ShowUserDetailsModel model)
        { 
            int success=0;
            string alertid = model.Alertid;
           
                string query = "select body,alert_day_id from alert_update_tbl where patient_id='" +SecurityManager.Encrypt( patientid) + "' and alert_day_id='" + model.Alertid + "'";
                MySqlCommand cmd = new MySqlCommand(query, obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    try
                    {
                        string query1 = "update alert_update_tbl set body='" + model.mailbody + "' where patient_id='" +SecurityManager.Encrypt(patientid)+ "' and alert_day_id='" + model.Alertid + "'";
                        MySqlCommand cmd1 = new MySqlCommand(query1, obj.con);
                        if (obj.con.State == ConnectionState.Closed)
                        {
                            obj.OpenDbConnection();
                        }
                     success=   cmd1.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                    }
                    finally
                    {
                        obj.CloseDbConnection();
                    }
                }
                else
                {
                    try
                    {
                        string query2 = "insert into alert_update_tbl(patient_id,alert_day_id,body)values('" +SecurityManager.Encrypt( patientid )+ "','" + model.Alertid + "','" + model.mailbody + "')";
                        MySqlCommand cmd2 = new MySqlCommand(query2, obj.con);
                        if (obj.con.State == ConnectionState.Closed)
                        {
                            obj.OpenDbConnection();
                        }
                     success=cmd2.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    { }

                    finally
                    {
                        obj.CloseDbConnection();
                    }
                }
           
            return success;
        }

        public static int DeactivalteAlert(string patientid, ShowUserDetailsModel model)
         { 
            int success=0;
            string status = model.Status;
            try
            {
            if (status == "Active")
            {
                string query1 = "select patient_id from alert_deactivate_tbl where patient_id='" + patientid + "' and alert_day_id= '" + model.Alertid + "'";
                MySqlCommand cmd1 = new MySqlCommand(query1,obj.con);
                MySqlDataAdapter da1 = new MySqlDataAdapter(cmd1);
                DataTable dt1 = new DataTable();
                da1.Fill(dt1);
                if (dt1.Rows.Count > 0)
                {
                    string Query = "delete from alert_deactivate_tbl where patient_id='" + patientid + "' and alert_day_id= '" + model.Alertid + "'";
                    MySqlCommand cmd = new MySqlCommand(Query, obj.con);
                    if (obj.con.State == ConnectionState.Closed)
                    {
                        obj.OpenDbConnection();
                    }
                    success = cmd.ExecuteNonQuery();
                    obj.CloseDbConnection();
                }
            }
            else
            {
                string Query = "insert into alert_deactivate_tbl(patient_id,alert_day_id)values('" + patientid + "','" + model.Alertid + "')";
                MySqlCommand cmd = new MySqlCommand(Query, obj.con);
                if (obj.con.State == ConnectionState.Closed)
                {
                    obj.OpenDbConnection();
                }
                success = cmd.ExecuteNonQuery();
                obj.CloseDbConnection();
               
            }
            }
            catch(Exception ex)
            {
            
            }
        
            return success;
         }
        public static int UpdatePatientalert(ShowUserDetailsModel model)
        {
            int success = 0;
            string status = model.Status;
          //  ShowUserDetailsModel patientstatus = new ShowUserDetailsModel();
            string query = "select AlertMailId from alert_mail where AlertMailId='"+model.Alertid+"' and AlertTo='"+model.AlertTo+"'";
            MySqlCommand cmd1 = new MySqlCommand(query,obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd1);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {

                MySqlCommand cmd = new MySqlCommand("update alert_mail set status=@status,Mail_Body=@mailbody where AlertMailId=@alertmailid", obj.con);
                cmd.Parameters.AddWithValue("@status", status);
                cmd.Parameters.AddWithValue("@mailbody", model.mailbody);
                cmd.Parameters.AddWithValue("@alertmailid", model.Alertid);
                if (obj.con.State == ConnectionState.Closed)
                {
                    obj.OpenDbConnection();
                }
                success = cmd.ExecuteNonQuery();
                obj.CloseDbConnection();
            }
            return success;
        }

        public static int CreateNewUser(AdminRegisterModel model)
        {
            try
            {
                int SuccessId = 0;

                // User Logged Detail Start

                UserLogDetail ULD = new UserLogDetail();
                ULD.UserTypeId = Convert.ToInt16(model.UserTypeID);
                ULD.UserId = SecurityManager.Encrypt(model.Email.ToLower());
                ULD.ViewName = "Admin/Register";
                ULD.OperationName = "Save";
                ULD.Detail = "New User Created Successfully!";
                ULD.ModifiedRecord = SecurityManager.Encrypt(model.Email.ToLower());
                ULD.DetailForUserView = "New User Created Successfully!";
                //ULD.logTime=

                // User Logged Detail End

                MySqlCommand cmd = new MySqlCommand("select * from userregister where EmailId='" + SecurityManager.Encrypt(model.Email.ToLower()) + "'", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    string Query = "INSERT INTO userregister(U_Id, R_Id, FacilityId, F_Name, L_Name,EmailId, Password, MobileNo,CreatedDate,IsActive) VALUES ('" + SecurityManager.Encrypt(model.Email) + "','" + model.UserTypeID + "','" + model.FacilityID + "','" + SecurityManager.Encrypt(model.FirstName) + "','" + SecurityManager.Encrypt(model.LastName) + "','" + SecurityManager.Encrypt(model.Email) + "','" + SecurityManager.Encrypt(model.Password) + "','" + model.MobileNo + "','" + Convert.ToDateTime(LoginDate).ToString("yyyy-MM-dd") + "','" + "1" + "')";
                    MySqlCommand cmd1 = new MySqlCommand(Query, obj.con);
                    obj.OpenDbConnection();
                    SuccessId = cmd1.ExecuteNonQuery();
                    obj.CloseDbConnection();
                    int SuccessId1 = AdminClass.UserLogDetail(ULD);
                    GetPatientInformation.ErrorMessage = "User Record Updated Successfully!";
                }
                return SuccessId;
            }
            catch (Exception e)
            {
                GetPatientInformation.ErrorMessage = e.Message;
                GetPatientInformation.ErrorMessage = "Some thing is not right Please Contact with Developer Team";
                return 0;
            }
        }

        public static UserLevelList GetuserLevelList()
        {
            int No = 0;
            UserLevelList model = new UserLevelList();
            try
            {
                List<UserLevel> UserLevelDetail = new List<UserLevel>();

                MySqlCommand cmd = new MySqlCommand("SELECT IFNULL(R_id, '') AS R_id, IFNULL(R_name, '') AS R_name FROM userrole WHERE Isactive=" + 1 + "", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        No = No + 1;
                        UserLevelDetail.Add(new UserLevel
                        {
                            SrNo = No,
                            UserTypeId = Convert.ToInt32(dt.Rows[i]["R_id"].ToString()),
                            UserType = dt.Rows[i]["R_name"].ToString(),
                            Edit = Connection.AllowUpdate,
                            Delete = Connection.AllowDelete
                        });
                    }
                }
                model.userLevelList = UserLevelDetail;
            }
            catch (Exception e)
            {
            }
            return model;
        }

        public static ReferralList GetReferralList()
        {
            int No = 0;
            ReferralList model = new ReferralList();
            try
            {
                List<ReferralDetail> referralDetail = new List<ReferralDetail>();
                MySqlCommand cmd1 = new MySqlCommand("SELECT IFNULL(ReferralId, '') AS ReferralId, IFNULL(ReferralName, 'NA') AS ReferralName, IFNULL(Description, 'NA') AS Description FROM referrallist WHERE IsActive=" + 1 + "", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd1);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        No = No + 1;
                        string referalname = dt.Rows[i]["ReferralName"].ToString();
                        string referaldescription=dt.Rows[i]["Description"].ToString();
                        if (referalname == "")
                        {
                            referalname = "NA";
                        }
                        if (referaldescription == "")
                        {
                            referaldescription = "NA";
                        }

                        referralDetail.Add(new ReferralDetail
                        {
                            SrNo = No,
                            ReferralId = Convert.ToInt32(dt.Rows[i]["ReferralId"].ToString()),
                            ReferralName = referalname,
                            ReferralDescription = referaldescription,
                            Edit = Connection.AllowUpdate,
                            Delete = Connection.AllowDelete
                        });
                    }
                }
                model.referralDetail = referralDetail;

            }
            catch (Exception e)
            {

            }
            return model;
        }

        public static string CreatePatientDetail(PatientRegistration PR)
        {
            string Success = "0", Result = "0", UserID, EmailID, RoleID = "10";
            try
            {
                if (!String.IsNullOrEmpty(PR.UserNameId))
                {
                    UserID = PR.UserNameId;
                    Success = "1";
                }
                else
                {
                    UserID = "";
                }
                if (!String.IsNullOrEmpty(PR.EmailId))
                {
                    EmailID = SecurityManager.Encrypt(PR.EmailId);
                    Success = "2";
                }
                else
                {
                    EmailID = "";
                }
                double BMI = 703.0 * Convert.ToInt32(PR.Weight) / Convert.ToInt32(PR.Height) / Convert.ToInt32(PR.Height); // BMI Calculate 
                double BMIValue = Math.Round(BMI, 2, MidpointRounding.AwayFromZero);

                // User Logged Detail Start

                UserLogDetail ULD = new UserLogDetail();
                ULD.UserTypeId = Convert.ToInt16(RoleID);
                ULD.UserId = SecurityManager.Encrypt(PR.UserNameId);
                ULD.ViewName = "Admin/CreatePatient";
                ULD.OperationName = "Save";
                ULD.Detail = "New Patient Created Successfully!";
                ULD.ModifiedRecord = SecurityManager.Encrypt(PR.UserNameId);
                ULD.DetailForUserView = "New Patient Created Successfully!";
  
                // User Logged Detail End
                if (PR.ReferralId != 0)
                {
                    MySqlCommand cmdd1 = new MySqlCommand("select * from referraluser where U_Id=@U_Id", obj.con);
                    cmdd1.Parameters.AddWithValue("@U_Id", SecurityManager.Encrypt(PR.UserNameId));
                    MySqlDataAdapter asd1 = new MySqlDataAdapter(cmdd1);
                    DataTable ddt = new DataTable();
                    asd1.Fill(ddt);
                    if (ddt.Rows.Count > 0)
                    {
                        MySqlCommand cmdd = new MySqlCommand("update referraluser set  ReferralId =@ReferralId where U_Id= @U_Id", obj.con);
                        cmdd.Parameters.AddWithValue("@ReferralId", PR.ReferralId);
                        cmdd.Parameters.AddWithValue("@U_Id", SecurityManager.Encrypt(PR.UserNameId));
                        obj.OpenDbConnection();
                        cmdd.ExecuteNonQuery();
                        obj.CloseDbConnection();
                    }
                    else
                    {
                        MySqlCommand cmdd = new MySqlCommand("insert into referraluser (ReferralId,U_Id) values (@ReferralId,@U_Id)", obj.con);
                        cmdd.Parameters.AddWithValue("@ReferralId", PR.ReferralId);
                        cmdd.Parameters.AddWithValue("@U_Id", SecurityManager.Encrypt(PR.UserNameId));
                        obj.OpenDbConnection();
                        cmdd.ExecuteNonQuery();
                        obj.CloseDbConnection();
                    }
                }

                //--------------------------- BMI Entry ------------------------------------

                if ((Convert.ToInt32(PR.Height) != 0) && (PR.Height != "") && (Convert.ToInt32(PR.Weight) != 0) && (PR.Weight.ToString() != ""))
                {
                    PatientInfoPut ob = new PatientInfoPut();
                    string result = ob.PutPatientBMI(PR);
                }
                string BirthDate = Convert.ToDateTime(PR.DateOfBirth).ToString();
                PR.CityId = PR.CityId != null ? PR.CityId : "0";
                PR.StateId = PR.StateId != null ? PR.StateId : "0";
                PR.MailingCity = PR.MailingCity != null ? PR.MailingCity : "0";
                PR.MailingState = PR.MailingState != null ? PR.MailingState : "0";
                PR.EmpCityId = PR.EmpCityId != null ? PR.EmpCityId : "0";
                PR.EmpStateId = PR.EmpStateId != null ? PR.EmpStateId : "0";
                PR.EduId = PR.EduId != null ? PR.EduId : "0";
                PR.EmpCityId = PR.EmpCityId != null ? PR.EmpCityId : "0";
               
                string createddate=null;
                string userid =null;
                string Birthdate = null;
                
                if (!String.IsNullOrEmpty(PR.UserNameId))
                {
                  userid = SecurityManager.Encrypt(PR.UserNameId);
                }
                createddate = Convert.ToDateTime(LoginDate).ToString("yyyy-MM-dd HH:mm:ss");
                DateTime birthdate =Convert.ToDateTime(PR.DateOfBirth);
                Birthdate = Convert.ToDateTime(birthdate).ToString("yyyy-MM-dd");
                
              //  string dateofbirth = Birthdate.ToString("yyyy-MM-dd HH:mm:ss");
               // var dateofbirth = DateTime.Parse(birthdate, new CultureInfo("en-US", true)).ToShortDateString("yyyy-MM-dd");
                string Query1 = "insert into userregister (U_Id,R_Id,FacilityId,F_Name,L_Name,Gender,DOB,EmailId,EthnicityId,MobileNo,CreatedDate,IsActive,Is_Reactive,Inactive,InactiveDate) values ('" + userid + "','" + RoleID + "','" + PR.FacilityId + "','" + SecurityManager.Encrypt(PR.FirstName) + "','" + SecurityManager.Encrypt(PR.LastName) + "','" + PR.Gender + "','" + Birthdate + "','" + EmailID + "','" + PR.EthnicityId + "','" + PR.MobileNo + "','" + createddate + "'," + 1 + "," + 0 + "," + 0 + ",'" + createddate + "')";
                string Query2 = "insert into patient_otherinfo(PatientId,R_id,NickName,Height,Weight,BMI,CreatedOn,IsDeactive,IsDeleted,IsReactive) values ('" + SecurityManager.Encrypt(PR.UserNameId) + "','" + RoleID + "','" + PR.NickName + "', '" + PR.Height + "', '" + PR.Weight + "','" + BMIValue + "','" + createddate + "'," + 0 + "," + 0 + "," + 0 + ")";

                MySqlCommand cmd1 = new MySqlCommand(Query1, obj.con);
                MySqlCommand cmd2 = new MySqlCommand(Query2, obj.con);

                obj.OpenDbConnection();
                Result = cmd1.ExecuteNonQuery().ToString();
                Result = cmd2.ExecuteNonQuery().ToString();

                Connection.UserId = PR.UserNameId;
                Connection.PatientIsActive = "true";
                string Query3=null;
                string Query4 = null;

                if (PR.CityId == "0" || PR.StateId == "0" || PR.MailingCity=="0" || PR.MailingState=="0")
                {
                    
                }
                else
                {
                     Query3 = "update userregister set CityId='" + PR.CityId + "',StateId='" + PR.StateId + "',MailingCity='" + PR.MailingCity + "',MailingState='" + PR.MailingState + "' where U_Id='" + SecurityManager.Encrypt(PR.UserNameId) + "'";
                     Query4 = "update patient_otherinfo set(Emp_CityId='" + PR.EmpCityId + "',Emp_StateId='" + PR.EmpStateId + "'  where PatientId='" + SecurityManager.Encrypt(PR.UserNameId) + "'";
                     MySqlCommand cmd3 = new MySqlCommand(Query3, obj.con);
                     MySqlCommand cmd4 = new MySqlCommand(Query4, obj.con);                
                }
                obj.CloseDbConnection();
                int SuccessId1 = AdminClass.UserLogDetail(ULD);
                return Result;
            }
            catch (Exception)
            {
                return Result;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }

        public static int UpdateAdminProfile(AdminRegisterModel model, string ButtonType, string SelectedUserId, int UtypeId)
        {
            try
            {
                int SuccessId = 0;
                string Query = "";

                //User Logged Detail Start

                UserLogDetail ULD = new UserLogDetail();
                ULD.UserId = SelectedUserId;
                ULD.UserTypeId = UtypeId;
                ULD.ViewName = "Admin/EditUser?userid" + SelectedUserId;
                ULD.ModifiedRecord = SecurityManager.Encrypt(model.Email.ToLower());

                //User Logged Detail End

                if (ButtonType == "1")
                {
                    Query = "update userregister set FacilityId='" + model.FacilityID + "' ,F_Name='" + SecurityManager.Encrypt(model.FirstName) + "' ,L_Name='" + SecurityManager.Encrypt(model.LastName) + "' ,EmailId='" + SecurityManager.Encrypt(model.Email) + "' ,MobileNo='" + model.MobileNo + "'  where U_Id='" + SelectedUserId + "'";

                    ULD.OperationName = "Update";
                    ULD.Detail = "User Detail Updated Successfully!";
                    ULD.DetailForUserView = "User Detail Updated Successfully!";
                }
                else if (ButtonType == "2")
                {
                    int Delete = 0;
                    Query = "update userregister set IsActive='" + Delete + "' where U_Id='" + SelectedUserId + "'";

                    ULD.OperationName = "Delete";
                    ULD.Detail = "User Detail Deleted Successfully!";
                    ULD.DetailForUserView = "User Detail Deleted Successfully!";
                }

                MySqlCommand cmd = new MySqlCommand(Query, obj.con);
                obj.OpenDbConnection();
                SuccessId = cmd.ExecuteNonQuery();
                obj.CloseDbConnection();

                int SuccessId1 = AdminClass.UserLogDetail(ULD);
                GetPatientInformation.ErrorMessage = "User Record Updates Successfully!";
                return SuccessId;
            }
            catch (Exception e)
            {
                GetPatientInformation.ErrorMessage = e.ToString();
                GetPatientInformation.ErrorMessage = "Some thing is not right Please Contact with Developer Team";
                return 0;
            }
        }

        public static int ChangePassword(PatientRegistration model,string EmailId, int UserTypeId)
        {
            try
            {
                int UserId = 0, Success = 0;
               // string SelectedEmailId = EmailId;
                string SelectedEmailId = SecurityManager.Encrypt(EmailId);
              //  var OldPassword = model.OldPassword;
                string NewPass = SecurityManager.Encrypt(model.Password);

                MySqlCommand Mcmd = new MySqlCommand("select U_Id,EmailId,F_Name,L_Name,Password,R_Id from userregister where EmailId='" + SelectedEmailId + "'", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(Mcmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count != 0)
                {
                    string AvailablePass = SecurityManager.Decrypt(dt.Rows[0]["Password"].ToString());
                   
                   
                        MySqlCommand cmd1 = new MySqlCommand("update userregister set Password ='" + NewPass + "' where EmailId='" + SelectedEmailId + "'", obj.con);
                        obj.OpenDbConnection();
                        Success = cmd1.ExecuteNonQuery();
                        obj.CloseDbConnection();
                        GetPatientInformation.ErrorMessage = "New user '" + model.PatientId + "' is Added Successfully";
                        Success = 1;
                   
                    return Success;
                }
                else
                {
                    MySqlCommand Mcmd1 = new MySqlCommand("select U_Id,EmailId,F_Name,L_Name,Password,R_Id from userregister where U_Id='" + SelectedEmailId + "'", obj.con);
                    MySqlDataAdapter Mda = new MySqlDataAdapter(Mcmd1);
                    DataTable Mdt = new DataTable();
                    Mda.Fill(Mdt);
                    if (Mdt.Rows.Count != 0)
                    {
                        string AvailablePass = SecurityManager.Decrypt(Mdt.Rows[0]["Password"].ToString());
                       
                            MySqlCommand cmd1 = new MySqlCommand("update userregister set Password ='" + NewPass + "' where U_Id='" + SelectedEmailId + "'", obj.con);
                            obj.OpenDbConnection();
                            Success = cmd1.ExecuteNonQuery();
                            obj.CloseDbConnection();
                            GetPatientInformation.ErrorMessage = "New user '" + model.PatientId + "' is Added Successfully";
                            Success = 1;
                        
                        return Success;
                    }
                }
                return Success;
            }
            catch (Exception e)
            {
                GetPatientInformation.ErrorMessage = e.Message;
                GetPatientInformation.ErrorMessage = "Some thing is not right Please Contact with Developer Team";
                return 0;
            }
        }

        public static int UpdateUser(AdminRegisterModel model, string ButtonType, string SelectedUserId, int RoleId)
        {
            try
            {
                string Query = "";
                int SuccessId = 0;
                //User Logged Detail Start

                UserLogDetail ULD = new UserLogDetail();
                ULD.ViewName = "Admin/EditUser?userid" + SelectedUserId;
                ULD.ModifiedRecord = SecurityManager.Encrypt(model.Email);
                ULD.UserId = SelectedUserId;
                ULD.UserTypeId = RoleId;

                //User Logged Detail End

                if (ButtonType == "1")
                {
                    Query = "update userregister set R_Id='" + model.UserTypeID + "',FacilityId='" + model.FacilityID + "',F_Name='" + SecurityManager.Encrypt(model.FirstName) + "',L_Name='" + SecurityManager.Encrypt(model.LastName) + "',EmailId='" + SecurityManager.Encrypt(model.Email) + "',MobileNo='" + model.MobileNo + "' where U_Id='" + SelectedUserId + "'";

                    MySqlCommand cmd = new MySqlCommand(Query, obj.con);
                    obj.OpenDbConnection();
                    SuccessId = cmd.ExecuteNonQuery();
                    obj.CloseDbConnection();

                    ULD.OperationName = "Update";
                    ULD.Detail = "User Detail Updated Successfully!";
                    ULD.DetailForUserView = "User Detail Updated Successfully!";
                }
                else if (ButtonType == "2")
                {
                    MySqlCommand cmd = new MySqlCommand("UPDATE `userregister`  SET  `IsActive` = 0 where  `U_Id` ='" + SelectedUserId + "'", obj.con);
                    obj.OpenDbConnection();
                    SuccessId = cmd.ExecuteNonQuery();
                    obj.CloseDbConnection();

                    ULD.OperationName = "Delete";
                    ULD.Detail = "User Detail Deleted Successfully!";
                    ULD.DetailForUserView = "User Detail Deleted Successfully!";
                }


                int SuccessId1 = AdminClass.UserLogDetail(ULD);
                GetPatientInformation.ErrorMessage = "User Record Updates Successfully!";
                return SuccessId;
            }
            catch (Exception e)
            {
                GetPatientInformation.ErrorMessage = e.ToString();
                GetPatientInformation.ErrorMessage = "Some thing is not right Please Contact with Developer Team";
                return 0;
            }
        }

        public static int SaveFacility(Facility model, string SelectedUserId, int RoleId)
        {
            try
            {
                int SuccessId = 0;

                //User Logged Detail Start
                UserLogDetail ULD = new UserLogDetail();

                ULD.ViewName = "Admin/Facility";
                ULD.OperationName = "Save";
                ULD.Detail = "New Location Create Successfully!";
                ULD.ModifiedRecord = model.LocationName;
                ULD.DetailForUserView = "New Location Create Successfully!";
                ULD.UserId = SelectedUserId;
                ULD.UserTypeId = RoleId;

                //User Logged Detail End

                MySqlCommand cmd = new MySqlCommand("select * from facility where Location='" + model.LocationName + "' and IsActive = 1 ", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    string Query = @"INSERT INTO `facility`(`Location`, `Street`, `StateId`, `CityId`, `Zipcode`, `ContactNo`, `FaxNo`, `ManagerId`, `EmailId`, `IsActive`) VALUES ('" + model.LocationName + "','" + model.Address + "','" + model.State + "','" + model.City + "','" + model.Zipcode + "','" + model.PhoneNumber + "','" + model.FaxNumber + "','" + SecurityManager.Encrypt(model.Manager) + "','" + model.EmailAddress + "','1')";
                    MySqlCommand cmd1 = new MySqlCommand(Query, obj.con);
                    obj.OpenDbConnection();
                    SuccessId = cmd1.ExecuteNonQuery();
                    obj.CloseDbConnection();
                    int SuccessId1 = AdminClass.UserLogDetail(ULD);
                    GetPatientInformation.ErrorMessage = "New Location Added Suucessfully";
                    return SuccessId;
                }
                else
                {
                    return SuccessId;
                }
            }
            catch (Exception e)
            {
                GetPatientInformation.ErrorMessage = e.ToString();
                GetPatientInformation.ErrorMessage = "Some thing is not right Please Contact with Developer Team";
                return 0;
            }
        }

        public static int SaveNewReferral(Referral model, string SelectedUserId, int RoleId)
        {
            try
            {
                int SuccessId = 0;

                //User Logged Detail Start

                UserLogDetail ULD = new UserLogDetail();
                ULD.ViewName = "Admin/CreateReferral";
                ULD.OperationName = "Save";
                ULD.Detail = "New Referral Created Successfully!";
                ULD.ModifiedRecord = model.Name;
                ULD.DetailForUserView = "New Referral Created Successfully!";
                ULD.UserId = SelectedUserId;
                ULD.UserTypeId = RoleId;

                //User Logged Detail End

                MySqlCommand cmd1 = new MySqlCommand("SELECT * FROM referrallist where ReferralName='" + model.Name + "'", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd1);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    MySqlCommand cmd = new MySqlCommand("insert into referrallist (ReferralName, Description, IsActive) values (@ReferralName,@Description,@IsActive)", obj.con);
                    cmd.Parameters.AddWithValue("@ReferralName", model.Name);
                    cmd.Parameters.AddWithValue("@Description", model.Description);
                    cmd.Parameters.AddWithValue("@IsActive", "1");
                    obj.OpenDbConnection();
                    SuccessId = cmd.ExecuteNonQuery();
                    obj.CloseDbConnection();
                    int SuccessId1 = AdminClass.UserLogDetail(ULD);
                    GetPatientInformation.ErrorMessage = "New Referral '" + model.Name + "' is Added Successfully";
                    return SuccessId;
                }
                else
                {
                    GetPatientInformation.ErrorMessage = "Referral Name '" + model.Name + "' Already Exist Please Change Referral Name";
                    return 0;
                }
            }
            catch (Exception e)
            {
                GetPatientInformation.ErrorMessage = "Some thing is not right Please Contact with Developer Team";
                return 0;
            }
        }

        public static string ForgetPassword(PatientRegistration model)
        {
            try
            {
                int UserId = 0, Success = 0;
                string mailConfirm = "Something is not right..";
                string strname = string.Empty;
                string strPracticename = string.Empty;
                string strEmailid = string.Empty;
                string strpassword = string.Empty;
                string D_EmailId = model.EmailId;
                string email = SecurityManager.Encrypt(model.EmailId);
                MySqlCommand cmd = new MySqlCommand("select U_Id,F_Name,L_Name,EmailId,Password,ForgetPasswordString from userregister where EmailId='" + email + "'", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count != 0)
                {
                    var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                    var random = new Random();
                    string PasswordResetString = new string(
                        Enumerable.Repeat(chars, 8)
                                  .Select(s => s[random.Next(s.Length)])
                                  .ToArray());

                    MySqlCommand cmd1 = new MySqlCommand("update userregister set ForgetPasswordString='" + PasswordResetString + "' where EmailId='" + email + "'", obj.con);

                    obj.OpenDbConnection();
                    Success = cmd1.ExecuteNonQuery();
                    obj.CloseDbConnection();

                    strEmailid = SecurityManager.Decrypt(dt.Rows[0]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[0]["L_Name"].ToString());
                    string Subject = "Password Reset Link";
                    string MailTo = D_EmailId;
                    string Body = "Hello:" + strEmailid + Environment.NewLine + @" Verification Code for Password Reset : " + PasswordResetString;
                    MailHelper objhelper = new MailHelper();
                     mailConfirm = objhelper.SendEmail(MailTo, Subject, Body);

                    return mailConfirm;

                }
                return mailConfirm;
            }
            catch (Exception e)
            { 
                return e.Message; 
            }
        }

        public static int ResetPassword(PatientRegistration model)
        {
            try
            {
                int UserId = 0, Success = 0;

                string EmailAddress = SecurityManager.Encrypt(model.EmailId);
                string Pass = SecurityManager.Encrypt(model.Password);

                MySqlCommand cmd1 = new MySqlCommand("select U_Id,EmailId,Password,ForgetPasswordString from userregister where EmailId='" + EmailAddress + "' and ForgetPasswordString='" + model.ForgetPasswordString + "'", obj.con);
                MySqlDataAdapter da1 = new MySqlDataAdapter(cmd1);                
                DataTable dt1 = new DataTable();
                da1.Fill(dt1);
                if (dt1.Rows.Count != 0)
                {
                    MySqlCommand cmd2 = new MySqlCommand("update userregister set Password='" + Pass + "' where EmailId='" + EmailAddress + "'", obj.con);                   
                    obj.OpenDbConnection();
                    Success = cmd2.ExecuteNonQuery();
                    obj.CloseDbConnection();
                    GetPatientInformation.ErrorMessage = "New user '" + model.PatientId + "' is Added Successfully";
                }
                Success = Success == 1 ? 1 : 0;
                return Success;
            }
            catch (Exception e)
            {
                GetPatientInformation.ErrorMessage = e.Message;
                GetPatientInformation.ErrorMessage = "Some thing is not right Please Contact with Developer Team";
                return 0;
            }
        }

        public static int SaveNewUserType(UserLevel model, string SelectedUserId, int RoleId)
        {
            try
            {
                int SuccessId = 0;

                //User Logged Detail Start

                UserLogDetail ULD = new UserLogDetail();
                ULD.ViewName = "Admin/CreateUserLevel";
                ULD.OperationName = "Save";
                ULD.Detail = "New User Type Created Successfully!";
                ULD.ModifiedRecord = model.UserType;
                ULD.DetailForUserView = "New User Type Created Successfully!";
                ULD.UserId = SelectedUserId;
                ULD.UserTypeId = RoleId;

                //User Logged Detail End

                MySqlCommand cmd1 = new MySqlCommand("SELECT * FROM userrole where `Isactive`=1 and R_name='" + model.UserType + "'", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd1);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count == 0)
                {
                    MySqlCommand cmd = new MySqlCommand("insert into userrole (R_name, Isactive) values ('" + model.UserType + "','1')", obj.con);
                    obj.OpenDbConnection();
                    SuccessId = cmd.ExecuteNonQuery();
                    obj.CloseDbConnection();
                    int SuccessId1 = AdminClass.UserLogDetail(ULD);
                    GetPatientInformation.ErrorMessage = "New User Type '" + model.UserType + "' is Added Successfully";
                    return SuccessId;
                }
                else
                {

                    //MySqlCommand cmd = new MySqlCommand("update  userrole set Isactive=1 where R_name='" + model.UserType + "'", obj.con);
                    //obj.OpenDbConnection();
                    //SuccessId = cmd.ExecuteNonQuery();
                    //obj.CloseDbConnection();
                    //int SuccessId1 = AdminClass.UserLogDetail(ULD);
                    //GetPatientInformation.ErrorMessage = "New User Type '" + model.UserType + "' is Added Successfully";
                    //return SuccessId;
                    GetPatientInformation.ErrorMessage = "User Type '" + model.UserType + "' Already Exist Please Change User Type";
                    return 0;
                }
            }
            catch (Exception e)
            {
                GetPatientInformation.ErrorMessage = "Some thing is not right Please Contact with Developer Team";
                return 0;
            }
        }
    }
}