﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.BussinessLayer;
using NewAPGApplication.Models;

namespace NewAPGApplication.BussinessLayer
{
    public class GetOperatorName
    {

        DbConnection obj = new DbConnection();

        public static DataTable GetLocationList()
        {
            DbConnection obj = new DbConnection();
            DataTable dt = null;
            MySqlCommand cmd = new MySqlCommand("select Location,FacilityId from facility order by Location", obj.con);
            MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            asd.Fill(dt);
            return dt;
        }

        //public DataTable getlocation(int location)
        //{
        //    DbConnection obj = new DbConnection();
        //    DataTable dt = null;
        //    MySqlCommand cmd = new MySqlCommand("select Location,FacilityId from facility where FacilityId='" + location + "' order by Location", obj.con);
        //    MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
        //    dt = new DataTable();
        //    asd.Fill(dt);
        //    return dt;
        //}


        public DataTable GetOperator(string id)
        {
            DataTable ds = null;
            try
            {
                obj.OpenDbConnection();
                MySqlCommand cmd = new MySqlCommand("select * from userrole Where R_id=@R_id AND Isactive='" + 1 + "'", obj.con);
                cmd.Parameters.AddWithValue("@R_id", id);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                ds = new DataTable();
                asd.Fill(ds);
                return ds;
            }
            catch (Exception)
            {
                return ds;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }

        public static int GetPatientIsActive(string id)    // --------------------------------- Get Patient Data For Login IsActive Or Not 
        {
            DataSet dss = null;
            DbConnection obj = new DbConnection();
            int IsDeactive = 0; // 1 Means Patient Active For Login and 0 is not Active for Login
            try
            {
                IsDeactive = 1;
                MySqlCommand cmd = new MySqlCommand("select PatientId,R_id,IsDeleted,IsReactive from patient_otherinfo Where PatientId=@PatientId and IsDeleted=@IsDeleted", obj.con);
                cmd.Parameters.AddWithValue("@PatientId", id);
                cmd.Parameters.AddWithValue("@IsDeleted", IsDeactive);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                dss = new DataSet();
                asd.Fill(dss);
                IsDeactive = Convert.ToInt16(dss.Tables[0].Rows[0]["IsDeleted"].ToString());
                return IsDeactive;
            }
            catch (Exception)
            {
                return IsDeactive;
            }
            finally
            {

            }
        }

        public static string GetPatientID(string id)    // --------------------------------- Get Patient For Active Account by user through Email Activation Link 
        {
            DataSet dss = null;
            DbConnection obj = new DbConnection();
            string PatientID = ""; // 1 Means Patient Active For Login and 0 is not Active for Login
            try
            {
              
                MySqlCommand cmd = new MySqlCommand("select PatientId,R_id from patient_otherinfo Where PatientId=@PatientId", obj.con);
                cmd.Parameters.AddWithValue("@PatientId", id);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                dss = new DataSet();
                asd.Fill(dss);
                PatientID = dss.Tables[0].Rows[0]["PatientId"].ToString();
                return PatientID;
            }
            catch (Exception)
            {
                return PatientID;
            }
            finally
            {

            }
        }

        public static Facility GetFacilityDetail(int tempId)         // Get Facility Details For update
        {
            DbConnection obj = new DbConnection();

            Facility URM = new Facility();
            try
            {
               // MySqlCommand cmd = new MySqlCommand("select * from facility where FacilityId ='" + tempId + "'", obj.con);
                MySqlCommand cmd = new MySqlCommand(@"select f.*,c.C_Name,ur.F_Name,ur.L_Name from facility as f join city as c on c.CityId= f.CityId Left join userregister as ur on ur.U_Id= f.ManagerId where f.FacilityId ='" + tempId + "'", obj.con);
              
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    URM.LocationName = dt.Rows[0]["Location"].ToString();
                    URM.Address = dt.Rows[0]["Street"].ToString();
                    URM.State = dt.Rows[0]["StateId"].ToString();
                    URM.CityId =Convert.ToInt32( dt.Rows[0]["CityId"].ToString());
                    URM.City = dt.Rows[0]["C_Name"].ToString();
                    URM.Zipcode = dt.Rows[0]["Zipcode"].ToString();
                    URM.PhoneNumber = dt.Rows[0]["ContactNo"].ToString();
                    URM.FaxNumber = dt.Rows[0]["FaxNo"].ToString();
                    URM.U_Id =SecurityManager.Decrypt(dt.Rows[0]["ManagerId"].ToString());

                    URM.Manager = SecurityManager.Decrypt(dt.Rows[0]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[0]["L_Name"].ToString());
                    URM.EmailAddress = SecurityManager.Decrypt(dt.Rows[0]["EmailId"].ToString());
                }
                return URM;
            }
            catch (Exception e)
            {
                return URM;
            }
        }



        public static DataTable getlocation(string Location)
        {
            //throw new NotImplementedException();
            DbConnection obj = new DbConnection();
            DataTable dt = null;
            MySqlCommand cmd = new MySqlCommand("select Location,FacilityId from facility where FacilityId='" + Location + "' order by Location", obj.con);
            MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
            dt = new DataTable();
            asd.Fill(dt);
            return dt;
        }
    }
}