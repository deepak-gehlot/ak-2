﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.Models;
using NewAPGApplication.BussinessLayer;


namespace NewAPGApplication.BussinessLayer
{
    public class PutPatientDetails
    {
        DbConnection obj = new DbConnection();
        string Success = null;


        public string PutPainInfo(BodyTest PR, string Uid)
        {
            string Success = "0";
            try
            {
                MySqlCommand cmd = new MySqlCommand("select * from PainDetail where PatientId='" + Uid + "'", obj.con);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                asd.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    string Query = @"update PainDetail set FrontPainArea='" + PR.FrontPainArea + "', BackPainArea='" + PR.BackPainArea + "', RightsidePainArea='" + PR.LeftPainArea + "', LeftsidePainArea='" + PR.LeftPainArea + "' where PatientId='" + Uid + "'  ";
                    MySqlCommand cmd1 = new MySqlCommand(Query, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd1.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                    return Success;
                }
                else
                {
                    string Query = @"insert into PainDetail (PatientId,FrontPainArea,BackPainArea,RightsidePainArea,LeftsidePainArea) values ('" + Uid + "','" + PR.FrontPainArea + "','" + PR.BackPainArea + "','" + PR.LeftPainArea + "','" + PR.LeftPainArea + "')";
                    MySqlCommand cmd1 = new MySqlCommand(Query, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd1.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                    return Success;
                }
            }
            catch (Exception)
            {
                return Success;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }


        public string PutMalePainInfo(BodyTest PR, string Uid)
        {
            string Success = "0";
            try
            {
                //-----------

                MySqlCommand cmd = new MySqlCommand("select * from PainDetail where PatientId='" + Uid + "'", obj.con);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                asd.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    string Query = @"update PainDetail set Pain_Period='" + PR.PainHistory + "', PainCondition='" + PR.PainDescription + "'  where PatientId='" + Uid + "'  ";
                    MySqlCommand cmdd = new MySqlCommand(Query, obj.con);
                    obj.OpenDbConnection();
                    Success = cmdd.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();                  
                }

                //----------- 
               string PaidDetailID = GetPainDetailID(Uid);

               MySqlCommand cmd1 = new MySqlCommand("select PatientId from  patient_medicalinfo where PatientId='" + Uid + "'", obj.con);
                MySqlDataAdapter asd1 = new MySqlDataAdapter(cmd1);
                DataTable dt1 = new DataTable();
                asd1.Fill(dt1);
                if (dt1.Rows.Count > 0)
                {
                    string Query = @"update patient_medicalinfo set SubmittedOn='" + Convert.ToDateTime(PR.SubmittedOnDate).ToString("yyyy-MM-dd") + "', Pain_DetailId='" + PaidDetailID + "', PatientSignature='" + PR.SignaturePatient + "', PhysicianSignature='" + PR.PhysicianSignature + "', NurseSignature='" + PR.NurseSignature + "'  where PatientId='" + Uid + "'  ";
                    MySqlCommand cmd12 = new MySqlCommand(Query, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd12.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();                   
                }
                return Success;

            }
            catch (Exception)
            {
                return Success;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }


        public string PutFeMalePainInfo(BodyTest PR, string Uid)
        {
            string Success = "0";
            try
            {
                //-----------

                MySqlCommand cmd = new MySqlCommand("select * from PainDetail where PatientId='" + Uid + "'", obj.con);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                asd.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    string Query = @"update PainDetail set Pain_Period='" + PR.PainHistory + "', PainCondition='" + PR.PainDescription + "'  where PatientId='" + Uid + "'  ";
                    MySqlCommand cmdd = new MySqlCommand(Query, obj.con);
                    obj.OpenDbConnection();
                    Success = cmdd.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }

               
                string PaidDetailID = GetPainDetailID(Uid);   //-----------  Get Pain Detail Id

                MySqlCommand cmd1 = new MySqlCommand("select PatientId from  patient_medicalinfo where PatientId='" + Uid + "'", obj.con);
                MySqlDataAdapter asd1 = new MySqlDataAdapter(cmd1);
                DataTable dt1 = new DataTable();
                asd1.Fill(dt1);
                if (dt1.Rows.Count > 0)
                {
                    string Query = @"update patient_medicalinfo set SubmittedOn='" + Convert.ToDateTime(PR.SubmittedOnDate).ToString("yyyy-MM-dd") + "', Pain_DetailId='" + PaidDetailID + "', PatientSignature='" + PR.SignaturePatient + "', PhysicianSignature='" + PR.PhysicianSignature + "', NurseSignature='" + PR.NurseSignature + "'  where PatientId='" + Uid + "'  ";
                    MySqlCommand cmd12 = new MySqlCommand(Query, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd12.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }


                MySqlCommand mcmd = new MySqlCommand("select W_DetailId,PatientId from  patient_womandetails where PatientId='" + Uid + "'", obj.con);
                MySqlDataAdapter masd1 = new MySqlDataAdapter(mcmd);
                DataTable dt12 = new DataTable();
                masd1.Fill(dt12);
                if (dt12.Rows.Count < 0)
                {
                   
                }
                else
                {
                    string Query = @"insert into patient_womandetails (PatientId,CanPregnant,Pregnant,LastPeriodNormal,LastPeriodOn,LastMammogramNormal,LastMammogramOn,LastPepSmearNormal,LastPepSmearOn) values ('" + Uid + "','" + PR.CanPregnant + "','" + PR.Pregnant + "','" + PR.LastPeriodNormal + "','" + Convert.ToDateTime(PR.LastPeriodOn).ToString("yyyy-MM-dd") + "','" + PR.LastMammogramNormal + "','" + Convert.ToDateTime(PR.LastMammogramOn).ToString("yyyy-MM-dd") + "','" + PR.LastPepSmearNormal + "','" + Convert.ToDateTime(PR.LastPepSmearOn).ToString("yyyy-MM-dd") + "')";
                    MySqlCommand cmd12 = new MySqlCommand(Query, obj.con);
                    obj.OpenDbConnection();
                    Success = cmd12.ExecuteNonQuery().ToString();
                    obj.CloseDbConnection();
                }

                return Success;

            }
            catch (Exception)
            {
                return Success;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }


        public string GetPainDetailID(string id)
        {
            DataTable dt = null;
            string PainId = "0";
            try
            {
                obj.OpenDbConnection();
                MySqlCommand cmd = new MySqlCommand("select * from  paindetail Where PatientId=@PatientId", obj.con);
                cmd.Parameters.AddWithValue("@PatientId", id);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                dt = new DataTable();
                asd.Fill(dt);
                if(dt.Rows.Count>0)
                {
                    PainId = dt.Rows[0]["Pain_DetailId"].ToString();
                }

                return PainId;
            }
            catch (Exception)
            {
                return PainId;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }
    }
}

   // PatientId,CanPregnant,Pregnant,LastPeriodNormal,LastPeriodOn,LastMammogramNormal,LastMammogramOn,LastPepSmearNormal,LastPepSmearOn