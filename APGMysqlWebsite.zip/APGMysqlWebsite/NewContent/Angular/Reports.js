﻿var app = angular.module("MyReportApps", []);

app.controller('APGGraphicReport', ['$scope', '$http', function ($scope, $http) {
    GetFailictyList();
    // $scope.ReportData =[];
  
    function GetFailictyList() {
        $scope.ReportData = {};
        $http({
            method: 'Get',
            url: '/DataBind/GetAllFacilityList'
        }).success(function (data, status, headers, config) {
            if (data == "0") {
                location.href = '/Account/LogOut'; 
            }
            else {
                $scope.GetFailictyList = data;
            }
          
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    ChangeFacilitysubmit1();
    
    function ChangeFacilitysubmit1() {
       
 
        $http({
            method: 'Get',
            url: '/Report/AgeGraphicReport?Facility='+ 0        
        }).success(function (data, status, headers, config) {

            if (data == "0") {
                location.href = '/Account/LogOut';
            }
            else {
                $scope.ReportData = data;
            }
           
            //alert();
          //  document.getElementById("FId").value = data.FacilityId;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    }
    
    $scope.ChangeFacility = function (alldetails) {
        //alert(alldetails)      
        var FacilityId = alldetails;
       
            $http({
                method: 'Get',
                url: '/Report/AgeGraphicReport?Facility=' + FacilityId
            }).success(function (data, status, headers, config) {
                if (data == "0") {
                    location.href = '/Account/LogOut';
                }
                else {
                    $scope.ReportData = data;
                }
            }).error(function (data, status, headers, config) {
                $scope.message = 'Unexpected Error';
            });
        }
    }

]);