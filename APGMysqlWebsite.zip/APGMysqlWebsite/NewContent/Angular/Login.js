﻿var app = angular.module("PatientAdmin", []);

app.controller('LoginNGcontroller', ['$scope', '$http', function ($scope, $http) {
    $scope.PatientModel = {}
    $scope.submitted = false;

    $scope.data = {};
    $scope.alldetails = {};

 

}]);

//            Questionaries
