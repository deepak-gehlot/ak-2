﻿var app = angular.module("myapp", []);

app.controller('HEALTHQuestionaireController', ['$scope', '$http', function ($scope, $http) {
    $scope.PatientModel = {}
    
    $scope.submitted = false;

    $scope.data = {};
    $scope.alldetails = {};

    //------------------------------Get USer Details -------------------------------------

    GetUserDetail();
    function GetUserDetail() {
        $http({
            method: 'Get',
            url: '/ExistSearch/GetPatientInfo'
        }).success(function (data, status, headers, config) {

            $scope.PatientModel = data


            if (data.Email == "" || data.Email == null) {
                $scope.truefalse = false;
            }
            else {
                $scope.truefalse = true;
            }
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    //------------------------------ Insert -------------------------------------

    $scope.onsubmit1 = function (alldetails, ButtonType) {
        $scope.submitted = true;       
        insertPatientQuestionnaire(alldetails);
     
        function insertPatientQuestionnaire(data) {
         
            $("#divLoading").show();
            $scope.Validation = false;
            $scope.UserNameId = false;        
            $scope.MedicalValues = false;
            $scope.SurgeriesValues = false;
            $scope.MedicationAllergy = false;
            $scope.FoodAllergy = false;
            $scope.Allergies = false;          
            $scope.Smoke = false;
            $scope.PacksInday = false;
            $scope.Alcohol = false;
            $scope.PacksperDay = false;
            $scope.Drug = false;
            $scope.DrugName = false;
            $scope.AbuseVictim = false;
            $scope.AbuseVictimDetail = false;
            $scope.ClaimOrLawsuit = false;
            $scope.Compensation = false;
            $scope.InjuryOrInsurance = false;
            $scope.Other = false;
            $scope.Disability = false;          
            $scope.Review = false;
        
            $scope.Treatments = false;         
            $scope.XraysDate = false;
            $scope.XraysLocation = false;
            $scope.XraysForWhat = false;          
            $scope.CtMriDate = false;
            $scope.CtMriLocation = false;
            $scope.CtMriForWhat = false;            
            $scope.MyelogramDate = false;
            $scope.MyelogramLocation = false;
            $scope.MyelogramForWhat = false;           
            $scope.UltrasoundDate = false;
            $scope.UltrasoundLocation = false;
            $scope.UltrasoundForWhat = false;           
            $scope.EMGDate = false;
            $scope.EMGLocation = false;
            $scope.EMGForWhat = false;          
            $scope.TAPhysicianDate = false;
            $scope.TAPhysicianLocation = false;
            $scope.AnotherPhysicianForWhat = false;          
            $scope.CurrentMedications = false;
            //   $scope.Strength = false;
            //  $scope.NoOfDose = false;          
            $scope.FamilyHistory = false;
            //    $scope.PersonName = false;
            $scope.SubmittedOn = false;
            $scope.PatientSignature = false;
            $scope.SignatureValue = false;
            //$scope.SubmittedDate = false;         
            //$scope.MonthNm = false;
            //$scope.YearNm = false;
            $scope.HeartPerson= false;
            $scope.EpilepsyPerson= false;
            $scope.HypertensionPerson = false;
            $scope.GlaucomaPerson = false;
            $scope.StrokePerson= false;
            $scope.BleedingPerson = false;
            $scope.CancerPerson= false;
            $scope.KidneyPerson = false;
            $scope.DiabetesPerson = false;
            $scope.ThyroidPerson = false;
            
          

            var GetErrors = '';
            var usernameid = data.UserNameId;           
            var medicalValues = document.getElementById("MedicalValues");                  
            var surgeriesValues = document.getElementById("SurgeriesValues");      
            var medicalalergy = data.MedicationAllergy;        
            var foosalergy = data.FoodAllergy;          
            var allergies = document.getElementById("Allergies");  
            var smoke = data.Smoke;
            var packindays = data.PacksInday;
            var alcohal = data.Alcohol;
            var packprday = data.PacksperDay;
            var drug = data.Drug;
            var drugname = data.DrugName;
            var abucevictim = data.AbuseVictim;
            var abucevictimdetails = data.AbuseVictimDetail;
            var claimlawcuit = data.ClaimOrLawsuit;
            var compensation = data.Compensation;
            var inj_insurance = data.InjuryOrInsurance;
            var other = data.Other;
            var deasability = data.Disability;
            var review = document.getElementById("Review");         
            
            var treatments = document.getElementById("Treatments");           
            var xraydate = data.XraysDate;
            var xraylocation = data.XraysLocation;
            var xrayforwhat = data.XraysForWhat;
            var ctmridate = data.CtMriDate;
            var ctmrilocation = data.CtMriLocation;
            var ctmriforwhat = data.CtMriForWhat;
            var mylogramdate = data.MyelogramDate;
            var mylogramlocation = data.MyelogramLocation;
            var mylogramforwhat = data.MyelogramForWhat;
            var ultradate = data.UltrasoundDate;
            var ultralocation = data.UltrasoundLocation;
            var ultraforwhat = data.UltrasoundForWhat;
            var emgdate = data.EMGDate;
            var emglocation = data.EMGLocation;
            var emgforwhat = data.EMGForWhat;
            var physiciandate = data.TAPhysicianDate;
            var physicianlocation = data.TAPhysicianLocation;
            var physicianforwhat = data.AnotherPhysicianForWhat;           
            var currentMedications = document.getElementById("CurrentMedications");          
            // var streanth = data.Strength;
            //  var noofdose = data.NoOfDose;           
            var familyHistory = document.getElementById("FamilyHistory");
          
            //var personname = data.PersonName;
            var submittedon = data.SubmittedOn;
            // var patientsign = data.PatientSignature;
          
            var patientSignature = document.getElementById("PatientModel.PatientSignature");
          
            //var painlevel = data.PainLevel;
            //var currentpaincondition = data.CurrentPainCondition;
            //var painarea = data.PainArea;
            //var monthnm = data.MonthNm;
            //var yearnm = data.YearNm;         

            var heartperson = data.HeartPerson;
            var epilepsyperson = data.EpilepsyPerson;
            var heartperson = data.HypertensionPerson;
            var hypertensionperson = data.GlaucomaPerson;
            var strokeperson = data.StrokePerson;
            var bleedingperson = data.BleedingPerson;
            var cancerperson = data.CancerPerson;
            var kidneytperson = data.KidneyPerson;
            var diabetesperson = data.DiabetesPerson;
            var thyroidperson = data.ThyroidPerson;

            

          
            if (GetErrors == null || GetErrors == '') {
                var PatientiInfoModule = {
                    UserNameId: usernameid,
                    MedicalValues: medicalValues.value,
                    SurgeriesValues: surgeriesValues.value,
                    MedicationAllergy: medicalalergy,
                    FoodAllergy: foosalergy,
                    Allergies: allergies.value,
                    Smoke: smoke,
                    PacksInday: packindays,
                    Alcohol: alcohal,
                    PacksperDay: packprday,
                    Drug: drug,
                    DrugName: drugname,
                    AbuseVictim: abucevictim,
                    AbuseVictimDetail: abucevictimdetails,
                    ClaimOrLawsuit: claimlawcuit,
                    Compensation: compensation,
                    InjuryOrInsurance: inj_insurance,
                    Other: other,
                    Disability: deasability,
                    Review: review.value,
                   
                    Treatments: treatments.value,
                    XraysDate: xraydate,
                    XraysLocation: xraylocation,
                    XraysForWhat: xrayforwhat,
                    CtMriDate: ctmridate,
                    CtMriLocation: ctmrilocation,
                    CtMriForWhat: ctmriforwhat,
                    MyelogramDate: mylogramdate,
                    MyelogramLocation: mylogramlocation,
                    MyelogramForWhat: mylogramforwhat,
                    UltrasoundDate: ultradate,
                    UltrasoundLocation: ultralocation,
                    UltrasoundForWhat: ultraforwhat,
                    EMGDate: emgdate,
                    EMGLocation: emglocation,
                    EMGForWhat: emgforwhat,
                    TAPhysicianDate: physiciandate,
                    TAPhysicianLocation: physicianlocation,
                    AnotherPhysicianForWhat: physicianforwhat,
                    CurrentMedications: currentMedications,
                    // Strength: streanth,
                    // NoOfDose: noofdose,                  
                    FamilyHistory: familyHistory,
                    // PersonName: personname,
                    SubmittedOn: submittedon,
                    //PatientSignature: patientsign,
                    PatientSignature: patientSignature.value,
                    //PainLevel: painlevel,
                    //CurrentPainCondition: currentpaincondition,
                    //PainArea: painarea,
                    //MonthNm: monthnm,
                    //YearNm: yearnm
                    HeartPerson: heartperson,
                    EpilepsyPerson: epilepsyperson,
                    HypertensionPerson: heartperson,
                    GlaucomaPerson: hypertensionperson,
                    StrokePerson: strokeperson,
                    BleedingPerson: bleedingperson,
                    CancerPerson: cancerperson,
                    KidneyPerson: kidneytperson,
                    DiabetesPerson: diabetesperson,
                    ThyroidPerson: thyroidperson
                }
               //alert(4);

                $http({

                    method: 'POST',
                    url: '/PatientQuestionnaire/PutPatientQuestionnaire',
                    data: PatientiInfoModule
                }).success(function (data) {
                    $("#divLoading").hide();
                    $scope.Gender = data;
                    if ($scope.Gender == "\"Male\"") {
                        method: 'get',
                        location.href = '/PatientQuestionnaire/MaleBodyTest';
                    }
                    else if ($scope.Gender == "\"Female\"") {
                            method: 'get',
                            location.href = '/PatientQuestionnaire/FemaleBodyTest';
                    }                  
                });
            }
            else {
                $("#divLoading").hide();
                $scope.Validation = true;
            }

        }
    }

   
}]);

app.controller('BodyPainTestController', ['$scope', '$http', function ($scope, $http) {
    $scope.BodyTest = {}
    // GetPainDetail();
    function GetPainDetail() {
        $http({
            method: 'Get',
            url: '/Patient/GetBodyTestDetail'
        }).success(function (data, status, headers, config) {
            $scope.BodyTest = data
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails) {
        insertonsubmit(alldetails);
      //  alert(1003);
        function insertonsubmit(data) {
            $("#divLoading").show();
            var GetErrors = '';
            //alert(1001);
            var frontPainArea = document.getElementById("BodyTest.FrontPainArea");
            var backPainArea = document.getElementById("BodyTest.BackPainArea");
            var rightPainArea = document.getElementById("BodyTest.RightPainArea");
            var leftPainArea = document.getElementById("BodyTest.LeftPainArea");
            var PainDescription = frontPainArea + backPainArea + rightPainArea + leftPainArea;

            //alert(frontPainArea.value);
            //alert(backPainArea.value);
            //alert(rightPainArea.value);
            //alert(leftPainArea.value);

            if ((frontPainArea == null || frontPainArea == '') && (backPainArea == null || backPainArea == '') && (rightPainArea == null || rightPainArea == '') &&(leftPainArea == null || leftPainArea == '')){
                GetErrors += 'Please select Pain Area' + '\n';

            }
          

            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = { FrontPainArea: frontPainArea.value, BackPainArea: backPainArea.value, RightPainArea: rightPainArea.value, LeftPainArea: leftPainArea.value }
               
                $http({
                    
                    method: 'POST',
                    url: '/PatientQuestionnaire/PutPainSelection',
                    data: AddPatientModule
                }).success(function (data) {
                    $("#divLoading").hide();
                    $scope.Patientmodel = '';
                    $scope.Gender = data;
                    if ($scope.Gender == "\"Male\"") {
                        method: 'get',
                        location.href = '/PatientQuestionnaire/MalePainReport';
                    }
                    else if ($scope.Gender == "\"Female\"") {
                            method: 'get',
                            location.href = '/PatientQuestionnaire/FemalePainReport';
                    }
                });
            }
            else {
                alert(GetErrors);
            }
        }
    }
}]);

app.controller('PainReportController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.Patientmodel = {}
    $scope.onsubmit1 = function (alldetails) {
        $scope.submitted = true;
        
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $("#divLoading").show();
            $scope.PainHistory = false;
            $scope.PainDescription = false;
            $scope.PhysicianSignature = false;
            $scope.NurseSignature = false;
            $scope.SignaturePatient = false;
            $scope.SubmittedOnDate = false;

            $scope.CanPregnant = false;
            $scope.Pregnant  = false;
            $scope.LastPeriodNormal = false;
            $scope.LastPeriodOn = false;
            $scope.LastMammogramNormal  = false;
            $scope.LastMammogramOn  = false;
            $scope.LastPepSmearNormal = false;
            $scope.LastPepSmearOn = false;
            

            var GetErrors = '';
            var painhistory = document.getElementById("PainHistory");         
          //  alert(painhistory.value);

            var submittedondate = document.getElementById("SubmittedOn");
           // alert(submittedondate.value);

            var painDescription = document.getElementById("PainDescription");          
          //  alert(painDescription.value);

            var physiciansignature = document.getElementById("SignatureValue1");         
         //   alert(physiciansignature.value);

            var nursesignature = document.getElementById("SignatureValue2");          
        //    alert(nursesignature.value);

            var signaturepatient = document.getElementById("SignatureValue3");
        //    alert(signaturepatient.value);

            var canpregnant = document.getElementById("CanPregnant");
         //   alert(canpregnant.value);

            var pregnant = document.getElementById("Pregnant");
         //   alert(pregnant.value);

            var lastperiodnormal = document.getElementById("LastPeriodNormal");
        //    alert(lastperiodnormal.value);

            var lastperiodon = document.getElementById("datepicker1");
        //    alert(lastperiodon.value);

            var lastmemmonormal = document.getElementById("LastMammogramNormal");
        //    alert(lastmemmonormal.value);

            var lastmemmogramon = document.getElementById("datepicker2");
          //  alert(lastmemmogramon.value);

            var lastpepsmearnormal = document.getElementById("LastPepSmearNormal");
         //   alert(lastpepsmearnormal.value);

            var lastpepsmearon = document.getElementById("datepicker3");
           // alert(lastpepsmearon.value);

         
            var submitton = data.SubmittedOn;
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = {

                    PainHistory: painhistory.value,
                    PainDescription: painDescription.value,
                    PhysicianSignature: physiciansignature.value,
                    NurseSignature: nursesignature.value,
                    SignaturePatient: signaturepatient.value,
                    SubmittedOnDate: submittedondate.value,

                    CanPregnant: canpregnant.value,
                    Pregnant: pregnant.value,
                    LastPeriodNormal: lastperiodnormal.value,
                    LastPeriodOn: lastperiodon.value,
                    LastMammogramNormal: lastmemmonormal.value,
                    LastMammogramOn: lastmemmogramon.value,
                    LastPepSmearNormal: lastpepsmearnormal.value,
                    LastPepSmearOn: lastpepsmearon.value

                }
               // alert(3);
                $http({
                    method: 'POST',
                    url: '/PatientQuestionnaire/PutPainDetails',
                    data: AddPatientModule
                }).success(function (data) {
                    $("#divLoading").hide();
                   // $scope.ABC = data;
                    var Con = data;
                    alert(data);
                    console.log(data)

                    if (Con == null || Con == "1" || Con == "\"1\"") {
                        method: 'get',
                        alert('Register Successfully Completed !');
                        location.href = '/Womac/SelectWomacKnee';
                        data: PatientiInfoModule
                    }
                    else if (Con == null || Con == "0" || Con == "\"0\"") {
                            method: 'get',
                            alert('Register Not Successfully Completed !');
                            data: PatientiInfoModule
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }
    }
}]);