﻿var app = angular.module("PatientAdmin", []);

app.controller('NewPatientRegistration', ['$scope', '$http', function ($scope, $http) {
  
   
    $scope.PatientModel = {}
    $scope.submitted = false;
 
    $scope.data = {};
    $scope.alldetails = {};

    GetAllFacilityList();

    function GetAllFacilityList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetAllFacilityList'
        }).success(function (data, status, headers, config) {
            $scope.GetAllFacilityList = data;
        }).error(function (data, 
             headers, config) {
            $scope.message = 'Unexpected Error';
        });
    }

    //-------------------------- All Ethnicity Bind ---------------------------------
    
    GetAllEthnicityList();

    function GetAllEthnicityList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetAllEthnicityList'
        }).success(function (data, status, headers, config) {
            $scope.GetAllEthnicityList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    }
   
    //-------------------------- Check IS User ID Exist -----------------------------
 
    $scope.FocusOnIsUserIdExist = function (UserNameId) {
        var data = '';
        CheckUserIdExist(UserNameId);

        function CheckUserIdExist(data) {
           
            var GetErrors = '';
            $('.errorMsg').remove();
            if (data != null || data != undefined) {
                if (data.match("@") || data.match(" ")) {
                    $('#UserNameId').append('<div class="errorMsg" style="color:red">In Soc. Security Number @ and Blanked Spcace is not Allowed!</div>');
                    document.getElementById("UserIdExist").value = "-1";                   
                }
                else if (data != '') {                   
                    $http({
                        method: 'Get',
                        url: '/ExistSearch/GetUserNameIdExist?UserID=' + data

                    }).success(function (Success, status, headers, config) {
                        if (Success == 0) {
                            document.getElementById("UserIdExist").value = "0";
                        }
                        else {
                            $('#UserNameId').append('<div class="errorMsg" style="color:red">This Soc. Security Number Already Exist!</div>');
                            document.getElementById("UserIdExist").value = "1";
                        }
                    }).error(function (data, status, headers, config) {
                        $scope.message = 'Unexpected Error';
                    });
                }
            }
        }
    }

    //-------------------------- Check IS Email-ID Exist ----------------------------

    $scope.FocusOnIsEmailIdExist = function (Email,userid)
    {
        var useridd=userid;
        CheckEmailIdExist(Email, useridd);
        function CheckEmailIdExist(data, useridd)
        {
            var GetErrors = '';
            $('.errorMsg').remove();
            if (data != null || data != undefined) {
                if (data != '') {
                    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                    if (!re.test(data)) {
                        $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                        document.getElementById("EmailIdExit").value = "-1";
                    }
                    else {
                        $http({
                            method: 'Get',
                            url: '/ExistSearch/GetEmailIdExists?Email_id=' + data
                        }).success(function (Success, status, headers, config) {
                            if (Success == 0) {
                                $('.errorMsg').remove();
                                document.getElementById("EmailIdExit").value = "0";
                            }
                            else {
                                $('.errorMsg').remove();
                                $('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId Already Register Please Use Different EmailId</div>');
                                document.getElementById("EmailIdExit").value = "1";
                            }
                        }).error(function (data, status, headers, config) {
                            $scope.message = 'Unexpected Error';
                        });
                    }
                }
            }
        }

    }

    //--------------------------User (Patient) Registration  ------------------------------

   
    $scope.onsubmit = function (alldetails, ButtonType) {
     
        $scope.submitted = true;
        var useridd = $scope.PatientModel.UserNameId;
        var data = $scope.PatientModel.EmailId;
        CheckEmailIdExist(data, useridd);
        var conn = 1;
      
        function CheckEmailIdExist(data, useridd) {
          
            var GetErrors = '';
            $('.errorMsg1').remove();
            if (data != null && data != undefined && data != '') {
                conn = 0;
                if (data != '') {
                    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                    if (!re.test(data)) {
                        $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                        document.getElementById("EmailIdExit").value = "-1";
                    }
                    else {
                        $http({
                            method: 'Get',
                            url: '/ExistSearch/GetEmailIdExists?Email_id=' + data
                        }).success(function (Success, status, headers, config) {
                           
                            if (Success == 1) {
                                $('.errorMsg').remove();
                                $('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId Already Register Please Use Different EmailId</div>');
                                document.getElementById("EmailIdExit").value = "1";
                            }
                            else {
                                   document.getElementById("EmailIdExit").value = "0";
                                    insertonsubmit(alldetails);
                                  }
                        }).error(function (data, status, headers, config) {
                            $scope.message = 'Unexpected Error';
                        });
                    }
                }
            }
          
        }
        if (conn == 1)
        {
            insertonsubmit(alldetails);
        }
        function insertonsubmit(data) {

            //$("#divLoading").show();
            $scope.Validation = false;
            $scope.FacilityId = false;
            $scope.UserNameId = false;
            $scope.FirstName = false;
            $scope.LastName = false;
            $scope.BirthDate = false;
            $scope.DateOfBirth = false;
            $scope.birthdate = false;
            $scope.Gender = false;
            $scope.Height = false;
            $scope.Weight = false;
            $scope.EthnicityId = false;
            $scope.EmailId = false;
            $scope.Password = false;
            $scope.ConformPassword = false;
            $scope.PIN = false;
            $scope.MobileNo = false;
            $scope.OtherContactNo = false;
            $scope.Soc_Security = false;
           
            //-----------------------------
         
            var GetErrors = '';
            var buttonType = ButtonType;
            var facilityId = data.FacilityId;           
            var userNameId = data.UserNameId;

            var firstName = data.FirstName;
            var lastname = data.LastName;
            var birthdatee = document.getElementById("datepicker").value;
            var birthdate = new Date(birthdatee);
            var gender = data.Gender;
            var height = data.Height;
            var weight = data.Weight;
            var ethnicityId = data.EthnicityId;
            var emailid = data.EmailId;
            //var password = data.Password;
            //var confirmpassword = data.ConformPassword;
            //var pin = data.PIN;
           
            var mobileNo = data.MobileNo;
            var othercontact = '0';
            var socsecurity = '0';

           

            $('.errorMsg').remove();
            if (document.getElementById("UserIdExist").value == "1") {
                $('#UserNameId').append('<div class="errorMsg" style="color:red">This User Id Already Exist !</div>');
                GetErrors += '1' + '\n';
            }

            if (document.getElementById("UserIdExist").value == "-1") {
                $('#UserNameId').append('<div class="errorMsg" style="color:red">In User Id @ and Blanked Spcace is not Allowed! </div>');
                GetErrors += '2' + '\n';
            }

            if (document.getElementById("EmailIdExit").value == "1") {
                $('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId Already Register Please Use Different EmailId </div>');
                GetErrors += '3' + '\n';
            }

            if (document.getElementById("EmailIdExit").value == "-1") {
                $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id </div>');
                GetErrors += '4' + '\n';
            }
            
            if ((userNameId == null || userNameId == '')) {
                $scope.UserNameId = { color: 'red' };
                GetErrors += '5' + '\n';
            }

            if (firstName == null || firstName == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '7' + '\n';
            }

            if (lastname == null || lastname == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '8' + '\n';
            }
            if (buttonType == 1) {
                if (password == null || password == '') {
                    $scope.Password = { color: 'red' };
                    GetErrors += '9' + '\n';
                }
                if (password != null && password != '' && password.length < 8) {
                    $('#PwdLength').append('<div class="errorMsg" style="color:red">Password Lenght must be Minimum 8 character</div>');
                    GetErrors += '10' + '\n';
                }

                if (confirmpassword == null || confirmpassword == '') {
                    $scope.Confirmpwd = { color: 'red' };
                    GetErrors += '11' + '\n';
                }
                if (password != confirmpassword) {
                    $('#MatchPassword').append('<div class="errorMsg" style="color:red">Password and Confirm Password not Mached</div>');
                    GetErrors += '12' + '\n';
                }
            }
            //-----------------------------

            if (facilityId == null || facilityId == '') {
                $scope.FacilityId = { color: 'red' };
                GetErrors += '13' + '\n';
            }

            if (gender == null || gender == '') {
                $scope.Gender = { color: 'red' };
                GetErrors += '15' + '\n';
            }

            if (height == null || height == '') {
                $scope.Height = { color: 'red' };
                GetErrors += '16' + '\n';
            }

            if (height > 100 || height < 24) {
                $('#Height').append('<div class="errorMsg" style="color:red">Invalid Height</div>');
                GetErrors += '17' + '\n';
            }

            if (weight == null || weight == '') {
                $scope.Weight = { color: 'red' };
                GetErrors += '18' + '\n';
            }

            if (ethnicityId == null || ethnicityId == '') {
                $scope.EthnicityId = { color: 'red' };
                GetErrors += '19' + '\n';
            }

            //if (pin == null || pin == '') {
            //    $scope.PIN = { color: 'red' };
            //    GetErrors += '20' + '\n';
            //}

            //if (pin != null && pin != '' && pin.length != 4) {
            //    $('#PIN').append('<div class="errorMsg" style="color:red">Pin No Lenght Must be 4 Digit</div>');
            //    GetErrors += '21' + '\n';
            //}

            if (mobileNo == null || mobileNo == '') {
                $scope.MobileNo = { color: 'red' };
                GetErrors += '22' + '\n';
            }

            //if (socsecurity == null || socsecurity == '') {
            //    $scope.Soc_Security = { color: 'red' };
            //    GetErrors += '23' + '\n';
            //}
            //if (othercontact == null || othercontact == '') {
            //    $scope.PrimaryContactNo = { color: 'red' };
            //    GetErrors += '24' + '\n';
            //}
                   
            // Start --------------- Date Formate Check

            var s = document.getElementById("datepicker").value;
            var arr = s.split("-");
            var MM = arr[0];
            var dd = arr[1];
            var yy = arr[2];

            if (yy > 2015) {
                alert('date of birth should not be future date .!');
                $scope.BirthDate = { color: 'red' };
                GetErrors += '25' + '\n';
            }
            else if (dd > 32 || dd == '00') {
                alert('Invalid Date .!');
                $scope.BirthDate = { color: 'red' };
                GetErrors += '25' + '\n';
            }
            else if (MM > 13 || MM == '00') {
                alert('Invalid Date .!');
                $scope.BirthDate = { color: 'red' };
                GetErrors += '25' + '\n';
            }
            if (yy == '00') {
                alert('Invalid Date .!');
                $scope.BirthDate = { color: 'red' };
                GetErrors += '25' + '\n';
            }

            //--------------------------------End

            if (birthdate == null || birthdate == '') {
                $scope.BirthDate = { color: 'red' };
                GetErrors += '14' + '\n';
            }

            var today = new Date();
            if (new Date(birthdate).getTime() > today) {
                $('#Dateob').append('<div class="errorMsg" style="color:red">date of birth should not be future date</div>');
                $scope.BirthDate = { color: 'red' };
                GetErrors += '25' + '\n';
            }
         
            //----------------------------
       
            if (GetErrors == null || GetErrors == '') {

                var AddPatientModule = {
                    FacilityId: facilityId, UserNameId: userNameId, FirstName: firstName, LastName: lastname,
                    DateOfBirth: birthdate, Gender: gender, Height: height, Weight: weight, EthnicityId: ethnicityId,
                    EmailId: emailid, MobileNo: mobileNo, OtherContactNo: othercontact, ButtonType: buttonType

                }
                console.log(AddPatientModule);
                if (buttonType == 2) {
                
                    $http({
                        method: 'POST',
                        url: '/Admin/CreatePatientRegister',
                        data: AddPatientModule
                    }).success(function (data) {
                        var success = data;
                            $("#divLoading").hide();
                            swal({
                                title: 'Success',
                                text: 'Registration Successfull. Do You want to give your first womac?',
                                type: 'success',
                                showCancelButton: true,
                                confirmButtonColor: '#3085d6',
                                cancelButtonColor: '#d33',
                                confirmButtonText: 'Yes',
                                cancelButtonText: 'No',
                                confirmButtonClass: 'confirm-class',
                                cancelButtonClass: 'cancel-class',
                                closeOnConfirm: false,
                                closeOnCancel: false
                            },
                             function (isConfirm) {
                                 if (isConfirm) {

                                     location.href = '/Womac/SelectWomacKnee';
                                 } else {
                                     location.href = '/Admin/PatientList?FormId=' + 4;
                                 }
                             });
                        
                        //else {
                        //    alert("Something is not right please try again.");
                        //    location.href = '/Admin/CreatePatient?FormId=' + 16;
                        //}
                    });
                }
                else if (buttonType == 1)
                {
                  
                    $http({
                        method: 'POST',
                        url: '/Account/UserRegistration',
                        data: AddPatientModule
                    }).success(function (data) {
                        var Con = data;
                        if (Con != 0) {
                            $("#divLoading").hide();
                            $scope.ABC = data;


                            if (Con == null || Con == "1" || Con == "\"1\"") {
                                alert('Registration successfull');

                                location.href = '/Womac/SelectWomacKnee?PatientId=' + userNameId;
                                //  location.href = '/Account/ThanksIndex'
                                //$scope.PatientModel = '';

                                //doConfirm("Do you want to give your First Womac?", function yes() {

                                //    location.href = '/Womac/SelectWomacKnee';
                                //}, function no() {
                                //    location.href = '/Patient/MyIndex?FormId=' + FormId;
                                // });

                            }
                            else if (Con == null || Con == "2" || Con == "\"2\"") {
                                alert('Registration successfull');
                                location.href = '/Womac/SelectWomacKnee';
                                //$scope.PatientModel = '';

                                //doConfirm("Do you want to give your First Womac?", function yes() {
                                //    //form.submit();
                                //    location.href = '/Womac/SelectWomacKnee';
                                //}, function no() {
                                //    location.href = '/Patient/MyIndex?FormId=' + FormId;
                                //});


                            }
                            else if ($scope.ABC == "\"3\"") {
                                alert('This UserName/Email-id is already Registered!. Please enter different UserName/Email-id');
                            }
                        }
                        else {
                            alert("Something is not right Please try again.");
                            location.href = '/Patient/MyIndex';
                        }


                    }).error(function (serverResponse, status, headers, config) {
                        $scope.PatientModel = '';
                        $("#divLoading").hide();
                    });

                }
            }
            else {
                $("#divLoading").hide();
             
                $scope.Validation = true;
            }
         
        }
    }
    function doConfirm(msg, yesFn, noFn) {
      
        var confirmBox = $("#confirmBox");
        confirmBox.find(".message").text(msg);
        confirmBox.find(".yes,.no").unbind().click(function () {
            confirmBox.hide();
        });
        confirmBox.find(".yes").click(yesFn);
        confirmBox.find(".no").click(noFn);
        confirmBox.show();
    }


 }]);


//-------------------------------------- Login  ----------------------------------------------
   
    
app.controller('LoginNGcontroller', ['$scope', '$http', function ($scope, $http) {
   
    $scope.PatientModel = {}
    $scope.submitted = false;

    $scope.data = {};
    $scope.alldetails = {};
 
    $scope.Onlogin = function (alldetails, ButtonType) {
        $scope.submitted = true;
    
        Loginonsubmit(alldetails);
        function Loginonsubmit(data) {
            $("#divLoading").show();
            $scope.Validation = false;
            $("#divLoading").show();
            $scope.submitted = true;
            $scope.Validation = false;
            $scope.LoginEmail = false;
            $scope.LoginPassword = false;


            //-----------------------------
          
            var GetErrors = '';
            var buttonType = ButtonType;
            var loginemail = data.LoginEmail;
            var loginpassword = data.LoginPassword;


            if (loginemail == null || loginemail == '') {
                $scope.LoginEmail = { color: 'red' };
                GetErrors += '1' + '\n';
            }

            if (loginpassword == null || loginpassword == '') {
                $scope.LoginPassword = { color: 'red' };
                GetErrors += '2' + '\n';
            }
        
            if (GetErrors == null || GetErrors == '') {
             
                var AddPatientModule = {
                    LoginEmail: loginemail,
                    LoginPassword: loginpassword
                }
                
                $http({
                    method: 'POST',
                    url: '/Account/GoingOnLogin',
                    data: AddPatientModule
                }).success(function (data) {
                  
                    $("#divLoading").hide();
                    $scope.ABC = data;
                    var Con = data;
                   
                    console.log(data)
                  
                    if (Con == null || Con == "1" || Con == "\"1\"") {
                        method: 'get',
                        location.href = '/PatientDeshboard/PatientIndex';
                       // alert(' Patient Login !');
                        data: AddPatientModule
                    }
                    else if (Con == null || Con == "2" || Con == "\"2\"") {
                            method: 'get',
                            location.href = '/Admin/AdminIndex';
                       // alert('Admin Login');
                        data: AddPatientModule
                    }
                    else {
                        alert('This UserName/Email-id Not Found!. Please enter different UserName/Email-id');
                    }
                }).error(function (serverResponse, status, headers, config) {
                    $scope.PatientModel = '';
                    $("#divLoading").hide();
                });
            }
            else {
                $("#divLoading").hide();
                $scope.Validation = true;
            }
        }
    }

   
    
}]);


//-------------------------------------- Verification Code  ----------------------------------------------

app.controller('RegistrationConformation', ['$scope', '$http', function ($scope, $http) {
    $scope.onsubmit12 = function (alldetails) {
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $("#divLoading").show();
            var forgetPasswordString = data.ForgetPasswordString;
            var email = data.EmailId;
            var password = data.Password;
            var AddPatientModule = { ForgetPasswordString: forgetPasswordString, EmailId: email, Password: password }
            $http({
                method: 'POST',
                url: '/Account/Varification',
                data: AddPatientModule
            }).success(function (data) {
                $scope.VarificationString = data;
                if ($scope.VarificationString == "\"1\"") {
                    method: 'get';
                    location.href = '/Patient/ThankYou';
                    $("#divLoading").hide();
                    alert('Verification Successful!');

                }
                else if ($scope.VarificationString == "\"2\"") {
                        method: 'get';
                    $("#divLoading").hide();
                    alert('Invalid Verification String!');
                    location.href = '/Account/VarificationIndex';
                }
                else if ($scope.VarificationString == "\"-1\"") {
                        method: 'get';
                    $("#divLoading").hide();
                    alert('Email-id Not Exist!');
                    location.href = '/Account/VarificationIndex';
                }
                else if ($scope.VarificationString == "\"-3\"") {
                        method: 'get';
                    alert('Already Verified!');
                    location.href = '/Account/VarificationIndex';
                }

                else {
                    $("#divLoading").hide();
                }
            });
        }
    }
}]);







 