﻿var app = angular.module("MyInsurance", []);

app.controller('PatientInsurance', ['$scope', '$http', function ($scope, $http) {
    $scope.PatientModel = {}

    $scope.submitted = false;

    $scope.data = {};
    $scope.alldetails = {};
    
    //------------------------------Get USer Details -------------------------------------

    GetInsureUserDetail();
    function GetInsureUserDetail() {
        $http({
            method: 'Get',
            url: '/ExistSearch/GetInsureUserDetail'
        }).success(function (data, status, headers, config) {

            $scope.Insurance = data


            if (data.Email == "" || data.Email == null) {
                $scope.truefalse = false;
            }
            else {
                $scope.truefalse = true;
            }
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    //------------------------------ All State Bind -------------------------------------

    GetAllStateList();

    function GetAllStateList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetAllStateList'
        }).success(function (data, status, headers, config) {
            $scope.GetAllStateList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    }
    //----------------------------- GetCity ----------------------------------------------

    $scope.Getcity = function () {
        var StateId = $scope.PatientModel.StateId;

        if (StateId) {

            $http({
                method: 'POST',
                url: '/DataBind/GetCityList',
                data: JSON.stringify({ StateId: StateId })
            }).success(function (data, status, headers, config) {
                $scope.GetCityList = data;
            }).error(function (data, status, headers, config) {
                $scope.message = 'Unexpected Error';
            });
        }
        else {
            $scope.GetCityList = null;
        }
    }
    //----------------------------- GetCity ----------------------------------------------
    $scope.GetI_city = function () {
        var StateId = $scope.PatientModel.I_StateId;

        if (StateId) {

            $http({
                method: 'POST',
                url: '/DataBind/GetCityList',
                data: JSON.stringify({ StateId: StateId })
            }).success(function (data, status, headers, config) {
                $scope.GetI_CityList = data;
            }).error(function (data, status, headers, config) {
                $scope.message = 'Unexpected Error';
            });
        }
        else {
            $scope.GetI_CityList = null;
        }
    }

    //
    $scope.onsubmit2 = function (alldetails, ButtonType) {
        $scope.submitted = true;

        insertPatientInfo(alldetails);
        function insertPatientInfo(data) {
            $("#divLoading").show();
            $scope.Validation = false;
            $scope.UserNameId = false;
            //  $scope.Rid = false;
            $scope.PolicyNo = false;
            //$scope.InsType = false;
            $scope.InsureName  = false;
            $scope.GroupNo = false;
            $scope.EmployerName = false;
            $scope.Relation = false;
            
            // $scope.InsId = false;
         
            $scope.I_Name = false;
            $scope.I_Address = false;
            $scope.I_CityId = false;
            $scope.I_StateId = false;
            $scope.I_ZipCode = false;
            $scope.I_Policy = false;
            $scope.I_InsureName = false;
            $scope.I_Relation = false;
            $scope.I_Soc_Security = false;
            $scope.I_BirthDate = false;
            $scope.I_groupNo = false;
            $scope.I_EmployerName = false;

         
            var GetErrors = '';
            var usernameid = data.UserNameId;
            //var roleid = data.Rid;
            var policy = data.Policy;
            // var  instype= data.InsType;
            var insure_name = data.InsureName;
            var groupno = data.GroupNo;
            var empname = data.EmployerName;
            var relation = data.Relation;

            //var insid = data.InsId;
            var IName = data.I_Name;
            var IAddress = data.I_Address;
            var ICityId = data.I_CityId;
            var IStateId = data.I_StateId;
            var IZipCode = data.I_ZipCode;
            var IPolicy = data.I_Policy;
            var IInsureName = data.I_InsureName;
            var IRelation = data.I_Relation;
            var ISoc_Security = data.I_Soc_Security;
            var IBirthDate = document.getElementById("datepicker").value;
            var IgroupNo = data.I_groupNo;
            var IEmployerName = data.I_EmployerName;
          
            $('.errorMsg').remove();

            if ((usernameid == null || usernameid == '')) {
              
                GetErrors += '1' + '\n';
            }

            if (IBirthDate != null || IBirthDate != '') {

            var today = new Date();                   
            if (today > IBirthDate) {
                  //  $('#Dateob').append('<div class="errorMsg" style="color:red">date of birth should not be future date</div>');
                }
            }

            if (GetErrors == null || GetErrors == '') {

                var PatientiInfoModule = {

                    UserNameId: usernameid,                   
                    Policy: policy,                   
                    InsureName: insure_name,
                    GroupNo: groupno,
                    EmployerName: empname,
                    Relation: relation,                                      
                    I_Name: IName,
                    I_Address: IAddress,
                    I_CityId: ICityId,
                    I_StateId: IStateId,
                    I_ZipCode: IZipCode,
                    I_Policy: IPolicy,
                    I_InsureName: IInsureName,
                    I_Relation: IRelation,
                    I_Soc_Security: ISoc_Security,
                    I_BirthDate: IBirthDate,
                    I_groupNo: IgroupNo,
                    I_EmployerName: IEmployerName

                }
                $http({

                    method: 'POST',
                    url: '/Patient/PatientInsurance',
                    data: PatientiInfoModule
                }).success(function (data) {
                    $("#divLoading").hide();
                    $scope.ABC = data;
                    var Con = data;

                    console.log(data)

                    if (Con == null || Con == "1" || Con == "\"1\"") {
                        method: 'get',
                        alert('Insurance Data updated ..!');
                        GetInsureUserDetail();
                       // location.href = '/Admin/Index?param=Patient Platform Setting';
                        //   location.href = '/PatientQuestionnaire/HealthQuestionnaire_1';
                       // alert('Register Successfully !');
                        data: PatientiInfoModule
                    }
                }).error(function (serverResponse, status, headers, config) {
                    $scope.Insurance = '';
                    $("#divLoading").hide();
                });
            }
            else {
                $("#divLoading").hide();
                $scope.Validation = true;
            }

        }
    }

}]);