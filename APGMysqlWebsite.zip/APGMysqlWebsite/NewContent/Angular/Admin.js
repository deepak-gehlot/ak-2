﻿
var app = angular.module('MyAdmin', []);


app.controller('CheckUserAuthOnDeshboard', ['$scope', '$http', function ($scope, $http) {
   // alert("JG");
    $scope.onsubmit = function (alldetails, FormId) {
        insertonsubmit(alldetails, FormId);
        function insertonsubmit(FormId, AccessView) {
            var GetErrors = '';
            var accessView = AccessView;
            var formId = FormId;
            if (GetErrors == null || GetErrors == '') {
                var AddUserRoleType = { FormId: formId }
                $http({
                    method: 'Post',
                    url: '/Admin/CheckUserAuthentication',
                    data: AddUserRoleType
                }).success(function (data) {
                    var SuccessId = data;
                    if (SuccessId == 0) {
                        alert('You dont have permission to Access These Records!');
                    }
                    else if (SuccessId == 1) {
                        location.href = accessView;
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }
    }

app.controller('NewPatientRegistration', ['$scope', '$http', function ($scope, $http) {
        if (emailAddress != undefined) {
            var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            if (!re.test(emailAddress)) {
                $scope.EmailId = true;
                GetErrors += 'Invalid Format' + '\n';
            }
        }
    
    }]);


    $scope.OnSeaching = function (alldetails, AccessView) {
        Seachingonsubmit(alldetails, AccessView);
        function Seachingonsubmit(AccessView) {
            var GetErrors = '';
            var searchValue = document.getElementById("Name").value;
        
            var accessView = AccessView + searchValue;
          
            $http({
                url: accessView
            }).success(function (data) {
                var SuccessId = data;
                if (SuccessId == 0) {
                    alert('You dont have permission to Access These Records!');
                }
                else if (SuccessId == 1) {
                    location.href = accessView;
                }
            });

        }
    }
}]);

app.controller('RegistrationByAdmin', ['$scope', '$http', function ($scope, $http) {
   
    $scope.AdminRegisterModel = {}

    //-------------------------- Check IS Email-ID Exist ----------------------------

    $scope.FocusOnIsEmailIdExist = function (Email) {

        CheckEmailIdExist(Email);

        function CheckEmailIdExist(data) {
            var GetErrors = '';
            $('.errorMsg').remove();
            if (data != null || data != undefined) {
                if (data != '') {
                    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                    if (!re.test(data)) {
                        $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                        document.getElementById("EmailIdExit").value = "-1";
                    }
                    else {
                        $http({
                            method: 'Get',
                            url: '/ExistSearch/GetEmailIdExist?Email_id=' + data
                        }).success(function (Success, status, headers, config) {
                            if (Success == 0) {
                                document.getElementById("EmailIdExit").value = "0";
                            }
                            else {
                                $('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId Already Register Please Use Different EmailId</div>');
                                document.getElementById("EmailIdExit").value = "1";
                            }
                        }).error(function (data, status, headers, config) {
                            $scope.message = 'Unexpected Error';
                        });
                    }
                }
            }
        }
    }


    GetuserlevelList();
    function GetuserlevelList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetuserlevelList'
        }).success(function (data, status, headers, config) {
            $scope.GetuserlevelList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetFailictyList();
    function GetFailictyList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetAllFacilityList'
        }).success(function (data, status, headers, config) {
            $scope.GetFailictyList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };


    $scope.reloadRoute = function () {
        location.reload();
    }

    $scope.Reload = function () {
        location.reload();
    }


    $scope.onsubmit = function (alldetails) {

        $scope.UserTypeID = false;
        $scope.FacilityId = false;
        $scope.FirstName = false;
        $scope.LastName = false;
        $scope.Email = false;
        $scope.Password = false;
        $scope.PasswordLength = false;
        $scope.Confirmpwd = false;
        $scope.MatchPassword = false;
        $scope.MobileNo = false;
        CreateUserByAdmin(alldetails);
        function CreateUserByAdmin(data) {
            var GetErrors = '';
            var userTypeID = data.UserTypeID;
            var facilityID = data.FacilityID;
            var firstname = data.Firstname;
            var lastname = data.Lastname;
            var email = data.Email;
            var password = data.Password;
            var confirmpwd = data.Confirmpwd;
            var mobileNo = data.MobileNo;


            $('.errorMsg').remove();
            if (userTypeID == null) {
                $scope.UserTypeID = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (facilityID == null) {
                $scope.FacilityId = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (firstname == null || firstname == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (lastname == null || lastname == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '4' + '\n';
            }

            if (email == null || email == '') {
                $scope.Email = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (password == null || password == '') {
                $scope.Password = { color: 'red' };
                GetErrors += '6' + '\n';
            }
            if (password != null && password != '' && password.length < 8) {
                $scope.PasswordLength = true;
                GetErrors += 'Password Lenght must be Minimum 8 character' + '\n';
            }
            if (confirmpwd == null || confirmpwd == '') {
                $scope.Confirmpwd = { color: 'red' };
                GetErrors += 'Please Enter Confirm Password' + '\n';
            }
            if (password != confirmpwd) {
                $scope.MatchPassword = true;
                GetErrors += 'Password and Confirm Password not Mached' + '\n';
            }
            if (mobileNo == null || mobileNo == '') {
                $scope.MobileNo = { color: 'red' };
                GetErrors += '7' + '\n';
            }
            if (mobileNo != null || mobileNo != undefined) {
                var re = /^\(?[(. ]{1}\)?([0-9]{3})?[). ]{1}?([0-9]{3})?[-. ]{1}?([0-9]{4})$/;
                if (!re.test(mobileNo)) {
                    $('#MobileContactNo').append('<div class="errorMsg" style="color:red">Invalid Format </div>');
                    GetErrors += '14' + '\n';
                }
            }


            if (GetErrors == null || GetErrors == '') {
                var AddNewUserModule = {
                    UserTypeID: userTypeID, FacilityID: facilityID, Firstname: firstname, Lastname: lastname, Email: email, Password: password, MobileNo: mobileNo
                }
                $http({
                    method: 'POST',
                    url: '/Home/UserRegistrationByAdmin',
                    data: AddNewUserModule
                }).success(function (data) {
                    var SuccessId = data;
                    var FormId = JSON.parse(data);
                    if (SuccessId == "\"0\"") {
                        alert('This User Already Exist!');
                    }
                    else if (SuccessId == "\"-1\"") {
                        location.href = '/Account/LogOut';
                    }
                    else if (SuccessId == "\"-2\"") {
                        alert('Operation Not Executed Please Check Properly!');
                    }
                    else {


                        $scope.AdminRegisterModel = '';


                        doConfirm("New User Added Successfully! \n Do you want to add Another New User?", function yes() {
                            //form.submit();
                        }, function no() {
                            location.href = '/Home/UserList?FormId=' + FormId;
                        });



                        //if (confirm("New User Added Successfully! \n Do you want to add Another New User?") == true) {
                        //    $scope.AdminRegisterModel = '';
                        //} else {
                        //    // location.href = '/Admin/UserList?FormId=' + FormId;
                        //    location.href = '/Home/UserList?FormId=' + FormId;
                        //}
                    }
                });
            }
            else {

            }
        }

        function doConfirm(msg, yesFn, noFn) {
            var confirmBox = $("#confirmBox");
            confirmBox.find(".message").text(msg);
            confirmBox.find(".yes,.no").unbind().click(function () {
                confirmBox.hide();
            });
            confirmBox.find(".yes").click(yesFn);
            confirmBox.find(".no").click(noFn);
            confirmBox.show();
        }
    }

}]);

app.controller('CreatePatientcontroller', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.PatientModel = {}
    GetEducationList();
    function GetEducationList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetEducationList'
        }).success(function (data, status, headers, config) {
            $scope.GetEducationList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetAllEthnicityList();
    function GetAllEthnicityList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetAllEthnicityList'
        }).success(function (data, status, headers, config) {
            $scope.GetAllEthnicityList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetAllFacilityList();
    function GetAllFacilityList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetAllFacilityList'
        }).success(function (data, status, headers, config) {
            $scope.GetAllFacilityList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetAllStateList();
    function GetAllStateList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetAllStateList'
        }).success(function (data, status, headers, config) {
            $scope.GetAllStateList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    //----------------------------- Get  City ----------------------------------------------

    $scope.Getcity = function () {
     
        var StateId = $scope.PatientModel.StateId;

        if (StateId) {

            $http({
                method: 'POST',
                url: '/DataBind/GetCityList',
                data: JSON.stringify({ StateId: StateId })
            }).success(function (data, status, headers, config) {
                $scope.GetCityList = data;
                console.log("citylist", $scope.GetCityList);
            }).error(function (data, status, headers, config) {
                $scope.message = 'Unexpected Error';
            });
        }
        else {
            $scope.GetCityList = null;
        }
    }

    //----------------------------- Get MAIL City ----------------------------------------------

    $scope.GetMailcity = function () {
        var StateId = $scope.PatientModel.MailingState;
        
        if (StateId) {

            $http({
                method: 'POST',
                url: '/DataBind/GetMAILCityList',
                data: JSON.stringify({ StateId: StateId })
            }).success(function (data, status, headers, config) {
                $scope.GetMAILCityList = data;
            }).error(function (data, status, headers, config) {
                $scope.message = 'Unexpected Error';
            });
        }
        else {
            $scope.GetCityList = null;
        }
    }

    //----------------------------- GetCity ----------------------------------------------

    $scope.GetEMPcity = function () {
        var StateId = $scope.PatientModel.EmpStateId;

        if (StateId) {

            $http({
                method: 'POST',
                url: '/DataBind/GetEMPCityList',
                data: JSON.stringify({ StateId: StateId })
            }).success(function (data, status, headers, config) {
                $scope.GetEMPCityList = data;
            }).error(function (data, status, headers, config) {
                $scope.message = 'Unexpected Error';
            });
        }
        else {
            $scope.GetCityList = null;
        }
    }
        
    GetReferralList();
    function GetReferralList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetReferralList'
        }).success(function (data, status, headers, config) {
            $scope.GetReferralList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    //-------------------------- Check IS User ID Exist -----------------------------

    $scope.FocusOnIsUserIdExist = function (UserNameId) {

        CheckUserIdExist(UserNameId);

        function CheckUserIdExist(data) {
            var GetErrors = '';
            $('.errorMsg').remove();
            if (data != null || data != undefined) {
                if (data.match("@") || data.match(" ")) {
                    $('#UserNameId').append('<div class="errorMsg" style="color:red">In User Id @ and Blanked Spcace is not Allowed!</div>');
                    document.getElementById("UserIdExist").value = "-1";
                }

                else if (data != '') {
                    $http({
                        method: 'Get',
                        url: '/ExistSearch/GetUserNameIdExist?UserID=' + data

                    }).success(function (Success, status, headers, config) {
                        if (Success == 0) {
                            document.getElementById("UserIdExist").value = "0";
                        }
                        else {
                            $('#UserNameId').append('<div class="errorMsg" style="color:red">This User Id Already Exist!</div>');
                            document.getElementById("UserIdExist").value = "1";
                        }
                    }).error(function (data, status, headers, config) {
                        $scope.message = 'Unexpected Error';
                    });
                }
            }
        }
    }

    //-------------------------- Check IS Email-ID Exist ----------------------------

    $scope.FocusOnIsEmailIdExist = function (Email) {

        CheckEmailIdExist(Email);

        function CheckEmailIdExist(data) {
            var GetErrors = '';
            $('.errorMsg').remove();
            if (data != null || data != undefined) {
                if (data != '') {
                    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                    if (!re.test(data)) {
                        $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                        document.getElementById("EmailIdExit").value = "-1";
                    }
                    else {
                        $http({
                            method: 'Get',
                            url: '/ExistSearch/GetEmailIdExist?Email_id=' + data
                        }).success(function (Success, status, headers, config) {
                            if (Success == 0) {
                                document.getElementById("EmailIdExit").value = "0";
                            }
                            else {
                                $('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId Already Register Please Use Different EmailId</div>');
                                document.getElementById("EmailIdExit").value = "1";
                            }
                        }).error(function (data, status, headers, config) {
                            $scope.message = 'Unexpected Error';
                        });
                    }
                }
            }
        }

    }

    $scope.onsubmit = function (alldetails, ButtonType) {
        $scope.submitted = true;
        insertonsubmit(alldetails);

        function insertonsubmit(data) {

            $("#divLoading").show();
            $scope.UserNameId = false;
            $scope.Validation = false;
            $scope.FacilityId = false;
            $scope.FirstName = false;
            $scope.LastName = false;
            $scope.DateOfBirth = false;
            $scope.Gender = false;
            $scope.Height = false;
            $scope.Weight = false;
            $scope.Ethnicity = false;
            $scope.PIN = false;
            $scope.PINLength = false;
            $scope.PrimaryContactNo = false;
            $scope.SocSec = false;
            $scope.EduId = false;
            $scope.WorkType = false;
            $scope.Email = false;
            $scope.Password = false;
            $scope.Confirmpwd = false;
            $scope.PasswordLength = false;
            $scope.MaxFeet = false;
            $scope.MaxInch = false;
            $scope.WorkType = false;

            var GetErrors = '';
            var buttonType = ButtonType;
            var userNameId = data.UserNameId;
            var facilityId = data.FacilityId;
            var firstName = data.FirstName;
            var lastname = data.LastName;
            var nickName = data.NickName;
            var birthday = document.getElementById("datepicker").value;
          
            var gender = data.Gender;
            var street = data.Street;
            var city = data.City;
            var state = data.State;
            var zipCode = data.ZipCode;
            var email = data.Email;
            var pin = data.PIN;
            var password = data.Password;
            var confirmpwd = data.Confirmpwd;
            var heightFeet = data.HeightFeet;
            var heightInch = data.HeightInch;
            var height = data.Height;
            var weight = data.Weight;
            var primaryContactNo = data.MobileNo;
          var additionalContactNo = '0';
            var socSec = '0';
            var educationId = data.EduId;
            var occupation = data.Occupation;
            var workType = data.WorkType;
            var employer = data.Employer;
            var workPhone = data.WorkPhone;
            var contactAtWork = data.ContactAtWork
            var employerStreet = data.EmployerStreet;
            var employerCity = data.EmployerCity;
            var employerState = data.EmployerState;
            var employerZipCode = data.EmployerZipCode;
            var howKnowAboutUs = data.HowKnowAboutUs;
            var mCity = data.MCity;
            var mState = data.MState;
            var mZipCode = data.MZipCode;
            var referral = '';

            if (howKnowAboutUs == 'referral') {
                referral = data.Referral;
            }

            var currentlyHaveCP = data.CurrentlyHaveCP;

            var cPName = '';

            if (currentlyHaveCP == 'True') {
                cPName = data.CPName;
            }

            var currentlyHavePCP = data.CurrentlyHavePCP;
            var pCPName = '';

            if (currentlyHavePCP == 'True') {
                pCPName = data.PCPName;
            }

            var mailingAddress = data.MailingAddress;
            var ethnicityId = data.EthnicityId;

            $('.errorMsg').remove();

            if (document.getElementById("UserNameIdAvailable").value == "0") {
                $('#UserNameId').append('<div class="errorMsg" style="color:red">This User Id Already Exist!</div>');
                GetErrors += '1' + '\n';
            }

            if (document.getElementById("UserNameIdAvailable").value == "-1") {
                $('#UserNameId').append('<div class="errorMsg" style="color:red">In User Id @ and Blanked Spcace is not Allowed!</div>');
                GetErrors += '2' + '\n';
            }

            if (document.getElementById("EmailAvailable").value == "0") {
                $('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId Already Register Please Use Different EmailId</div>');
                GetErrors += '3' + '\n';
            }

            if (document.getElementById("EmailAvailable").value == "-1") {
                $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                GetErrors += '4' + '\n';
            }

            if ((userNameId == null || userNameId == '')) {
                $scope.UserNameId = { color: 'red' };
                alert("UserId or Email-Address any single one Is Required For Registration!");
                GetErrors += '5' + '\n';
            }

            if (facilityId == null || facilityId == '') {
                $scope.FacilityId = { color: 'red' };
                GetErrors += '6' + '\n';
            }

            if (firstName == null || firstName == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '7' + '\n';
            }

            if (lastname == null || lastname == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '8' + '\n';
            }

           
            if (gender == null || gender == '') {
                $scope.Gender = { color: 'red' };
                GetErrors += '10' + '\n';
            }

            if (height == null || height == '') {
                $scope.Height = { color: 'red' };
                GetErrors += '11' + '\n';
            }

            if (height > 100 || height < 24) {
                $('#Height').append('<div class="errorMsg" style="color:red">Invalid Height</div>');
                GetErrors += '12' + '\n';
            }

            if (weight == null || weight == '') {
                $scope.Weight = { color: 'red' };
                GetErrors += '13' + '\n';
            }

            if (weight > 500 || weight < 35) {
                $('#Weight').append('<div class="errorMsg" style="color:red">Invalid Weight</div>');
                GetErrors += '14' + '\n';
            }

            if (ethnicityId == null || ethnicityId == '') {
                $scope.EthnicityId = { color: 'red' };
                GetErrors += '15' + '\n';
            }
        
           
            if (password == null || password == '') {
                $scope.Password = { color: 'red' };
                GetErrors += '17' + '\n';
            }

            if (confirmpwd == null || confirmpwd == '') {
                $scope.Confirmpwd = { color: 'red' };
                GetErrors += '18' + '\n';
            }

            if (password != null && password != undefined && password.length < 8) {
                $('#PwdLength').append('<div class="errorMsg" style="color:red">Password Lenght must be Minimum 8 character</div>');
                GetErrors += '19' + '\n';
            }

            if (password != confirmpwd) {
                $('#MatchPassword').append('<div class="errorMsg" style="color:red">Password and Confirm Password Should be Same</div>');
                GetErrors += '20' + '\n';
            }

            if (pin == null || pin == '') {
                $scope.PIN = { color: 'red' };
                GetErrors += '21' + '\n';
            }

            if (pin != null && pin != '' && pin.length != 4) {
                $('#PINLength').append('<div class="errorMsg" style="color:red">Pin No Lenght Must be 4 Digit</div>');
                GetErrors += '22' + '\n';
            }

            if (primaryContactNo == null || primaryContactNo == '') {
                $scope.PrimaryContactNo = { color: 'red' };
                GetErrors += '23' + '\n';
            }
            if (primaryContactNo != null || primaryContactNo != undefined) {
                var re = /^\(?[(. ]{1}\)?([0-9]{3})?[). ]{1}?([0-9]{3})?[-. ]{1}?([0-9]{4})$/;
                if (!re.test(primaryContactNo)) {
                    $('#PrimaryContactNo').append('<div class="errorMsg" style="color:red">Format is not valid</div>');
                    GetErrors += '24' + '\n';
                }
            }

            //if (socSec == null || socSec == '') {
            //    $scope.Soc_Security = { color: 'red' };
            //    GetErrors += '25' + '\n';
            //}

            //if (socSec != null || socSec != undefined) {
            //    var re = /^\ ?([0-9]{3})?[-. ]?([0-9]{2})[-. ]?([0-9]{4})$/;
            //    if (!re.test(socSec)) {
            //        $('#SocSecNo').append('<div class="errorMsg" style="color:red">Format is not valid</div>');
            //        GetErrors += '26' + '\n';
            //    }
            //}

            if (workType == null || workType == '') {
                $scope.WorkType = { color: 'red' };
                GetErrors += '27' + '\n';
            }

            if (educationId == null || educationId == '') {
                $scope.EduId = { color: 'red' };
                GetErrors += '28' + '\n';
            }


            // Start --------------- Date Formate Check

            var s = document.getElementById("datepicker").value;
            var arr = s.split("-");
            var MM = arr[0];
            var dd = arr[1];
            var yy = arr[2];


            if (yy > 2014) {
                alert('date of birth should not be future date .!');
                $scope.DOB = { color: 'red' };
                GetErrors += '25' + '\n';
            }
            else if (dd > 32 || dd == '00') {
                alert('Invalid Date .!');
                $scope.DOB = { color: 'red' };
                GetErrors += '25' + '\n';
            }
            else if (MM > 13 || MM == '00') {
                alert('Invalid Date .!');
                $scope.DOB = { color: 'red' };
                GetErrors += '25' + '\n';
            }
            if (yy == '00' || yy == '0') {
                alert('Invalid Date .!');
                $scope.DOB = { color: 'red' };
                GetErrors += '25' + '\n';
            }

            //--------------------------------End

            if (birthday == null || birthday == '') {
                $scope.DOB = { color: 'red' };
                GetErrors += '9' + '\n';
            }

            var today = new Date();
            if (new Date(birthday).getTime() > today) {
                $('#Dateob').append('<div class="errorMsg" style="color:red">date of birth should not be future date</div>');
                $scope.DOB = { color: 'red' };
                GetErrors += '8' + '\n';
            }


           
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = {
                    UserNameId: userNameId, FirstName: firstName, LastName: lastname, NickName: nickName, DateOfBirth: birthday, Gender: gender, Street: street, City: city, State: state, ZipCode: zipCode, Email: email, PIN: pin, Password: password,
                    HeightFeet: heightFeet, HeightInch: heightInch, Height: height, Weight: weight, MobileNo: primaryContactNo, AdditionalContactNo: additionalContactNo, Soc_Security: socSec, EduId: educationId,
                    Occupation: occupation, WorkType: workType, Employer: employer, WorkPhone: workPhone, ContactAtWork: contactAtWork, EmployerStreet: employerStreet,
                    EmployerCity: employerCity, EmployerState: employerState, EmployerZipCode: employerZipCode, HowKnowAboutUs: howKnowAboutUs, CurrentlyHaveCP: currentlyHaveCP,
                    CPName: cPName, CurrentlyHavePCP: currentlyHavePCP, PCPName: pCPName, MailingAddress: mailingAddress, EthnicityId: ethnicityId, FacilityId: facilityId, Referral: referral,
                    MCity: mCity, MState: mState, MZipCode: mZipCode
                }

                $http({
                    method: 'POST',
                    url: '/Admin/CreatePatientRegister',
                    data: AddPatientModule
                }).success(function (data) {
                    $("#divLoading").hide();
                    var SuccessId = data;
                    if (SuccessId == "-1") {
                        location.href = '/Account/LogOut';
                    }
                    else if (SuccessId == "-2") {
                        alert('Operation Not Executed Please Check Properly!');
                    }
                    else {
                        if (buttonType == 1) {
                            console.log(SuccessId);

                            if (SuccessId == "0") {
                                alert('This Patient Type Already Exist!');
                            }
                            else {
                                                               
                                var id = JSON.parse(data);

                                document.getElementById("PatientId").value = id;
                                                               

                                if (confirm("Patient Record Added Successfully! Do You Want To Take Womac?") == true) {

                                    if (data != 0) {
                                        location.href = '/Admin/AdminSelectWomacKNee?PatientId=' + id;
                                    }
                                }
                                else {
                                    location.href = '/Admin/PatientList?FormId=4';
                                }
                            }
                        }
                        else if (buttonType == 2) {
                            location.href = '/Patient/Insurence';
                        }
                    }
                });
            }
            else {
                $("#divLoading").hide();
                $scope.Validation = true;
            }
        }
    }
}]);

app.controller('AddFacilityController', ['$scope', '$http', function ($scope, $http) {
   // alert(1);
   // $scope.Facility = {}

    //-----------------------------  Get  State ----------------------------------------------

    GetAllStateList();
    function GetAllStateList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetAllStateList'
        }).success(function (data, status, headers, config) {
            $scope.GetAllStateList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    //-----------------------------  Get  City ----------------------------------------------

    $scope.Getcity = function () {
        var StateId = $scope.Facility.State;

        if (StateId) {

            $http({
                method: 'POST',
                url: '/DataBind/GetCityList',
                data: JSON.stringify({ StateId: StateId })
            }).success(function (data, status, headers, config) {
                $scope.GetCityList = data;
            }).error(function (data, status, headers, config) {
                $scope.message = 'Unexpected Error';
            });
        }
        else {
            $scope.GetCityList = null;
        }
    }

    GetAllAdminList();
    function GetAllAdminList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetAllAdminList'
        }).success(function (data, status, headers, config) {
            $scope.GetAllAdminList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

  //  GetFacilityList();
    //function GetFacilityList() {
    //    $http({
    //        method: 'get',
    //        url: '/ExistSearch/EditFacilityDetail'
    //    }).success(function (data, status, headers, config) {
    //        $scope.Facility = data
    //    }).error(function (data, status, headers, config) {
    //        $scope.message = 'Unexpected Error';
    //    });
    //};

    
    $scope.onsubmit = function (alldetails) {
       
        $scope.submitted = true;
        insertonsubmit(alldetails);

        function insertonsubmit(data)
        {
            
            $scope.LocationName = false;
            $scope.Address = false;
            $scope.State = false;
            $scope.City = false;
            $scope.Zipcode = false;
            $scope.PhoneNumber = false;
            $scope.FaxNumber = false;
            $scope.Manager = false;
            $scope.EmailAddress = false;
            
            
            var GetErrors = '';
        
            var locationName = data.LocationName;
            var address = data.Address;
            var state = data.State;
            var city = data.City;
            var zipcode = data.Zipcode;
            var phoneNumber = data.PhoneNumber;
            var faxNumber = data.FaxNumber;
            var manager = data.Manager;
            var emailAddress = data.EmailAddress;

            if (locationName == null || locationName == '') {
                $scope.LocationName = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (address == null || address == '') {
                $scope.Address = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (state == null || state == '') {
                $scope.State = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (city == null || city == '') {
                $scope.CityId = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (zipcode == null || zipcode == '') {
                $scope.Zipcode = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (phoneNumber == null || phoneNumber == '') {
                $scope.PhoneNumber = { color: 'red' };
                GetErrors += '6' + '\n';
            }
            if (phoneNumber != null && phoneNumber != '' && phoneNumber.length != 13) {
                var re = /^\(?[(. ]{1}\)?([0-9]{3})?[). ]{1}?([0-9]{3})?[-. ]{1}?([0-9]{4})$/;
                if (!re.test(phoneNumber)) {

                    $scope.FacilityContactNo = true;
                    GetErrors += '\n' + 'Format is not valid' + '\n';

                }
            }

            if (faxNumber == null || faxNumber == '') {
                $scope.FaxNumber = { color: 'red' };
                GetErrors += '9' + '\n';
            }

            if (manager == null || manager == '') {
                $scope.Manager = { color: 'red' };
                GetErrors += '10' + '\n';
            }

            if (emailAddress == null || emailAddress == '') {
                $scope.EmailAddress = { color: 'red' };
                GetErrors += '11' + '\n';
            }
            if (emailAddress != null || emailAddress != undefined) {
                var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                if (!re.test(emailAddress)) {
                    $scope.EmailId = true;
                    GetErrors += 'Invalid Format' + '\n';
                }
            }
                     
            if (GetErrors == null || GetErrors == '') {
               
                    var AddPatientModule = {
                        LocationName: locationName, Address: address, State: state, City: city, Zipcode: zipcode,
                        PhoneNumber: phoneNumber, FaxNumber: faxNumber, Manager: manager, EmailAddress: emailAddress


                    }
                    $http({
                        method: 'POST',
                        url: '/Admin/Facility',
                        data: AddPatientModule
                    }).success(function (data) {
                        var SuccessId = data;
                        var FormId = JSON.parse(data);
                        if (SuccessId == "\"0\"") {
                            alert('This Location Name Already Exist!');
                        }
                        else if (SuccessId == "\"-1\"") {
                            location.href = '/Account/LogOut';
                        }
                        else if (SuccessId == "\"-2\"") {
                            alert('Operation Not Executed Please Check Properly!');
                        }
                        else {
                            $scope.Facility = '';
                            //if (confirm("New Facility Location Added Successfully! \n Do you want to add Another New Facility Location?") == true) {
                            //} else {
                            //    location.href = '/Home/FacilityList?FormId=' + FormId;
                            //}
                           
                            doConfirm("New Facility Location Added Successfully! \n Do you want to add Another New Facility Location?", function yes() {
                                //form.submit();
                            }, function no() {
                                location.href = '/Home/FacilityList?FormId=' + FormId;
                            });
                        }
                    });
                } else {
                }
           
        }
    }

    function doConfirm(msg, yesFn, noFn) {
        var confirmBox = $("#confirmBox");
        confirmBox.find(".message").text(msg);
        confirmBox.find(".yes,.no").unbind().click(function () {
            confirmBox.hide();
        });
        confirmBox.find(".yes").click(yesFn);
        confirmBox.find(".no").click(noFn);
        confirmBox.show();
    }
}]);

app.controller('EditFacilityDetail', ['$scope', '$http', function ($scope, $http) {

  
    $scope.Facility = {};
    $scope.CityList = [];
    $scope.Facility.City = "";
    $scope.GetAllStateList = [];
    var cityid = 0;
    var stateid = 0;
    //-----------------------------  Get  State ----------------------------------------------
   
    GetAllStateList();
    function GetAllStateList() {
       
        $http({
            method: 'Get',
            url: '/DataBind/GetAllStateList'
        }).success(function (data, status, headers, config) {
            GetAllAdminList();
            $scope.GetAllStateList = data;
          //  GetAllAdminList();
           
            
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };
  
    //-----------------------------  Get  City ----------------------------------------------


    $scope.GetCityList = function (id) {
       
        //alert($scope.Facility.State);
        var StateId = $scope.Facility.State;    
         if (StateId) {
            $http({
                method: 'POST',
                url: '/DataBind/GetCityList',
                data: JSON.stringify({ StateId: StateId })
            }).success(function (data) {
                              
                $scope.CityList = data;
               // $scope.Facility.City = cityid
                if (id == 1) {
                    $scope.Facility.CityId = "";
                }
                //alert(cityid);
                for (var i = 0; i < data.length; i++)
                {
                    if (data[i].Value == cityid)
                    {
                        //alert(data[i].Value);
                        $scope.Facility.City = cityid;
                       break;
                    }
                }
                if (i == data.length) {
                   // $scope.Facility.City = "";
                }
            }).error(function (data) {
              
            });
        }
        else {
             $scope.CityList = null;
        }
    }


    $scope.addcity = function (data) {
        var state = data.State;
        var city = data.City;
        if (city == null || city == "") {
            alert('Please enter city Name');
        }
        else {
            $http({
                method: 'POST',
                url: '/DataBind/AddCity/',
                data: { StateId: state, cityname: city }
            }).success(function (data, status, headers, config) {
                alert('City Added Successfully');
                $http({
                    method: 'POST',
                    url: '/DataBind/SelectlastCity',
                    data: { StateId: state,cityname: city }
                }).success(function (data, status, headers, config) {
                   
                    document.getElementById('txtSearchcity').value = data[0].City;
                    document.getElementById('cityid').value = data[0].City_Id;
                }).error(function (data, status, headers,config) {
                    $scope.message = 'Unexpected Error';
                });
            }).error(function (data, status, headers, config) {
                $scope.message = 'Unexpected Error';
            });

        }
    }
    
   
    function GetAllAdminList() {
      
        $http({
            method: 'Get',
            url: '/DataBind/GetAllAdminList'
        }).success(function (data, status, headers, config) {
            $scope.GetAllAdminList = data;
            GetFacilityList();
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

  
    function GetFacilityList() {
        $http({
            method: 'get',
            url: '/ExistSearch/EditFacilityDetail'
        }).success(function (data, status, headers, config) {
           // alert('Facility');
            $scope.Facility = data
           $("#managerid option[value='? undefined:undefined ?']").remove();
            cityid = $scope.Facility.City;
            
            $scope.GetCityList();
          
            document.getElementById('man_id').value = data.U_Id;
          
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };
   
    $scope.onsubmit = function (alldetails, ButtonType,num) {
        $scope.LocationName = false;
        $scope.Address = false;
        $scope.State = false;
        $scope.City = false;
        $scope.Zipcode = false;
        $scope.PhoneNumber = false;
        $scope.FaxNumber = false;
        $scope.Manager = false;
        $scope.EmailAddress = false;
       
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            var GetErrors = '';
            var buttonType = ButtonType;
            var locationName = data.LocationName;
            var address = data.Address;
            var state = data.State;
            //var statid = document.getElementById("statid").value;
            //var cityid = document.getElementById("cityid").value;
            //var StateId = statid;
            //var CityId = cityid;
            //alert(statid);
           //alert($scope.Facility.CityId);
            
            var Num = 0;
            var cityname = document.getElementById("hide").value;
          
            if (cityname == "") {
                var city = $scope.Facility.CityId;
                //alert(city);
                Num = 0;    
            }
            else
            {
                city = cityname;
                Num = 1;
            }
            var num = Num;
         
            var zipcode = data.Zipcode;
            var phoneNumber = data.PhoneNumber;
            var faxNumber = data.FaxNumber;
            var manager = data.U_Id;
           
           // var manager = $scope.Facility.U_Id;
          
          //  var manager = document.getElementById('man_id').value;
            var emailAddress = data.EmailAddress;
            if (locationName == null || locationName == '') {
                $scope.LocationName = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (address == null || address == '') {
                $scope.Address = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (state == null || state == '') {
                $scope.State = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (city == null || city == '') {
                $scope.CityId = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (zipcode == null || zipcode == '') {
                $scope.Zipcode = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (phoneNumber == null || phoneNumber == '') {
                $scope.PhoneNumber = { color: 'red' };
                GetErrors += '6' + '\n';
            }
            if (phoneNumber != null && phoneNumber != '' && phoneNumber.length != 13) {
                
                var re = /^\(?[(. ]{1}\)?([0-9]{3})?[). ]{1}?([0-9]{3})?[-. ]{1}?([0-9]{4})$/;
                if (!re.test(phoneNumber)) {
                    $scope.FacilityContactNo = true;
                    GetErrors += '\n' + 'Format is not valid' + '\n';                    
                }
               
            }
          
            if (faxNumber == null || faxNumber == '') {
                $scope.FaxNumber = { color: 'red' };
                GetErrors += '9' + '\n';
            }

            if (manager == null || manager == 'a' || manager=="") {
                $scope.Manager = { color: 'red' };
                GetErrors += '10' + '\n';
            }

            if (emailAddress == null || emailAddress == '') {
                $scope.EmailAddress = { color: 'red' };
                GetErrors += '11' + '\n';
            }
            if (emailAddress != null || emailAddress != undefined) {
                var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                if (!re.test(emailAddress)) {
                    $scope.EmailId = true;
                    GetErrors += 'Invalid Format' + '\n';
                }                
            }
            var ErrorMessage = null;
            if (buttonType == 1) {
                ErrorMessage = 'Please Click Ok to Confirm the Changes!'
            }
            else if (buttonType == 2) {
                ErrorMessage = 'Please Click Ok to Confirm the Delete!'
            }
          
            if (GetErrors == null || GetErrors == '') {
                if (confirm(ErrorMessage) == true) {
                   
                    var AddPatientModule = {
                        LocationName: locationName, Address: address, State: state, City: city, Zipcode: zipcode, PhoneNumber: phoneNumber, FaxNumber: faxNumber, Manager: manager,
                        EmailAddress: emailAddress, ButtonType: buttonType,Num:num,CityName:cityname
                    }
               
                    $http({
                        method: 'POST',
                        url: '/Home/EditFacilityData',
                        data: AddPatientModule
                      
                    }).success(function (data) {
                        var SuccessId = data;
                        var FormId = JSON.parse(data);
                        if (SuccessId == "\"0\"") {
                            alert('Operation Not Executed Please Check Properly!');
                        }
                        else if (SuccessId == "\"-1\"") {
                            location.href = '/Account/LogOut';
                        }
                        else if (SuccessId == "\"-2\"") {
                            alert('Operation Not Executed Please Check Properly!');
                        }
                        else {
                            $scope.UserRegisterModel = '';
                            location.href = '/Home/FacilityList?FormId=' + FormId;
                        }
                    });
                } else {
                }
            }
            else {
                //alert(GetErrors);
            }
        }
    }
    function getcityName(CityId) {
        $http({
            method: 'POST',
            url: '/DataBind/GetCityName',
            data: JSON.stringify({ CityId: CityId })
        }).success(function (data) {
            $scope.CityList = data;
            bindcity(CityId);
        }).error(function (data) {

        });
    }
    function bindcity(CityId)
    {
        
        $("#cityid").val(CityId);
        $scope.Facility.City = CityId;
    }

}]);

app.controller('EditUserProfileDetail', ['$scope', '$http', function ($scope, $http) {
   
    $scope.AdminRegisterModel = {}
   
    GetFailictyList();
    function GetFailictyList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetAllFacilityList'
        }).success(function (data, status, headers, config) {
            $scope.GetFailictyList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetUserDetail();
    function GetUserDetail() {
        $http({
            method: 'get',
            url: '/ExistSearch/GetAdminUserDetail'
        }).success(function (data, status, headers, config) {
            $scope.AdminRegisterModel = data
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails, ButtonType) {
        $scope.UserTypeID = false;
        $scope.FacilityId = false;
        $scope.FirstName = false;
        $scope.LastName = false;
        $scope.Email = false;
        $scope.MobileNo = false;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            var GetErrors = '';
            var buttonType = ButtonType;
            var userTypeID = data.UserTypeID;
            var facilityID = data.FacilityID;
            var firstName = data.FirstName;
            var lastName = data.LastName;
            var email = data.Email;
            var mobileNo = data.MobileNo;
            $('.errorMsg').remove();
            if (userTypeID == null) {
                $scope.UserTypeID = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (facilityID == null) {
                $scope.FacilityId = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (firstName == null || firstName == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (lastName == null || lastName == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (email == null || email == '') {
                $scope.Email = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (mobileNo == null || mobileNo == '') {
                $scope.MobileNo = { color: 'red' };
                GetErrors += '6' + '\n';
            }
            if (mobileNo != null || mobileNo != undefined) {
                var re = /^\(?[(. ]{1}\)?([0-9]{3})?[). ]{1}?([0-9]{3})?[-. ]{1}?([0-9]{4})$/;
                if (!re.test(mobileNo)) {
                    $('#mobileContactNo').append('<div class="errorMsg" style="color:red">Format is not valid</div>');
                    GetErrors += '14' + '\n';
                }
            }
            var ErrorMessage = null;
            if (buttonType == 1) {
                ErrorMessage = 'Please Click Ok to Confirm the Changes!'
            }
            else if (buttonType == 2) {
                ErrorMessage = 'Please Click Ok to Confirm the Delete!'
            }
            if (GetErrors == null || GetErrors == '') {
                if (confirm(ErrorMessage) == true) {
                    var AddPatientModule = {
                        UserTypeID: userTypeID, FacilityID: facilityID, FirstName: firstName, LastName: lastName, Email: email, MobileNo: mobileNo, ButtonType: buttonType
                    }
                    $http({
                        method: 'POST',
                        url: '/Admin/EditUserProfile',
                        data: AddPatientModule
                    }).success(function (data) {
                        UserType = data;
                        if (UserType == "\"-1\"") {
                            location.href = '/Account/LogOut';
                        }
                        else if (UserType == "\"1\"") {
                            $scope.AdminRegisterModel = '';
                            location.href = '/Admin/Index?param=User Setting';
                            alert('User Profile Updated!');
                        }
                        else if (UserType == "\"0\"") {
                            alert('Operation Not Executed Please Check Properly!');
                        }
                        //location.href = '/Admin/UserList';
                    });
                } else {
                }
            }
        }
    }
}]);

app.controller('PasswordResetController', ['$scope', '$http', function ($scope, $http) {
  
    $scope.submitted = false;
    $scope.PatientModel = {}
    $scope.onsubmit = function (alldetails) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $scope.Email = false;
            $scope.OldPassword = false;
            $scope.Password = false;
            $scope.Confirmpwd = false;
            $scope.PasswordLength = false;
            $scope.MatchPassword = false;
            var GetErrors = '';
            var email = document.getElementById("Email").value;  
            var oldPassword = data.OldPassword;
            var password = data.Password;
            var confirmpwd = document.getElementById("Confirmpwd").value;  //data.Confirmpwd;
            $('.errorMsg').remove();

                      
            if (email == null || email == '') {
                $scope.Email = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (oldPassword == null || oldPassword == '') {
                $scope.OldPassword = { color: 'red' };
                GetErrors += '3' + '\n';
                alert('Please enter correct old password !');
            }
            if (password == null || password == '') {
                $scope.Password = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (confirmpwd == null || confirmpwd == '') {
                $scope.Confirmpwd = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (password != null && password != undefined && password.length < 8) {
                $('#PwdLength').append('<div class="errorMsg" style="color:red">New Password Lenght must be Minimum 8 character</div>');
                GetErrors += '6' + '\n';
            }
            if (password != confirmpwd) {
                $('#MatchPassword').append('<div class="errorMsg" style="color:red">New Password and Confirm Password Should be Same</div>');
                GetErrors += '7' + '\n';
            }
           
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = { Email: email, OldPassword: oldPassword, Password: password, Confirmpwd: confirmpwd }
                $http({
                    method: 'POST',
                    url: '/Admin/ChangePassword',
                    data: AddPatientModule
                }).success(function (data) {
                    UserType = data;
                    $scope.PatientModel = '';
                    if (UserType == "\"0\"") {
                        location.href = '/Account/LogOut';
                    }
                    else {
                        if (UserType == "\"No\"") {
                            alert('Please enter correct old password !');
                        }
                        else if (UserType == "\"10\"") {
                            alert('Password Reset Successfully!');
                            location.href = '/Admin/Index?param=Patient Platform Setting';
                        }
                        else {
                            alert('Password Reset Successfully!');
                            location.href = '/Admin/Index?param=User Setting';
                        }
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }

    }
}]);

app.controller('PINResetController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.Patientmodel = {}
    $scope.onsubmit = function (alldetails) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $scope.Email = false;
            $scope.Password = false;
            $scope.PIN = false;
            $scope.ConfirmPIN = false;
            $scope.PINLength = false;
            $scope.MatchPIN = false;

            var GetErrors = '';

            var userNameId = document.getElementById("UserNameId").value;
            var email = document.getElementById("Email").value;
            var password = document.getElementById("Password").value;           // data.Password;
            var pin = document.getElementById("PIN").value;                    //  data.PIN;
            var confirmPIN = document.getElementById("ConfirmPIN").value;     //   data.ConfirmPIN;

            $('.errorMsg').remove();
            if ((userNameId == null || userNameId == '') && (email == null || email == '')) {
                $scope.Email = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (password == null || password == '' ) {
                $scope.Password = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (pin == null || pin == '') {
                $scope.PIN = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (confirmPIN == null || confirmPIN == '') {
                $scope.ConfirmPIN = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (pin != null && pin != undefined && pin.length != 4) {
                $('#PINLength').append('<div class="errorMsg" style="color:red">New PIN No Length Must be 4 Digit</div>');
                GetErrors += '6' + '\n';
            }
            if (pin != confirmPIN) {
                $('#MatchPIN').append('<div class="errorMsg" style="color:red">New PIN and Confirm PIN should be same</div>');
                GetErrors += '7' + '\n';
            }

            if ((password == null || password == '') && (pin == null || pin == '') && (confirmPIN == null || confirmPIN == '')) {
                alert('Please enter the required details.');
            }

            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = { UserNameId: userNameId, Email: email, Password: password, PIN: pin, ConfirmPIN: confirmPIN }
                $http({
                    method: 'POST',
                    url: '/Admin/PinNoChange',
                    data: AddPatientModule
                }).success(function (data) {
                    UserType = data;
                    $scope.PatientModel = '';
                    if (UserType == "\"No\"") {
                        alert('Your Profile Password not Match!');
                    }
                    else if (UserType == "\"-1\"") {
                        location.href = '/Account/LogOut';
                    }
                    else if (UserType == "\"1\"") {
                        $scope.Patientmodel = '';
                        alert('PIN Reset Successfully!');
                        location.href = '/Admin/Index?param=Patient Platform Setting';
                    }
                    else if (UserType == "\"0\"") {
                        alert('UserIdentifire or password not Match!');
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }

    }
}]);

app.controller('EditQuestionController', ['$scope', '$http', function ($scope, $http) {
    GetDiseaseQuestion();
    function GetDiseaseQuestion() {
        $http({
            method: 'Get',
            url: '/Admin/GetDiseaseQuestion'
        }).success(function (data, status, headers, config) {
            $scope.DiseaseQuestion = data
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails, ButtonType) {
        insertonsubmit(alldetails);
        function insertonsubmit(data) {

            $scope.UserNameId = false;
            var GetErrors = '';
            var buttonType = ButtonType;
            var diseaseId = data.DiseaseId;
            var diseaseTypeId = data.DiseaseTypeId;
            var diseaseTypeName = data.DiseaseTypeName;
            var diseaseName = data.DiseaseName;
            //QuestionName

           
            
            if (buttonType == 1) {
                if (diseaseName == null || diseaseName == '') {
                    alert('Please enter the question');
                    $scope.QuestionName = { color: 'red' };
                    GetErrors += '1' + '\n';
                }
                if (GetErrors == null || GetErrors == '') {

                    if (confirm("Please Click Ok to Confirm the Changes!") == true) {

                        var AddPatientModule = {
                            DiseaseId: diseaseId, DiseaseTypeId: diseaseTypeId, DiseaseTypeName: diseaseTypeName, DiseaseName: diseaseName, ButtonType: buttonType
                        }
                        $http({
                            method: 'POST',
                            url: '/Admin/EditDiseaseQuestion',
                            data: AddPatientModule
                        }).success(function (data) {
                            var DiseaseTypeId = JSON.parse(data);

                            if (DiseaseTypeId != 0) {
                                location.href = '/Home/WomacQuestionList?DiseaseTypeId=' + DiseaseTypeId;
                                alert('Question Edit Successfully');
                                $scope.DiseaseName = '';
                            }
                        });
                    } else {
                    }
                }
            } else if (buttonType == 2) {
                if (confirm("Please Click Ok to Confirm the Delete!") == true) {
                    var AddPatientModule = {
                        DiseaseId: diseaseId, DiseaseTypeId: diseaseTypeId, DiseaseTypeName: diseaseTypeName, DiseaseName: diseaseName, ButtonType: buttonType
                    }
                    $http({
                        method: 'POST',
                        url: '/Admin/EditDiseaseQuestion',
                        data: AddPatientModule
                    }).success(function (data) {
                        var DiseaseTypeId = JSON.parse(data);

                        if (DiseaseTypeId != 0) {
                            location.href = '/Home/WomacQuestionList?DiseaseTypeId=' + DiseaseTypeId;
                            alert('Question Delete Successfully');
                            $scope.DiseaseName = '';
                        }


                    });
                } else {
                }
            }
            
        }
    }
}]);

app.controller('DiseaseQuestionController', ['$scope', '$http', function ($scope, $http) {

    $scope.onsubmit = function (alldetails) {
            
        insertonsubmit(alldetails);
      
        function insertonsubmit(data) {
           
            $scope.DiseaseName = false;            
            var GetErrors = '';            
            var diseaseTypeId = document.getElementById("TypeId").value;         
            var diseaseName = document.getElementById("QuestionName").value;
                               
            if (diseaseName == null || diseaseName == '') {             
                $scope.DeseasName = { color: 'red' };
                alert('Please enter the question');
            }
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = { DiseaseName: diseaseName, DiseaseTypeId: diseaseTypeId }
                $http({
                    method: 'POST',
                    url: '/Admin/CreateDiseaseQuestion',
                    data: AddPatientModule
                }).success(function (data) {                    
                   
                    var DiseaseTypeId = JSON.parse(data);
                    
                    if (DiseaseTypeId != 0) {
                        alert('Question Add Successfully');
                        location.href = '/Home/WomacQuestionList?DiseaseTypeId=' + DiseaseTypeId;
                       
                        $scope.DiseaseQuestion = '';
                    }                   
                });
            }
            else {
                alert(GetErrors);
            }
        }
    }
}]);

app.controller('UpdateUserDetail', ['$scope', '$http', function ($scope, $http) {
    $scope.AdminRegisterModel = {}
    GetuserlevelList();

    $scope.FocusOnIsEmailIdExist = function (Email) {

        CheckEmailIdExist(Email);

        function CheckEmailIdExist(data) {
            var GetErrors = '';
            $('.errorMsg').remove();
            if (data != null || data != undefined) {
                if (data != '') {
                    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                    if (!re.test(data)) {
                        $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                        document.getElementById("EmailIdExit").value = "-1";
                    }                   
                }
            }
        }



    }

    function GetuserlevelList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetuserlevelList'
        }).success(function (data, status, headers, config) {
            $scope.GetuserlevelList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetAllFacilityList();
    function GetAllFacilityList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetAllFacilityList'
        }).success(function (data, status, headers, config) {
            $scope.GetAllFacilityList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetUserDetail();
    function GetUserDetail() {
        $http({
            method: 'get',
            url: '/ExistSearch/GetAdminUserDetail'
        }).success(function (data, status, headers, config) {
            $scope.AdminRegisterModel = data
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails, ButtonType) {
        $scope.UserTypeID = false;
        $scope.FacilityId = false;
        $scope.FirstName = false;
        $scope.LastName = false;
        $scope.Email = false;
        $scope.MobileNo = false;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            var GetErrors = '';
            var buttonType = ButtonType;
            var userTypeID = data.UserTypeID;
            var facilityID = data.FacilityID;
            var firstName = data.FirstName;
            var lastName = data.LastName;
            var email = data.Email;
            var mobileNo = data.MobileNo;
            $('.errorMsg').remove();
            if (userTypeID == null) {
                $scope.UserTypeID = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (facilityID == null || facilityID == '') {
                $scope.FacilityId = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (firstName == null || firstName == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (lastName == null || lastName == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (email == null || email == '') {
                $scope.Email = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (mobileNo == null || mobileNo == '') {
                $scope.MobileNo = { color: 'red' };
                GetErrors += '6' + '\n';
            }


            if (mobileNo != null || mobileNo != undefined) {
                var re = /^\(?[(. ]{1}\)?([0-9]{3})?[). ]{1}?([0-9]{3})?[-. ]{1}?([0-9]{4})$/;
                if (!re.test(mobileNo)) {
                    $('#mobileContactNo').append('<div class="errorMsg" style="color:red">Format is not valid</div>');
                    GetErrors += '14' + '\n';
                }
            }
            if (email != null || email != undefined) {
                var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                if (!re.test(email)) {
                    var cou = 1;
                    if (cou == 1)
                    {
                        $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                        GetErrors += '15' + '\n';
                    }
                  
                }
            }


        
            var ErrorMessage = null;
            if (buttonType == 1) {
                ErrorMessage = 'Please Click Ok to Confirm the Changes!'
            }
            else if (buttonType == 2) {
                ErrorMessage = 'Please Click Ok to Confirm the Delete!'
            }
            if (GetErrors == null || GetErrors == '') {
                if (confirm(ErrorMessage) == true) {
                    var AddPatientModule = {
                        UserTypeID: userTypeID, FacilityID: facilityID, FirstName: firstName, LastName: lastName, Email: email, MobileNo: mobileNo, ButtonType: buttonType
                    }
                    $http({
                        method: 'POST',
                        url: '/Admin/EditUser',
                        data: AddPatientModule
                    }).success(function (data) {
                        UserType = data;
                        if (UserType == "\"-1\"") {
                            location.href = '/Account/LogOut';
                        }
                        else if (UserType == "\"1\"") {
                            $scope.AdminRegisterModel = '';
                            location.href = '/Home/UserList?FormId=35';
                        }
                        else if (UserType == "\"0\"") {
                            alert('Operation Not Executed Please Check Properly!');
                        }
                    });
                } else {
                }
            }

            else {
                $('#EmailId').append('<div class="errorMsg" style="color:red"></div>');
                $('#mobileContactNo').append('<div class="errorMsg" style="color:red"></div>');
            }
        }
    }
}]);



app.controller('ChangePasswordController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.PatientModel = {}
 
    //-------------------------- Check IS Email-ID Exist ----------------------------

    $scope.FocusOnIsEmailIdExist = function (Email) {
   
        CheckEmailIdExist(Email);

        function CheckEmailIdExist(data) {
            var GetErrors = '';
            $('.errorMsg').remove();
            if (data != null || data != undefined) {
                if (data != '') {
                    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                    if (!re.test(data)) {
                        $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                        document.getElementById("EmailIdExit").value = "-1";
                    }
                    else {
                        $http({
                            method: 'Get',
                            url: '/ExistSearch/GetEmailIdExists?Email_id=' + data
                        }).success(function (Success, status, headers, config) {
                            if (Success == 0) {
                                $('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId Not Registered Please Use Registered EmailId</div>');
                                document.getElementById("EmailIdExit").value = "0";
                            }
                            else {                                
                                document.getElementById("EmailIdExit").value = "1";
                            }
                        }).error(function (data, status, headers, config) {
                            $scope.message = 'Unexpected Error';
                        });
                    }
                }
            }
        }
        

   }

    $scope.Patientmodel = {};

    //$scope.onsubmit = function (PatientModel) {
    //    $scope.submitted = true;

    //    $http({
    //        method: 'POST',
    //        url: '/Admin/ChangeUserPassword',
    //        data: PatientModel
    //    }).success(function (data) {
    //        alert("BMI Created Successfully.");
    //    })
    //}

   
    $scope.onsubmit = function (alldetails) {
     
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
       
            $scope.Email = false;
           // $scope.oldPassword = false;
            $scope.Password = false;
            $scope.Confirmpwd = false;
            $scope.PasswordLength = false;
            $scope.MatchPassword = false;
            var GetErrors = '';

            var email = document.getElementById("Email").value;
            var emailstatus = document.getElementById("EmailIdExit").value;
         
           // var oldpassword = data.oldPassword;
            var password = data.Password;
            var confirmpwd = data.Confirmpwd;

           
            if (email == null || email == '') {
                $scope.Email = true;
                GetErrors += 'Please enter Valid Email address' + '\n';
                alert('Please enter Valid Email address');
            }

            if (password == null || password == '') {
                $scope.Password = true;
                GetErrors += 'Please enter New password' + '\n';
            }
            //if (oldpassword == null || oldpassword == '') {
            //    $scope.oldPassword = true;
            //    GetErrors += 'Please enter old password' + '\n';
            //}
            if (confirmpwd == null || confirmpwd == '') {
                $scope.Confirmpwd = true;
                GetErrors += 'Please enter Confirm password' + '\n';
            }

            if (password != null && password != '' && password.length < 8) {
                $scope.PasswordLength = true;
                GetErrors += 'New Password Lenght must be Minimum 8 character' + '\n';
            }

            if (password != confirmpwd) {
                $scope.MatchPassword = true;
                GetErrors += 'New Password and Confirm Password Should be Same' + '\n';
            }
       
            if ((GetErrors == null || GetErrors == '') && (emailstatus != 0)) {
                var AddPatientModule = { Password: password, Confirmpwd: confirmpwd, EmailId: email }
             
                $http({
                    method: 'POST',
                    url: '/Admin/ChangePassword',
                    data: AddPatientModule
                }).success(function (data) {
                    UserType = data;
                    console.log(UserType);
                    $scope.PatientModel = '';
                    if (UserType == "\"User Not Exist!\"") {
                        alert("User Not Exist!");
                    }
                    else {

                        //if (UserType == "\"No\"") {
                        //    alert('Old Password id Wrong ..!');
                        //}

                        if (UserType == "\"10\"") {
                            alert('Password Changed Successfully!');
                            location.href = '/Admin/Index?param=User Platform Setting';
                        }

                        else if (UserType != "\"10\"" && UserType != "\"No\"") {
                            alert('Password Changed Successfully!');
                            location.href = '/Admin/Index?param=User Platform Setting';
                        }
                    }
                });
            }
            else {

            }
        }
    }
}]);

app.controller('ReferralController', ['$scope', '$http', function ($scope, $http) {

    $scope.Referral = {};

    $scope.onsubmit = function (alldetails) {

        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $scope.Name = false;
            $scope.Description = false;

            var GetErrors = '';

            var name = document.getElementById("ReferralName").value;                  // data.Name;
            var description = document.getElementById("ReferralDescription").value;   // data.Description;

            if (name == null || name == '') {
                $scope.Name = { color: 'red' };
                GetErrors += '1' + '\n';
            }

            if (description == null || description == '') {
                $scope.Description = { color: 'red' };
                GetErrors += '2' + '\n';
            }

            if (GetErrors == null || GetErrors == '') {
                var AddReferralModule = { Name: name, Description: description }
                $http({
                    method: 'POST',
                    url: '/Admin/CreateReferralSave',
                    data: AddReferralModule
                }).success(function (data) {
                    var SuccessId = data;
                    var FormId = JSON.parse(data);
                    if (SuccessId == "\"0\"") {
                        alert('Duplicate Referral Name!');
                    }
                    else if (SuccessId == "\"-1\"") {
                        location.href = '/Account/LogOut';
                    }
                    else if (SuccessId == "\"-2\"") {
                        alert('Operation Not Executed Please Check Properly!');
                    }
                    else {
                        alert('New Referral Added Successfully!');
                        $scope.Referral = '';
                        $scope.UserRoleType = '';
                        $scope.Name = '';
                        $scope.Description = '';
                        location.href = '/Home/ReferralList?FormId=' + FormId;
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }
    }
}]);

app.controller('UserRoleTypeController', ['$scope', '$http', function ($scope, $http) {
   
    $scope.UserRoleType = {};
 
    $scope.onsubmit = function (alldetails) {
 
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $scope.UserType = false;

            var GetErrors = '';

            var usertype = document.getElementById("UserType").value;    // data.UserType;

            if (usertype == null || usertype == '') {
                $scope.UserTypeName = { color: 'red' };
                GetErrors += '1' + '\n';
            }
                        
            if (GetErrors == null || GetErrors == '') {
                var AddUserTypeModule = { UserType: usertype}
                $http({
                    method: 'POST',
                    url: '/Admin/NewUserType',
                    data: AddUserTypeModule
                }).success(function (data) {
                    var SuccessId = data;
                    var FormId = JSON.parse(data);
                    if (SuccessId == "\"0\"") {
                        alert('Duplicate User Type !');
                    }
                    else if (SuccessId == "\"-1\"") {
                        location.href = '/Account/LogOut';
                    }
                    else if (SuccessId == "\"-2\"") {
                        alert('Operation Not Executed Please Check Properly!');
                    }
                    else if (SuccessId == "-1")
                    {
                        location.href='/Account/LogOut';
                    }
                    else {
                        alert('New User Type Added Successfully!');
                        $scope.Referral = '';
                        $scope.UserRoleType = '';
                        $scope.Name = '';
                        $scope.Description = '';
                        location.href = '/Home/UserLevel?FormId=' + FormId;
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }
    }
}]);

app.controller('ForgotPasswordController', ['$scope', '$http', function ($scope, $http) {

    $scope.PatientModel = {}

    //-------------------------- Check IS Email-ID Exist ----------------------------

    $scope.FocusOnIsEmailIdExist = function (Email) {
     
        CheckEmailIdExist(Email);

        function CheckEmailIdExist(data) {
            var GetErrors = '';
            $('.errorMsg').remove();
            if (data != null || data != undefined) {
                if (data != '') {
                    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                    if (!re.test(data)) {
                        $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                        document.getElementById("EmailIdExit").value = "-1";
                    }
                    else {
                        $http({
                            method: 'Get',
                            url: '/ExistSearch/CheckEmailIdExist?Email_id=' + data
                        }).success(function (Success, status, headers, config) {
                            if (Success == 0) {
                                $('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId Not Register Please Use Registered EmailId</div>');
                                document.getElementById("EmailIdExit").value = "0";
                            }
                            else {
                                document.getElementById("EmailIdExit").value = "1";
                            }
                        }).error(function (data, status, headers, config) {
                            $scope.message = 'Unexpected Error';
                        });
                    }
                }
            }
        }
    }

    $scope.onsubmit = function (alldetails) {

       
        $scope.EmailId = false;
       
        CreateUserByAdmin(alldetails);

        function CreateUserByAdmin(data) {
            var GetErrors = '';
           
            var email = data.EmailId;
           
           
            $('.errorMsg').remove();
            
            if (email == null || email == '') {
                $scope.Email = { color: 'red' };
                GetErrors += '1' + '\n';
            }           
            
            if (GetErrors == null || GetErrors == '') {
                var AddNewUserModule = {
                    EmailId: email
                }
                $http({
                    method: 'POST',
                    url: '/Account/Forgetpassword',
                    data: AddNewUserModule
                }).success(function (data) {
                    var SuccessId = data;
                    var FormId = JSON.parse(data);
                    if (SuccessId == "\"0\"") {
                        alert('Incorrect Email ID .!');
                    }                    
                    else if (SuccessId == "\"-2\"") {
                        alert('Operation Not Executed Please Check Properly!');
                    }
                    else {
                        if (SuccessId == "\"1\"") {
                            alert('Mail Send Successfully .!');
                            location.href = '/Account/Resetpassword';
                        }
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }
    }
}]);

app.controller('ResetPasswordController', ['$scope', '$http', function ($scope, $http) {

    $scope.PatientModel = {}

    //-------------------------- Check IS Email-ID Exist ----------------------------
      
    $scope.onsubmit = function (alldetails) {
                
        $scope.EmailId = false;
        $scope.Vcode = false;
        $scope.Password = false;
        $scope.PasswordLength = false;
        $scope.Confirmpwd = false;
        $scope.MatchPassword = false;
        $scope.ForgetPasswordString = false;

        CreateUserByAdmin(alldetails);
        function CreateUserByAdmin(data) {
            var GetErrors = '';
            var varifecation = data.ForgetPasswordString;
            var email = data.EmailId;
            var password = data.Password;
            var confirmpwd = data.Confirmpwd;
          
            //alert(varifecation);
            //alert(password);
            //alert(confirmpwd);

            $('.errorMsg').remove();
            
            if (varifecation == null || varifecation == '') {
                $scope.Vcode = true;
                GetErrors += '* Please Enter Valid Verification Code' + '\n';
            }
            if (password == null || password == '') {
                $scope.Password = { color: 'red' };
                GetErrors += '6' + '\n';
            }
            if (password != null && password != '' && password.length < 8) {
                $scope.PasswordLength = true;
                GetErrors += 'Password Lenght must be Minimum 8 character' + '\n';
            }
            if (confirmpwd == null || confirmpwd == '') {
                $scope.Confirmpwd = { color: 'red' };
                GetErrors += 'Please Enter Confirm Password' + '\n';
            }
            if (password != confirmpwd) {
                $scope.MatchPassword = true;
                GetErrors += 'Password and Confirm Password not Mached' + '\n';
            }
            
           
            if (GetErrors == null || GetErrors == '') {
                var AddNewUserModule = {

                    Email: email, ForgetPasswordString: varifecation, Password: password, Confirmpwd: confirmpwd
                }
               
                $http({

                    method: 'POST',
                    url: '/Account/Resetpassword',
                   
                    data: AddNewUserModule
                }).success(function (data) {
                    var SuccessId = data;
                    var FormId = JSON.parse(data);
                    if (SuccessId == "\"0\"") {
                        alert('Invalid Varification Code !');
                    }
                    else if (SuccessId == "\"1\"") {
                        alert('Your Password Change Successfully ..!');
                        location.href = '/Patient/MyIndex';
                    }
                    else  {
                        alert('Operation Not Executed Please Check Properly!');
                    }                    
                });
            }
            else {
                //alert(GetErrors);
            }
        }
    }
  
}]);

