﻿var app = angular.module("PatientInfo", []);




app.controller('PatientOtherInformation', ['$scope', '$http', function ($scope, $http) {

    $scope.PatientModel = {}
    
    $scope.submitted = false;

    $scope.data = {};
    $scope.alldetails = {};
    
    //-------------------------- Check IS Email-ID Exist ----------------------------

    $scope.FocusOnIsEmailIdExist = function (Email) {

        CheckEmailIdExist(Email);

        function CheckEmailIdExist(data) {
            var GetErrors = '';
            $('.errorMsg').remove();
            if (data != null || data != undefined) {
                if (data != '') {
                    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                    if (!re.test(data)) {
                        $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                        document.getElementById("EmailIdExit").value = "-1";
                    }
                    else {
                        $http({
                            method: 'Get',
                            url: '/ExistSearch/GetEmailIdExist?Email_id=' + data
                        }).success(function (Success, status, headers, config) {
                            if (Success == 0) {
                                document.getElementById("EmailIdExit").value = "0";
                            }
                            else {
                                $('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId Already Register Please Use Different EmailId</div>');
                                document.getElementById("EmailIdExit").value = "1";
                            }
                        }).error(function (data, status, headers, config) {
                            $scope.message = 'Unexpected Error';
                        });
                    }
                }
            }
        }



    }

    //-------------------------- All Facility Bind (APG Office Location) ----------------------------------

    GetAllFacilityList();
    
    function GetAllFacilityList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetAllFacilityList'
        }).success(function (data, status, headers, config) {
            $scope.GetAllFacilityList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    }

    //-------------------------- All Ethnicity Bind ---------------------------------

    GetAllEthnicityList();

    function GetAllEthnicityList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetAllEthnicityList'
        }).success(function (data, status, headers, config) {
            $scope.GetAllEthnicityList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    }

    //------------------------------Get USer Details -------------------------------------

    GetUserDetail();
    function GetUserDetail() {
        $http({
            method: 'Get',
            url: '/ExistSearch/GetUserDetail'
        }).success(function (data, status, headers, config) {
           
            $scope.PatientModel = data


            if (data.Email == "" || data.Email == null) {
                $scope.truefalse = false;
            }
            else {
                $scope.truefalse = true;
            }
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };
    
    //------------------------------ All State Bind -------------------------------------

    GetAllStateList();
 
    function GetAllStateList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetAllStateList'
        }).success(function (data, status, headers, config) {
            $scope.GetAllStateList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    }
    //----------------------------- GetCity ----------------------------------------------

    GetCityList();

    function GetCityList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetCityList'
        }).success(function (data, status, headers, config) {
            $scope.GetCityList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    }
    
    //----------------------------- All Education Bind -----------------------------------

    GetEducationList();
    
    function GetEducationList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetEducationList'
        }).success(function (data, status, headers, config) {
            $scope.GetEducationList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    }

    //----------------------------- All Education Bind -----------------------------------

    GetReferralList();

    function GetReferralList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetReferralList'
        }).success(function (data, status, headers, config) {
            $scope.GetReferralList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    }

    //-------------------------- Patient Info  ------------------------------


    $scope.onsubmited2 = function (alldetails, ButtonType) {
        $scope.submitted = true;
        insertPatientInfo(alldetails);
        function insertPatientInfo(data) {
            $("#divLoading").show();
            $scope.Validation = false;
            $scope.UserNameId = false;
            $scope.FacilityId = false;
            $scope.FirstName = false;
            $scope.LastName = false;
            $scope.Gender = false;
            $scope.EmailId = false;
            $scope.Address = false;
            $scope.CityId = false;
            $scope.StateId = false;
            $scope.ZipCode = false;
            $scope.MailingAddress = false;
            $scope.MailingCity = false;
            $scope.MailingState = false;
            $scope.MailingZipcode = false;
            $scope.EthnicityId = false;
            $scope.MobileNo = false;
            $scope.OtherContactNo = false;
            $scope.Soc_Security = false;
            $scope.BirthDate = false;

            $scope.NickName = false;
            $scope.Occuption = false;
            $scope.Employer = false;
            $scope.EmpStreet = false;
            $scope.EmpCityId = false;
            $scope.EmpStateId = false;
            $scope.EmpZipCode = false;
            $scope.EmpContactNo = false;
            $scope.EduId = false;
            $scope.PIN = false;
            $scope.WorkType = false;
            $scope.Height = false;
            $scope.Weight = false;
            $scope.WheelChair = false;
            $scope.ContactAtWork = false;
            $scope.KnowAboutUs = false;

            $scope.HaveChiropracticPhysician = false;
            $scope.ChiroPhysicianName = false;
            $scope.PrimaryPhysician = false;
            $scope.PrimPhysicianName = false;
            
            $scope.ReferralId = false;
            
            var GetErrors = '';
            var usernameid = data.UserNameId;
            var facilityid = data.FacilityId;
            var firstname = data.FirstName;
            var lastname = data.LastName;
            var gender = data.Gender;
            var emailid = data.EmailId;
            var address = data.Address;
            var cityid = data.CityId;
            var stateid = data.StateId;
            var zipcode = data.ZipCode;
            var mailindaddress = data.MailingAddress;
            var mailingcity = data.MailingCity;
            var mailingstate = data.MailingState;
            var mailingzipcode = data.MailingZipcode;
            var ethnicityid = data.EthnicityId;
            var mobileno = data.MobileNo;
            var othercontactno = data.OtherContactNo;
            var socsecurity = data.Soc_Security;
            var birthdate = document.getElementById("datepicker").value; // data.DateOfBirth; data.BirthDate
            var nickname = data.NickName;
            var occuption = data.Occuption;
            var employer = data.Employer;
            var empstreet = data.EmpStreet;
            var empcityid = data.EmpCityId;
            var empstateid = data.EmpStateId;
            var empzipcode = data.EmpZipCode;
            var empcontactno = data.EmpContactNo;
            var eduid = data.EduId;
            var pin = data.PIN;
            var worktype = data.WorkType;
            var height = data.Height;
            var weight = data.Weight;
            var wheelchair = data.WheelChair;
            var contactatwork = data.ContactAtWork;
            var knowaboutus = data.KnowAboutUs;
            var havechirophy = data.HaveChiropracticPhysician;
            var chirophyname = data.ChiroPhysicianName;
            var pphysician = data.PrimaryPhysician;
            var pphysicianname = data.PrimPhysicianName;
            var referralid = data.ReferralId;
           
            $('.errorMsg').remove();

            if ((usernameid == null || usernameid == '') && (emailid == null || emailid == '')) {
                alert("UserId or Email-Address any single one Is Required For Registration!");
                GetErrors += '1' + '\n';

            }

            if (facilityid == null || facilityid == '') {
                $scope.FacilityId = { color: 'red' };
                GetErrors += '2' + '\n';
            }

            if (firstname == null || firstname == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '3' + '\n';
            }

            if (lastname == null || lastname == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '4' + '\n';
            }

            if (gender == null || gender == '') {
                $scope.Gender = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            
            if (ethnicityid == null || ethnicityid == '') {
                $scope.EthnicityId = { color: 'red' };
                GetErrors += '14' + '\n';
            }

            if (mobileno == null || mobileno == '') {
                $scope.MobileNo = { color: 'red' };
                GetErrors += '15' + '\n';
            }
                      

            if (socsecurity == null || socsecurity == '') {
                $scope.Soc_Security = { color: 'red' };
                GetErrors += '17' + '\n';
            }

                     
            if (worktype == null || worktype == '') {
                $scope.WorkType = { color: 'red' };
                GetErrors += '30' + '\n';
            }
           
            if (height == null || height == '') {
                $scope.Height = { color: 'red' };
                GetErrors += '11' + '\n';
            }

            if (height > 100 || height < 24) {
                $('#Height').append('<div class="errorMsg" style="color:red">Invalid Height</div>');
                GetErrors += '12' + '\n';
            }

            if (weight == null || weight == '') {
                $scope.Weight = { color: 'red' };
                GetErrors += '13' + '\n';
            }

            if (weight > 500 || weight < 35) {
                $('#Weight').append('<div class="errorMsg" style="color:red">Invalid Weight</div>');
                GetErrors += '14' + '\n';
            }

            if (pin != null && pin != '' && pin.length != 4) {
                $('#PINLength').append('<div class="errorMsg" style="color:red">Pin No Lenght Must be 4 Digit</div>');
                GetErrors += '13' + '\n';
            }
         
            if (pin == null || pin == '') {
                $scope.PIN = { color: 'red' };
                GetErrors += '29' + '\n';
            }


            // Start --------------- Date Formate Check

            var s = document.getElementById("datepicker").value;
            var arr = s.split("-");
            var MM = arr[0];
            var dd = arr[1];
            var yy = arr[2];

            alert(MM);
            alert(dd);
            alert(yy);

            if (yy > 2014) {
                alert('date of birth should not be future date .!');
                $scope.DOB = { color: 'red' };
                GetErrors += '25' + '\n';
            }
            else if (dd > 32 || dd == '00') {
                alert('Invalid Date .!');
                $scope.DOB = { color: 'red' };
                GetErrors += '25' + '\n';
            }
            else if (MM > 13 || MM == '00') {
                alert('Invalid Date .!');
                $scope.DOB = { color: 'red' };
                GetErrors += '25' + '\n';
            }
            if (yy == '00' || yy == '0') {
                alert('Invalid Date .!');
                $scope.DOB = { color: 'red' };
                GetErrors += '25' + '\n';
            }

            //--------------------------------End

            if (birthdate == null || birthdate == '') {
                $scope.DOB = { color: 'red' };
                GetErrors += '18' + '\n';
            }

            var today = new Date();

            if (new Date(birthdate).getTime() > today) {
                $('#Dateob').append('<div class="errorMsg" style="color:red">date of birth should not be future date</div>');
                $scope.DOB = { color: 'red' };
                GetErrors += '19' + '\n';
            }


            if (GetErrors == null || GetErrors == '') {
                var PatientiInfoModule = {

                    UserNameId: usernameid,
                    FacilityId: facilityid,
                    FirstName: firstname,
                    LastName: lastname,
                    Gender: gender,
                    //DateOfBirth: dob,
                    EmailId: emailid,
                    Address: address,
                    CityId: cityid,
                    StateId: stateid,
                    ZipCode: zipcode,
                    MailingAddress: mailindaddress,
                    MailingCity: mailingcity,
                    MailingState: mailingstate,
                    MailingZipcode: mailingzipcode,
                    EthnicityId: ethnicityid,
                    MobileNo: mobileno,
                    OtherContactNo: othercontactno,
                    Soc_Security: socsecurity,
                    BirthDate: birthdate,

                    NickName: nickname,
                    Occuption: occuption,
                    Employer: employer,
                    EmpStreet: empstreet,
                    EmpCityId: empcityid,
                    EmpStateId: empstateid,
                    EmpZipCode: empzipcode,
                    EmpContactNo: empcontactno,
                    EduId: eduid,
                    PIN: pin,
                    WorkType: worktype,
                    Height: height,
                    Weight: weight,
                    WheelChair: wheelchair,
                    ContactAtWork: contactatwork,
                    KnowAboutUs: knowaboutus,

                    HaveChiropracticPhysician: havechirophy,
                    ChiroPhysicianName: chirophyname,
                    PrimaryPhysician: pphysician,
                    PrimPhysicianName: pphysicianname,
                    ReferralId: referralid

                }
                $http({

                    method: 'POST',

                    url: '/Patient/PutPatientInfo',
                    data: PatientiInfoModule
                }).success(function (data) {
                    $("#divLoading").hide();
                    $scope.ABC = data;
                    var Con = data;

                    console.log(data)

                    if (Con == null || Con == "1" || Con == "\"1\"") {
                        method: 'get',
                        location.href = '/Patient/Insurence';
                        data: PatientiInfoModule
                    }
                   
                }).error(function (serverResponse, status, headers, config) {
                    $scope.PatientModel = '';
                    $("#divLoading").hide();
                });
            }
            else {
                $("#divLoading").hide();
                $scope.Validation = true;
            }

        }
    }
}]);

//-------------------------------------- Patient BMI Controller  ----------------------------------------------

app.controller('PatientBMIController', ['$scope', '$http', function ($scope, $http) {
   
    $scope.submitted = false;
    $scope.PatientModel = {}
  
    GetPatientBMI();
    function GetPatientBMI() {
        $http({
            method: 'Get',
            url: '/Admin/GetPatientBMI'
        }).success(function (data, status, headers, config) {
           
            $scope.PatientModel = data         
            for (var item in data) {
                if (item == "PatientId") {
                    document.getElementById("PatientId").value = data.PatientId;
                   // alert(document.getElementById("PatientId").value);
                }
            }
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };
  
    $scope.onsubmit = function (alldetails) {       
        $scope.submitted = true;
        insertonsubmit(alldetails);
        
        function insertonsubmit(data) {
             
            var GetErrors = '';
            
            var patientId = data.PatientId;
            var patientname = data.FirstName;
           
            var height = data.Height;
            var heightFeet = data.HeightFeet;
            var heightInch = data.HeightInch;
            var weight = data.Weight;

            if (height == null || height == '') {
                $scope.Height = true;
                GetErrors += '1' + '\n';
            }
           
            if (weight == null || weight == '') {
                $scope.Weight = true;
                GetErrors += '2' + '\n';
            }
           

            if (height > 100 || height < 24) {
              //  $('#Height').append('<div class="errorMsg" style="color:red">Invalid Height</div>');

                $scope.Heights = true;
                GetErrors += 'Invalid Number' + '\n';

            }

            if (weight < 35 || weight > 600) {

                
                $scope.Weights = true;
                GetErrors += 'Invalid Number' + '\n';

               // $('#Weight').append('<div class="errorMsg" style="color:red">Invalid Weight</div>');
               
            }
            
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = {
                    PatientId: patientId, Height: height, HeightFeet: heightFeet, HeightInch: heightInch, Weight: weight
                }
                $http({
                    method: 'POST',
                   url: '/Admin/PatientBMI',
                    data: AddPatientModule
                }).success(function (data) {
                    
                    if (data == "\"-1\"") {
                        location.href = '/Account/LogOut';
                    }

                    else if (data == "1") {
                      //  document.getElementById("PatientId").value = patientId;
                        alert('New BMI Record Saved!');
                        location.href = '/Admin/PatientList?FormId=4';
                    }

                    else if (data == "2") {
                        if (confirm("BMI Record Already Available! \n Do you want to Record Save Again?") == true) {
                            document.getElementById("PatientId").value = patientId;
                            location.href = '/Admin/BMIUpdate?=' + patientId;
                        }
                    }
                    else if (data == "\"0\"") {
                        alert('New BMI Record Not Saved!!');
                    }

                });
            }
            else {
               
            }
        }
    }
}]);

//-------------------------------------- Patient BMI Controller  ----------------------------------------------

app.controller('NewInjectionController', ['$scope', '$http', function ($scope, $http) {

  
    $scope.Injection = {}
    GetPhysicainList();
    function GetPhysicainList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetPhysicainList'
        }).success(function (data, status, headers, config) {
            $scope.GetPhysicianList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetPhysicianTherapist();
    function GetPhysicianTherapist() {
        $http({
            method: 'Get',
            url: '/DataBind/GetPhysicianTherapist'
        }).success(function (data, status, headers, config) {
            $scope.GetPhysicalTherapistList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetPatientInjection();
    function GetPatientInjection() {
        $http({
            method: 'Get',
            url: '/Admin/GetPatientInjection'
        }).success(function (data, status, headers, config) {
            $scope.Injection = data;
            console.log(data);
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

        $scope.onsubmit = function (alldetails) {
        $scope.Email = false;
        $scope.MobileNo = false;
        AddNewInjection(alldetails);
        function AddNewInjection(data) {

            $scope.PatientId = false;
            $scope.PhysicianId = false;
            $scope.PhysicalTherapistId = false;
            $scope.Phy_Therapy = false;
            $scope.Knee = false;
            $scope.InjDate = false;
            $scope.AgeOnDate = false;

            var GetErrors = '';
            var patientId = data.PatientId;
            var physicianName = data.PhysicianId;
            var phy_TherapistName = data.PhysicalTherapistId;
            var phy_Therapy = data.Phy_Therapy;
            var knee = data.Knee;
            var phy_Therapy_date = data.InjDate;
            var ageOnDate = data.AgeOnDate;
           
           
            $('.errorMsg').remove();

            if (physicianName == null || physicianName == '') {
              
                $scope.PhysicianId = { color: 'red' };
                GetErrors += '1' + '\n';
            }

            if (phy_TherapistName == null || phy_TherapistName == '') {
             
                $scope.PhysicalTherapistId = { color: 'red' };
                GetErrors += '2' + '\n';
            }

            if (knee == null || knee == '') {
                $('#knee').append('<div class="errorMsg" style="color:red">Please Select Knee</div>');
                $scope.Knee = { color: 'red' };
                GetErrors += '3' + '\n';
            }

            if (phy_Therapy == null || phy_Therapy == '') {
              
                $scope.Phy_Therapy = { color: 'red' };
                GetErrors += '4' + '\n';
            }


            if (GetErrors == null || GetErrors == '') {
                var AddNewInjection = {
                    PatientId: patientId, PhysicianName: physicianName, Phy_TherapistName: phy_TherapistName, Phy_Therapy: phy_Therapy, Knee: knee, Phy_Therapy_date: phy_Therapy_date, AgeOnDate: ageOnDate
                }
                $http({
                    method: 'POST',
                    url: '/admin/NewInjection',
                    data: AddNewInjection
                }).success(function (data) {
                    $scope.Injection = '';
                    alert('Injection Detail Saved!');
                   
                    location.href = '/Admin/PatientList?FormId=4';
                });
            }
            else {
                //alert(GetErrors);
            }
        }
    }
}]);


//--------------------------------------Update Patient Details Controller  ------------------------------------
app.controller('UpdatePatientRegistration', ['$scope', '$http', function ($scope, $http) {
  
    $scope.PatientModel = {}
    $scope.submitted = false;
   
    $scope.data = {};
    $scope.alldetails = {};

    //-------------------------- Check IS Email-ID Exist ----------------------------

    $scope.FocusOnIsEmailIdExist = function (Email,userid) {

        CheckEmailIdExist(Email, userid);

        function CheckEmailIdExist(data,userid) {
          
            var id = 1;
            var statuss = 0;
            var GetErrors = '';
            $('.errorMsg').remove();
            if (data != null || data != undefined) {
              
                if (data != '') {
                    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                    if (!re.test(data)) {
                        $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                        document.getElementById("EmailIdExit").value = "-1";
                    }
                    else {
                        $http({
                            method: 'Get',
                            url: '/ExistSearch/GetEmailIdExist?Email_id=' + data +'&userid='+userid + '&id=' + id,
                        }).success(function (Success, status, headers, config) {
                            statuss = Success;
                        
                            if (Success == 2) {
                                location.href = '/Account/LogOut';
                            }
                            else{
                                if (Success == 0) {
                                    $('.errorMsg1').remove();
                                    document.getElementById("EmailIdExit").value = "0";
                                }
                                else {
                                    $('.errorMsg1').remove();
                                    $('#EmailId').append('<div class="errorMsg1" style="color:red">This EmailId is Already Registered Please Use Different EmailId</div>');
                                    document.getElementById("EmailIdExit").value = "1";
                                }
                            }
                        }).error(function (data, status, headers, config) {
                            $scope.message = 'Unexpected Error';
                        });
                    }
                }
            }
        }

    }
 
    //-------------------------- All Facility Bind (APG Office Location) ----------------------------------

    GetAllFacilityList();
  
    function GetAllFacilityList() {
      
        $http({
            method: 'Get',
            url: '/DataBind/GetAllFacilityList'
        }).success(function (data, status, headers, config) {
            $scope.GetAllFacilityList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    }

    //-------------------------- All Ethnicity Bind ---------------------------------
   
    GetAllEthnicityList();

    function GetAllEthnicityList() {
     
        $http({
            method: 'Get',
            url: '/DataBind/GetAllEthnicityList'
        }).success(function (data, status, headers, config) {
            $scope.GetAllEthnicityList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    }

 
    //----

    GetPatientDetails();
   
    function GetPatientDetails() {
      
        $http({
            method: 'Get',
            url: '/ExistSearch/GetUpdatePatientDetail'
        }).success(function (data, status, headers, config) {
          
            $scope.PatientRegistration = data
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function(alldetails) {
     
        $scope.submitted = true;
    
        var data = $scope.PatientRegistration.EmailId;
        var userid = $scope.PatientRegistration.UserNameId;
        var statuss = document.getElementById("EmailIdExit").value;
        var con = 1;
        CheckEmailIdExists(data, userid);

        function CheckEmailIdExists(data, userid) {
          
            var id = 1;
            var statuss = 0;
         
            var GetErrors = '';
            $('.errorMsg').remove();
            if (data != null && data != undefined && data!='') {
                con = 0;
            
                if (data != '') {
                    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                    if (!re.test(data)) {
                        $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                        document.getElementById("EmailIdExit").value = "-1";
                    }
                    else {
                        $http({
                            method: 'Get',
                            url: '/ExistSearch/GetEmailIdExist?Email_id=' + data + '&userid=' + userid + '&id=' + id,
                        }).success(function (Success, status, headers, config) {
                            statuss = Success;
                         
                            if (statuss == 1 || statuss == -1) {
                                $('.errorMsg1').remove();
                                $('#EmailId').append('<div class="errorMsg1" style="color:red">This EmailId is Already Registered Please Use Different EmailId</div>');
                               
                            }
                            else {
                                $('.errorMsg1').remove();
                                insertPatientInfo(alldetails);
                            }
                            //if (Success == 2) {
                            //    location.href = '/Account/LogOut';
                            //}
                            //else {
                            //    if (Success == 0) {
                            //        document.getElementById("EmailIdExit").value = "0";
                            //    }
                            //    else {

                            //      $('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId is Already Registerd. Please Use Different EmailId</div>');
                            //        document.getElementById("EmailIdExit").value = "1";
                            //    }
                            //}
                        }).error(function (data, status, headers, config) {
                            $scope.message = 'Unexpected Error';
                        });
                    }
                }
            }
        }
        if (con == 1)
        {
         
            insertPatientInfo(alldetails);
        }
        function insertPatientInfo(data) {
          
  
            var GetErrors = '';
            var usernameid = data.UserNameId;
          
            var facilityid = data.FacilityId;
            var firstname = data.FirstName;
           
         
            var lastname = data.LastName;
            var gender = data.Gender;
            var emailid = data.EmailId;
         
            var ethnicityid = data.EthnicityId;
         
            var mobileno = document.getElementById('Mobile').value;
         
        
            // var mobileno = data.MobileNo;
            // var othercontactno = data.OtherContactNo;
            //var othercontactno = document.getElementById('OtherContact').value;
          
            // var socsecurity = data.Soc_Security;
       
            // var socsecurity = document.getElementById('SocSec').value;
            var birthdatee = document.getElementById("datepicker").value; // data.DateOfBirth; data.BirthDate
            var birthdate = new Date(birthdatee);
            //var empzipcode = data.EmpZipCode;
            var pin = data.PIN;
          
            var height = data.Height;
            var weight = data.Weight;
           
            $('.errorMsg').remove();

            //if ((usernameid == null || usernameid == '') && (emailid == null || emailid == '')) {
            //    alert("UserId or Email-Address any single one Is Required For Registration!");
            //    GetErrors += '1' + '\n';
            //}

            if (facilityid == null || facilityid == '') {
                $scope.FacilityId = { color: 'red' };
                GetErrors += '2' + '\n';
            }

            if (firstname == null || firstname == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '3' + '\n';
            }

            if (lastname == null || lastname == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '4' + '\n';
            }

            if (gender == null || gender == '') {
                $scope.Gender = { color: 'red' };
                GetErrors += '5' + '\n';
            }

            if (ethnicityid == null || ethnicityid == '') {
                $scope.EthnicityId = { color: 'red' };
                GetErrors += '6' + '\n';
            }

            if (mobileno == null || mobileno == '') {
                $scope.MobileNo = { color: 'red' };
                GetErrors += '7' + '\n';
            }

            if (mobileno != null || mobileno != undefined) {
                var re = /^\(?[(. ]{1}\)?([0-9]{3})?[). ]{1}?([0-9]{3})?[-. ]{1}?([0-9]{4})$/;
                if (!re.test(mobileno)) {
                    $('#MobileContactNo').append('<div class="errorMsg" style="color:red">Invalid Format </div>');
                    GetErrors += '142' + '\n';
                }
            }
            //if (othercontactno != null || othercontactno != undefined) {
            //    var re = /^\(?[(. ]{1}\)?([0-9]{3})?[). ]{1}?([0-9]{3})?[-. ]{1}?([0-9]{4})$/;
            //    if (!re.test(othercontactno)) {
            //        $('#othercontactno12').append('<div class="errorMsg" style="color:red">Invalid Format </div>');
            //        GetErrors += '142' + '\n';
            //    }
            //}

            //if (socsecurity != null || socsecurity != undefined) {
            //    var re = /^\d{3}-\d{2}-\d{4}$/;
            //    if (!re.test(socsecurity)) {
            //        $('#socsecurity12').append('<div class="errorMsg" style="color:red">Invalid Format </div>');
            //        GetErrors += '142' + '\n';
            //    }
            //}

            //if (socsecurity == null || socsecurity == '') {
            //    $scope.Soc_Security = { color: 'red' };
            //    GetErrors += '8' + '\n';
            //}

            if (birthdate == null || birthdate == '') {
                $scope.DOB = { color: 'red' };
                GetErrors += '9' + '\n';
            }


            //if (pin == null || pin == '') {
            //    $scope.PIN = { color: 'red' };
            //    GetErrors += '10' + '\n';
            //}
         
            if (height == null || height == '') {
                $scope.Height = { color: 'red' };
                GetErrors += '12' + '\n';
            }
            if (weight == null || weight == '') {
                $scope.Weight = { color: 'red' };
                GetErrors += '13' + '\n';
            }

            if (height > 100 || height < 24) {
                $('#Height').append('<div class="errorMsg" style="color:red">Invalid Height</div>');
                GetErrors += '14' + '\n';
            }
            if (weight > 500 || weight < 35) {
                $('#Weight').append('<div class="errorMsg" style="color:red">Invalid Weight</div>');
                GetErrors += '15' + '\n';
            }
           

            // Start --------------- Date Formate Check

            var s = document.getElementById("datepicker").value;
            var arr = s.split("-");
            var MM = arr[0];
            var dd = arr[1];
            var yy = arr[2];


            if (yy > 2015) {
                alert('date of birth should not be future date .!');
                $scope.DOB = { color: 'red' };
                GetErrors += '25' + '\n';
            }
            else if (dd > 32 || dd == '00') {
                alert('Invalid Date .!');
                $scope.DOB = { color: 'red' };
                GetErrors += '25' + '\n';
            }
            else if (MM > 13 || MM == '00') {
                alert('Invalid Date .!');
                $scope.DOB = { color: 'red' };
                GetErrors += '25' + '\n';
            }
            if (yy == '00' || yy == '0') {
                alert('Invalid Date .!');
                $scope.DOB = { color: 'red' };
                GetErrors += '25' + '\n';
            }

            //--------------------------------End

            if (GetErrors == null || GetErrors == '') {
               
                if (statuss != 1) {
                    $("#divLoading").show();
                    var PatientiInfoModule = {
                        UserNameId: usernameid,
                        FacilityId: facilityid,
                        FirstName: firstname,
                        LastName: lastname,
                        Gender: gender,
                        //DateOfBirth: dob,
                        EmailId: emailid,
                        EthnicityId: ethnicityid,
                        MobileNo: mobileno,
                        DateOfBirth: birthdate,
                        PIN: pin,
                        Height: height,
                        Weight: weight
                    }
                   
                    $http({

                        method: 'POST',
                        url: '/Patient/PutPatientInfo',
                        data: PatientiInfoModule
                    }).success(function (data) {
                        $("#divLoading").hide();
                        $scope.ABC = data;
                        var Con = data;

                        console.log(data)

                        if (Con == null || Con == "1" || Con == "\"1\"") {
                            method: 'get',
                            alert('Data Update SuccessFully ..!');
                            location.href = '/Admin/PatientList?FormId=4';
                            $("#divLoading").hide();
                            data: PatientiInfoModule
                        }

                        else if (Con == null || Con == "2" || Con == "\"2\"") {
                                method: 'get',
                                 alert('Data Update SuccessFully ..!');
                            location.href = '/PatientDeshboard/PatientIndex';
                            $("#divLoading").hide();
                            data: PatientiInfoModule
                        }
                    }).error(function (serverResponse, status, headers, config) {
                        $scope.PatientModel = '';
                        $("#divLoading").hide();
                    });
                }
                else {
          
                //$('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId Already Registerd Please Use Different EmailId</div>');

                }
             
            }
            else {

                $("#divLoading").hide();

                $scope.Validation = true;
            }
            
        }

    }

    $scope.onPrint = function (data) {
        $scope.submitted = true;
        DataPrint(data);
        function DataPrint(data) {
            $http({
                method: 'Get',
                url: '/Admin/PrintDetail?PrintedForm=' + data
            }).success(function (data, status, headers, config) {
                $scope.Patientmodel = data
            }).error(function (data, status, headers, config) {
                $scope.message = 'Unexpected Error';
            });
        }
    }
}]);

app.controller('UpdatePatientDetailcontroller', ['$scope', '$http', function ($scope, $http) {
  
    $scope.PatientModel = {}    
    $scope.submitted = false;

    $scope.data = {};
    $scope.alldetails = {};

    //-------------------------- Check IS Email-ID Exist ----------------------------

    $scope.FocusOnIsEmailIdExist = function (Email) {

        CheckEmailIdExist(Email);

        function CheckEmailIdExist(data) {
            var id = 1;
            var GetErrors = '';
            $('.errorMsg').remove();
            if (data != null || data != undefined) {
                if (data != '') {
                    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                    if (!re.test(data)) {
                        $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                        document.getElementById("EmailIdExit").value = "-1";
                    }
                    else {
                        $http({
                            method: 'Get',
                            url: '/ExistSearch/GetEmailIdExist?Email_id=' + data +'&id='+id,
                        }).success(function (Success,status,headers,config) {
                            if (Success == 0) {
                                document.getElementById("EmailIdExit").value = "0";
                            }
                            else {
                              
                                $('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId Already Register Please Use Different EmailId</div>');
                                document.getElementById("EmailIdExit").value = "1";
                            }
                        }).error(function (data, status, headers, config) {
                            $scope.message = 'Unexpected Error';
                        });
                    }
                }
            }
        }



    }

    //-------------------------- All Facility Bind (APG Office Location) ----------------------------------

    GetAllFacilityList();

    function GetAllFacilityList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetAllFacilityList'
        }).success(function (data, status, headers, config) {
            $scope.GetAllFacilityList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    }

    //-------------------------- All Ethnicity Bind ---------------------------------

    GetAllEthnicityList();

    function GetAllEthnicityList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetAllEthnicityList'
        }).success(function (data, status, headers, config) {
            $scope.GetAllEthnicityList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    }
        
    //------------------------------ All State Bind -------------------------------------

    GetAllStateList();

    function GetAllStateList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetAllStateList'
        }).success(function (data, status, headers, config) {
            $scope.GetAllStateList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    }
    //----------------------------- Get  City ----------------------------------------------

    $scope.Getcity = function () {
        var StateId = $scope.PatientModel.StateId;

        if (StateId) {
           
            $http({
                method: 'POST',
                url: '/DataBind/GetCityList',
                data: JSON.stringify({ StateId: StateId })
            }).success(function (data, status, headers, config) {
                $scope.GetCityList = data;
            }).error(function (data, status, headers, config) {
                $scope.message = 'Unexpected Error';
            });
        }
        else {
            $scope.GetCityList = null;
        }
    }

    //----------------------------- Get MAIL City ----------------------------------------------

    $scope.GetMailcity = function () {
        var StateId = $scope.PatientModel.MailingState;
              
        if (StateId) {
         
            $http({
                method: 'POST',
                url: '/DataBind/GetMAILCityList',
                data: JSON.stringify({ StateId: StateId })
            }).success(function (data, status, headers, config) {
                $scope.GetMAILCityList = data;
            }).error(function (data, status, headers, config) {
                $scope.message = 'Unexpected Error';
            });
        }
        else {
            $scope.GetCityList = null;
        }
    }

    //----------------------------- GetCity ----------------------------------------------

    $scope.GetEMPcity = function () {
        var StateId = $scope.PatientModel.EmpStateId;

        if (StateId) {
           
            $http({
                method: 'POST',
                url: '/DataBind/GetEMPCityList',
                data: JSON.stringify({ StateId: StateId })
            }).success(function (data, status, headers, config) {
                $scope.GetEMPCityList = data;
            }).error(function (data, status, headers, config) {
                $scope.message = 'Unexpected Error';
            });
        }
        else {
            $scope.GetCityList = null;
        }
    }

    //----------------------------- All Education Bind -----------------------------------

    GetEducationList();

    function GetEducationList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetEducationList'
        }).success(function (data, status, headers, config) {
            $scope.GetEducationList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    }

    //----------------------------- All Education Bind -----------------------------------

    GetReferralList();

    function GetReferralList() {
        $http({
            method: 'Get',
            url: '/DataBind/GetReferralList'
        }).success(function (data, status, headers, config) {
            $scope.GetReferralList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    }

    //----


    GetPatientDetail();

    function GetPatientDetail() {
        $http({
            method: 'Get',
            url: '/ExistSearch/GetUpdatePatientDetail'
        }).success(function (data, status, headers, config) {
            $scope.PatientModel = data
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails, ButtonType) {
        $scope.submitted = true;
     
        insertPatientInfo(alldetails);
       
        function insertPatientInfo(data) {
            $("#divLoading").show();
            $scope.Validation = false;
            $scope.UserNameId = false;
            $scope.FacilityId = false;
            $scope.FirstName = false;
            $scope.LastName = false;
            $scope.Gender = false;
            $scope.EmailId = false;
            $scope.Address = false;
            $scope.CityId = false;
            $scope.StateId = false;
            $scope.ZipCode = false;
            $scope.MailingAddress = false;
            $scope.MailingCity = false;
            $scope.MailingState = false;
            $scope.MailingZipcode = false;
            $scope.EthnicityId = false;
            $scope.MobileNo = false;
            $scope.OtherContactNo = false;
            $scope.Soc_Security = false;
            $scope.BirthDate = false;
           
            $scope.NickName = false;
            $scope.Occuption = false;
            $scope.Employer = false;
            $scope.EmpStreet = false;
            $scope.EmpCityId = false;
            $scope.EmpStateId = false;
            $scope.EmpZipCode = false;
            $scope.EmpContactNo = false;
            $scope.EduId = false;
            $scope.PIN = false;
            $scope.WorkType = false;
            $scope.Height = false;
            $scope.Weight = false;
            $scope.WheelChair = false;
            $scope.ContactAtWork = false;
            $scope.KnowAboutUs = false;
          
            $scope.HaveChiropracticPhysician = false;
            $scope.ChiroPhysicianName = false;
            $scope.PrimaryPhysician = false;
            $scope.PrimPhysicianName = false;

            $scope.ReferralId = false;
           
            var GetErrors = '';
            var usernameid = data.UserNameId;
            var facilityid = data.FacilityId;
            var firstname = data.FirstName;
            var lastname = data.LastName;
            var gender = data.Gender;
            var emailid = data.EmailId;
            var address = data.Address;
            var cityid = data.CityId;
            var stateid = data.StateId;
            var zipcode = data.ZipCode;
            var mailindaddress = data.MailingAddress;
            var mailingcity = data.MailingCity;
            var mailingstate = data.MailingState;
            var mailingzipcode = data.MailingZipcode;
            var ethnicityid = data.EthnicityId;

            var mobileno = document.getElementById('PrimaryContact').value;
           // var mobileno = data.MobileNo;
           // var othercontactno = data.OtherContactNo;
            //var othercontactno = document.getElementById('OtherContact').value;
            var othercontactno ='0';
            // var socsecurity = data.Soc_Security;
            var socsecurity = '0';
           // var socsecurity = document.getElementById('SocSec').value;
            var birthdate = document.getElementById("datepicker").value; // data.DateOfBirth; data.BirthDate
           
            var nickname = data.NickName;
            var occuption = data.Occuption;
            var employer = data.Employer;
            var empstreet = data.EmpStreet;
            var empcityid = data.EmpCityId;
            var empstateid = data.EmpStateId;
            var empzipcode = data.EmpZipCode;
            var empcontactno = data.EmpContactNo;
            var eduid = data.EduId;
            var pin = data.PIN;
            var worktype = data.WorkType;
            var height = data.Height;
            var weight = data.Weight;
            var wheelchair = data.WheelChair;
            var contactatwork = data.ContactAtWork;
            var knowaboutus = data.KnowAboutUs;
            var havechirophy = data.HaveChiropracticPhysician;
            var chirophyname = data.ChiroPhysicianName;
            var pphysician = data.PrimaryPhysician;
            var pphysicianname = data.PrimPhysicianName;
            var referralid = data.ReferralId;
          
            $('.errorMsg').remove();
                      
            if ((usernameid == null || usernameid == '') && (emailid == null || emailid == '')) {
                alert("UserId or Email-Address any single one Is Required For Registration!");
                GetErrors += '1' + '\n';
            }

            if (facilityid == null || facilityid == '') {
                $scope.FacilityId = { color: 'red' };
                GetErrors += '2' + '\n';
            }

            if (firstname == null || firstname == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '3' + '\n';
            }

            if (lastname == null || lastname == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '4' + '\n';
            }

            if (gender == null || gender == '') {
                $scope.Gender = { color: 'red' };
                GetErrors += '5' + '\n';
            }

            if (ethnicityid == null || ethnicityid == '') {
                $scope.EthnicityId = { color: 'red' };
                GetErrors += '6' + '\n';
            }

            if (mobileno == null || mobileno == '') {
                $scope.MobileNo = { color: 'red' };
                GetErrors += '7' + '\n';
            }
         
            if (mobileno != null || mobileno != undefined) {
               var re = /^\(?[(. ]{1}\)?([0-9]{3})?[). ]{1}?([0-9]{3})?[-. ]{1}?([0-9]{4})$/;
               if (!re.test(mobileno)) {
                    $('#MobileContactNo').append('<div class="errorMsg" style="color:red">Invalid Format </div>');
                    GetErrors += '142' + '\n';
                }
            }
            //if (othercontactno != null || othercontactno != undefined) {
            //    var re = /^\(?[(. ]{1}\)?([0-9]{3})?[). ]{1}?([0-9]{3})?[-. ]{1}?([0-9]{4})$/;
            //    if (!re.test(othercontactno)) {
            //        $('#othercontactno12').append('<div class="errorMsg" style="color:red">Invalid Format </div>');
            //        GetErrors += '142' + '\n';
            //    }
            //}

            //if (socsecurity != null || socsecurity != undefined) {
            //    var re = /^\d{3}-\d{2}-\d{4}$/;
            //    if (!re.test(socsecurity)) {
            //        $('#socsecurity12').append('<div class="errorMsg" style="color:red">Invalid Format </div>');
            //        GetErrors += '142' + '\n';
            //    }
            //}
           
            //if (socsecurity == null || socsecurity == '') {
            //    $scope.Soc_Security = { color: 'red' };
            //    GetErrors += '8' + '\n';
            //}

            if (birthdate == null || birthdate == '') {
                $scope.DOB = { color: 'red' };
                GetErrors += '9' + '\n';
            }
            

            if (pin == null || pin == '') {
                $scope.PIN = { color: 'red' };
                GetErrors += '10' + '\n';
            }
            if (worktype == null || worktype == '') {
                $scope.WorkType = { color: 'red' };
                GetErrors += '11' + '\n';
            }
            if (height == null || height == '') {
                $scope.Height = { color: 'red' };
                GetErrors += '12' + '\n';
            }
            if (weight == null || weight == '') {
                $scope.Weight = { color: 'red' };
                GetErrors += '13' + '\n';
            }

            if (height > 100 || height < 24) {
                $('#Height').append('<div class="errorMsg" style="color:red">Invalid Height</div>');
                GetErrors += '14' + '\n';
            }
            if (weight > 500 || weight < 35) {
                $('#Weight').append('<div class="errorMsg" style="color:red">Invalid Weight</div>');
                GetErrors += '15' + '\n';
            }

            if (eduid == null || eduid == '') {
                $scope.EduId = { color: 'red' };
                GetErrors += '16' + '\n';
            }



            // Start --------------- Date Formate Check

            var s = document.getElementById("datepicker").value;
            var arr = s.split("-");
            var MM = arr[0];
            var dd = arr[1];
            var yy = arr[2];

         
            if (yy > 2014) {
                alert('date of birth should not be future date .!');
                $scope.DOB = { color: 'red' };
                GetErrors += '25' + '\n';
            }
            else if (dd > 32 || dd == '00') {
                alert('Invalid Date .!');
                $scope.DOB = { color: 'red' };
                GetErrors += '25' + '\n';
            }
            else if (MM > 13 || MM == '00') {
                alert('Invalid Date .!');
                $scope.DOB = { color: 'red' };
                GetErrors += '25' + '\n';
            }
            if (yy == '00' || yy == '0') {
                alert('Invalid Date .!');
                $scope.DOB = { color: 'red' };
                GetErrors += '25' + '\n';
            }

            //--------------------------------End
                        
            if (GetErrors == null || GetErrors == '') {
                var PatientiInfoModule = {

                    UserNameId: usernameid,
                    FacilityId: facilityid,
                    FirstName: firstname,
                    LastName: lastname,
                    Gender: gender,
                    //DateOfBirth: dob,
                    EmailId: emailid,
                    Address: address,
                    CityId: cityid,
                    StateId: stateid,
                    ZipCode: zipcode,
                    MailingAddress: mailindaddress,
                    MailingCity: mailingcity,
                    MailingState: mailingstate,
                    MailingZipcode: mailingzipcode,
                    EthnicityId: ethnicityid,
                    MobileNo: mobileno,
                    OtherContactNo: othercontactno,
                    Soc_Security: socsecurity,
                    BirthDate: birthdate,

                    NickName: nickname,
                    Occuption: occuption,
                    Employer: employer,
                    EmpStreet: empstreet,
                    EmpCityId: empcityid,
                    EmpStateId: empstateid,
                    EmpZipCode: empzipcode,
                    EmpContactNo: empcontactno,
                    EduId: eduid,
                    PIN: pin,
                    WorkType: worktype,
                    Height: height,
                    Weight: weight,
                    WheelChair: wheelchair,
                    ContactAtWork: contactatwork,
                    KnowAboutUs: knowaboutus,

                    HaveChiropracticPhysician: havechirophy,
                    ChiroPhysicianName: chirophyname,
                    PrimaryPhysician: pphysician,
                    PrimPhysicianName: pphysicianname,
                    ReferralId: referralid

                }
                $http({

                    method: 'POST',

                    url: '/Patient/PutPatientInfo',
                    data: PatientiInfoModule
                }).success(function (data) {
                    $("#divLoading").hide();
                    $scope.ABC = data;
                    var Con = data;

                    console.log(data)

                    if (Con == null || Con == "1" || Con == "\"1\"") {
                        method: 'get',
                        alert('Data Update SuccessFully ..!');
                        location.href = '/Admin/AdminIndex';

                        data: PatientiInfoModule
                    }

                    else if (Con == null || Con == "2" || Con == "\"2\"") {
                            method: 'get',
                             alert('Data Update SuccessFully ..!');
                        location.href = '/PatientDeshboard/PatientIndex';
                        data: PatientiInfoModule
                    }
                }).error(function (serverResponse, status, headers, config) {
                    $scope.PatientModel = '';
                    $("#divLoading").hide();
                });
            }
            else {
                $("#divLoading").hide();
                $scope.Validation = true;
            }

        }

    }  

    $scope.onPrint = function (data) {
        $scope.submitted = true;
        DataPrint(data);
        function DataPrint(data) {
            $http({
                method: 'Get',
                url: '/Admin/PrintDetail?PrintedForm=' + data
            }).success(function (data, status, headers, config) {
                $scope.Patientmodel = data
            }).error(function (data, status, headers, config) {
                $scope.message = 'Unexpected Error';
            });
        }
    }
}]);


//-------------------------------------- Patient Re Activation Controller  ------------------------------------


//app.controller('ReActivationController', ['$scope', '$http', function ($scope, $http) {
   
//    $scope.submitted = false;
//    $scope.ReActivation = {}

//    CalculateAgeInQC('1988/07/03')
//    function CalculateAgeInQC(DOB) {
//        var today = new Date();
//        var birthDate = new Date(DOB);
//        var age = today.getFullYear() - birthDate.getFullYear();
//        var m = today.getMonth() - birthDate.getMonth();
//        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
//            age--;
//        }
//    }

//    GetUserDetail();
//    function GetUserDetail() {
//        $http({
//            method: 'Get',
//            url: '/ExistSearch/GetPatientDetail'
//        }).success(function (data, status, headers, config) {
//            var today = new Date();
//            var birthDate = new Date(data.DOB);
//            var age = today.getFullYear() - birthDate.getFullYear();
//            var m = today.getMonth() - birthDate.getMonth();
//            if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
//                age--;
//            }
//            data.AgeOnReActivation = age;
//            $scope.ReActivation = data

//            document.getElementById("PatientName").value = data.FirstName + " " + data.LastName;
//            if (data.Gender == "Male") {
//                document.getElementById("FrontImage").src = "../Content/images/MaleFronthalfcuts/male_silhouette.png";
//                document.getElementById("FrontImage").useMap = "#FrontMaleBody";
//                document.getElementById("myImage").src = "../Content/images/MaleBack/male_silhouette_back.png";
//                document.getElementById("myImage").useMap = "#BackMaleBody";
//                document.getElementById("RightImage").src = "../Content/images/Male%20Side_Right_Assets/male_Right_Blank.png";
//                document.getElementById("RightImage").useMap = "#MaleSideRight";
//                document.getElementById("LeftImage").src = "../Content/images/Male%20Side_Left_Assets/male_Left_Blank.png";
//                document.getElementById("LeftImage").useMap = "#MaleSideLeft";
//            }
//            else if (data.Gender == "Female") {
//                document.getElementById("FrontImage").src = "../Content/images/FemaleFronthalfcuts/female_silhouette.png";
//                document.getElementById("FrontImage").useMap = "#FrontFemaleBody";
//                document.getElementById("myImage").src = "../Content/images/FemaleBackhalfcuts/female_back_silhouette.png";
//                document.getElementById("myImage").useMap = "#BackFemaleBody";
//                document.getElementById("RightImage").src = "../Content/images/Female%20Side_Right_Assets/female_Right_Blank.png";
//                document.getElementById("RightImage").useMap = "#FemaleSideRight";
//                document.getElementById("LeftImage").src = "../Content/images/Female%20Side_Left_Assets/female_Left_Blank.png";
//                document.getElementById("LeftImage").useMap = "#FemaleSideLeft";
//            }
//        }).error(function (data, status, headers, config) {
//            $scope.message = 'Unexpected Error';
//        });
//    };

//    $scope.onsubmit = function (alldetails) {

//        $scope.submitted = true;
//        insertonsubmit(alldetails);
//        function insertonsubmit(data) {
//          // alert();
//            //$("#divLoading").show();
//            var GetErrors = '';
//            $scope.ReferringPhysician = false;
//            $scope.PrimaryPhysician = false;
//            $scope.Pharmacy = false;
//            $scope.CityState = false;
//            $scope.PainHistoryOne = false;
//            $scope.PainHistoryTwo = false;
//            var PatientId = data.PatientId;
//            var AgeOnReActivation = data.AgeOnReActivation;
//            var ReferringPhysician = data.ReferringPhysician;
//            var PrimaryPhysician = data.PrimaryPhysician;
//            var Pharmacy = data.Pharmacy;
//            var CityState = data.CityState;
//            var PainHistoryOne = data.PainHistoryOne;
//            var PainHistoryTwo = data.PainHistoryTwo;
//            var RightPainArea = document.getElementById("ReActivation.RightPainArea").value;
//            var BackPainArea = document.getElementById("ReActivation.BackPainArea").value;
//            var FrontPainArea = document.getElementById("ReActivation.FrontPainArea").value;
//            var LeftPainArea = document.getElementById("ReActivation.LeftPainArea").value;
//            var PainDescription = document.getElementById("PainDescription").value;
//            var LastInjectionDate = document.getElementById("datepicker1").value;
//            var TypeOfInjection = document.getElementById("TypeOfInjection").value + " ," + data.Other;
//            var Helpful = data.Helpful;
//            var PercentRelief = data.PercentRelief;
//            var HowLong = data.HowLong;
//            var MedicationsPrescription = data.MedicationsPrescription;
//            var MedicationsPrescriptionDetail = data.MedicationsPrescriptionDetail;
//            var MedicalConditions = data.MedicalConditions;
//            var Surgeries = data.Surgeries;
//            var CurrentMedications = data.CurrentMedications;
//            var ALLERGIESMedications = data.ALLERGIESMedications;
//            var ALLERGIESFood = data.ALLERGIESFood;
//            var ALLERGIES = document.getElementById("ALLERGIES").value; //data.ALLERGIES;         
//            var REVIEWList = document.getElementById("REVIEW").value;
//            var PatientSignature = document.getElementById("SignatureValue").value;
//            var SignatureDate = data.SubmitDate;

//            //$('.errorMsg').remove();
//            //if (ReferringPhysician == null || ReferringPhysician == '') {
//            //    $scope.ReferringPhysician = { color: 'red' };
//            //    GetErrors += '1' + '\n';
//            //}
//            //if (PrimaryPhysician == null || PrimaryPhysician == '') {
//            //    $scope.PrimaryPhysician = { color: 'red' };
//            //    GetErrors += '2' + '\n';
//            //}
//            //if (Pharmacy == null || Pharmacy == '') {
//            //    $scope.Pharmacy = { color: 'red' };
//            //    GetErrors += '3' + '\n';
//            //}
//            //if (CityState == null || CityState == '') {
//            //    $scope.CityState = { color: 'red' };
//            //    GetErrors += '4' + '\n';
//            //}
//            //if (PainHistoryOne == null || PainHistoryOne == '') {
//            //    $scope.PainHistoryOne = { color: 'red' };
//            //    GetErrors += '5' + '\n';
//            //}
//            //if (PainHistoryTwo == null || PainHistoryTwo == '') {
//            //    $scope.PainHistoryTwo = { color: 'red' };
//            //    GetErrors += '6' + '\n';
//            //}
//            //var PainDescription = RightPainArea + BackPainArea + FrontPainArea + LeftPainArea;
//            //if (PainDescription == null || PainDescription == '') {
//            //    GetErrors += 'Please select Pain Area' + '\n';
//            //}
//            if (GetErrors == null || GetErrors == '') {
//                var ReActivation = {
//                    PatientId: PatientId, AgeOnReActivation: AgeOnReActivation, ReferringPhysician: ReferringPhysician, PrimaryPhysician: PrimaryPhysician, Pharmacy: Pharmacy,
//                    CityState: CityState, PainHistoryOne: PainHistoryOne, PainHistoryTwo: PainHistoryTwo, RightPainArea: RightPainArea, BackPainArea: BackPainArea,
//                    FrontPainArea: FrontPainArea, LeftPainArea: LeftPainArea, PainDescription: PainDescription, LastInjectionDate: LastInjectionDate, TypeOfInjection: TypeOfInjection,
//                    Helpful: Helpful, PercentRelief: PercentRelief, HowLong: HowLong, MedicationsPrescription: MedicationsPrescription, MedicationsPrescriptionDetail: MedicationsPrescriptionDetail,
//                    MedicalConditions: MedicalConditions, Surgeries: Surgeries, CurrentMedications: CurrentMedications, ALLERGIESMedications: ALLERGIESMedications, ALLERGIESFood: ALLERGIESFood,
//                    ALLERGIES: ALLERGIES, REVIEWList: REVIEWList, PatientSignature: PatientSignature, SignatureDate: SignatureDate
//                }
//                //  alert(2);

//                console.log('ReActivation', ReActivation);
//                $http({
//                    method: 'POST',
//                    url: '/Patient/ReActivation',
//                    data: ReActivation
//                }).success(function (data) {
//                    $("#divLoading").hide();
//                });
//            }
//            else {
//                alert("Fill Required Data");
//                $("#divLoading").hide();
//            }
//        }
//    }
//}]);


//-------------------------------------- Patient New Complaint Controller  ------------------------------------

app.controller('NewCompliantController', ['$scope', '$http', function ($scope, $http) {
   
    $scope.submitted = false;
    $scope.NewComplaint = {}
    GetUserDetail();
    function GetUserDetail() {
        $http({
            method: 'Get',
            url: '/ExistSearch/GetPatientDetail'
        }).success(function (data, status, headers, config) {
          
            document.getElementById("PatientName").value = data.FirstName + " " + data.LastName;
            if (data.Gender == "Male") {
                document.getElementById("FrontImage").src = "../Content/images/MaleFronthalfcuts/male_silhouette.png";
                document.getElementById("FrontImage").useMap = "#FrontMaleBody";
                document.getElementById("myImage").src = "../Content/images/MaleBack/male_silhouette_back.png";
                document.getElementById("myImage").useMap = "#BackMaleBody";
            }
            else if (data.Gender == "Female") {
                document.getElementById("FrontImage").src = "../Content/images/FemaleFronthalfcuts/female_silhouette.png";
                document.getElementById("FrontImage").useMap = "#FrontFemaleBody";
                document.getElementById("myImage").src = "../Content/images/FemaleBackhalfcuts/female_back_silhouette.png";
                document.getElementById("myImage").useMap = "#BackFemaleBody";
            }
              
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmited = function (alldetails) {
        
        $scope.submitted = true;
        insertonsubmit(alldetails);

        function insertonsubmit(data) {
            
            $("#divLoading").show();
            $scope.Validation = false;
            $scope.NewInjuryDate = false;
            $scope.NewInjuryDescription = false;
            $scope.LastCheckUp = false;
            $scope.LastCheckUpDetail = false;
            $scope.CurrentMobility = false;
            $scope.EmailLastFullDayWorkId = false;
          
            var GetErrors = '';
            var PatientId = data.PatientId;
            var NewInjuryDate = document.getElementById("LastGlucoseTestDate").value; //data.NewInjuryDate;
            var Cause = document.getElementById("Cause").value;
            var NewInjuryDescription = data.NewInjuryDescription;
            var LastCheckUp = data.LastCheckUp;
            var LastCheckUpDetail = data.LastCheckUpDetail;
            var FrontPainArea = document.getElementById("NewComplaint.FrontPainArea").value;
            var BackPainArea = document.getElementById("NewComplaint.BackPainArea").value;
            var PainDescription = document.getElementById("PainDescription").value;
            var CurrentMobility = data.CurrentMobility;
            var CurrentEmployeement = document.getElementById("CurrentEmployeement").value;
            var LastFullDayWork = data.LastFullDayWork;
           
            if (NewInjuryDate == '' || NewInjuryDate == null)
            {
                $scope.InjDate = { color: 'red' };
                GetErrors += '1' + '\n';
            }
         
            if (Cause == '' || Cause==null)
            {
                $scope.cause = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (NewInjuryDescription == '' || NewInjuryDescription == null)
            {
                GetErrors += '2' + '\n';
            }
           
            // Start --------------- Date Formate Check

            var s = document.getElementById("LastGlucoseTestDate").value;
            var arr = s.split("-");
            var MM = arr[1];
            var dd = arr[2];
            var yy = arr[0];
           
           

            if (yy > 2016) {
                alert('date of Injury should not be future date .!');
                $scope.InjDate = { color: 'red' };
                GetErrors += '25' + '\n';
            }
           
            else if (dd > 32 || dd == '00') {
                alert('Invalid Injury Date 1.!');
                $scope.InjDate = { color: 'red' };
                GetErrors += '25' + '\n';
            }
            else if (MM > 13 || MM == '00') {
                alert('Invalid Injury Date 2.!');
                $scope.InjDate = { color: 'red' };
                GetErrors += '25' + '\n';
            }
            if (yy == '00' || yy == '0') {
                alert('Invalid Injury Date 3.!');
                $scope.InjDate = { color: 'red' };
                GetErrors += '25' + '\n';
            }

            //--------------------------------End
           

            if (GetErrors == null || GetErrors == '') {
              
                var NewCompliant = {

                    PatientId: PatientId, NewInjuryDate: NewInjuryDate, Cause: Cause, NewInjuryDescription: NewInjuryDescription,
                    LastCheckUp: LastCheckUp, LastCheckUpDetail: LastCheckUpDetail, FrontPainArea: FrontPainArea, BackPainArea: BackPainArea,
                    PainDescription: PainDescription, CurrentMobility: CurrentMobility, CurrentEmployeement: CurrentEmployeement, LastFullDayWork: LastFullDayWork
                }
               
                $http({
                    method: 'POST',
                    url: '/Patient/NewCompliant',
                    data: NewCompliant
                }).success(function (data) {
                   
                  
                    $("#divLoading").hide();
                    $scope.ABC = data;
                    var Con = data;
                   // alert(Con);

                  

                    if (Con == null || Con == "10" || Con == "\"10\"") {
                      //  alert();
                      //  method: 'get',
                        alert('Your Compliant Saved');
                        location.href = '/Admin/Index?param=Patient Platform Setting';
                        data: PatientiInfoModule
                    }
                    else {
                        alert('Your Compliant Saved');
                        location.href = '/Admin/Index?param=User Patient';
                        data: PatientiInfoModule
                    }
                });
            }
            else {
                $("#divLoading").hide();
            }
        }

    }
}]);

//--------------------------------------- Patient Medical Authorization Controller

app.controller('PatientMedicalAuthorizationController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.PatientModel = {}

    GetPatientMedicalAuthorizationDetail();
   
    function GetPatientMedicalAuthorizationDetail() {
        $http({
            method: 'Get',
            url: '/ExistSearch/GetPatientMedicalAuthorizationDetail'
        }).success(function (data, status, headers, config) {
            $scope.PatientModel = data
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $("#divLoading").show();
           
            $scope.OrgName = false;
            $scope.OrgAddress = false;
            $scope.OrgContactNo = false;
            var GetErrors = '';
            
            var releaseTo = data.ReleaseTo;
            var obtainFrom = data.ObtainFrom;
            var orgName = data.OrgName;
            var orgAddress = data.OrgAddress;
            var orgContactNo = data.OrgContactNo;
            var appliesTo = data.AppliesTo;
            if (appliesTo == "Other") {
                appliesTo = data.TextAppliesTo;
            }
            var validTill = data.ValidTill;
            var signature = document.getElementById("SignatureValue1").value;
            var signDate = document.getElementById("SignDate").value;

          
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = {
                    ReleaseTo: releaseTo, ObtainFrom: obtainFrom,
                    OrgName: orgName, OrgAddress: orgAddress, OrgContactNo: orgContactNo, AppliesTo: appliesTo, ValidTill: validTill, Signature: signature, SignDate: signDate
                }
                $http({
                    method: 'POST',
                    url: '/Patient/PatientMedicalAuthorization',
                    data: AddPatientModule
                }).success(function (data) {
                  
                    $("#divLoading").hide();
                    $scope.ABC = data;
                    var Con = data;

                    console.log(data)
                   
                    if (Con == null || Con == "1" || Con == "\"1\"") {
                        method: 'get',
                        location.href = '/Patient/PatientConsentForm';                        
                    }
                    else {
                        location.href = '/Patient/PatientConsentForm';
                    }

                });
            }
            else {
            }
        }

    }

}]);


//--------------------------------------- Patient Consent Controller

app.controller('PatientConsentController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.PatientModel = {}
    $scope.onsubmit = function (alldetails) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $("#divLoading").show();
            $scope.Signature = false;
            $scope.AkgDate = false;
            var GetErrors = '';
            var signature = document.getElementById("SignatureValue1").value;
            var akgDate = document.getElementById("AkgDate").value;
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = { Signature: signature, AkgDate: akgDate }
                $http({
                    method: 'POST',
                    url: '/Patient/PatientConsentForm',
                    data: AddPatientModule
                }).success(function (data) {

                    $("#divLoading").hide();
                    $scope.ABC = data;
                    var Con = data;
                    console.log(data)                   
                    if ( Con == "1" || Con == "\"1\"") {                    
                        alert('Registration Completed!')
                        location.href = '/Admin/AdminIndex';
                    }
                    else {
                        
                        alert('Registration Completed!')
                        location.href = '/Account/LogOut'
                        
                    }
                    $("#divLoading").hide();
                });
            }
            else {
               
            }
        }
    }
}]);
