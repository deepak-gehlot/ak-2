﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.BussinessLayer;
using NewAPGApplication.Models;
using System.Web.Security;
using PagedList;
using PagedList.Mvc;
using System.IO;

namespace NewAPGApplication.Controllers
{
    public class WomacController : Controller
    {
        GetPatientInformation ob = new GetPatientInformation();
        DbConnection obj = new DbConnection();

        int WomacTestId = 0;
        string Success, UserID, EmailID;
        bool RememberMe;
        DataSet ds1, ds2, ds3, dss,ds5,ds6,  dds1 = null;

        public int CheckSession(int CheckNo)
        {
            int returnValue = 0;
            if (CheckNo == 1)
            {
                if ((Session["UserIdentityForLayOut"] != null) || (Session["UserId"] != null))
                {
                    if (Session["LoginUserId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            if (CheckNo == 2)
            {
                if ((Session["UserIdentityForLayOut"] != null)||(Session["UserId"]!=null))
                {
                    if (Session["UserTypeId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            return returnValue;
        }

        public string IsWomacDone(string PatientId)
        {
            string Result = "0";
            MySqlCommand cmd = new MySqlCommand("select * from  womac_test where PatientId= '" + PatientId.ToString() + "'", obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count != 0)
            {
                Result = "YES";
            }
            else
            {
                Result = "NO";
            }
            return Result;
        }

        //------------------------------------------Womac Patient List

        public ActionResult WomacPatientList(int FormId,FormCollection From, string Filtername)
        {
          
            PatientWomacReportList model = new PatientWomacReportList();
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                       // Session["AccessFormId"] = FormId;
                        int update = 0;
                        int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                        int LoggedFacilityId = Session["LoggedInFacilityId"].ToString() != "0" ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                        int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                        if (Allowed == 1)
                        {
                            var Name = Filtername;
                            ViewBag.searchname = Name;
                            ViewBag.save = Connection.AllowSave;
                           
                            if (!String.IsNullOrEmpty(Name))
                            {
                                model = GetFilterRecord.GetWomacList(Name, LoggedFacilityId, update);
                            }

                            else
                            {
                                model = GetPatientInformation.GetWomacList(LoggedFacilityId, update);
                            }
                        }
                        else
                        {
                            ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                            return RedirectToAction("AdminIndex", "Admin");
                        }
                   
                        return View(model);
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("LogOut", "Account");
            }
           // return View(model);
        }

        [HttpPost]
        public ActionResult womacsearchpatient_reset(int FormId)
        {
            Session["PName"] = null;
            PatientWomacReportList model = new PatientWomacReportList();
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    // Session["Paitent_deactive"]= From["Name"];
                    int LoggedFacilityId = Session["LoggedInFacilityId"].ToString() != "0" ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    Session["AccessFormId"] = FormId;

                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    if (Allowed == 1)
                    {
                        Session["CreateUser"] = Connection.AllowSave == "1" ? 1 : 0;

                        model = GetPatientInformation.GetWomacList(LoggedFacilityId);
                        return View("WomacPatientList", model);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("DashBoard", "Home");
            }

        }

        [HttpPost]
        public ActionResult womacsearchpatient_reset1(int FormId)
        {
            Session["PName"] = null;
            PatientWomacReportList model = new PatientWomacReportList();
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    // Session["Paitent_deactive"]= From["Name"];
                    int update = 1;
                    int LoggedFacilityId = Session["LoggedInFacilityId"].ToString() != "0" ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    Session["AccessFormId"] = FormId;

                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    if (Allowed == 1)
                    {
                        Session["CreateUser"] = Connection.AllowSave == "1" ? 1 : 0;

                        model = GetPatientInformation.GetWomacList(LoggedFacilityId, update);
                        return View("ChangeWomacDate", model);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("DashBoard", "Home");
            }

        }

        //------Change womac Date------
        
        public ActionResult ChangeWomacDate(int FormId,FormCollection From, string Filtername)
        {
                PatientWomacReportList model = new PatientWomacReportList();
                try
                {
                    int SessionState = CheckSession(1);
                    if (SessionState == 1)
                    {
                        Session["AccessFormId"] = FormId;
                        int update = 1;
                        int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                        int LoggedFacilityId = Session["LoggedInFacilityId"].ToString() != "0" ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                        int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                        if (Allowed == 1)
                        {
                            var Name = Filtername;
                            ViewBag.searchname = Name;
                            ViewBag.save = Connection.AllowSave;
                           // ViewBag.save = "1";

                            if (!String.IsNullOrEmpty(Name))
                            {
                                model = GetFilterRecord.GetWomacList(Name, LoggedFacilityId,update);
                            }

                            else
                            {
                               model = GetPatientInformation.GetWomacList(LoggedFacilityId, update);
                            }
                        }
                        else
                        {
                            ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                            return RedirectToAction("AdminIndex", "Admin");
                        }

                        return View(model);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "User Session TimeOut";
                        return RedirectToAction("LogOut", "Account");
                    }
                }
                catch (Exception e)
                {
                    return RedirectToAction("LogOut", "Account");
                }
               // return View(model);
           
        }
        //-------------------------------------- Get Patient First womac 

       
        public ActionResult PatientWomac(int FormId, FormCollection From,string Filtername)
        {
            int tempLoggedinFacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;

           
            Session["AccessFormId"] = FormId;
            var df = SecurityManager.Encrypt("000000000");
            PatientList model = new PatientList();
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    Session["CreateUser"] = Connection.AllowSave;
                    ViewBag.save = Connection.AllowSave;
                    if (Allowed == 1)
                    {

                        if (tempLoggedinFacilityId != 0)
                        {
                           // var Name = From["Name"];
                            var Name = Filtername;
                            ViewBag.searchname = Name;
                            if (!String.IsNullOrEmpty(Name))
                            {
                                model = GetFilterRecord.GetWomacPatientList(Name, tempLoggedinFacilityId);
                            }
                            else
                            {
                                model = GetPatientInformation.GetWomacPatientList(tempLoggedinFacilityId);
                            }
                        }
                        return View(model);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

        [HttpPost]
        public ActionResult DeactivatePatientList_reset(int FormId, int reset)
        {
           // Session["Paitent_deactive"] = null;
            PatientList model = new PatientList();
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    // Session["Paitent_deactive"]= From["Name"];
                    int tempLoggedinFacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    Session["AccessFormId"] = FormId;

                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    if (Allowed == 1)
                    {
                        Session["CreateUser"] = Connection.AllowSave == "1" ? 1 : 0;

                        model = GetPatientInformation.GetWomacPatientList(tempLoggedinFacilityId);

                        return View("PatientWomac", model);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                        return RedirectToAction("DashBoard", "Home");
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("DashBoard", "Home");
            }

        }


        //Logged Patient List

        public PatientWomacReportList GetPatientWomacList(string PatientId)
        {
            PatientWomacReportList model = new PatientWomacReportList();
            try
            {
                int LoggedFacilityId = Session["LoggedInFacilityId"].ToString() != "0" ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;

                if (PatientId != "")
                {
                    List<PatientWomacReport> PatientWomacReportDetail = new List<PatientWomacReport>();

                    MySqlCommand cmd = new MySqlCommand("SELECT distinct IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee FROM userregister t1 INNER JOIN womac_test t2 ON t2.PatientId = t1.U_Id  where t1.U_Id='" + PatientId.ToString() + "'", obj.con);

                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);

                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            string PatientID = dt.Rows[i]["U_Id"].ToString();

                            string Kneevalue = dt.Rows[i]["Knee"].ToString() == "Left Knee,Right Knee" ? "Left Knee,Right Knee" : dt.Rows[i]["Knee"].ToString();

                            string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());

                            string WomacTestDate1 = null, WomacTestDate2 = null, WomacTestDate3 = null, IsComplete2 = null, IsComplete3 = null;

                            DataTable Dtw1 = WomacCalender.GetWomacNo(PatientID, 1, Convert.ToInt16(LoggedFacilityId));
                            DataTable Dtw2 = WomacCalender.GetWomacNo(PatientID, 2, Convert.ToInt16(LoggedFacilityId));
                            DataTable Dtw3 = WomacCalender.GetWomacNo(PatientID, 3, Convert.ToInt16(LoggedFacilityId));

                            int WomacNo = 0;

                            if (Dtw3.Rows.Count > 0)
                            {
                                WomacNo = Convert.ToInt16(Dtw3.Rows[0]["WOMAC_Name"].ToString());
                            }
                            else if (Dtw2.Rows.Count > 0)
                            {
                                WomacNo = Convert.ToInt16(Dtw2.Rows[0]["WOMAC_Name"].ToString());
                            }
                            else if (Dtw1.Rows.Count > 0)
                            {
                                WomacNo = Convert.ToInt16(Dtw1.Rows[0]["WOMAC_Name"].ToString());
                            }

                            if (WomacNo == 1)
                            {

                                WomacTestDate1 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw1.Rows[0]["Complete"].ToString());
                                WomacTestDate2 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_NexttestOn"].ToString().Replace("12:00:00 AM", " "), IsComplete2);
                                WomacTestDate3 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_NexttestOn"].ToString().Replace("12:00:00 AM", " "), IsComplete3);

                                if (WomacTestDate2 == WomacTestDate3)
                                {
                                    WomacTestDate3 = WomacCalender.WoMacTestDate_III(Dtw1.Rows[0]["WOMAC_NexttestOn"].ToString().Replace("12:00:00 AM", " "), IsComplete3);
                                }

                            }
                            else if (WomacNo == 2)
                            {
                                WomacTestDate1 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw1.Rows[0]["Complete"].ToString());
                                WomacTestDate2 = WomacCalender.WoMacTestDate(Dtw2.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw2.Rows[0]["Complete"].ToString());
                                WomacTestDate3 = WomacCalender.WoMacTestDate(Dtw2.Rows[0]["WOMAC_NexttestOn"].ToString().Replace("12:00:00 AM", " "), IsComplete3);
                            }
                            else if (WomacNo == 3)
                            {
                                WomacTestDate1 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw1.Rows[0]["Complete"].ToString());
                                WomacTestDate2 = WomacCalender.WoMacTestDate(Dtw2.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw2.Rows[0]["Complete"].ToString());
                                WomacTestDate3 = WomacCalender.WoMacTestDate(Dtw3.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw3.Rows[0]["Complete"].ToString());
                            }

                            PatientWomacReportDetail.Add(new PatientWomacReport
                            {
                                PatientId = dt.Rows[i]["U_Id"].ToString(),
                                PatientName = PN,
                                Knee = Kneevalue,
                                Womac1 = WomacTestDate1,
                                Womac2 = WomacTestDate2,
                                Womac3 = WomacTestDate3
                            });

                        }
                    }

                    model.PatientWomacRepotList = PatientWomacReportDetail;
                }
            }
            catch (Exception e)
            {
            }
            return model;
        }

        public ActionResult SelectWomacKnee(string PatientId,string viewed="")
        {
            ViewBag.backview = viewed;
            string UserNameId = "";
            string patientid = null;
            if (PatientId != null)
            {
                patientid =SecurityManager.Encrypt(PatientId).ToString();
            }
          
            try
            {

                patientid = patientid != null ? patientid : SecurityManager.Encrypt(Session["SelectedUserId"].ToString());
                    // string IsWomac = IsWomacDone(PatientId.ToString());
                var PID = patientid;

                    MySqlCommand cmd = new MySqlCommand("select IFNULL(Gender, '') AS Gender from  userregister where U_Id= '" + patientid + "'", obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count != 0)
                    {
                        if (dt.Rows[0]["Gender"].ToString().Trim() == "Male")
                        {
                            Session["Gender"] = dt.Rows[0]["Gender"].ToString();
                        }
                        else if (dt.Rows[0]["Gender"].ToString().Trim() == "Female")
                        {
                            Session["Gender"] = dt.Rows[0]["Gender"].ToString();
                        }
                        ViewBag.PatientId =SecurityManager.Decrypt(patientid);
                    }
                    string KneeType = AdminClass.GetKneeType(patientid.ToString());
                    Session["TestDone"] = KneeType;
                    return View();
              

            }

            catch
            {
                return RedirectToAction("MyIndex", "Patient");
            }
        }
        
        //------------------------------------------ Due Womac Patient List

        public ActionResult DueWomacList(int? Page, string ListType = "")
        {
            try
            {                
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    if (!String.IsNullOrEmpty(ListType))
                    {
                        Session["ListType"] = ListType.ToString();
                    }
                    string LT = Session["ListType"].ToString();
                    var tupleModel = new Tuple<IPagedList<PatientWomacReport>>(GetDueWomacList(LT, Page));
                    ViewBag.ListType = ListType;
                    return View(tupleModel);
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch(Exception ex)
            {
            }
            return RedirectToAction("LogOut", "Account");
        }

        private IPagedList<PatientWomacReport> GetDueWomacList(string ListType, int? Page)
        {
            Session["AccessFormId"] = 101;
            string WOMAC_Name="0";
            string qury="";
            PatientWomacReportList model = new PatientWomacReportList();
            try
            {
                int tempLoggedinFacilityId = Session["LoggedInFacilityId"].ToString() != "0" ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                int j = 0;
                if (tempLoggedinFacilityId != 0)
                {
                    if (ListType == "Progress WOMAC Due")
                    {
                        j = 1;
                        //WOMAC_Name = "1";
                       //qury= "(t2.WOMAC_Name =1  OR  t2.WOMAC_Name =2)";
                       // qury = "SELECT distinct t1.U_Id,IFNULL(t2.PatientId, '0') AS PatientId, IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,t2.WOMAC_TestOn,IFNULL(t2.Knee, '') AS Knee ,IFNULL(DATE_FORMAT(t2.WOMAC_TestOn, '%b-%e-%Y ') , '')  AS WOMAC_TestOn ,IFNULL(t2.WOMAC_Name, '') AS WOMAC_Name,IFNULL(t2.WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,IFNULL(t2.Complete, '') AS Complete FROM userregister t1 INNER JOIN  womac_test t2 ON t1.U_Id=t2.PatientId where t1.FacilityId= '" + tempLoggedinFacilityId + "' and t1.R_Id=10  and t1.IsActive= 1  and (t2.WOMAC_Name =1  OR  t2.WOMAC_Name =2) and  t2.Complete ='FALSE'";
                        qury = "SELECT IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.FacilityId, '') AS FacilityId,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee,IFNULL(DATE_FORMAT(t2.WOMAC_TestOn, '%b-%e-%Y ') , '')  AS WOMAC_TestOn , IFNULL(WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,max(case when t2.WOMAC_Name = '1' then t2.Complete else ' 'end) as '1', max(case when t2.WOMAC_Name = '2' then t2.Complete else ' 'end) as '2',max(case when t2.WOMAC_Name = '3' then t2.Complete else ' 'end) as '3' FROM userregister t1 INNER JOIN  womac_test t2 ON t2.PatientId = t1.U_Id where t1.IsActive = 1 and t1.R_Id =10 group by  t1.U_Id  order by WOMAC_TestOn desc";
                    }
                    else if (ListType == "Final WOMAC Due")
                    {
                       // WOMAC_Name = "3";
                       // qury = "(t2.WOMAC_Name =3)";
                        qury = "select * from (SELECT IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.FacilityId, '') AS FacilityId,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee,IFNULL(DATE_FORMAT(t2.WOMAC_TestOn, '%b-%e-%Y '), '') AS WOMAC_TestOn, IFNULL(t2.WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,max(case when t2.WOMAC_Name = '1' then t2.Complete else ' 'end) as '1', max(case when t2.WOMAC_Name = '2' then t2.Complete else ' 'end) as '2',max(case when t2.WOMAC_Name = '3' then t2.Complete else ' 'end) as '3' FROM userregister t1 INNER JOIN  womac_test t2 ON t2.PatientId = t1.U_Id where t1.IsActive = 1 and t1.R_Id =10 group by  t1.U_Id  order by WOMAC_TestOn desc) as TTTT where TTTT.1 = 'True' and  TTTT.2 = 'True'  and  TTTT.3 != 'True'";

                    }

                    List<PatientWomacReport> PatientWomacReportDetail = new List<PatientWomacReport>();
                    MySqlCommand cmd = new MySqlCommand(qury, obj.con);
                    // MySqlCommand cmd = new MySqlCommand("SELECT distinct IFNULL(t2.PatientId, '') AS PatientId,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee,IFNULL(t2.WOMAC_TestOn, '') AS WOMAC_TestOn,IFNULL(t2.WOMAC_Name, '') AS WOMAC_Name,IFNULL(t2.WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,IFNULL(t2.Complete, '') AS Complete FROM userregister t1 INNER JOIN  womac_test t2 ON t1.U_Id=t2.PatientId where t1.FacilityId='" + tempLoggedinFacilityId + "'and t2.WOMAC_Name='" + WOMAC_Name + "' and t1.R_Id='" + 10 + "' and t1.IsActive='" + 1 + "'", obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                       
                        if (j == 1)
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                string PatientID = dt.Rows[i]["U_Id"].ToString();
                                                  
                                if ((dt.Rows[i]["1"].ToString() == "True" || dt.Rows[i]["1"].ToString() == "False" || dt.Rows[i]["2"].ToString() == "False") && (dt.Rows[i]["1"].ToString() != "True" || dt.Rows[i]["2"].ToString() != "True"))
                                {
                                    string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                                    string WomacTestDate1 = null, WomacTestDate2 = null, WomacTestDate3 = null;
                                    string womacdate1 = null,womacdate2 = null,womacdate3 = null;
                                    string Womactype = null;
                                    if (dt.Rows[i]["1"].ToString() == "False" || dt.Rows[i]["1"].ToString() == " ")
                                    {
                                        Womactype = "1";
                                    }
                                    else if (dt.Rows[i]["2"].ToString() == "False" || dt.Rows[i]["2"].ToString() == " ")
                                    {
                                        Womactype = "2";
                                    }
                                    else if (dt.Rows[i]["3"].ToString() == "False" || dt.Rows[i]["3"].ToString() == " ")
                                    {
                                        Womactype = "3";
                                    }
                                     DataTable Dtw2 = WomacCalender.GetWomacNo(PatientID, 2, Convert.ToInt16(tempLoggedinFacilityId));
                                     DataTable Dtw1 = WomacCalender.GetWomacNo(PatientID, 1, Convert.ToInt16(tempLoggedinFacilityId));
                                     if (Dtw2.Rows.Count != 0)
                                     {
                                         WomacTestDate2 = Convert.ToDateTime(Dtw1.Rows[0]["WOMAC_NexttestOn"]).ToString("MMM-dd-yyyy");
                                     }
                                     else
                                     {
                                         WomacTestDate1 = Convert.ToDateTime(Dtw1.Rows[0]["WOMAC_NexttestOn"]).ToString("MMM-dd-yyyy");
                                     
                                     }  // womacdate2 = Convert.ToDateTime(WomacTestDate2).AddDays(15).ToString("MMM-dd-yyyy");                                   
                                    // if (WomacTestDate1)

                                    PatientWomacReportDetail.Add(new PatientWomacReport
                                    {
                                        PatientId =SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                        PatientName = PN,
                                        Knee = dt.Rows[i]["Knee"].ToString(),      //dt.Rows[i]["Knee"].ToString(),
                                        Womac1 = WomacTestDate1,
                                        Womac2 = WomacTestDate2,
                                        Womac3 = WomacTestDate3,
                                        WomacId = Womactype,
                                        WomacListType = ListType
                                    });

                                }
                                else
                                {


                                }
                            }

                        }
                        else
                        { 
                        for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                string PatientID = dt.Rows[i]["U_Id"].ToString();
                                 DataTable Dtw3 = WomacCalender.GetWomacNo(PatientID, 3, Convert.ToInt16(tempLoggedinFacilityId));
                                 DataTable Dtw2 = WomacCalender.GetWomacNo(PatientID, 2, Convert.ToInt16(tempLoggedinFacilityId));
                        
                                   string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                                    string WomacTestDate1 = null, WomacTestDate2 = null, WomacTestDate3 = null;
                                  //  string womacdate1 = null, womacdate2 = null, womacdate3 = null;
                                    string Womactype = null;
                                    if (dt.Rows[i]["1"].ToString() == "False" || dt.Rows[i]["1"].ToString() == " ")
                                    {
                                        Womactype = "1";
                                    }
                                    else if (dt.Rows[i]["2"].ToString() == "False" || dt.Rows[i]["2"].ToString() == " ")
                                    {
                                        Womactype = "2";
                                    }
                                    else if (dt.Rows[i]["3"].ToString() == "False" || dt.Rows[i]["3"].ToString() == " ")
                                    {
                                        Womactype = "3";
                                    }
                                    if (Dtw3.Rows.Count != 0)
                                    {
                                        if (Dtw3.Rows[0]["WOMAC_TestOn"] != null)
                                        {       
                                            WomacTestDate3 = Convert.ToDateTime(Dtw3.Rows[0]["WOMAC_TestOn"]).ToString("MMM-dd-yyyy");
                                            // womacdate3 = Convert.ToDateTime(WomacTestDate3).AddDays(15).ToString("MMM-dd-yyyy");
                                        }
                                    }
                                    else
                                    {
                                        string womactdate3 = (Dtw2.Rows[0]["WOMAC_NexttestOn"] + " " + "00:00:00").ToString();
                                        WomacTestDate3 = Convert.ToDateTime(womactdate3).ToString("MMM-dd-yyyy");
                                    }

                                    PatientWomacReportDetail.Add(new PatientWomacReport
                                    {
                                        PatientId =SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                        PatientName = PN,
                                        Knee = dt.Rows[i]["Knee"].ToString(),      //dt.Rows[i]["Knee"].ToString(),
                                        Womac1 = WomacTestDate1,
                                        Womac2 = WomacTestDate2,
                                        Womac3 = WomacTestDate3,
                                        WomacId = Womactype,
                                        WomacListType = ListType
                                    });

                                }
                        }
                        
                    }
                    model.PatientWomacRepotList = PatientWomacReportDetail;
                }
            }
            catch(Exception ex)
            {
            }
            return model.PatientWomacRepotList.ToList().ToPagedList(Page ?? 1, 15);
        }
        
        //-----------------------------------------Single Knee

        public ActionResult SingleKneeWomac(string Knee)
        {
            int Womac_Id = 1;
            int SessionState = CheckSession(1);
            if (SessionState == 1)
            {
                if (ModelState.IsValid)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());

                    string Pid = Session["UserId"].ToString() != null ? Session["UserId"].ToString() : "0";

                    string PatientId = SecurityManager.Encrypt(Pid);

                    var Womac = SingleKneeWomacTestCalGet(PatientId, Knee, Womac_Id);
                    return View(Womac);
                }
                else
                {
                    Session.Remove("DiseaseTypeId");
                    return RedirectToAction("NewIndex", "Patient");
                }
            }
            else
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        public Womac1 SingleKneeWomacTestCalGet(string PatientId, string Knee, int WomacId)
        {
             //PatientId = SecurityManager.Encrypt(PatientId);
            var Womac = new Womac1();
            if (PatientId == null)
            { }
            else
            {
                PatientId = PatientId.Replace(" ", "+");
            }
                string UserId = PatientId.ToString();    
      

            if (Session["LoginUserId"] != null)
            {

                ds1 = ob.GetPhysicainList();
                ds2 = ob.GetPhysicianTherapist();
                ds5 = ob.GetPhysicainListNew();
                ds6 = ob.GetPhysicianTherapistNew();
                ds3 = ob.GetUserData(PatientId);             //------------- Get Data From table 'userregister'
                dss = ob.GetWomacList(PatientId, WomacId);            //-------------- Get Is Womec Available
                dds1 = ob.GetAllDiseaseList();

                List<SelectListItem> Physician = new List<SelectListItem>();
                for (int i = 0; i <= ds5.Tables[0].Rows.Count - 1; i++)
                {
                    string PN = SecurityManager.Decrypt(ds5.Tables[0].Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(ds5.Tables[0].Rows[i]["L_Name"].ToString());
                    string value = SecurityManager.Decrypt(ds5.Tables[0].Rows[i]["U_Id"].ToString());
                    Physician.Add(new SelectListItem { Text = PN, Value = value });
                }
                ViewData["Physician"] = Physician;


                List<SelectListItem> PhysicianTherapist = new List<SelectListItem>();
                for (int i = 0; i <= ds6.Tables[0].Rows.Count - 1; i++)
                {
                    string PN = SecurityManager.Decrypt(ds6.Tables[0].Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(ds6.Tables[0].Rows[i]["L_Name"].ToString());
                    string value = SecurityManager.Decrypt(ds6.Tables[0].Rows[i]["U_Id"].ToString());
                    PhysicianTherapist.Add(new SelectListItem { Text = PN, Value = value });
                }
                ViewData["PhysicianTherapist"] = PhysicianTherapist;

            }

            if (ds3.Tables[0].Rows.Count != 0)
            {
                
                Womac.PatientId = SecurityManager.Decrypt(ds3.Tables[0].Rows[0]["U_Id"].ToString());
                string Name = SecurityManager.Decrypt(ds3.Tables[0].Rows[0]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(ds3.Tables[0].Rows[0]["L_Name"].ToString());
                Womac.PatientName = Name;

                if (!String.IsNullOrEmpty(ds3.Tables[0].Rows[0]["DOB"].ToString()))
                {
                    Womac.DOB = Convert.ToDateTime(ds3.Tables[0].Rows[0]["DOB"].ToString()).ToString("MMM-dd-yyyy");
                }

                Womac.FacilityId = Convert.ToInt32(ds3.Tables[0].Rows[0]["FacilityId"].ToString());

                int Fid = Convert.ToInt32(ds3.Tables[0].Rows[0]["FacilityId"].ToString());

                DataTable data = ob.GetFacilityLocationName(Fid);
                if (data.Rows.Count > 0)
                {
                    Womac.FacilityName = data.Rows[0]["Location"].ToString();
                    Connection.FacilityName = data.Rows[0]["Location"].ToString();
                }
                Womac.Knee = Knee;
            }

            if (dss.Tables[0].Rows.Count != 0)
            {
                Womac.WomacDate = Convert.ToDateTime(dss.Tables[0].Rows[0]["WOMAC_TestOn"].ToString()).ToString("MMMM-dd-yyyy");
                Womac.Knee = dss.Tables[0].Rows[0]["KneeTestTo"].ToString();
                for (int i = 0; i < dss.Tables[0].Rows.Count; i++)
                {
                    int Counter = 1;
                    DataTable dt = new DataTable();
                    string Question = null;
                    var userlist = dss.Tables[0].Rows[i]["Answer"].ToString();
                    var allids = userlist;
                    string[] useridlist = allids.Split(',');
                    var Q = dss.Tables[0].Rows[i]["Disease_DetailId"].ToString();
                    var allQ = Q;
                    string[] Qidlist = allQ.Split(',');


                  
                  
                    for (int j = 0; j < useridlist.Length; j++)
                    {
                        int QuestionId = Convert.ToInt32(Qidlist[j].ToString());

                 


                        MySqlDataAdapter asd = new MySqlDataAdapter("select * from  diseaselist Where Disease_DetailId='" + QuestionId + "'", obj.con);
                        dt = new DataTable();
                        asd.Fill(dt);

                        if (dt.Rows.Count != 0)
                        {
                            for (int l = 0; l < dt.Rows.Count; l++)
                            {
                                if (Convert.ToInt32(dt.Rows[l]["Disease_DetailId"].ToString()) == QuestionId)
                                {
                                    Question = dt.Rows[l]["Disease_DetailId"].ToString();
                                }
                            }
                        }

                        bool none = false, slight = false, moderate = false, severe = false, extreme = false;
                        int k = Convert.ToInt32(useridlist[j].ToString());
                        if (k == 0)
                        {
                            none = true;
                        }
                        else if (k == 1)
                        {
                            slight = true;
                        }
                        else if (k == 2)
                        {
                            moderate = true;
                        }
                        else if (k == 3)
                        {
                            severe = true;
                        }
                        else if (k == 4)
                        {
                            extreme = true;
                        }

                        Session["DiseaseTypeId"] = dds1.Tables[0].Rows[i]["DiseaseId"].ToString();
                        ViewBag.QuestionType = dds1.Tables[0].Rows[i]["DiseasesType"].ToString();

                       
                        var Query = new WomacTest
                        {
                            ID = Convert.ToInt32(dt.Rows[0]["Disease_DetailId"].ToString()),
                            QuestionTypeId = Convert.ToInt32(dt.Rows[0]["DiseaseId"].ToString()),
                            QuestionValue = Counter.ToString() + "." + dt.Rows[0]["DiseaseName"].ToString()
                        };


                        Session.Remove("save");
                        Session["save"] = "save";
                        if (Convert.ToBoolean(dss.Tables[0].Rows[0]["Complete"].ToString()) == true)
                        {
                            Session["WomacComplete"] = "True";
                            Query.Answers.Add(new Answer { ID = i.ToString() + "none", AnswerText = "None", AnswerValue = 0, IsChecked = none, Disabled = true });
                            Query.Answers.Add(new Answer { ID = i.ToString() + "slight", AnswerText = "Slight", AnswerValue = 1, IsChecked = slight, Disabled = true });
                            Query.Answers.Add(new Answer { ID = i.ToString() + "moderate", AnswerText = "Moderate", AnswerValue = 2, IsChecked = moderate, Disabled = true });
                            Query.Answers.Add(new Answer { ID = i.ToString() + "severe", AnswerText = "Severe", AnswerValue = 3, IsChecked = severe, Disabled = true });
                            Query.Answers.Add(new Answer { ID = i.ToString() + "extreme", AnswerText = "Extreme/Can't Do", AnswerValue = 4, IsChecked = extreme, Disabled = true });
                        }
                        else if (Convert.ToBoolean(dss.Tables[0].Rows[0]["Complete"].ToString()) == false)
                        {
                            Session["WomacComplete"] = "False";
                            Query.Answers.Add(new Answer { ID = i.ToString() + "none", AnswerText = "None", AnswerValue = 0, IsChecked = none, Disabled = false });
                            Query.Answers.Add(new Answer { ID = i.ToString() + "slight", AnswerText = "Slight", AnswerValue = 1, IsChecked = slight, Disabled = false });
                            Query.Answers.Add(new Answer { ID = i.ToString() + "moderate", AnswerText = "Moderate", AnswerValue = 2, IsChecked = moderate, Disabled = false });
                            Query.Answers.Add(new Answer { ID = i.ToString() + "severe", AnswerText = "Severe", AnswerValue = 3, IsChecked = severe, Disabled = false });
                            Query.Answers.Add(new Answer { ID = i.ToString() + "extreme", AnswerText = "Extreme/Can't Do", AnswerValue = 4, IsChecked = extreme, Disabled = false });
                        }
                       

                        if (Convert.ToInt32(dss.Tables[0].Rows[i][0].ToString()) == 1)
                        {
                            Counter = Counter + 1;
                            Womac.WomacTests1.Add(Query);
                        }
                        else if (Convert.ToInt32(dss.Tables[0].Rows[i][0].ToString()) == 2)
                        {
                            Counter = Counter + 1;
                            Womac.WomacTests2.Add(Query);
                        }
                        else if (Convert.ToInt32(dss.Tables[0].Rows[i][0].ToString()) == 3)
                        {
                            Counter = Counter + 1;
                            Womac.WomacTests3.Add(Query);
                        }
                    }
                }
            }
            else
            {
                Womac.WomacDate = DateTime.Now.ToString("MMM-dd-yyyy");
                Session.Remove("save");
                Session["WomacComplete"] = "False";
                if (dds1.Tables[0].Rows.Count != 0)
                {
                    int Counter = 1;
                    for (int i = 0; i < dds1.Tables[0].Rows.Count; i++)
                    {
                        Session["DiseaseTypeId"] = dds1.Tables[0].Rows[i]["DiseaseId"].ToString();
                        ViewBag.QuestionType = dds1.Tables[0].Rows[i]["DiseaseName"].ToString();

                        var Query = new WomacTest
                        {
                            ID = Convert.ToInt32(dds1.Tables[0].Rows[i]["Disease_DetailId"].ToString()),
                            QuestionTypeId = Convert.ToInt32(dds1.Tables[0].Rows[i]["DiseaseId"].ToString()),
                            QuestionValue = Counter.ToString() + "." + dds1.Tables[0].Rows[i]["DiseaseName"].ToString()
                        };

                        Query.Answers.Add(new Answer { ID = i.ToString() + "none", AnswerText = "None", AnswerValue = 0, IsChecked = true, Disabled = false });
                        Query.Answers.Add(new Answer { ID = i.ToString() + "slight", AnswerText = "Slight", AnswerValue = 1, IsChecked = false, Disabled = false });
                        Query.Answers.Add(new Answer { ID = i.ToString() + "moderate", AnswerText = "Moderate", AnswerValue = 2, IsChecked = false, Disabled = false });
                        Query.Answers.Add(new Answer { ID = i.ToString() + "severe", AnswerText = "Severe", AnswerValue = 3, IsChecked = false, Disabled = false });
                        Query.Answers.Add(new Answer { ID = i.ToString() + "extreme", AnswerText = "Extreme/Can't Do", AnswerValue = 4, IsChecked = false, Disabled = false });

                       

                        if (Convert.ToInt32(dds1.Tables[0].Rows[i][0].ToString()) == 1)
                        {
                            Counter = Counter + 1;
                            Womac.WomacTests1.Add(Query);
                        }
                        else if (Convert.ToInt32(dds1.Tables[0].Rows[i][0].ToString()) == 2)
                        {
                            Counter = Counter + 1;
                            Womac.WomacTests2.Add(Query);
                        }
                        else if (Convert.ToInt32(dds1.Tables[0].Rows[i][0].ToString()) == 3)
                        {
                            Counter = Counter + 1;
                            Womac.WomacTests3.Add(Query);
                        }
                    }
                }
            }
            return Womac;
        }

        [HttpPost]
        public ActionResult SingleKneeWomac(Womac1 model)
        {
            WomacTestId = 1;
            int SessionState = CheckSession(1);
            if (SessionState == 1)
            {
                if (ModelState.IsValid)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());

                    string Pid = Session["UserId"].ToString() != null ? Session["UserId"].ToString() : "0";
                    string PatientId = SecurityManager.Encrypt(Pid);
                    Connection.PatientId = PatientId;

                    SingleKneeWomacTestCalPost(model, WomacTestId);

                    if (LUTypeId != 10) // 10 IS ROLE ID of Patient
                    {
                        return RedirectToAction("Dashboard_A", "AdminDeshboard");
                    }
                    else
                    {
                        TempData["Message"] = "Your Registration Completed ....!";
                        return RedirectToAction("PatientIndex", "PatientDeshboard");
                    }                    
                }
                else
                {
                    Session.Remove("DiseaseTypeId");
                    return RedirectToAction("PatientIndex", "PatientDeshboard");
                }
            }
            else
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        public void SingleKneeWomacTestCalPost(Womac1 model, int WomacidNo)
        {
            int QueId = 1;
            int AnswerValue = 0, QuestionTypeId = 0;
            int FinalScrore = 0, TotalP = 0, TotalS = 0, TotalPh = 0;
            int UserId = 0, SuccessId;
            for (int i = 1; i <= 3; i++)
            {
                int TotalScore = 0;

                string UserNameId = Connection.PatientId; //Session["UserId"].ToString() != null ? Session["UserId"].ToString() : "0";
                string bb = model.PatientId;
                string QuestionId = null, AnswerId = null;
                if (i == 1)
                {
                    foreach (var Que in model.WomacTests1)
                    {
                        QuestionTypeId = ob.GetQuestionId(Que.ID); //int.Parse(dds1.Tables[0].Rows[i]["QuesTypeId"].ToString());
                        QuestionId = (QuestionId == null) ? QuestionId + Que.ID : QuestionId + "," + Que.ID;
                        string selectedAnswer = Convert.ToString(Que.SelectedAnswer);
                        AnswerValue = (selectedAnswer == null) ? 0 : SingleKneeWomacAnswer(Convert.ToString(Que.SelectedAnswer));
                        TotalP = TotalScore = TotalScore + AnswerValue;
                        AnswerId = (AnswerId == null) ? AnswerId + AnswerValue : AnswerId + "," + AnswerValue;
                    }
                }
                else if (i == 2)
                {
                    foreach (var Que in model.WomacTests2)
                    {
                        QuestionTypeId = ob.GetQuestionId(Que.ID);
                        QuestionId = (QuestionId == null) ? QuestionId + Que.ID : QuestionId + "," + Que.ID;
                        //  string 
                        string selectedAnswer = Convert.ToString(Que.SelectedAnswer);
                        AnswerValue = (selectedAnswer == null) ? 0 : SingleKneeWomacAnswer(Convert.ToString(Que.SelectedAnswer));
                        TotalS = TotalScore = TotalScore + AnswerValue;
                        AnswerId = (AnswerId == null) ? AnswerId + AnswerValue : AnswerId + "," + AnswerValue;
                    }
                }
                else if (i == 3)
                {
                    foreach (var Que in model.WomacTests3)
                    {
                        QuestionTypeId = ob.GetQuestionId(Que.ID);
                        QuestionId = (QuestionId == null) ? QuestionId + Que.ID : QuestionId + "," + Que.ID;
                        string selectedAnswer = Convert.ToString(Que.SelectedAnswer);
                        AnswerValue = (selectedAnswer == null) ? 0 : SingleKneeWomacAnswer(Convert.ToString(Que.SelectedAnswer));
                        TotalPh = TotalScore = TotalScore + AnswerValue;
                        AnswerId = (AnswerId == null) ? AnswerId + AnswerValue : AnswerId + "," + AnswerValue;
                    }
                }
                if (QuestionId != null && AnswerId != null)
                {
                    DateTime LoginDate = DateTime.Parse(DateTime.Now.ToString());
                    string logindate = Convert.ToDateTime(model.WomacDate).ToString("yyyy-MM-dd hh:mm:ss");
                    DateTime NextWomac = DateTime.Parse((Convert.ToDateTime(model.WomacDate).AddDays(15).ToShortDateString()));
                    //  DateTime NextWomac = DateTime.Parse(DateTime.Now.AddDays(15).ToShortDateString());
                    var knee = model.Knee;
                    var womacno = WomacidNo;
                   // string logindate = Convert.ToDateTime(LoginDate).ToString("yyyy-MM-dd hh:mm:ss");
                    MySqlCommand cmd = new MySqlCommand("select IFNULL(WOMAC_Id, '') AS WOMAC_Id,IFNULL(PatientId, '') AS PatientId,IFNULL(FacilityId, '') AS FacilityId from womac_test where PatientId='" +SecurityManager.Encrypt( Connection.PatientId) + "' and WOMAC_Name='" + WomacidNo + "' and KneeTestTo='" + model.Knee + "'and DieaseId='" + QuestionTypeId + "'", obj.con);
                    MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    asd.Fill(dt);
                    if (dt.Rows.Count == 0)
                    {
                        string QueryStr = @"insert into womac_test (PatientId,FacilityId,DieaseId,Disease_DetailId,TotalScore,Knee,KneeTestTo,WOMAC_TestOn,WOMAC_Name,WOMAC_NexttestOn,Complete,Answer)  
                        values ('" +SecurityManager.Encrypt( Connection.PatientId) + "','" + model.FacilityId + "','" + QuestionTypeId + "','" + QuestionId + "','" + TotalScore + "','" + model.Knee + "','" + model.Knee + "','" + logindate + "','" + WomacidNo + "','" + Convert.ToDateTime(NextWomac).ToString("yyyy-MM-dd hh:mm:ss") + "','" + false + "','" + AnswerId + "')";
                        MySqlCommand cmd1 = new MySqlCommand(QueryStr, obj.con);
                        obj.OpenDbConnection();
                        cmd1.ExecuteNonQuery();
                        obj.CloseDbConnection();
                    }
                    else
                    {
                        var tr="True";
                        string QueryStr = @"update womac_test set FacilityId='" + model.FacilityId + "',Disease_DetailId='" + QuestionId + "',TotalScore='" + TotalScore + "',KneeTestTo='" + model.Knee + "',WOMAC_TestOn='" + logindate + "',WOMAC_NexttestOn='" + Convert.ToDateTime(NextWomac).ToString("yyyy-MM-dd hh:mm:ss") + "',Complete='" + tr + "', Answer ='" + AnswerId + "' where PatientId='" +SecurityManager.Encrypt(Connection.PatientId )+ "' and DieaseId='" + QuestionTypeId + "' and Knee='" + model.Knee + "' and WOMAC_Name ='" + WomacidNo + "'  "; 
                        MySqlCommand cmd1 = new MySqlCommand(QueryStr, obj.con);
                        obj.OpenDbConnection();
                        cmd1.ExecuteNonQuery();
                        obj.CloseDbConnection();
                    }
                }
            }
        }

        private int SingleKneeWomacAnswer(string selectedAnswer)
        {
            int AnswerValue = 0;
            if (selectedAnswer.ToLower() == "None".ToLower()) { AnswerValue = 0; }
            else if (selectedAnswer.ToLower() == "Slight".ToLower()) { AnswerValue = 1; }
            else if (selectedAnswer.ToLower() == "Moderate".ToLower()) { AnswerValue = 2; }
            else if (selectedAnswer.ToLower() == "Severe".ToLower()) { AnswerValue = 3; }
            else if (selectedAnswer.ToLower() == "Extreme/Can't Do".ToLower()) { AnswerValue = 4; }
            return AnswerValue;
        }

        //-----------------------------------------Both Knee

        public ActionResult BothKneeWomac()
        {
            string Knee = "Left Knee,Right Knee";
            int SessionState = CheckSession(1);
            if (SessionState == 1)
            {
                WomacTestId = 1;
                if (ModelState.IsValid)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                                      
                    string Pid = Session["UserId"].ToString() != null ? Session["UserId"].ToString() : "0";
                    string PatientId = SecurityManager.Encrypt(Pid);
                    Connection.PatientId = PatientId;
                    
                    var Womac = BothKneeWomacTestBothCalGet(PatientId, Knee, WomacTestId);
                    return View(Womac);
                }
                else
                {
                    Session.Remove("DiseaseTypeId");
                    return RedirectToAction("MyIndex", "Patient");
                }
            }
            else
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        public WomacBoth BothKneeWomacTestBothCalGet(string Patientid, string Knee, int WomacidNo)
        {
            string PatientId = null;
            if (Patientid == null)
            {
            }
            else
            {
                Patientid = Patientid.Replace(" ", "+");
                PatientId = Patientid;
            }
           
            string TempUid = PatientId.ToString();          //Session["UserId"].ToString();

            var Womac = new WomacBoth();
            string UserId = PatientId.ToString();                       //Convert.ToInt32(Session["UserId"].ToString());

            if (Session["LoginUserId"] != null)
            {
             
                ds1 = ob.GetPhysicainList();
                ds2 = ob.GetPhysicianTherapist();
                ds5 = ob.GetPhysicainListNew();
                ds6 = ob.GetPhysicianTherapistNew();
                ds3 = ob.GetUserData(PatientId);                   //------------- Get Data From table 'userregister'
                dss = ob.GetWomacList(PatientId,WomacidNo);      //-------------- Get Is Womec Available
                dds1 = ob.GetAllDiseaseList();

                List<SelectListItem> Physician = new List<SelectListItem>();
                for (int i = 0; i <= ds5.Tables[0].Rows.Count - 1; i++)
                {
                    string PN = SecurityManager.Decrypt(ds5.Tables[0].Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(ds5.Tables[0].Rows[i]["L_Name"].ToString());
                    string value = SecurityManager.Decrypt(ds5.Tables[0].Rows[i]["U_Id"].ToString());
                   Physician.Add(new SelectListItem { Text = PN, Value = value });
                }
                ViewData["Physician"] = Physician;
                
                List<SelectListItem> PhysicianTherapist = new List<SelectListItem>();
                for (int i = 0; i <= ds6.Tables[0].Rows.Count - 1; i++)
                {
                    string PN = SecurityManager.Decrypt(ds6.Tables[0].Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(ds6.Tables[0].Rows[i]["L_Name"].ToString());
                    string value = SecurityManager.Decrypt(ds6.Tables[0].Rows[i]["U_Id"].ToString());
                   PhysicianTherapist.Add(new SelectListItem { Text = PN, Value = value });
                }
                ViewData["PhysicianTherapist"] = PhysicianTherapist;

            }

            if (ds3.Tables[0].Rows.Count != 0)
            {
               
                Womac.PatientId = SecurityManager.Decrypt(ds3.Tables[0].Rows[0]["U_Id"].ToString());
              
                string Name = SecurityManager.Decrypt(ds3.Tables[0].Rows[0]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(ds3.Tables[0].Rows[0]["L_Name"].ToString());
                Womac.PatientName = Name;

                if (!String.IsNullOrEmpty(ds3.Tables[0].Rows[0]["DOB"].ToString()))
                {
                    Womac.DOB = Convert.ToDateTime(ds3.Tables[0].Rows[0]["DOB"].ToString()).ToString("MMM-dd-yyyy");
                }

                Womac.FacilityId = Convert.ToInt32(ds3.Tables[0].Rows[0]["FacilityId"].ToString());
                int Fid = Convert.ToInt32(ds3.Tables[0].Rows[0]["FacilityId"].ToString());
                DataTable data = ob.GetFacilityLocationName(Fid);
                if (data.Rows.Count > 0)
                {
                    Womac.FacilityName = data.Rows[0]["Location"].ToString();
                }
                    Womac.Knee = Knee;
                
            }
            if (dss.Tables[0].Rows.Count != 0)
            {
                Womac.WomacDate = Convert.ToDateTime(dss.Tables[0].Rows[0]["WOMAC_TestOn"].ToString()).ToString("MMMM-dd-yyyy");
                Womac.Knee = dss.Tables[0].Rows[0]["Knee"].ToString();

                for (int i = 0; i < dss.Tables[0].Rows.Count; i=i+2)
                {
                    int Counter = 1;
                    DataTable dt = new DataTable();
                    string Question = null;
                    var userlist = dss.Tables[0].Rows[i]["Answer"].ToString();
                    var Rightlist = dss.Tables[0].Rows[i + 1]["Answer"].ToString();
                   // var Rightlist = dss.Tables[0].Rows[i]["Answer"].ToString();
                    var allids = userlist;
                    var RightAllids = Rightlist;
                    string[] useridlist = allids.Split(',');
                    string[] rightuseridlist = RightAllids.Split(',');
                    var Q = dss.Tables[0].Rows[i]["Disease_DetailId"].ToString();
                    var allQ = Q;
                    string[] Qidlist = allQ.Split(',');


                    //dss1 = ob.GetDiseaseList(allQ);      //------------------Get Is Desease List

                    for (int j = 0; j < useridlist.Length; j++)
                    {
                        int QuestionId = Convert.ToInt32(Qidlist[j].ToString());

                        MySqlDataAdapter asd = new MySqlDataAdapter("select * from  diseaselist Where Disease_DetailId='" + QuestionId + "'", obj.con);
                        dt = new DataTable();
                        asd.Fill(dt);

                        if (dt.Rows.Count != 0)
                        {
                            for (int l = 0; l < dt.Rows.Count; l++)
                            {
                                if (Convert.ToInt32(dt.Rows[l]["Disease_DetailId"].ToString()) == QuestionId)
                                {
                                    Question = dt.Rows[l]["DiseaseName"].ToString();
                                }
                            }
                        }

                        bool Leftnone = false, Leftslight = false, Leftmoderate = false, Leftsevere = false, Leftextreme = false;
                        bool Rightnone = false, Rightslight = false, Rightmoderate = false, Rightsevere = false, Rightextreme = false;
                        int k = Convert.ToInt32(useridlist[j].ToString());
                        int m = Convert.ToInt32(rightuseridlist[j].ToString());
                        Leftnone = k == 0 ? true : false;
                        Leftslight = k == 1 ? true : false;
                        Leftmoderate = k == 2 ? true : false;
                        Leftsevere = k == 3 ? true : false;
                        Leftextreme = k == 4 ? true : false;
                        Rightnone = m == 0 ? true : false;
                        Rightslight = m == 1 ? true : false;
                        Rightmoderate = m == 2 ? true : false;
                        Rightsevere = m == 3 ? true : false;
                        Rightextreme = m == 4 ? true : false;



                        Session["DiseaseTypeId"] = dds1.Tables[0].Rows[i]["DiseaseId"].ToString();
                        ViewBag.QuestionType = dds1.Tables[0].Rows[i]["DiseasesType"].ToString();

                        var Query = new WomacTestBoth
                        {
                            ID = Convert.ToInt32(dt.Rows[0]["Disease_DetailId"].ToString()),
                            QuestionTypeId = Convert.ToInt32(dt.Rows[0]["DiseaseId"].ToString()),
                            QuestionValue = Counter.ToString() + "." + dt.Rows[0]["DiseaseName"].ToString()
                        };
                                                
                        Session.Remove("save");
                        Session["save"] = "save";
                        if (Convert.ToBoolean(dss.Tables[0].Rows[0]["Complete"].ToString()) == true)
                        {
                            Session["WomacComplete"] = "True";
                            Query.Answers1.Add(new Answer { ID = i.ToString() + "Leftnone", AnswerText = "(0)", AnswerValue = 0, IsChecked = Leftnone, Disabled = true });
                            Query.Answers1.Add(new Answer { ID = i.ToString() + "Leftslight", AnswerText = "(1)", AnswerValue = 1, IsChecked = Leftslight, Disabled = true });
                            Query.Answers1.Add(new Answer { ID = i.ToString() + "Leftmoderate", AnswerText = "(2)", AnswerValue = 2, IsChecked = Leftmoderate, Disabled = true });
                            Query.Answers1.Add(new Answer { ID = i.ToString() + "Leftsevere", AnswerText = "(3)", AnswerValue = 3, IsChecked = Leftsevere, Disabled = true });
                            Query.Answers1.Add(new Answer { ID = i.ToString() + "Leftextreme", AnswerText = "(4)", AnswerValue = 4, IsChecked = Leftextreme, Disabled = true });
                            Query.Answers2.Add(new Answer { ID = i.ToString() + "Rightnone", AnswerText = "(0)", AnswerValue = 0, IsChecked = Rightnone, Disabled = true });
                            Query.Answers2.Add(new Answer { ID = i.ToString() + "Rightslight", AnswerText = "(1)", AnswerValue = 1, IsChecked = Rightslight, Disabled = true });
                            Query.Answers2.Add(new Answer { ID = i.ToString() + "Rightmoderate", AnswerText = "(2)", AnswerValue = 2, IsChecked = Rightmoderate, Disabled = true });
                            Query.Answers2.Add(new Answer { ID = i.ToString() + "Rightsevere", AnswerText = "(3)", AnswerValue = 3, IsChecked = Rightsevere, Disabled = true });
                            Query.Answers2.Add(new Answer { ID = i.ToString() + "Rightextreme", AnswerText = "(4)", AnswerValue = 4, IsChecked = Rightextreme, Disabled = true });
                        }
                        else if (Convert.ToBoolean(dss.Tables[0].Rows[0]["Complete"].ToString()) == false)
                        {
                            Session["WomacComplete"] = "False";
                            Query.Answers1.Add(new Answer { ID = i.ToString() + "Leftnone", AnswerText = "(0)", AnswerValue = 0, IsChecked = Leftnone, Disabled = false });
                            Query.Answers1.Add(new Answer { ID = i.ToString() + "Leftslight", AnswerText = "(1)", AnswerValue = 1, IsChecked = Leftslight, Disabled = false });
                            Query.Answers1.Add(new Answer { ID = i.ToString() + "Leftmoderate", AnswerText = "(2)", AnswerValue = 2, IsChecked = Leftmoderate, Disabled = false });
                            Query.Answers1.Add(new Answer { ID = i.ToString() + "Leftsevere", AnswerText = "(3)", AnswerValue = 3, IsChecked = Leftsevere, Disabled = false });
                            Query.Answers1.Add(new Answer { ID = i.ToString() + "Leftextreme", AnswerText = "(4)", AnswerValue = 4, IsChecked = Leftextreme, Disabled = false });
                            Query.Answers2.Add(new Answer { ID = i.ToString() + "Rightnone", AnswerText = "(0)", AnswerValue = 0, IsChecked = Rightnone, Disabled = false });
                            Query.Answers2.Add(new Answer { ID = i.ToString() + "Rightslight", AnswerText = "(1)", AnswerValue = 1, IsChecked = Rightslight, Disabled = false });
                            Query.Answers2.Add(new Answer { ID = i.ToString() + "Rightmoderate", AnswerText = "(2)", AnswerValue = 2, IsChecked = Rightmoderate, Disabled = false });
                            Query.Answers2.Add(new Answer { ID = i.ToString() + "Rightsevere", AnswerText = "(3)", AnswerValue = 3, IsChecked = Rightsevere, Disabled = false });
                            Query.Answers2.Add(new Answer { ID = i.ToString() + "Rightextreme", AnswerText = "(4)", AnswerValue = 4, IsChecked = Rightextreme, Disabled = false });
                        }

                       

                        if (Convert.ToInt32(dss.Tables[0].Rows[i][0].ToString()) == 1)
                        {
                            Counter = Counter + 1;
                            Womac.WomacTests1.Add(Query);
                        }
                        else if (Convert.ToInt32(dss.Tables[0].Rows[i][0].ToString()) == 2)
                        {
                            Counter = Counter + 1;
                            Womac.WomacTests2.Add(Query);
                        }
                        else if (Convert.ToInt32(dss.Tables[0].Rows[i][0].ToString()) == 3)
                        {
                            Counter = Counter + 1;
                            Womac.WomacTests3.Add(Query);
                        }
                    }
                }
            }
          
            else
            {
                Session.Remove("save");
                Session["WomacComplete"] = "False";
                if (dds1.Tables[0].Rows.Count != 0)
                {
                    Womac.WomacDate = DateTime.Now.ToString("MMM-dd-yyyy");
                    int Counter = 1;
                    for (int i = 0; i < dds1.Tables[0].Rows.Count; i++)
                    {
                        Session["DiseaseTypeId"] = dds1.Tables[0].Rows[i]["DiseaseId"].ToString();
                        ViewBag.QuestionType = dds1.Tables[0].Rows[i]["DiseasesType"].ToString();

                        var Query = new WomacTestBoth
                        {
                            ID = Convert.ToInt32(dds1.Tables[0].Rows[i]["Disease_DetailId"].ToString()),
                            QuestionTypeId = Convert.ToInt32(dds1.Tables[0].Rows[i]["DiseaseId"].ToString()),
                            QuestionValue = Counter.ToString() + "." + dds1.Tables[0].Rows[i]["DiseaseName"].ToString()
                        };
                        
                        Query.Answers1.Add(new Answer { ID = i.ToString() + "Leftnone", AnswerText = "(0)", AnswerValue = 0, IsChecked = true, Disabled = false });
                        Query.Answers1.Add(new Answer { ID = i.ToString() + "Leftslight", AnswerText = "(1)", AnswerValue = 1, IsChecked = false, Disabled = false });
                        Query.Answers1.Add(new Answer { ID = i.ToString() + "Leftmoderate", AnswerText = "(2)", AnswerValue = 2, IsChecked = false, Disabled = false });
                        Query.Answers1.Add(new Answer { ID = i.ToString() + "Leftsevere", AnswerText = "(3)", AnswerValue = 3, IsChecked = false, Disabled = false });
                        Query.Answers1.Add(new Answer { ID = i.ToString() + "Leftextreme", AnswerText = "(4)", AnswerValue = 4, IsChecked = false, Disabled = false });

                        Query.Answers2.Add(new Answer { ID = i.ToString() + "Rightnone", AnswerText = "(0)", AnswerValue = 0, IsChecked = true, Disabled = false });
                        Query.Answers2.Add(new Answer { ID = i.ToString() + "Rightslight", AnswerText = "(1)", AnswerValue = 1, IsChecked = false, Disabled = false });
                        Query.Answers2.Add(new Answer { ID = i.ToString() + "Rightmoderate", AnswerText = "(2)", AnswerValue = 2, IsChecked = false, Disabled = false });
                        Query.Answers2.Add(new Answer { ID = i.ToString() + "Rightsevere", AnswerText = "(3)", AnswerValue = 3, IsChecked = false, Disabled = false });
                        Query.Answers2.Add(new Answer { ID = i.ToString() + "Rightextreme", AnswerText = "(4)", AnswerValue = 4, IsChecked = false, Disabled = false });

                       
                        if (Convert.ToInt32(dds1.Tables[0].Rows[i][0].ToString()) == 1)
                        {
                            Counter = Counter + 1;
                            Womac.WomacTests1.Add(Query);
                        }
                        else if (Convert.ToInt32(dds1.Tables[0].Rows[i][0].ToString()) == 2)
                        {
                            Counter = Counter + 1;
                            Womac.WomacTests2.Add(Query);
                        }
                        else if (Convert.ToInt32(dds1.Tables[0].Rows[i][0].ToString()) == 3)
                        {
                            Counter = Counter + 1;
                            Womac.WomacTests3.Add(Query);
                        }
                    }
                }
            }
            return Womac;
        }

        [HttpPost]
        public ActionResult BothKneeWomac(WomacBoth model)
        {
            int SessionState = CheckSession(1);
            if (SessionState == 1)
            {
                if (ModelState.IsValid)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    
                    string Pid = Session["UserId"].ToString() != null ? Session["UserId"].ToString() : "0";
                    string PatientId = SecurityManager.Encrypt(Pid);
                    Connection.PatientId = PatientId;


                    BothKneeWomacTestCalPostBoth(model, 1);//WomacTestId=1 


                    if (LUTypeId != 10) //PatientId=10 as on date Feb-23-2015
                    {
                        return RedirectToAction("Dashboard_A", "AdminDeshboard");
                    }
                    else
                    {
                        return RedirectToAction("PatientIndex", "PatientDeshboard");
                        //return RedirectToAction("BothKneeWomac", "Womac");
                    }

                }
                Session.Remove("DiseaseTypeId");
                return RedirectToAction("BothKneeWomac", "Womac");
            }
            else
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        private int BothKneeWomacAnswer(string selectedAnswer)
        {
            int AnswerValue = 0;
            if (selectedAnswer.ToLower() == "(0)".ToLower()) { AnswerValue = 0; }
            else if (selectedAnswer.ToLower() == "(1)".ToLower()) { AnswerValue = 1; }
            else if (selectedAnswer.ToLower() == "(2)".ToLower()) { AnswerValue = 2; }
            else if (selectedAnswer.ToLower() == "(3)".ToLower()) { AnswerValue = 3; }
            else if (selectedAnswer.ToLower() == "(4)".ToLower()) { AnswerValue = 4; }
            return AnswerValue;
        }

        public void BothKneeWomacTestCalPostBoth(WomacBoth model, int WomacidNo)
        {
           
            int AnswerValue1 = 0, AnswerValue2 = 0, QuestionTypeId = 0;
            int tempLoggedinFacilityId = Session["LoggedInFacilityId"].ToString() != "0" ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
              
            int TotalP1 = 0, TotalS1 = 0, TotalPh1 = 0;
            int  TotalP2 = 0, TotalS2 = 0, TotalPh2 = 0;
            for (int i = 1; i <= 3; i++)
            {
                int TotalScore1 = 0;
                int TotalScore2 = 0;

                string Pid = Session["UserId"].ToString() != null ? Session["UserId"].ToString() : "0";
                string UserNameId = "";// Connection.UserId != "0" ? Connection.UserId : SecurityManager.Encrypt(Pid);

                if (model.PatientId == null)
                {
                    UserNameId = Connection.UserId != "0" ? Connection.UserId : SecurityManager.Encrypt(Pid);

                }
                else {

                     UserNameId = model.PatientId;
                }
                //string UserNameId = model.PatientId;

                string QuestionId = null, AnswerId1 = null, AnswerId2 = null;
                if (i == 1)
                {
                    foreach (var Que in model.WomacTests1)
                    {
                        QuestionTypeId = ob.GetQuestionId(Que.ID);
                        QuestionId = (QuestionId == null) ? QuestionId + Que.ID : QuestionId + "," + Que.ID;
                        string selectedAnswer1 = Convert.ToString(Que.SelectedAnswer1);
                        string selectedAnswer2 = Convert.ToString(Que.SelectedAnswer2);
                        AnswerValue1 = (selectedAnswer1 == null) ? 0 : BothKneeWomacAnswer(Convert.ToString(Que.SelectedAnswer1));
                        AnswerValue2 = (selectedAnswer2 == null) ? 0 : BothKneeWomacAnswer(Convert.ToString(Que.SelectedAnswer2));
                        TotalP1 = TotalScore1 = TotalScore1 + AnswerValue1;
                        TotalP2 = TotalScore2 = TotalScore2 + AnswerValue2;
                        AnswerId1 = (AnswerId1 == null) ? AnswerId1 + AnswerValue1 : AnswerId1 + "," + AnswerValue1;
                        AnswerId2 = (AnswerId2 == null) ? AnswerId2 + AnswerValue2 : AnswerId2 + "," + AnswerValue2;
                    }
                }
                else if (i == 2)
                {
                    foreach (var Que in model.WomacTests2)
                    {
                        QuestionTypeId = ob.GetQuestionId(Que.ID);
                        QuestionId = (QuestionId == null) ? QuestionId + Que.ID : QuestionId + "," + Que.ID;
                        string selectedAnswer1 = Convert.ToString(Que.SelectedAnswer1);
                        string selectedAnswer2 = Convert.ToString(Que.SelectedAnswer2);
                        AnswerValue1 = (selectedAnswer1 == null) ? 0 : BothKneeWomacAnswer(Convert.ToString(Que.SelectedAnswer1));
                        AnswerValue2 = (selectedAnswer2 == null) ? 0 : BothKneeWomacAnswer(Convert.ToString(Que.SelectedAnswer2));
                        TotalS1 = TotalScore1 = TotalScore1 + AnswerValue1;
                        TotalS2 = TotalScore2 = TotalScore2 + AnswerValue2;
                        AnswerId1 = (AnswerId1 == null) ? AnswerId1 + AnswerValue1 : AnswerId1 + "," + AnswerValue1;
                        AnswerId2 = (AnswerId2 == null) ? AnswerId2 + AnswerValue2 : AnswerId2 + "," + AnswerValue2;
                    }
                }
                else if (i == 3)
                {
                    foreach (var Que in model.WomacTests3)
                    {
                        QuestionTypeId = ob.GetQuestionId(Que.ID);
                        QuestionId = (QuestionId == null) ? QuestionId + Que.ID : QuestionId + "," + Que.ID;
                        string selectedAnswer1 = Convert.ToString(Que.SelectedAnswer1);
                        string selectedAnswer2 = Convert.ToString(Que.SelectedAnswer2);
                        AnswerValue1 = (selectedAnswer1 == null) ? 0 : BothKneeWomacAnswer(Convert.ToString(Que.SelectedAnswer1));
                        AnswerValue2 = (selectedAnswer2 == null) ? 0 : BothKneeWomacAnswer(Convert.ToString(Que.SelectedAnswer2));
                        TotalPh1 = TotalScore1 = TotalScore1 + AnswerValue1;
                        TotalPh2 = TotalScore2 = TotalScore2 + AnswerValue2;
                        AnswerId1 = (AnswerId1 == null) ? AnswerId1 + AnswerValue1 : AnswerId1 + "," + AnswerValue1;
                        AnswerId2 = (AnswerId2 == null) ? AnswerId2 + AnswerValue2 : AnswerId2 + "," + AnswerValue2;
                    }
                }
                DateTime LoginDate = DateTime.Parse(DateTime.Now.ToString());
                string logindate = Convert.ToDateTime(model.WomacDate).ToString("yyyy-MM-dd hh:mm:ss");
                DateTime NextWomac = DateTime.Parse((Convert.ToDateTime(model.WomacDate).AddDays(15).ToShortDateString()));

                if (QuestionId != null && AnswerId1 != null)
                {
                    int womacid = 0;
                    // Save the data 
                    string KneeName = "Left Knee";
                    MySqlCommand cmd = new MySqlCommand("select IFNULL(WOMAC_Id, '' ) AS WOMAC_Id,IFNULL(PatientId, '' ) AS PatientId ,IFNULL(Disease_DetailId, '') AS Disease_DetailId,IFNULL(Answer, '') AS Answer,IFNULL(FacilityId, '') AS FacilityId from womac_test where PatientId='" +SecurityManager.Encrypt(UserNameId) + "' and WOMAC_Name='" + WomacidNo + "' and KneeTestTo='" + KneeName + "' and DieaseId='" + QuestionTypeId + "'", obj.con);
                    MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    asd.Fill(dt);
                    if (dt.Rows.Count == 0)
                    {
                        //DateTime LoginDate = DateTime.Parse(DateTime.Now.ToString());
                        //DateTime NextWomac = DateTime.Parse(DateTime.Now.AddDays(15).ToShortDateString());

                        string QueryStr = @"insert into womac_test (PatientId,FacilityId,DieaseId,Disease_DetailId,TotalScore,Knee,KneeTestTo,WOMAC_TestOn,WOMAC_Name,WOMAC_NexttestOn,Complete,Answer)  
                        values ('" + SecurityManager.Encrypt(UserNameId) + "','" + tempLoggedinFacilityId + "','" + QuestionTypeId + "','" + QuestionId + "','" + TotalScore1 + "','" + model.Knee + "','" + KneeName + "','" + logindate + "','" + WomacidNo + "','" + Convert.ToDateTime(NextWomac).ToString("yyyy-MM-dd hh:mm:ss") + "','" + false + "','" + AnswerId1 + "')";

                        MySqlCommand cmd1 = new MySqlCommand(QueryStr, obj.con);
                        obj.OpenDbConnection();
                        cmd1.ExecuteNonQuery();
                        obj.CloseDbConnection();

                    }
                    else
                    {
                        womacid =Convert.ToInt32(dt.Rows[0]["WOMAC_Id"].ToString());
                        var tr = "True";
                        //DateTime LoginDate = DateTime.Parse(DateTime.Now.ToString());
                        //DateTime NextWomac = DateTime.Parse(DateTime.Now.AddDays(15).ToShortDateString());

                        string QueryStr = @"update womac_test set FacilityId='" + tempLoggedinFacilityId + "',Disease_DetailId='" + QuestionId + "',TotalScore='" + TotalScore1 + "',KneeTestTo='" + KneeName + "',WOMAC_TestOn='" + logindate + "',WOMAC_NexttestOn='" + Convert.ToDateTime(NextWomac).ToString("yyyy-MM-dd hh:mm:ss") + "',Complete='" + tr + "',Answer='" + AnswerId1 + "' where  WOMAC_Id='" + womacid + "'";                   
                        MySqlCommand cmd1 = new MySqlCommand(QueryStr, obj.con);
                        obj.OpenDbConnection();
                        cmd1.ExecuteNonQuery();
                        obj.CloseDbConnection();
                    
                    
                    }
                }

                if (QuestionId != null && AnswerId2 != null)
                {
                    // Save the data 
                    int womacid = 0;
                    string KneeName = "Right Knee";
                    MySqlCommand cmd = new MySqlCommand("select IFNULL(WOMAC_Id, '' ) AS WOMAC_Id,IFNULL(PatientId, '' ) AS PatientId,IFNULL(Disease_DetailId, '') AS Disease_DetailId,IFNULL(Answer, '') AS Answer,IFNULL(FacilityId, '') AS FacilityId from womac_test where PatientId='" +SecurityManager.Encrypt(UserNameId) + "' and WOMAC_Name='" + WomacidNo + "' and KneeTestTo='" + KneeName + "' and DieaseId='" + QuestionTypeId + "' ", obj.con);
                    MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    asd.Fill(dt);
                    if (dt.Rows.Count == 0)
                    {
                        //DateTime LoginDate = DateTime.Parse(DateTime.Now.ToString());
                        //DateTime NextWomac = DateTime.Parse(DateTime.Now.AddDays(15).ToShortDateString());

                        string QueryStr = @"insert into womac_test (PatientId,FacilityId,DieaseId,Disease_DetailId,TotalScore,Knee,KneeTestTo,WOMAC_TestOn,WOMAC_Name,WOMAC_NexttestOn,Complete,Answer)  
                        values ('" + SecurityManager.Encrypt(UserNameId) + "','" + tempLoggedinFacilityId + "','" + QuestionTypeId + "','" + QuestionId + "','" + TotalScore2 + "','" + model.Knee + "','" + KneeName + "','" + logindate + "','" + WomacidNo + "','" + Convert.ToDateTime(NextWomac).ToString("yyyy-MM-dd hh:mm:ss") + "','" + false + "','" + AnswerId2 + "')";

                        MySqlCommand cmd1 = new MySqlCommand(QueryStr, obj.con);
                        obj.OpenDbConnection();
                        cmd1.ExecuteNonQuery();
                        obj.CloseDbConnection();
                    }
                    else
                    {
                        womacid = Convert.ToInt32(dt.Rows[0]["WOMAC_Id"].ToString());
                        var tr = "True";
                        //DateTime LoginDate = DateTime.Parse(DateTime.Now.ToString());
                        //DateTime NextWomac = DateTime.Parse(DateTime.Now.AddDays(15).ToShortDateString());

                        string QueryStr = @"update womac_test set FacilityId='" + tempLoggedinFacilityId + "',Disease_DetailId='" + QuestionId + "',TotalScore='" + TotalScore2 + "',KneeTestTo='" + KneeName + "',WOMAC_TestOn='" + logindate + "',WOMAC_NexttestOn='" + Convert.ToDateTime(NextWomac).ToString("yyyy-MM-dd hh:mm:ss") + "',Complete='" + tr + "',Answer='" + AnswerId2 + "' where  WOMAC_Id='" + womacid + "'";
                        MySqlCommand cmd1 = new MySqlCommand(QueryStr, obj.con);
                        obj.OpenDbConnection();
                        cmd1.ExecuteNonQuery();
                        obj.CloseDbConnection();
                    
                    }
                }
            }
        }

       // ----------------------------------------Get Womac Information Single Knee
       
        [HttpGet]
        public ActionResult PatientDetailedInformation(string PatientId, int WomacId, string Knee, string viewed = "")
        {
            ViewBag.back = viewed;
          //  string pass = SecurityManager.Decrypt("3+cMg1E30d8YsE8t/kRNzw==");
            if (PatientId == null)
            {

            }
            else
            {
                PatientId = PatientId.Replace(" ","+");
            }
            try
            {
                Session["PatientId"] = PatientId;
                Session["WomacId"] = WomacId;
                Session["Knee"] = Knee;
              //  string va = SecurityManager.Decrypt("3+cMg1E30d8YsE8t/kRNzw==");
                string UserID =SecurityManager.Decrypt(PatientId.ToString());
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    string Pid;
                    int WId = WomacId;
                    Pid = PatientId.ToString();
                    Connection.PatientId = PatientId.ToString();
                    WId = Convert.ToInt16(WomacId);
                    ViewBag.WomacTestId = WId;
                    ViewBag.PatientId = Pid;
                    //ViewBag.CurrentDate = Connection.LoginDate.ToString("MMM-dd-yyyy");
                    //DateTime LoginDate = DateTime.Parse(DateTime.Now.ToString());
                    ViewBag.CurrentDate = DateTime.Parse(DateTime.Now.ToString());
                    Connection.WomacTestId = WId;
                    Connection.UserId = Pid;

                    var tupleModel = new Tuple<PatientRegistration, Womac1, PhysicalTherapyDetail>(UserDetail(Pid, WId), SingleKneeWomacTestCalGet(Pid, Knee, WId), GetPatientPTDetail(Pid.ToString(), Convert.ToInt16(WId), Knee));
                   
                    ViewBag.FacilityName = Connection.FacilityName;
                    return View(tupleModel);
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

        private PatientRegistration UserDetail(string PatientId, int WomacId)
        {
            //---single knee
            PatientId = PatientId.Replace(" ","+");
            DataSet ds1 = ob.GetPhysicainList();
            DataSet ds2 = ob.GetPhysicianTherapist();
          
            DataSet ds3 = ob.GetUserData(PatientId);
            DataSet ds4 = ob.GetPatientInfo(PatientId);


            PatientRegistration PR = new PatientRegistration();

            if (ds3.Tables[0].Rows.Count != 0)
            {
                PR.PatientId = ds3.Tables[0].Rows[0]["U_Id"].ToString();
                string PN =SecurityManager.Decrypt(ds3.Tables[0].Rows[0]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(ds3.Tables[0].Rows[0]["L_Name"].ToString());
                PR.FirstName = PN;
                if(!String.IsNullOrEmpty(ds3.Tables[0].Rows[0]["U_Id"].ToString()))
                {
                 PR.Soc_Security =SecurityManager.Decrypt(ds3.Tables[0].Rows[0]["U_Id"].ToString());              
                }
                 PR.BirthDate = !String.IsNullOrEmpty(ds3.Tables[0].Rows[0]["DOB"].ToString()) ? Convert.ToDateTime(ds3.Tables[0].Rows[0]["DOB"].ToString()).ToString("MMM-dd-yyyy") : "";
                Connection.BirthDate = PR.BirthDate;

                if (ds3.Tables[0].Rows[0]["EthnicityId"].ToString() != "")
                {
                    int EthnicityId = Convert.ToInt16(ds3.Tables[0].Rows[0]["EthnicityId"].ToString());

                    DataSet dst = ob.GetEthnicityName(EthnicityId);
                    PR.EthnicityName = dst.Tables[0].Rows[0]["Ethnicity_Name"].ToString();
                }
                else
                {
                    PR.EthnicityId = "0";
                }
            }
            if (ds4.Tables[0].Rows.Count > 0)
            {
                PR.Height = !String.IsNullOrEmpty(ds4.Tables[0].Rows[0]["Height"].ToString()) ? ds4.Tables[0].Rows[0]["Height"].ToString() : "0";
                PR.Weight = Convert.ToInt16(ds4.Tables[0].Rows[0]["Weight"].ToString());
                if (ds4.Tables[0].Rows[0]["Edu_Id"].ToString() != "")
                {
                    PR.EduId = ds4.Tables[0].Rows[0]["Edu_Id"].ToString();
                }
                else
                {
                    PR.EduId = "0";
                }
                PR.WorkType = ds4.Tables[0].Rows[0]["WorkType"].ToString();

                PR.BMI = !String.IsNullOrEmpty(ds4.Tables[0].Rows[0]["BMI"].ToString()) ? float.Parse(ds4.Tables[0].Rows[0]["BMI"].ToString()) : 0;
                PR.WheelChair = ds4.Tables[0].Rows[0]["WheelChair"].ToString().Trim();
            }
            else {
                PR.BMI = 0;
                PR.EduId = "0";
                PR.WorkType = "";
                PR.Height = "0";
                PR.Weight = 0;
            }
            return PR;
        }

        public PhysicalTherapyDetail GetPatientPTDetail(string PatientId, int WomacId, string Knee)
        {
            Session["pidboth"] = PatientId;
            Session["wid"] = WomacId;
            Session["kn"] = Knee;
            PhysicalTherapyDetail PR = new PhysicalTherapyDetail();
            try
            {
                PR.PatientId = PatientId.ToString();
                PR.WomacTestId = WomacId;
                PR.Knee = Knee;
                
                DataTable dt1 = ob.GetPatientTheripyDetail(PR.PatientId, PR.WomacTestId, PR.Knee);
              
                if (dt1.Rows.Count != 0)
                {
                    string  physicantherepist="";
                    PR.PhysicianName =SecurityManager.Decrypt((dt1.Rows[0]["Physician"].ToString()));
                    PR.Phy_TherapistName =SecurityManager.Decrypt((dt1.Rows[0]["PhysicianTherapist"].ToString()));
                    physicantherepist = dt1.Rows[0]["IsPhysicalTherapist"].ToString();
                    if (physicantherepist == "1")
                    {
                        PR.Phy_Therapy = "Yes";
                    }
                    else {
                        PR.Phy_Therapy = "No";
                    }
                   // PR.Phy_Therapy = dt1.Rows[0]["IsPhysicalTherapist"].ToString();

                    PR.Phy_Therapy_Date = Convert.ToDateTime(dt1.Rows[0]["TheraphyOn"]).ToString("MMM-dd-yyyy");
                    PR.AgeOnDate = ob.AgeCalculator(Convert.ToDateTime(Connection.BirthDate));
                    PR.Injected = dt1.Rows[0]["Injected"].ToString();
                    string knee = dt1.Rows[0]["Knee"].ToString();
                    string InjectionNo = (dt1.Rows[0]["Kellgren_gread"].ToString());
                    if (knee == "Left Knee,Right Knee")
                    {
                        string[] injecton = InjectionNo.Split(',');
                        PR.OsteoarthritisFirstKnee = injecton[0].ToString();
                        PR.OsteoarthritisSecondKnee = injecton[1].ToString();
                    }
                    else
                    {
                        PR.InjectionNomber = dt1.Rows[0]["Kellgren_gread"].ToString();
                    }
                }
                else
                {
                    string  no = "0";
                    PR.Phy_Therapy = "No";
                    PR.Phy_Therapy_Date = DateTime.Now.ToString("MMM-dd-yyyy");
                    PR.AgeOnDate = ob.AgeCalculator(Convert.ToDateTime(Connection.BirthDate));
                    PR.Injected = "No";
                    if (Knee == "Left Knee,Right Knee")
                    {
                        PR.OsteoarthritisFirstKnee = no;
                        PR.OsteoarthritisSecondKnee = no;
                    }
                    else
                    {
                         PR.InjectionNomber =no;
                    }

                  
                }
            }
            catch (Exception e)
            {
            }
            return PR;
        }

        //---------------------------------------- Post Womac Information Single Knee

        [HttpPost]
        public ActionResult PatientDetailedInformation(string PatientId, int WomacId, string Knee, [Bind(Prefix = "Item1")] PatientRegistration model1, [Bind(Prefix = "Item2")] Womac1 model, [Bind(Prefix = "Item3")] PhysicalTherapyDetail model3, FormCollection Form)
        {
            if (PatientId == null)
            {

            }
            else
            {
                PatientId = PatientId.Replace(" ", "+");
            }
                string UserId = "";
            try
            {
                var saveType = Form["SaveType"];
               
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    //User Logged Detail Start

                    string UserNameId = Session["LoginUserId"].ToString() != null ? Session["LoginUserId"].ToString() : Session["UserNameId"].ToString();                                       
                    UserLogDetail ULD = new UserLogDetail();
                    ULD.UserTypeId =Convert.ToInt16(Session["UserTypeId"].ToString()!=""?Convert.ToInt16(Session["UserTypeId"].ToString()):0);
                    ULD.UserId = SecurityManager.Encrypt(UserNameId);
                    ULD.ViewName = "Patient/PatientDetailedinformation";
                    ULD.OperationName = "Save/Update";
                    ULD.ModifiedRecord = model1.FirstName;

                    //User Logged Detail End

                    if (saveType.ToLower() == "")
                    {
         
                        Connection.UserId = PatientId;
                        UserId = PatientId.ToString();
                        PatientPhysicalTherapyInfo(model3, WomacId);
                        model.Knee = Knee;
                        string kneename = Knee;
                        if (WomacId == 1)
                        {
                            SingleKneeWomacTestCalPost(model, 1);
                        }
                        else if (WomacId == 2)
                        {
                            SingleKneeWomacTestCalPost(model, 2);
                        }
                        else if (WomacId == 3)
                        {
                            SingleKneeWomacTestCalPost(model, 3);
                            UpdatePatientStatus(PatientId,model.WomacDate);
                        }
                        PatientPhysicalTherapyInfo(model3, WomacId);
                        ULD.Detail = "Womac-" + WomacId + " Record Detail Save/Update Successfully!";
                        ULD.DetailForUserView = "Womac-" + WomacId + "  Record Detail Saved/Update Successfully!";                            
                    }
                    else if (saveType.ToLower() == "complete")
                    {
                        if (WomacId == 1)
                        {
                            SingleKneeWomacTestCalPost(model, 1);
                        }
                        else if (WomacId == 2)
                        {
                            SingleKneeWomacTestCalPost(model, 2);
                        }
                        else if (WomacId == 3)
                        {
                            SingleKneeWomacTestCalPost(model, 3);
                        }


                        
                        PatientPhysicalTherapyInfo(model3, WomacId);
                        WomactestComplete(PatientId, WomacId, Knee, model3);
                        ULD.Detail = "Womac-" + WomacId + "  Record Detail Save/Update with Complete Successfully!";
                        ULD.DetailForUserView = "Womac-" + WomacId + "  Record Detail Saved/Update with Complete Successfully!";
                    }
                    int SuccessId1 = AdminClass.UserLogDetail(ULD);       // User Log Details Insert

                 
                    //  return RedirectToAction("PatientIndex", "PatientDeshboard", new { PatientId, WomacId, Knee });
                    return RedirectToAction("PatientDetailedInformation", "Womac", new { PatientId, WomacId, Knee });
                }

                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }

            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin", new { param = "User Platform Setting" });
            }
        }

        public void UpdatePatientStatus(string patientid,string womacdate)
        {
            try
            {
                updateAlertstatus(patientid,womacdate);
                string patientidd = SecurityManager.Encrypt(patientid).ToString();
                string status = null;
                bool reactive = false, inactive = true;
                int deactive = 0;
                string query = "select Complete from womac_test where PatientId='" + patientidd + "' and WOMAC_Name='" + 3 + "'";
                MySqlCommand cmd = new MySqlCommand(query, obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    status = dt.Rows[0]["Complete"].ToString();
                }
                if (status == "True")
                {
                    string query1 = "update userregister set IsActive=@IsActive,Is_Reactive=@Is_Reactive, Inactive=@Inactive,InactiveDate=@inactivedate where U_Id=@U_Id";
                    string query6 = "update  `patient_otherinfo` set `IsDeactive`= '" + deactive + "' where PatientId=@U_Id";
             
                    MySqlCommand cmd1 = new MySqlCommand(query1, obj.con);
                    MySqlCommand cmd6 = new MySqlCommand(query6,obj.con);
                    cmd1.Parameters.AddWithValue("@IsActive", inactive);
                    cmd1.Parameters.AddWithValue("@Is_Reactive", reactive);
                    cmd1.Parameters.AddWithValue("@Inactive", inactive);
                    cmd1.Parameters.AddWithValue("@inactivedate",Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss tt")));
                    cmd1.Parameters.AddWithValue("@U_Id", SecurityManager.Encrypt(patientid).ToString());
                    cmd6.Parameters.AddWithValue("@U_Id", SecurityManager.Encrypt(patientid).ToString());
               
                    if (obj.con.State == ConnectionState.Closed)
                    {
                        obj.OpenDbConnection();
                    }
                    int success = cmd1.ExecuteNonQuery();
                        success = cmd6.ExecuteNonQuery();
                    if (obj.con.State == ConnectionState.Open)
                    {
                        obj.CloseDbConnection();
                    }
                    if (success == 1)
                    {
                        try
                        {
                            string body = "This is first alert.";
                            string query3 = "select body,alert_day_id from alert_update_tbl where patient_id='" + SecurityManager.Encrypt(patientid) + "' and alert_day_id='" + 1 + "'";
                            MySqlCommand cmd3 = new MySqlCommand(query3, obj.con);
                            MySqlDataAdapter da3 = new MySqlDataAdapter(cmd3);
                            DataTable dt1 = new DataTable();
                            da3.Fill(dt1);
                            if (dt1.Rows.Count > 0)
                            {
                                string query4 = "update alert_update_tbl set body='" + body + "' where patient_id='" + SecurityManager.Encrypt(patientid) + "' and alert_day_id='" + 1 + "'";
                                MySqlCommand cmd4 = new MySqlCommand(query4, obj.con);
                                if (obj.con.State == ConnectionState.Closed)
                                {
                                    obj.OpenDbConnection();
                                }
                                success = cmd1.ExecuteNonQuery();
                                if (obj.con.State == ConnectionState.Open)
                                {
                                    obj.CloseDbConnection();
                                }
                            }
                            else
                            {
                                string query2 = "insert into alert_update_tbl(patient_id,alert_day_id,body)values('" + SecurityManager.Encrypt(patientid) + "','" + 1 + "','" + body + "')";
                                MySqlCommand cmd2 = new MySqlCommand(query2, obj.con);
                                if (obj.con.State == ConnectionState.Closed)
                                {
                                    obj.OpenDbConnection();
                                }
                                success = cmd2.ExecuteNonQuery();
                                if (obj.con.State == ConnectionState.Open)
                                {
                                    obj.CloseDbConnection();
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            throw;
                        }
                    }
                }  
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public void updateAlertstatus(string patientid,string womacdate)
        {
            try
            {

                string alertstartdate = Convert.ToDateTime(womacdate).ToString("yyyy-MM-dd hh:mm:ss");
                  
                int success = 0;
                string body = "This is First Alert";
                // string patientid = SecurityManager.Encrypt(model.).ToString();
                string query1 = "select * from alert_complete_tbl where patient_id='" + SecurityManager.Encrypt(patientid) + "' and alert_day_id='" +1+ "'";
                MySqlCommand cmd1 = new MySqlCommand(query1, obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd1);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    string query = "update alert_complete_tbl set `note`='" + body + "',Update_Date=@updatedate where patient_id='" + SecurityManager.Encrypt(patientid) + "' and alert_day_id='" + 1 + "'";
                    MySqlCommand cmd = new MySqlCommand(query, obj.con);
                    cmd.Parameters.AddWithValue("@updatedate", alertstartdate);
                    if (obj.con.State == ConnectionState.Closed)
                    {
                        obj.OpenDbConnection();
                    }
                    success = cmd.ExecuteNonQuery();
                    if (obj.con.State == ConnectionState.Open)
                    {
                        obj.CloseDbConnection();
                    }

                }
                else
                {
                    string query = "insert into `alert_complete_tbl`(`patient_id`,`alert_day_id`,`note`,Update_Date)values('" + SecurityManager.Encrypt(patientid) + "','" + 1 + "','" + body + "',@updatedate)";
                    MySqlCommand cmd = new MySqlCommand(query, obj.con);
                    cmd.Parameters.AddWithValue("@updatedate", alertstartdate);
                    if (obj.con.State == ConnectionState.Closed)
                    {
                        obj.OpenDbConnection();
                    }
                    success = cmd.ExecuteNonQuery();
                    if (obj.con.State == ConnectionState.Open)
                    {
                        obj.CloseDbConnection();
                    }
                }
            }
            catch(Exception ex)
            {

            }
        
        
        }

        public void UpdatePatientAlertStatusOnWomacDateChange(string patientid, string womacdate)
        {
            try
            {
                updateAlertstatusOnWomacDateChange(patientid, womacdate);
                string patientidd = SecurityManager.Encrypt(patientid).ToString();
                string status = null;
                bool reactive = false, inactive = true;
                int deactive = 0;
                string query = "select Complete from womac_test where PatientId='" + patientidd + "' and WOMAC_Name='" + 3 + "'";
                MySqlCommand cmd = new MySqlCommand(query, obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    status = dt.Rows[0]["Complete"].ToString();
                }
                if (status == "True")
                {
                    string query1 = "update userregister set IsActive=@IsActive,Is_Reactive=@Is_Reactive, Inactive=@Inactive,InactiveDate=@inactivedate where U_Id=@U_Id";
                    string query6 = "update  `patient_otherinfo` set `IsDeactive`= '" + deactive + "' where PatientId=@U_Id";

                    MySqlCommand cmd1 = new MySqlCommand(query1, obj.con);
                    MySqlCommand cmd6 = new MySqlCommand(query6, obj.con);
                    cmd1.Parameters.AddWithValue("@IsActive", inactive);
                    cmd1.Parameters.AddWithValue("@Is_Reactive", reactive);
                    cmd1.Parameters.AddWithValue("@Inactive", inactive);
                    cmd1.Parameters.AddWithValue("@inactivedate", Convert.ToDateTime(womacdate).ToString("yyyy-MM-dd HH:mm:ss tt"));
                    cmd1.Parameters.AddWithValue("@U_Id", SecurityManager.Encrypt(patientid).ToString());
                    cmd6.Parameters.AddWithValue("@U_Id", SecurityManager.Encrypt(patientid).ToString());

                    if (obj.con.State == ConnectionState.Closed) 
                    {
                        obj.OpenDbConnection();
                    }
                    int success = cmd1.ExecuteNonQuery();
                    success = cmd6.ExecuteNonQuery();
                    if (obj.con.State == ConnectionState.Open)
                    {
                        obj.CloseDbConnection();
                    }
                    if (success == 1)
                    {
                        try
                        {
                            string body = "";
                            int alertdayid = 0;
                            DateTime currentdate = DateTime.Now;
                            DateTime womacdt = Convert.ToDateTime(womacdate);
                            var totalday=(currentdate - womacdt).Days;
                            if (totalday <= 45)
                            {
                                body = "This is first alert.";
                                alertdayid = 1;
                            }
                            else if (totalday <= 90)
                            {
                                body = "This is second alert.";
                                alertdayid = 2;
                            }
                            else if (totalday <= 120)
                            {
                                body = "This is third alert.";
                                alertdayid = 3;
                            }

                            string query3 = "select body,alert_day_id from alert_update_tbl where patient_id='" + SecurityManager.Encrypt(patientid) + "' and alert_day_id='" + alertdayid + "'";
                            MySqlCommand cmd3 = new MySqlCommand(query3, obj.con);
                            MySqlDataAdapter da3 = new MySqlDataAdapter(cmd3);
                            DataTable dt1 = new DataTable();
                            da3.Fill(dt1);
                            if (dt1.Rows.Count > 0)
                            {
                                string query4 = "update alert_update_tbl set body='" + body + "' where patient_id='" + SecurityManager.Encrypt(patientid) + "' and alert_day_id='" + alertdayid + "'";
                                MySqlCommand cmd4 = new MySqlCommand(query4, obj.con);
                                if (obj.con.State == ConnectionState.Closed)
                                {
                                    obj.OpenDbConnection();
                                }
                                success = cmd1.ExecuteNonQuery();
                                if (obj.con.State == ConnectionState.Open)
                                {
                                    obj.CloseDbConnection();
                                }
                            }
                            else
                            {
                                if (alertdayid != 0)
                                {
                                    string query2 = "insert into alert_update_tbl(patient_id,alert_day_id,body)values('" + SecurityManager.Encrypt(patientid) + "','" + alertdayid + "','" + body + "')";
                                    MySqlCommand cmd2 = new MySqlCommand(query2, obj.con);
                                    if (obj.con.State == ConnectionState.Closed)
                                    {
                                        obj.OpenDbConnection();
                                    }
                                    success = cmd2.ExecuteNonQuery();
                                    if (obj.con.State == ConnectionState.Open)
                                    {
                                        obj.CloseDbConnection();
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public void updateAlertstatusOnWomacDateChange(string patientid, string womacdate)
        {
            try
            {

                string alertstartdate = Convert.ToDateTime(womacdate).ToString("yyyy-MM-dd hh:mm:ss");

                int success = 0;
                string body = "";
                int alertdayid = 0;
                DateTime currentdate = DateTime.Now;
                DateTime womacdt = Convert.ToDateTime(womacdate);
                var totalday = (currentdate - womacdt).Days;
                if (totalday <= 45)
                {
                    body = "This is first alert.";
                    alertdayid = 1;
                }
                else if (totalday <= 90)
                {
                    body = "This is second alert.";
                    alertdayid = 2;
                }
                else if (totalday <= 120)
                {
                    body = "This is third alert.";
                    alertdayid = 3;
                }
                // string patientid = SecurityManager.Encrypt(model.).ToString();
                string query1 = "select * from alert_complete_tbl where patient_id='" + SecurityManager.Encrypt(patientid) + "' and IsDeleted!='"+"True"+"'";
                MySqlCommand cmd1 = new MySqlCommand(query1, obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd1);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (obj.con.State == ConnectionState.Closed)
                    {
                        obj.OpenDbConnection();
                    }
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string query = "update alert_complete_tbl set IsDeleted='" + true + "',Update_Date=@updatedate where patient_id='" + SecurityManager.Encrypt(patientid) + "' and id='"+dt.Rows[i][0]+"'";
                        MySqlCommand cmd = new MySqlCommand(query, obj.con);
                        cmd.Parameters.AddWithValue("@updatedate", alertstartdate);
                        success = cmd.ExecuteNonQuery();
                    }
                    if (obj.con.State == ConnectionState.Open)
                    {
                        obj.CloseDbConnection();
                    }

                    string query2 = "insert into `alert_complete_tbl`(`patient_id`,`alert_day_id`,`note`,Update_Date)values('" + SecurityManager.Encrypt(patientid) + "','" + alertdayid + "','" + body + "',@updatedate)";
                    MySqlCommand cmd2 = new MySqlCommand(query2, obj.con);
                    cmd2.Parameters.AddWithValue("@updatedate", alertstartdate);
                    if (obj.con.State == ConnectionState.Closed)
                    {
                        obj.OpenDbConnection();
                    }
                    success = cmd2.ExecuteNonQuery();
                    if (obj.con.State == ConnectionState.Open)
                    {
                        obj.CloseDbConnection();
                    }
                }
                else
                {
                    if (alertdayid != 0)
                    {
                        string query = "insert into `alert_complete_tbl`(`patient_id`,`alert_day_id`,`note`,Update_Date)values('" + SecurityManager.Encrypt(patientid) + "','" + alertdayid + "','" + body + "',@updatedate)";
                        MySqlCommand cmd = new MySqlCommand(query, obj.con);
                        cmd.Parameters.AddWithValue("@updatedate", alertstartdate);
                        if (obj.con.State == ConnectionState.Closed)
                        {
                            obj.OpenDbConnection();
                        }
                        success = cmd.ExecuteNonQuery();
                        if (obj.con.State == ConnectionState.Open)
                        {
                            obj.CloseDbConnection();
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }


        }
        private void WomactestComplete(string PatientId, int WomacId, string Knee, PhysicalTherapyDetail model3)
        {
            try
            {
                var tr = "True";
                int SuccessId = 0;
                MySqlCommand cmd2 = new MySqlCommand("update womac_test set Complete= '" + tr + "' where PatientId='" +SecurityManager.Encrypt( PatientId) + "' and WOMAC_Name='" + WomacId + "' and Knee='" + Knee + "'", obj.con);
                obj.OpenDbConnection();
                SuccessId = cmd2.ExecuteNonQuery();
                obj.CloseDbConnection();
              // PatientPhysicalTherapyInfo(model3, Convert.ToInt32(WomacId));                
            }
            catch (Exception)
            {
            }
        }

        public void PatientPhysicalTherapyInfo(PhysicalTherapyDetail Model, int WomacId)
        {
            try
            {
                int physicalTherepy=0;
                string Kellgren_gread = null;
                if (Model.Phy_Therapy == "Yes")
                {
                    physicalTherepy = 1;
                }
                else {
                    physicalTherepy = 0;
                }
                if (Model.Knee == "Left Knee,Right Knee")
                {
                    Kellgren_gread = Model.OsteoarthritisFirstKnee + "," + Model.OsteoarthritisSecondKnee;
                }
                else {
                    Kellgren_gread = Model.InjectionNomber;
                }
                    int SuccessId = 0;
                    int InjectionNo = ob.GetInjectionNo(Model.PatientId, WomacId, Model.Knee);
                    MySqlCommand cmd = new MySqlCommand("select * from injectiondetails where PatientId='" +SecurityManager.Encrypt(Model.PatientId )+ "' and WOMAC_Name='" + WomacId + "' and Knee='" + Model.Knee + "'", obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count == 0)
                    {
                        // Count How Much Injection take by Patient ...
                        int TeraphyId = dt.Rows.Count != 0 ? Convert.ToInt32(dt.Rows[0][0].ToString()) : 0;
                        MySqlCommand cmd2 = new MySqlCommand("insert into injectiondetails(PatientId,WOMAC_Name,PhysicianTherapist,Physician,IsPhysicalTherapist,Knee,Injected,InjectionNumber,Kellgren_gread,TheraphyOn) values ('" + SecurityManager.Encrypt(Model.PatientId) + "','" + Model.WomacTestId + "','" + SecurityManager.Encrypt(Model.Phy_TherapistName) + "','" + SecurityManager.Encrypt(Model.PhysicianName) + "','" + physicalTherepy + "','" + Model.Knee + "','" + Model.Injected + "','" + InjectionNo + "','" + Kellgren_gread + "','" + Convert.ToDateTime(Model.Phy_Therapy_Date).ToString("yyyy-MM-dd") + "')", obj.con);
                        obj.OpenDbConnection();
                        SuccessId = cmd2.ExecuteNonQuery();
                        obj.CloseDbConnection();
                    }
                    else
                    {
                        int TeraphyId = dt.Rows.Count != 0 ? Convert.ToInt32(dt.Rows[0][0].ToString()) : 0;
                      //  MySqlCommand cmd2 = new MySqlCommand("update injectiondetails set PhysicianTherapist='" + SecurityManager.Encrypt(Model.Phy_TherapistName) + "',Physician='" + SecurityManager.Encrypt(Model.PhysicianName) + "',IsPhysicalTherapist='" + physicalTherepy + "',Injected='" + Model.Injected + "', InjectionNumber='" + injectionNo + "', TheraphyOn= '" + Convert.ToDateTime(Model.Phy_Therapy_Date).ToString("yyyy-MM-dd") + "' where PatientId='" + SecurityManager.Encrypt(Model.PatientId) + "' and WOMAC_Name='" + Model.WomacTestId + "' and Knee='" + Model.Knee + "'", obj.con);
                        MySqlCommand cmd2 = new MySqlCommand("update injectiondetails set PhysicianTherapist='" + SecurityManager.Encrypt(Model.Phy_TherapistName) + "',Physician='" + SecurityManager.Encrypt(Model.PhysicianName) + "',IsPhysicalTherapist='" + physicalTherepy + "',Injected='" + Model.Injected + "', InjectionNumber='" + InjectionNo + "', TheraphyOn= '" + Convert.ToDateTime(Model.Phy_Therapy_Date).ToString("yyyy-MM-dd") + "',Kellgren_gread='" + Kellgren_gread + "' where PatientId='" + SecurityManager.Encrypt(Model.PatientId) + "' and WOMAC_Name='" + Model.WomacTestId + "' and Knee='" + Model.Knee + "'", obj.con);
                     
                        obj.OpenDbConnection();
                        SuccessId = cmd2.ExecuteNonQuery();
                        obj.CloseDbConnection();                       
                    }
                
            }
            catch (Exception e)
            {
            }
        }
       
        //---------------------------------------- Get Patient Info Both Knee

        [HttpGet]
        public ActionResult PatientDetailedinformationBoth(string PatientId, string Knee, int WomacId, string viewed = "")
        {
            ViewBag.back = viewed;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    string Pid;
                    int WId;
                    Pid = PatientId;
                    WId = Convert.ToInt32(WomacId);
                    ViewBag.WomacTestId = WId;
                    ViewBag.PatientId = Pid;
                    ViewBag.CurrentDate = Connection.LoginDate.ToString("MMM-dd-yyyy");
                    ViewBag.FacilityName = Connection.FacilityName;
                    Connection.UserId = Pid;
                    string Patient_Id = PatientId.ToString();
                    var tupleModel = new Tuple<PatientRegistration, WomacBoth, PhysicalTherapyDetail>(UserDetail(Pid, WId), BothKneeWomacTestBothCalGet(Patient_Id, "Left Knee,Right Knee", WId), GetPatientPTDetail(Pid.ToString(), WId, Knee));
                    return View(tupleModel);
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

        [HttpPost]
        public ActionResult PatientDetailedinformationBoth(string PatientId, int WomacId, string Knee, [Bind(Prefix = "Item1")] PatientRegistration model1, [Bind(Prefix = "Item2")] WomacBoth model, [Bind(Prefix = "Item3")] PhysicalTherapyDetail model3, FormCollection Form)
        {
           
            try
            {
                if (PatientId == null)
                { }
                else
                {
                    PatientId = PatientId.Replace(" ", "+");
                    
                }
                var saveType = Form["SaveType"];
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {                    
                    // User Logged Detail Start

                    string UserNameId = Session["LoginUserId"].ToString() != null ? Session["LoginUserId"].ToString() : Session["UserNameId"].ToString();
                    UserLogDetail ULD = new UserLogDetail();
                    ULD.UserTypeId = Convert.ToInt16(Session["UserTypeId"].ToString() != "" ? Convert.ToInt16(Session["UserTypeId"].ToString()) : 0);
                    ULD.UserId = SecurityManager.Encrypt(UserNameId);
                    ULD.ViewName = "Patient/PatientDetailedinformationBoth";
                    ULD.OperationName = "Save/Update";
                    ULD.ModifiedRecord = model1.FirstName;

                    // User Logged Detail End

                    if (saveType.ToLower() == "")
                    {
                        Connection.UserId = PatientId;
                        model.Knee = Knee;
                        PatientPhysicalTherapyInfo(model3, Convert.ToInt32(WomacId));
                        if (WomacId == 1)
                        {
                            BothKneeWomacTestCalPostBoth(model, 1); // WomacTestId=1
                        }
                        else if (WomacId == 2)
                        {
                            BothKneeWomacTestCalPostBoth(model, 2); // WomacTestId=2
                        }
                        else if (WomacId == 3)
                        {
                            BothKneeWomacTestCalPostBoth(model, 3); // WomacTestId=3
                            UpdatePatientStatus(PatientId,model.WomacDate);
                        }
                      
                        ULD.Detail = "Womac-" + WomacId + " Record Detail Save/Update Successfully!";
                        ULD.DetailForUserView = "Womac-" + WomacId + "  Record Detail Saved/Update Successfully!";
                    }
                    else if (saveType.ToLower() == "complete")
                    {

                        if (WomacId == 1)
                        {
                            BothKneeWomacTestCalPostBoth(model, 1); // WomacTestId=1
                        }
                        else if (WomacId == 2)
                        {
                            BothKneeWomacTestCalPostBoth(model, 2); // WomacTestId=2
                        }
                        else if (WomacId == 3)
                        {
                            BothKneeWomacTestCalPostBoth(model, 3); // WomacTestId=3
                        }

                        WomactestComplete(PatientId, WomacId, Knee, model3);
                        PatientPhysicalTherapyInfo(model3, Convert.ToInt32(WomacId));
                        ULD.Detail = "Womac-" + WomacId + "  Record Detail Save/Update with Complete Successfully!";
                        ULD.DetailForUserView = "Womac-" + WomacId + "  Record Detail Saved/Update with Complete Successfully!";
                    }
                    int SuccessId1 = AdminClass.UserLogDetail(ULD); // User Log Details Insert

                    return RedirectToAction("PatientDetailedinformationBoth", "Womac", new { PatientId, WomacId, Knee });
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin", new { param = "User Platform Setting" });
            }
        }
        [HttpGet]
        public ActionResult readPatientDetailedInformation(string PatientId, int WomacId, string Knee, string viewed = "")
        {
            ViewBag.back = viewed;
            try
            {
                Session["PatientId"] = PatientId;
                Session["WomacId"] = WomacId;
                Session["Knee"] = Knee;

                string UserID = SecurityManager.Decrypt(PatientId.ToString());
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    string Pid;
                    int WId = WomacId;
                    Pid = PatientId.ToString();
                    Connection.PatientId = PatientId.ToString();
                    WId = Convert.ToInt16(WomacId);
                    ViewBag.WomacTestId = WId;
                    ViewBag.PatientId = Pid;
                    //ViewBag.CurrentDate = Connection.LoginDate.ToString("MMM-dd-yyyy");
                    //DateTime LoginDate = DateTime.Parse(DateTime.Now.ToString());
                    ViewBag.CurrentDate = DateTime.Parse(DateTime.Now.ToString());
                    Connection.WomacTestId = WId;
                    Connection.UserId = Pid;

                    var tupleModel = new Tuple<PatientRegistration, Womac1, PhysicalTherapyDetail>(UserDetail(Pid, WId), SingleKneeWomacTestCalGet(Pid, Knee, WId), GetPatientPTDetail(Pid.ToString(), Convert.ToInt16(WId), Knee));

                    ViewBag.FacilityName = Connection.FacilityName;
                    return View(tupleModel);
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

        [HttpPost]
        public ActionResult readPatientDetailedInformation(string PatientId, int WomacId, string Knee, [Bind(Prefix = "Item2")] Womac1 model, string viewed = "", string id = "")
        {
            ViewBag.back = viewed;
            try
            {
                Session["PatientId"] = PatientId;
                Session["WomacId"] = WomacId;
                Session["Knee"] = Knee;

                string UserID = SecurityManager.Decrypt(PatientId.ToString());
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    SingleKneeWomacTestCalPost(model, WomacId);
                    //UpdatePatientStatus(PatientId,model.WomacDate);
                    if (WomacId == 3)
                    {
                        UpdatePatientAlertStatusOnWomacDateChange(PatientId, model.WomacDate);
                    }
                   string Pid;
                    int WId = WomacId;
                    Pid = PatientId.ToString();
                    Connection.PatientId = PatientId.ToString();
                    WId = Convert.ToInt16(WomacId);
                    ViewBag.WomacTestId = WId;
                    ViewBag.PatientId = Pid;
                    //ViewBag.CurrentDate = Connection.LoginDate.ToString("MMM-dd-yyyy");
                    //DateTime LoginDate = DateTime.Parse(DateTime.Now.ToString());
                    ViewBag.CurrentDate = DateTime.Parse(DateTime.Now.ToString());
                    Connection.WomacTestId = WId;
                    Connection.UserId = Pid;

                    var tupleModel = new Tuple<PatientRegistration, Womac1, PhysicalTherapyDetail>(UserDetail(Pid, WId), SingleKneeWomacTestCalGet(Pid, Knee, WId), GetPatientPTDetail(Pid.ToString(), Convert.ToInt16(WId), Knee));

                    ViewBag.FacilityName = Connection.FacilityName;
                    return View(tupleModel);
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }


      
        [HttpGet]
        public ActionResult readPatientDetailedInformationboth(string PatientId, int WomacId, string Knee, string viewed = "")
        {
            ViewBag.back = viewed;
            Session["pidboth1"] = PatientId;
              Session["wid1"]=WomacId;
              Session["kn1"]=Knee;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    string Pid;
                    int WId;
                    Pid = PatientId;
                    WId = Convert.ToInt32(WomacId);
                    ViewBag.WomacTestId = WId;
                    ViewBag.PatientId = Pid;
                    ViewBag.CurrentDate = Connection.LoginDate.ToString("MMM-dd-yyyy");
                    ViewBag.FacilityName = Connection.FacilityName;
                    Connection.UserId = Pid;
                    string Patient_Id = PatientId.ToString();
                    var tupleModel = new Tuple<PatientRegistration, WomacBoth, PhysicalTherapyDetail>(UserDetail(Pid, WId), BothKneeWomacTestBothCalGet(Patient_Id, "Left Knee,Right Knee", WId), GetPatientPTDetail(Pid.ToString(), WId, Knee));
                    return View(tupleModel);
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

        [HttpPost]
        public ActionResult readPatientDetailedInformationboth(string PatientId, int WomacId, string Knee,[Bind(Prefix = "Item2")] WomacBoth model, string viewed = "")
        {
            ViewBag.back = viewed;
            Session["pidboth1"] = PatientId;
            Session["wid1"] = WomacId;
            Session["kn1"] = Knee;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    BothKneeWomacTestCalPostBoth(model, WomacId);
                    if (WomacId == 3)
                    {
                        UpdatePatientAlertStatusOnWomacDateChange(PatientId, model.WomacDate);
                    }
                    string Pid;
                    int WId;
                    Pid = PatientId;
                    WId = Convert.ToInt32(WomacId);
                    ViewBag.WomacTestId = WId;
                    ViewBag.PatientId = Pid;
                    ViewBag.CurrentDate = Connection.LoginDate.ToString("MMM-dd-yyyy");
                    ViewBag.FacilityName = Connection.FacilityName;
                    Connection.UserId = Pid;
                    string Patient_Id = PatientId.ToString();
                    var tupleModel = new Tuple<PatientRegistration, WomacBoth, PhysicalTherapyDetail>(UserDetail(Pid, WId), BothKneeWomacTestBothCalGet(Patient_Id, "Left Knee,Right Knee", WId), GetPatientPTDetail(Pid.ToString(), WId, Knee));
                    return View(tupleModel);
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

    }
}
