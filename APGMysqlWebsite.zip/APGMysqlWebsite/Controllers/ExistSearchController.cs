﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.Models;
using NewAPGApplication.BussinessLayer;
using System.Data.OleDb;

namespace NewAPGApplication.Controllers
{
    public class ExistSearchController : Controller
    {

        DbConnection obj = new DbConnection();

        public int CheckSession(int CheckNo)
        {
            int returnValue = 0;
            if (CheckNo == 1)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["LoginUserId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            if (CheckNo == 2)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["UserTypeId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            return returnValue;
        }


        [HttpGet]
        public JsonResult GetUserNameIdExist(string UserID)
        {
            int ExistUserID = 0;
            MySqlCommand cmd = new MySqlCommand("select U_Id,R_Id,EmailId,FacilityId,F_Name,L_Name,Gender from userregister where U_Id=@U_Id", obj.con);
            cmd.Parameters.AddWithValue("@U_Id", SecurityManager.Encrypt(UserID));
            MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            asd.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                ExistUserID = 1;
            }

            else
            {
                ExistUserID = 0;
            }
            return Json(ExistUserID, JsonRequestBehavior.AllowGet);
        }

        public JsonResult CheckEmailIdExist(string Email_id, string userid, int id = 0)
        {
             int idd = 0;
            idd = id;
            string uid = null;
            if (userid != null)
            {
              uid = userid;
            }
           
            string patientEmailid = null;
            int ExistEmailId = 0;
            int state = 2;
            try
            {
                string query1 = "select U_Id, EmailId from userregister where EmailId='" + SecurityManager.Encrypt(Email_id) + "'";
                MySqlCommand cmd2 = new MySqlCommand(query1, obj.con);
                MySqlDataAdapter da2 = new MySqlDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);
                if (dt2.Rows.Count > 0)
                {
                  //  patientEmailid = SecurityManager.Decrypt(dt2.Rows[0]["EmailId"].ToString());
                    ExistEmailId = 1;
                }
            }
            catch (Exception ex)
            { 
            
            }
            return Json(ExistEmailId, JsonRequestBehavior.AllowGet);
    
        }

        public JsonResult GetEmailIdExist(string Email_id,string userid, int id=0)
        {
           
            int idd = 0;
            idd = id;
            string uid = null;
            if (userid != null)
            {
              uid = userid;
            }
           
            string patientEmailid = null;
            int ExistEmailId = 0;
            int state = 2;
            int SessionState = CheckSession(1);
            if (SessionState == 1)
            {
                string query1 = "select U_Id, EmailId from userregister where U_Id='" + SecurityManager.Encrypt(uid) + "'";
                MySqlCommand cmd2 = new MySqlCommand(query1,obj.con);
                MySqlDataAdapter da2 = new MySqlDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);
                if (dt2.Rows.Count > 0)
                {
                    patientEmailid =SecurityManager.Decrypt(dt2.Rows[0]["EmailId"].ToString());
                }
                else
                { 
                
                }
                //if (Session["patientEmailid"] != null)
                //{
                //    patientEmailid = Session["patientEmailid"].ToString();
                //}
               
                string U_id = SecurityManager.Encrypt(Email_id.ToString());

                string query = "select U_Id,R_Id,EmailId,FacilityId,F_Name,L_Name,Gender from userregister where EmailId=@EmailId";

                MySqlCommand cmd = new MySqlCommand(query, obj.con);
                cmd.Parameters.AddWithValue("@EmailId", SecurityManager.Encrypt(Email_id));
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                asd.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (idd == 1)
                    {
                        if (patientEmailid == Email_id)
                        {
                            ExistEmailId = 0;
                        }
                        else
                        {
                            ExistEmailId = 1;
                        }
                    }
                    else
                    {
                        if (dt.Rows.Count > 0)
                        {
                            ExistEmailId = 1;
                        }
                        else
                        {
                            ExistEmailId = 0;
                        }
                    }
                }
                else
                {
                    try
                    {
                        MySqlCommand cmd1 = new MySqlCommand("select U_Id,R_Id,EmailId,FacilityId,F_Name,L_Name,Gender from userregister where U_Id='" + U_id + "'", obj.con);
                        //  cmd.Parameters.AddWithValue("@U_Id", U_id);
                        MySqlDataAdapter asd1 = new MySqlDataAdapter(cmd1);
                        DataTable dt1 = new DataTable();
                        asd1.Fill(dt1);
                        if (dt1.Rows.Count > 0)
                        {
                            if (idd == 1)
                            {
                                if (patientEmailid == Email_id)
                                {
                                    ExistEmailId = 0;
                                }
                                else
                                {
                                    ExistEmailId = 1;
                                }
                            }
                            else
                            {
                                if (dt1.Rows.Count > 0)
                                {
                                    ExistEmailId = 1;
                                }
                                else
                                {
                                    ExistEmailId = 0;
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {

                    }

                }
            }
            else
            {
                return Json(state, JsonRequestBehavior.AllowGet);
            }
            return Json(ExistEmailId, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetEmailIdExists(string Email_id)
        {
            int idd = 0;
             string uid=null;
             if (Email_id != null)
             {
                 uid = SecurityManager.Encrypt(Email_id);
             }
  
            int ExistEmailId = 0;
          
            int SessionState = CheckSession(1);
            if (SessionState == 1)
            {
                string query1 = "select EmailId from userregister where EmailId='" + uid + "'";
                MySqlCommand cmd2 = new MySqlCommand(query1, obj.con);
                MySqlDataAdapter da2 = new MySqlDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);
                if (dt2.Rows.Count > 0)
                {
                    ExistEmailId = 1;
                }
                else
                {

                }
            }
            else
            {
                return Json(ExistEmailId, JsonRequestBehavior.AllowGet);
            }
            return Json(ExistEmailId, JsonRequestBehavior.AllowGet);
        }


        [HttpGet]
        public JsonResult GetUserDetail(PatientRegistration M1) //---------------------------------------- Call On Patient Info
        {
            try
            {

                if (Session["LoginUserId"] != null)
                {
                    string TempUid = Session["UserId"].ToString();
                    GetPatientInformation obj = new GetPatientInformation();
                    DataSet ds = obj.GetUserData(TempUid);      //-------------------------------------Get Data From table ' patient_otherinfo'

                    DataSet dss = obj.GetPatientInfo(SecurityManager.Encrypt(TempUid));  //-------------------------------------Get Data From table 'userregister'

                    M1.UserNameId = Session["UserId"].ToString();

                    if (ds.Tables[0].Rows[0]["FacilityId"] != null)
                    {
                        int Fid = Convert.ToInt16(ds.Tables[0].Rows[0]["FacilityId"].ToString());
                    }

                    DataSet ds1 = GetFacilityName(ds.Tables[0].Rows[0]["FacilityId"].ToString());

                    if (ds1.Tables[0].Rows[0]["Location"] != null)
                    {
                        string FacilityName = ds1.Tables[0].Rows[0]["Location"].ToString();       //-------------------------------------Get Facility Name
                        ViewBag.FacilityName = FacilityName;
                    }

                    M1.FirstName = SecurityManager.Decrypt(ds.Tables[0].Rows[0]["F_Name"].ToString());
                    M1.LastName = SecurityManager.Decrypt(ds.Tables[0].Rows[0]["L_Name"].ToString());
                    M1.Gender = ds.Tables[0].Rows[0]["Gender"].ToString();
                    M1.BirthDate = (Convert.ToDateTime(ds.Tables[0].Rows[0]["DOB"])).ToString("MMMM-dd-yyyy");
                    M1.EmailId = SecurityManager.Decrypt(ds.Tables[0].Rows[0]["EmailId"].ToString());
                    M1.Password = SecurityManager.Decrypt(ds.Tables[0].Rows[0]["Password"].ToString());
                    M1.MobileNo = ds.Tables[0].Rows[0]["MobileNo"].ToString();
                    M1.EthnicityId = ds.Tables[0].Rows[0]["EthnicityId"].ToString();
                    M1.Soc_Security = ds.Tables[0].Rows[0]["Soc_Security"].ToString();

                    M1.Height = dss.Tables[0].Rows[0]["Height"].ToString();
                    M1.Weight = Convert.ToInt16(dss.Tables[0].Rows[0]["Weight"].ToString());
                    M1.PIN = Convert.ToInt16(dss.Tables[0].Rows[0]["PINNO"].ToString());
                }
            }
            catch (Exception)
            {
            }
            return Json(M1, JsonRequestBehavior.AllowGet);
        }

        public DataSet GetFacilityName(string id)
        {
            DataSet ds1 = null;
            try
            {
                obj.OpenDbConnection();
                MySqlCommand cmd = new MySqlCommand("select IFNULL(`FacilityId`, '') AS FacilityId , IFNULL(`Location`, '') AS  Location, IFNULL(`Street`, '') AS  Street, IFNULL(`StateId`, '') AS StateId , IFNULL(`Zipcode`, '') AS  Zipcode, IFNULL(`ContactNo`, '') AS  ContactNo, IFNULL(`FaxNo`, '') AS FaxNo , IFNULL(`ManagerId`, '') AS  ManagerId, IFNULL(`EmailId`, '') AS  EmailId,`IsActive`,  IFNULL(`CityId`, '') AS  CityId from  facility Where FacilityId=@FacilityId and IsActive='" + 1 + "'", obj.con);
                cmd.Parameters.AddWithValue("@FacilityId", id);
                MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
                ds1 = new DataSet();
                asd.Fill(ds1);
                return ds1;
            }
            catch (Exception)
            {
                return ds1;
            }
            finally
            {
                obj.CloseDbConnection();
            }
        }

        [HttpGet]
        public JsonResult GetInsureUserDetail(Insurance M1)  //---------------------------------------- Call On Insurance
        {
            try
            {

                if (Session["LoginUserId"] != null)
                {
                    string TempUid = Session["TempPatientId"] != null ? SecurityManager.Encrypt(Session["TempPatientId"].ToString()) : SecurityManager.Encrypt(Session["UserId"].ToString());

                    GetPatientInformation obj = new GetPatientInformation();

                    DataSet ds = obj.GetUserData(TempUid);      //-------------------------------------Get Data From table ' patient_otherinfo'

                    DataSet dss = obj.GetPatientInfo(TempUid);  //-------------------------------------Get Data From table 'userregister'

                    DataTable dt = obj.GetInsuranceData(TempUid);

                    M1.UserNameId = SecurityManager.Decrypt(TempUid);

                    DataSet ds1 = GetFacilityName(ds.Tables[0].Rows[0]["FacilityId"].ToString());

                    M1.Name = SecurityManager.Decrypt(ds.Tables[0].Rows[0]["F_Name"].ToString()) +" "+ SecurityManager.Decrypt(ds.Tables[0].Rows[0]["L_Name"].ToString());

                    M1.Address = ds.Tables[0].Rows[0]["Address"].ToString();
                    M1.CityId = ds.Tables[0].Rows[0]["CityId"].ToString() != null ? ds.Tables[0].Rows[0]["CityId"].ToString() : "0";
                    M1.StateId = ds.Tables[0].Rows[0]["StateId"].ToString() != null ? ds.Tables[0].Rows[0]["StateId"].ToString() : "0";
                    M1.ZipCode = ds.Tables[0].Rows[0]["Zipcode"].ToString() != "0" ? ds.Tables[0].Rows[0]["Zipcode"].ToString() : "";
                    M1.BirthDate = (Convert.ToDateTime(ds.Tables[0].Rows[0]["DOB"])).ToString("MMMM-dd-yyyy");
                    string Security = ds.Tables[0].Rows[0]["Soc_Security"].ToString();
                    string num = "0";
                    if (Security == num)
                    {
                        M1.Soc_Security = "";
                    }
                    else
                    {
                        M1.Soc_Security = ds.Tables[0].Rows[0]["Soc_Security"].ToString();
                    }
                    M1.EmployerName = dss.Tables[0].Rows[0]["Employer"].ToString();
                    if (dt.Rows.Count > 0)
                    {
                        int InsNo = Convert.ToInt16(dt.Rows[0]["Ins_Id"].ToString());
                        M1.Policy = dt.Rows[0]["PolicyNo"].ToString();
                        M1.InsureName = dt.Rows[0]["Ins_Name"].ToString();
                        M1.Relation = dt.Rows[0]["Relation"].ToString();
                        M1.GroupNo = dt.Rows[0]["GroupNo"].ToString();
                        M1.EmployerName = dt.Rows[0]["EmployerName"].ToString();
                        DataTable dt1 = obj.GetSecondaryInsuranceData(InsNo);
                        if (dt1.Rows.Count > 0)
                        {
                            M1.I_Name = dt1.Rows[0]["Name"].ToString();
                            M1.I_Address = dt1.Rows[0]["Address"].ToString();
                            M1.I_CityId = dt1.Rows[0]["CityId"].ToString() != null ? dt1.Rows[0]["CityId"].ToString() : "0";
                            M1.I_StateId = dt1.Rows[0]["StateId"].ToString() != null ? dt1.Rows[0]["StateId"].ToString() : "0";
                            M1.I_ZipCode = dt1.Rows[0]["Zipcode"].ToString() != "0" ? dt1.Rows[0]["Zipcode"].ToString() : "";
                            M1.I_Soc_Security = dt1.Rows[0]["SocialSecurity"].ToString();
                            M1.I_Relation = dt1.Rows[0]["Relation"].ToString();
                            M1.I_BirthDate =dt1.Rows[0]["DOB"].ToString();
                            M1.I_EmployerName = dt1.Rows[0]["EmployerName"].ToString();
                            M1.I_Address = dt1.Rows[0]["Address"].ToString();
                        }
                    }
                }
            }

            catch (Exception)
            {
            }
            return Json(M1, JsonRequestBehavior.AllowGet);
        }
        
        [HttpGet]
        public JsonResult GetPatientInfo(PatientQuestionnaire M1)  //---------------------------------------- Call On Insurance
        {
            try
            {
                if (Session["LoginUserId"] != null)
                {
                    string TempUid = Session["UserId"].ToString();
                    GetPatientInformation obj = new GetPatientInformation();
                    DataSet ds = obj.GetUserData(SecurityManager.Decrypt(TempUid));      //-------------------------------------Get Data From table ' patient_otherinfo'

                    M1.UserNameId = Session["UserId"].ToString();
                    M1.Name = SecurityManager.Decrypt(ds.Tables[0].Rows[0]["F_Name"].ToString()) + SecurityManager.Decrypt(ds.Tables[0].Rows[0]["L_Name"].ToString());
                    M1.DOB = (Convert.ToDateTime(ds.Tables[0].Rows[0]["DOB"])).ToString("MMMM-dd-yyyy");
                }
            }
            catch (Exception)
            {
            }
            return Json(M1, JsonRequestBehavior.AllowGet);
        }
        
        [HttpGet]
        public JsonResult GetUserInformation(PatientRegistration M1) //---------------------------------------- Call On Registration II Part
        {
            try
            {
                if (Session["LoginUserId"] != null)
                {
                    string TempUid = Session["UserId"].ToString();
                    GetPatientInformation obj = new GetPatientInformation();
                    DataSet ds = obj.GetUserData(SecurityManager.Encrypt(TempUid));      //-------------------------------------Get Data From table 'userregister'

                    M1.UserNameId = Session["UserId"].ToString();
                    M1.FirstName = SecurityManager.Decrypt(ds.Tables[0].Rows[0]["F_Name"].ToString());
                    M1.LastName = SecurityManager.Decrypt(ds.Tables[0].Rows[0]["L_Name"].ToString());
                    M1.EmailId = SecurityManager.Decrypt(ds.Tables[0].Rows[0]["EmailId"].ToString());
                    M1.Password = SecurityManager.Decrypt(ds.Tables[0].Rows[0]["Password"].ToString());                  
                }
            }
            catch (Exception)
            {
            }
            return Json(M1, JsonRequestBehavior.AllowGet);
        }
               
        [HttpGet]
        public JsonResult GetUpdatePatientDetail(PatientRegistration M1) //---------------------------------------- Call On Patient Info
        {
            try
            {
                int state = 0;
                if (Session["UserIdentityForLayOut"] != null)
                {
                    var TempUid = Session["SelectedUserId"].ToString();
                    TempUid = TempUid.Replace(" ", "+");
                    GetPatientInformation obj = new GetPatientInformation();
                    DataSet ds = obj.GetUserData(TempUid);      //-------------------------------------Get Data From table 'userregister '


                    DataSet dss = obj.GetPatientInfo(TempUid);  //-------------------------------------Get Data From table 'patient_otherinfo'

                    M1.UserNameId = SecurityManager.Decrypt(TempUid);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        if (ds.Tables[0].Rows[0]["FacilityId"] != null)
                        {
                            int Fid = Convert.ToInt16(ds.Tables[0].Rows[0]["FacilityId"].ToString());
                        }
                        if (ds.Tables[0].Rows[0]["FacilityId"].ToString() == null)
                        {

                        }
                        else
                        {
                            DataSet ds1 = GetFacilityName(ds.Tables[0].Rows[0]["FacilityId"].ToString());

                            if (ds1.Tables[0].Rows.Count > 0)
                            {
                                if (ds1.Tables[0].Rows[0]["Location"] != null)
                                {
                                    string FacilityName = ds1.Tables[0].Rows[0]["Location"].ToString();       //-------------------------------------Get Facility Name
                                    ViewBag.FacilityName = FacilityName;
                                }
                            }
                        }
                         M1.FacilityId = ds.Tables[0].Rows[0]["FacilityId"].ToString();
                    }
                  
                    M1.FirstName = SecurityManager.Decrypt(ds.Tables[0].Rows[0]["F_Name"].ToString());
                    M1.LastName = SecurityManager.Decrypt(ds.Tables[0].Rows[0]["L_Name"].ToString());                  
                    M1.Gender = ds.Tables[0].Rows[0]["Gender"].ToString();
                    M1.EthnicityId = ds.Tables[0].Rows[0]["EthnicityId"].ToString();
                    M1.BirthDate = (Convert.ToDateTime(ds.Tables[0].Rows[0]["DOB"])).ToString("MM-dd-yyyy");
                    M1.EmailId = SecurityManager.Decrypt(ds.Tables[0].Rows[0]["EmailId"].ToString());
                    //M1.Password = SecurityManager.Decrypt(ds.Tables[0].Rows[0]["Password"].ToString());
                    M1.MobileNo = ds.Tables[0].Rows[0]["MobileNo"].ToString();
                    if (dss.Tables[0].Rows.Count > 0)
                    {
                        M1.Height = dss.Tables[0].Rows[0]["Height"].ToString();
                        M1.Weight = Convert.ToInt16(dss.Tables[0].Rows[0]["Weight"].ToString());
                 
                    }
                     M1.PIN = Convert.ToInt16(ds.Tables[0].Rows[0]["Zipcode"]);
                    Session["patientEmailid"] = SecurityManager.Decrypt(ds.Tables[0].Rows[0]["EmailId"].ToString());

                }
                else
                {
                    return Json(state, JsonRequestBehavior.AllowGet);
                }
            }

            catch (Exception)
            {
            }
            return Json(M1, JsonRequestBehavior.AllowGet);
        }
        
        [HttpGet]
        public JsonResult GetPatientDetail()                             //---------------------------------------- Call On Patient Re Activation
        {
            PatientRegistration PR = new Models.PatientRegistration();   
            try
            {
                string SelectedUserId = Session["SelectedUserId"] != null ? Session["SelectedUserId"].ToString() : "0";
                PR = GetPatientInformation.GetPatientDetail(SelectedUserId);               
            }
            catch (Exception e)
            {
            }
            return Json(PR,JsonRequestBehavior.AllowGet);
        }
        
        [HttpGet]
        public JsonResult GetPatientMedicalAuthorizationDetail()         //---------------------------------------- Call On Get Patient Medical Authorization
        {
            GetPatientInformation ob = new GetPatientInformation();
            MedicalInformation PMA = new MedicalInformation();
            try
            {
                string SelectedUserId = Session["SelectedUserId"] != null ? Session["SelectedUserId"].ToString() : "0";
                string ChangedLoginUserId = Session["UserId"] != null ? Session["UserId"].ToString() : "0";
                string PatientId = SelectedUserId == "0" ? ChangedLoginUserId : SelectedUserId;

                MySqlCommand cmd = new MySqlCommand("select * from patient_medicalreport where 	PatientId ='" + SecurityManager.Encrypt(PatientId) + "'", obj.con);  
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count != 0)
                {
                    PMA.ReleaseTo = ds.Tables[0].Rows[0]["ReleaseTo"].ToString();
                    PMA.ObtainFrom = ds.Tables[0].Rows[0]["Obtain"].ToString();
                    PMA.OrgName = ds.Tables[0].Rows[0]["OrgName"].ToString();
                    PMA.OrgAddress = ds.Tables[0].Rows[0]["OrgAddress"].ToString();
                    PMA.OrgContactNo = ds.Tables[0].Rows[0]["orgPhone"].ToString();
                    PMA.AppliesTo = ds.Tables[0].Rows[0]["AppliedOn"].ToString();
                    PMA.ValidTill = ds.Tables[0].Rows[0]["SignatureOn"].ToString();
                    PMA.SignDate = ds.Tables[0].Rows[0]["PatientSign"].ToString();
                }
                DataSet ds1 = ob.GetUserData(SecurityManager.Encrypt(PatientId));

                if (ds1.Tables[0].Rows.Count != 0)
                {
                    string PN = SecurityManager.Decrypt(ds1.Tables[0].Rows[0]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(ds1.Tables[0].Rows[0]["L_Name"].ToString());
                    PMA.PatientName = PN;
                    if (!String.IsNullOrEmpty(ds1.Tables[0].Rows[0]["DOB"].ToString()))
                    {
                        PMA.DOB = Convert.ToString(Convert.ToDateTime(ds1.Tables[0].Rows[0]["DOB"].ToString()).ToString("MMM-dd-yyyy"));
                    }
                    PMA.Street = ds1.Tables[0].Rows[0]["Address"].ToString();
                 // string C = ds1.Tables[0].Rows[0]["CityId"].ToString() + "," + ds1.Tables[0].Rows[0]["StateId"].ToString() + "," + ds1.Tables[0].Rows[0]["Zipcode"].ToString();
                 // PMA.City = C;
                    PMA.SocSec = ds1.Tables[0].Rows[0]["Soc_Security"].ToString();
                    PMA.ContactNo = ds1.Tables[0].Rows[0]["MobileNo"].ToString();
                }
               
            }
            catch (Exception e)
            {
              
            }
            return Json(PMA, JsonRequestBehavior.AllowGet);
        }
                
        [HttpGet]
        public JsonResult EditFacilityDetail()   // -------------------------------------------- Get Facility Details
        {
            Facility URM = new Facility();
            try
            {
                int tempId = Session["selectedFacilityId"] != null ? Convert.ToInt32(Session["selectedFacilityId"].ToString()) : 0;
                if (tempId != 0)
                {
                    URM = GetOperatorName.GetFacilityDetail(tempId);
                }               
            }
            catch (Exception e)
            {
                ModelState.AddModelError("", e.Message);
            }
            return Json(URM, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult GetAdminUserDetail(AdminRegisterModel M1) //---------------------------------------- Call On Patient Info
        {
            try
            {

                if (Session["LoginUserId"] != null)
                {
                    string TempUid = Session["SelectedUserId"].ToString() != "" ? Session["SelectedUserId"].ToString() :SecurityManager.Encrypt(Session["UserId"].ToString());
                    GetPatientInformation obj = new GetPatientInformation();
                    DataSet ds = obj.GetUserData(SecurityManager.Decrypt(TempUid));      // ------------------------------------- Get Data From table ' patient_otherinfo'
                    
                   // DataSet dss = obj.GetPatientInfo(SecurityManager.Encrypt(TempUid));  // ------------------------------------- Get Data From table 'userregister'

                    M1.UserTypeID = Session["UserId"].ToString();

                    if (ds.Tables[0].Rows[0]["FacilityId"] != null)
                    {
                        int Fid = Convert.ToInt16(ds.Tables[0].Rows[0]["FacilityId"].ToString());

                        M1.FacilityID = ds.Tables[0].Rows[0]["FacilityId"].ToString();
                    }

                    DataSet ds1 = GetFacilityName(ds.Tables[0].Rows[0]["FacilityId"].ToString());
                    if (ds1.Tables[0].Rows.Count > 0)
                    {
                        if (ds1.Tables[0].Rows[0]["Location"] != null)
                        {
                            string FacilityName = ds1.Tables[0].Rows[0]["Location"].ToString();       // ------------------------------------- Get Facility Name
                            ViewBag.FacilityName = FacilityName;
                        }
                    }
                    M1.UserTypeID = ds.Tables[0].Rows[0]["R_Id"].ToString();

                    M1.FirstName = SecurityManager.Decrypt(ds.Tables[0].Rows[0]["F_Name"].ToString());
                    M1.LastName = SecurityManager.Decrypt(ds.Tables[0].Rows[0]["L_Name"].ToString());
                                     
                    M1.Email = SecurityManager.Decrypt(ds.Tables[0].Rows[0]["EmailId"].ToString());                   
                    M1.MobileNo = ds.Tables[0].Rows[0]["MobileNo"].ToString();
                  
                }
            }
            catch (Exception)
            {
            }
            return Json(M1, JsonRequestBehavior.AllowGet);
        }
        
    }
}