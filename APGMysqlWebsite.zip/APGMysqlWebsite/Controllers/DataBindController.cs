﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.Models;
using System.Data.OleDb;

namespace NewAPGApplication.Controllers
{
    public class DataBindController : Controller
    {

        DbConnection obj = new DbConnection();

        public int CheckSession(int CheckNo)
        {
            int returnValue = 0;
            if (CheckNo == 1)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["LoginUserId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            if (CheckNo == 2)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["UserTypeId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            return returnValue;
        }


        public JsonResult GetAllFacilityList()
        {
            List<SelectListItem> FacilityList = new List<SelectListItem>();
              
            //int SessionState = CheckSession(1);
            //if (SessionState == 1)
            //{

                MySqlCommand cmd = new MySqlCommand("select FacilityId,Location from facility order by Location", obj.con); // There "1" Means Active 
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        FacilityList.Add(new SelectListItem { Text = dt.Rows[i]["Location"].ToString(), Value = dt.Rows[i]["FacilityId"].ToString() });
                    }
                }
                ViewBag.PolicyList = FacilityList;
            //}
            //else
            //{
            //    return Json(SessionState, JsonRequestBehavior.AllowGet);
            //}
            return Json(FacilityList, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetAllEthnicityList()
        {
            List<SelectListItem> EthnicityList = new List<SelectListItem>();
            MySqlCommand cmd = new MySqlCommand("select IFNULL(EthnicityId, '') AS EthnicityId,IFNULL(Ethnicity_Name, '') AS Ethnicity_Name from ethnicity order by Ethnicity_Name", obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();       
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    EthnicityList.Add(new SelectListItem { Text = dt.Rows[i]["Ethnicity_Name"].ToString(), Value = dt.Rows[i]["EthnicityId"].ToString() });
                }
            }
            ViewBag.PolicyList = EthnicityList;
            return Json(EthnicityList, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetAllStateList()
        {
            List<SelectListItem> StateList = new List<SelectListItem>();
            MySqlCommand cmd = new MySqlCommand("select StateId,S_Name,Abbreviation from state where IsActive='" + 1 + "' order by S_Name", obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    StateList.Add(new SelectListItem { Text = dt.Rows[i]["S_Name"].ToString(), Value = dt.Rows[i]["StateId"].ToString() });
                }
            }

            ViewBag.PolicyList = StateList;
            return Json(StateList, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetEducationList()
        {
            List<SelectListItem> EduList = new List<SelectListItem>();
            MySqlCommand cmd = new MySqlCommand("select Edu_Id,Edu_Name from educationlist order by Edu_Name", obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    EduList.Add(new SelectListItem { Text = dt.Rows[i]["Edu_Name"].ToString(), Value = dt.Rows[i]["Edu_Id"].ToString() });
                }
            }

            ViewBag.PolicyList = EduList;
            return Json(EduList, JsonRequestBehavior.AllowGet);
        }

         [HttpPost]
        public JsonResult GetCityList(int StateId)
        {
            List<SelectListItem> CityList = new List<SelectListItem>();
            MySqlCommand cmd = new MySqlCommand("select * from city where StateId='" + StateId + "' order by C_Name", obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    CityList.Add(new SelectListItem { Text = dt.Rows[i]["C_Name"].ToString(), Value = dt.Rows[i]["CityId"].ToString() });
                }
            }

            ViewBag.PolicyList = CityList;
            return Json(CityList);
        }
         [HttpPost]
         public JsonResult GetCityName(int CityId)
         {
             List<SelectListItem> CityList = new List<SelectListItem>();
             MySqlCommand cmd = new MySqlCommand("select * from city where CityId='" + CityId + "' order by C_Name", obj.con);
             MySqlDataAdapter da = new MySqlDataAdapter(cmd);
             DataTable dt = new DataTable();
             da.Fill(dt);
             if (dt.Rows.Count > 0)
             {
                 for (int i = 0; i < dt.Rows.Count; i++)
                 {
                     CityList.Add(new SelectListItem { Text = dt.Rows[i]["C_Name"].ToString(), Value = dt.Rows[i]["CityId"].ToString() });
                 }
             }

             ViewBag.PolicyList = CityList;
             return Json(CityList);
         }
         public JsonResult GetallCityList(string term)
         {
             List<SelectListItem> CityList = new List<SelectListItem>();
             MySqlCommand cmd = new MySqlCommand("select * from city where C_Name like '"+term+"%'", obj.con);
             MySqlDataAdapter da = new MySqlDataAdapter(cmd);
             DataTable dt = new DataTable();
             da.Fill(dt);
             if (dt.Rows.Count > 0)
             {
                 for (int i = 0; i < dt.Rows.Count; i++)
                 {
                     CityList.Add(new SelectListItem { Text = dt.Rows[i]["C_Name"].ToString(), Value = dt.Rows[i]["CityId"].ToString() });
                 }
             }

             ViewBag.PolicyList = CityList;
             return Json(CityList, JsonRequestBehavior.AllowGet);
         }

         public class cityinfo
         {
             public string City { get; set; }
             public string City_Id { get; set; }
         
         }
         public JsonResult SelectlastCity(int StateId, string cityname)
         {
             List<cityinfo> CityList = new List<cityinfo>();
             MySqlCommand cmd = new MySqlCommand("select * from city where C_Name ='" + cityname + "' and StateId='" + StateId + "'", obj.con);
             MySqlDataAdapter da = new MySqlDataAdapter(cmd);
             DataTable dt = new DataTable();
             da.Fill(dt);
             if (dt.Rows.Count > 0)
             {
                 for (int i = 0; i < dt.Rows.Count; i++)
                 {
                     CityList.Add(new cityinfo { City = dt.Rows[i]["C_Name"].ToString(), City_Id = dt.Rows[i]["CityId"].ToString() });
                 }
             }

             ViewBag.PolicyList = CityList;
             return Json(CityList, JsonRequestBehavior.AllowGet);
         }

         public JsonResult AddCity(int StateId, string cityname )
         {
             var success = 0;
             MySqlCommand cmd = new MySqlCommand("insert into city ( C_Name,StateId)values('" + cityname + "','" + StateId + "')", obj.con);
             obj.con.Open();
           success=  cmd.ExecuteNonQuery();
             obj.con.Close();

             return Json(success, JsonRequestBehavior.AllowGet);
         }


         [HttpPost]
         public JsonResult GetMAILCityList(int StateId)
         {
             List<SelectListItem> MCityList = new List<SelectListItem>();
             MySqlCommand cmd = new MySqlCommand("select * from city where StateId='" + StateId + "' order by C_Name", obj.con);
             MySqlDataAdapter da = new MySqlDataAdapter(cmd);
             DataTable dt = new DataTable();
             da.Fill(dt);
             if (dt.Rows.Count > 0)
             {
                 for (int i = 0; i < dt.Rows.Count; i++)
                 {
                     MCityList.Add(new SelectListItem { Text = dt.Rows[i]["C_Name"].ToString(), Value = dt.Rows[i]["CityId"].ToString() });
                 }
             }

             ViewBag.PolicyList = MCityList;
             return Json(MCityList, JsonRequestBehavior.AllowGet);
         }


         [HttpPost]
         public JsonResult GetEMPCityList(int StateId)
         {
             List<SelectListItem> ECityList = new List<SelectListItem>();
             MySqlCommand cmd = new MySqlCommand("select * from city where StateId='" + StateId + "' order by C_Name", obj.con);
             MySqlDataAdapter da = new MySqlDataAdapter(cmd);
             DataTable dt = new DataTable();
             da.Fill(dt);
             if (dt.Rows.Count > 0)
             {
                 for (int i = 0; i < dt.Rows.Count; i++)
                 {
                     ECityList.Add(new SelectListItem { Text = dt.Rows[i]["C_Name"].ToString(), Value = dt.Rows[i]["CityId"].ToString() });
                 }
             }

             ViewBag.PolicyList = ECityList;
             return Json(ECityList, JsonRequestBehavior.AllowGet);
         }
       
        public JsonResult GetReferralList()
        {
            List<SelectListItem> ReferralList = new List<SelectListItem>();
            MySqlCommand cmd = new MySqlCommand("select * from referrallist where IsActive='" + 1 + "' order by ReferralName", obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    ReferralList.Add(new SelectListItem { Text = dt.Rows[i]["ReferralName"].ToString(), Value = dt.Rows[i]["ReferralId"].ToString() });
                }
            }

            ViewBag.PolicyList = ReferralList;
            return Json(ReferralList, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetPhysicainList()
        {

            var FacilityId = Session["LoggedInFacilityId"];
            List<SelectListItem> PhysicainList = new List<SelectListItem>();
            MySqlCommand cmd = new MySqlCommand("select F_Name,L_Name,U_Id from userregister where R_Id='" + 6 + "' and IsActive='" + 1 + "' order by F_Name", obj.con); 
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                    PhysicainList.Add(new SelectListItem { Text = PN, Value = SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()) });
                }
            }

            ViewBag.PolicyList = PhysicainList;
            return Json(PhysicainList, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetPhysicianTherapist()
        {
            var FacilityId = Session["LoggedInFacilityId"];
            List<SelectListItem> PhysicianTherapist = new List<SelectListItem>();
            //MySqlCommand cmd = new MySqlCommand("select * from userregister where R_Id='" + 7 + "' and IsActive='" + 1 + "'order by F_Name", obj.con);
            MySqlCommand cmd = new MySqlCommand("select F_Name,L_Name,U_Id from userregister where R_Id='" + 7 + "' and IsActive='" + 1 + "' order by F_Name", obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                    PhysicianTherapist.Add(new SelectListItem { Text = PN, Value = SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()) });
                }
            }

            ViewBag.PolicyList = PhysicianTherapist;
            return Json(PhysicianTherapist, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetAllAdminList()
        {
            List<SelectListItem> AdminList = new List<SelectListItem>();
            MySqlCommand cmd = new MySqlCommand("select U_Id,R_Id,F_Name,L_Name,IsActive from userregister where R_Id !='" + 10 + "' and IsActive='" + 1 + "'order by F_Name", obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());

                    AdminList.Add(new SelectListItem { Text = PN, Value = SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()) });
                }
            }
            ViewBag.PolicyList = AdminList;
            return Json(AdminList, JsonRequestBehavior.AllowGet);
        }

        public JsonResult Getallmanagerlist(string term)

        {
           // F_Name like '" + term + "%' and
            List<SelectListItem> AdminList = new List<SelectListItem>();
            MySqlCommand cmd = new MySqlCommand("select U_Id,R_Id,F_Name,L_Name,IsActive from userregister where   R_Id !='" + 10 + "' and IsActive='" + 1 + "'order by F_Name", obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());

                    AdminList.Add(new SelectListItem { Text = PN, Value = SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()) });
                }
            }
            ViewBag.PolicyList = AdminList;
            return Json(AdminList, JsonRequestBehavior.AllowGet);
        }


        [HttpGet]
        public JsonResult GetuserlevelList()
        {
            List<SelectListItem> UserList = new List<SelectListItem>();
            MySqlCommand cmd = new MySqlCommand("select * from userrole where  Isactive='" + 1 + "' and R_id !='"+10+"' order by R_name", obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    UserList.Add(new SelectListItem { Text = dt.Rows[i]["R_name"].ToString(), Value = dt.Rows[i]["R_id"].ToString() });
                }
            }
            ViewBag.PolicyList = UserList;
            return Json(UserList, JsonRequestBehavior.AllowGet);
        }


    }
}
