﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.Models;
using NewAPGApplication.BussinessLayer;
using Newtonsoft.Json;

namespace NewAPGApplication.Controllers
{
    public class DynamicMenuController : Controller
    {
        string Display = null, ContollerName = null, ActionName = null, ParameterName = null;
        DbConnection obj = new DbConnection();

        public ActionResult Index()
        {
            return View();
        }

        public int CheckSession(int CheckNo)
        {
            int returnValue = 0;
            if (CheckNo == 1)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["LoginUserId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            if (CheckNo == 2)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["UserTypeId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            return returnValue;
        }

        public string GetFacilityName(int ID)
        {
            string LocationName = "";

            MySqlCommand cmd = new MySqlCommand("select FacilityId,Location from facility where FacilityId='" + ID + "'", obj.con); // There "1" Means Active 
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                LocationName = dt.Rows[0]["Location"].ToString();
            }
            return LocationName;
        }

        public ActionResult RenderMenu(string UserType)
        {
            Menu M = new Menu();
            M.MenuItems = null;
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    List<MenuItem> MItems = new List<MenuItem>();
                    string Query = "SELECT distinct t1.MainMenuId,t1.MainMenuName,t2.R_id,t2.view FROM mainmenunavigation t1 INNER JOIN mainnavigationauthentication t2 ON t1.MainMenuId=t2.MainMenuId where t2.R_id='" + UserType + "'";
                    MySqlCommand cmd = new MySqlCommand(Query, obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    if (ds.Tables[0].Rows.Count != 0)
                    {
                        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                        {
                            if (ds.Tables[0].Rows[i]["view"].ToString() == "1")
                            {
                                int Mid = Convert.ToInt32(ds.Tables[0].Rows[i]["MainMenuId"].ToString());

                                switch (Mid)
                                {
                                    // ------- Admin Menu
                                    case 1:
                                        Display = "DASHBOARD";
                                        ContollerName = MenuUrl.Adm_DeshBoard_controller;
                                        ActionName = MenuUrl.Adm_DeshBoard_ActionResult;
                                        ParameterName = MenuUrl.Adm_DeshBoard_Parameters;
                                        break;

                                    case 2:
                                        Display = "PATIENT";
                                        ContollerName = MenuUrl.Adm_Patient_controller;
                                        ActionName = MenuUrl.Adm_Patient_ActionResult;
                                        ParameterName = MenuUrl.Adm_Patient_Parameters;
                                        break;

                                    case 3:
                                        Display = "WOMAC";
                                        ContollerName = MenuUrl.Adm_Womac_controller;
                                        ActionName = MenuUrl.Adm_Womac_ActionResult;
                                        ParameterName = MenuUrl.Adm_Womac_Parameters;
                                        break;

                                    case 4:
                                        Display = "ALERTS";
                                        ContollerName = MenuUrl.Adm_Alert_controller;
                                        ActionName = MenuUrl.Adm_Alert_ActionResult;
                                        ParameterName = MenuUrl.Adm_Alert_Parameters;
                                        break;

                                    case 5:
                                        Display = "REPORTS";
                                        ContollerName = MenuUrl.Adm_Report_controller;
                                        ActionName = MenuUrl.Adm_Report_ActionResult;
                                        ParameterName = MenuUrl.Adm_Report_Parameters;
                                        break;

                                    case 6:
                                        Display = "FACILITIES";
                                        ContollerName = MenuUrl.Adm_Facility_controller;
                                        ActionName = MenuUrl.Adm_Facility_ActionResult;
                                        ParameterName = MenuUrl.Adm_Facility_Parameters;
                                        break;

                                    // ------- Patient Menu

                                    case 7:
                                        Display = "DASHBOARD";
                                        ContollerName = MenuUrl.Patient_DeshBoard_controller;
                                        ActionName = MenuUrl.Patient_DeshBoard_ActionResult;
                                        break;
                                    case 8:
                                        Display = "INJECTION";
                                        ContollerName = MenuUrl.Patient_Injection_controller;
                                        ActionName = MenuUrl.Patient_Injection_ActionResult;
                                        break;

                                    case 9:
                                        Display = "WOMAC";
                                        ContollerName = MenuUrl.Patient_Womac_controller;
                                        ActionName = MenuUrl.Patient_Womac_ActionResult;
                                        break;

                                    case 10:
                                        Display = "BMI";
                                        ContollerName = MenuUrl.Patient_Bmi_controller;
                                        ActionName = MenuUrl.Patient_Bmi_ActionResult;
                                        break;

                                    case 11:
                                        Display = "ALERTS";
                                        ContollerName = MenuUrl.Patient_Alert_controller;
                                        ActionName = MenuUrl.Patient_Alert_ActionResult;
                                        break;

                                }

                                MItems.Add(new MenuItem
                                {
                                    Id = Convert.ToInt32(ds.Tables[0].Rows[i]["MainMenuId"].ToString()),
                                    Name = Display,
                                    ControllerName = ContollerName,
                                    ActionName = ActionName,
                                    ParameterList = ParameterName
                                });
                            }
                        }
                    }

                    // string AllowWomac = ds.Tables[1].Rows[0][0].ToString();
                    //  Session["AllowWomacComplete"] = AllowWomac.ToLower();

                    M.MenuItems = MItems;
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            return PartialView("_MenuLayout", M);
        }

        [HttpGet]
        public ActionResult UserTypeList(int FormId)
        {
            int No = 0;
            Session["AccessFormId"] = FormId;
            UserLevelList model = new UserLevelList();
            ViewBag.ErrorMessage = GetPatientInformation.ErrorMessage;
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    List<UserLevel> UserLevelDetail = new List<UserLevel>();
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    Session["CreateUser"] = Connection.AllowSave; //== "True" ? 1 : 0;
                    if (Allowed == 1)
                    {
                        string qury=null;
                        if (LUTypeId == 2)
                        {
                            qury = "select * from userrole where Isactive='" + 1 + "' and R_Id !='" + 1 + "'";
                        }
                        else
                        {
                            qury = "select * from userrole where Isactive='" + 1 + "'";
                        }

                        MySqlCommand cmd = new MySqlCommand(qury, obj.con);
                        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                No++;
                                UserLevelDetail.Add(new UserLevel
                                {
                                    SrNo = No,
                                    UserTypeId = Convert.ToInt32(dt.Rows[i]["R_id"].ToString()),
                                    UserType = dt.Rows[i]["R_name"].ToString(),
                                    Edit = Connection.AllowUpdate,
                                    Delete = Connection.AllowDelete
                                });
                            }
                        }
                    }
                    model.userLevelList = UserLevelDetail;
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch
            {
            }
            return View(model);
        }

        [HttpGet]
        public ActionResult UsertypeAuthentication(string userTypeId)
        {
            //Session["AccessFormId"] = 3;
            Connection.UserId = userTypeId;
            Session["SelectedUserId"] = userTypeId;
            UserLevelAouthenticationList model = new UserLevelAouthenticationList();
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {

                    if (Session["UserIdentityForLayOut"] != null)
                    {
                        List<UserLevelAouthentication> userLevelAouthenticationDetail = new List<UserLevelAouthentication>();
                        string Query = "select t1.MainMenuId,t1.MainMenuName,t2.R_id,t2.view from mainmenunavigation t1 INNER JOIN mainnavigationauthentication t2 on t1.MainMenuId=t2.MainMenuId where t2.R_id='" + userTypeId + "'";
                        MySqlCommand cmd = new MySqlCommand(Query, obj.con);
                        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                userLevelAouthenticationDetail.Add(new UserLevelAouthentication
                                {
                                    FormId = Convert.ToInt32(dt.Rows[i]["MainMenuId"].ToString()),
                                    Displayvalue = dt.Rows[i]["MainMenuName"].ToString(),
                                    Showform = Convert.ToInt16(dt.Rows[i]["view"].ToString())
                                });
                            }
                        }
                        else
                        {

                            Query = "SELECT  	MainMenuId,MainMenuName,'0' as view FROM `mainmenunavigation`";
                            cmd = new MySqlCommand(Query, obj.con);
                            da = new MySqlDataAdapter(cmd);
                            dt = new DataTable();
                            da.Fill(dt);




                            if (dt.Rows.Count > 0)
                            {
                                for (int i = 0; i < dt.Rows.Count; i++)
                                {
                                    userLevelAouthenticationDetail.Add(new UserLevelAouthentication
                                    {
                                        R_id = userTypeId,
                                        FormId = Convert.ToInt32(dt.Rows[i]["MainMenuId"].ToString()),
                                        Displayvalue = dt.Rows[i]["MainMenuName"].ToString(),
                                        Showform = Convert.ToInt16(dt.Rows[i]["view"].ToString())
                                    });
                                }
                            }
                        }
                        model.userLevelAouthenticationlList = userLevelAouthenticationDetail;
                    }
                    else
                    {
                        return RedirectToAction("UsertypeAuthentication", "DynamicMenu");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
            }
            return View(model);

        }

        [HttpGet]
        public JsonResult Getflag(int id)
        { 
           int flag=0;
        try{
           int SessionState = CheckSession(1);
           if (SessionState == 1)
           {
               string query = "Select   IFNULL(Flag,'0') AS Flag from userregister where R_Id='"+id+"'";
               MySqlCommand cmd = new MySqlCommand(query,obj.con);
               MySqlDataAdapter da = new MySqlDataAdapter(cmd);
               DataTable dt = new DataTable();
               da.Fill(dt);
               if (dt.Rows.Count > 0)
               {
                   flag =Convert.ToInt16(dt.Rows[0]["Flag"]);
               }
           }
           else
           {
               return Json(flag, JsonRequestBehavior.AllowGet);
           }
          }
            catch(Exception ex)
           {
               return Json(ex.Message, JsonRequestBehavior.AllowGet);
           }
        return Json(flag, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult AddToWomacDropdown(int userTypeId)
        {
            ViewBag.usertype = userTypeId;
            return View();
        }

        [HttpPost]
        public JsonResult AddToWomacDropdownList(UserModel model)
        {
            string data=null;
          
            int success = 0;
             try
            {
                
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    string query = "update userregister set Flag=@flag where R_Id=@R_Id";
                    MySqlCommand cmd = new MySqlCommand(query,obj.con);
                    cmd.Parameters.AddWithValue("@flag",model.Flag);
                    cmd.Parameters.AddWithValue("@R_Id",model.UserType);
                    if (obj.con.State == ConnectionState.Closed)
                    {
                        obj.con.Open();
                    }
                      success = cmd.ExecuteNonQuery();
                      if (obj.con.State == ConnectionState.Open)
                      {
                          obj.con.Close();
                      }
                }
                else
                {
                    return Json(success, JsonRequestBehavior.AllowGet);
                }
            }
             catch (Exception e)
             {
                 return Json(success, JsonRequestBehavior.AllowGet);
             }
             return Json(success, JsonRequestBehavior.AllowGet);
        }


        public ActionResult UserViewAuthentication(int userTypeId, FormCollection frm)
        {
            GetPatientInformation.ErrorMessage = "";
            Session["SelectedUserId"] = userTypeId;
            UserLevelViewAouthenticationList model = new UserLevelViewAouthenticationList();
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    if (Session["UserIdentityForLayOut"] != null)
                    {
                        List<UserLevelViewAouthentication> userLevelViewAouthenticationDetail = new List<UserLevelViewAouthentication>();
                        string Query = "select t2.AuthenticationId,t1.MenuId,t1.MenuName,t3.SectionId,t3.SectionName,t2.R_id,t2.FormShow,t2.ImageUrl,t2.SelectAll,t2.view,t2.Update,t2.Delete,t2.Save,t2.Print from mainmenu t1 INNER JOIN userauthentication t2 on t1.MenuId=t2.MenuId INNER JOIN viewsections t3 on t2.SectionId = t3.SectionId where t2.R_id='" + userTypeId + "' ";

                        MySqlCommand cmd = new MySqlCommand(Query, obj.con);
                        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                        DataSet ds = new DataSet();
                        da.Fill(ds);

                        if (ds.Tables[0].Rows.Count != 0)
                        {
                            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                            {
                                userLevelViewAouthenticationDetail.Add(new UserLevelViewAouthentication
                                {
                                    FormId = Convert.ToInt32(ds.Tables[0].Rows[i]["AuthenticationId"].ToString()),
                                    MainMenu = ds.Tables[0].Rows[i]["MenuName"].ToString(),
                                    Displayvalue = ds.Tables[0].Rows[i]["SectionName"].ToString(),
                                    Showform = Convert.ToInt16(ds.Tables[0].Rows[i]["view"].ToString()),
                                    Saveform = Convert.ToInt16(ds.Tables[0].Rows[i]["Save"].ToString()),
                                    UpdateForm = Convert.ToInt16(ds.Tables[0].Rows[i]["Update"].ToString()),
                                    DeleteForm = Convert.ToInt16(ds.Tables[0].Rows[i]["Delete"].ToString()),
                                    printFrom = Convert.ToInt16(ds.Tables[0].Rows[i]["Print"].ToString())

                                });
                            }
                            //}
                            model.userLevelViewAouthenticationlList = userLevelViewAouthenticationDetail;
                            return View(model);
                        }
                        else
                        {
                            string Query1 = "select t2.AuthenticationId,t1.MenuId,t1.MenuName,t3.SectionId,t3.SectionName,t2.R_id,t2.FormShow,t2.ImageUrl,t2.SelectAll,t2.view,t2.Update,t2.Delete,t2.Save,t2.Print from mainmenu t1 INNER JOIN userauthentication t2 on t1.MenuId=t2.MenuId INNER JOIN viewsections t3 on t2.SectionId = t3.SectionId group by t3.SectionName";
                            // string Query1 = "select t2.AuthenticationId,t1.MenuId,t1.MenuName,t3.SectionId,t3.SectionName,t2.R_id,t2.FormShow,t2.ImageUrl,t2.SelectAll,'0' as t2.view ,'0' as t2.Update,'0' as t2.Delete,'0' as t2.Save,'0' as t2.Print from mainmenu t1 INNER JOIN userauthentication t2 on t1.MenuId=t2.MenuId INNER JOIN viewsections t3 on t2.SectionId = t3.SectionId group by t3.SectionName";

                            MySqlCommand cmd1 = new MySqlCommand(Query1, obj.con);
                            MySqlDataAdapter da1 = new MySqlDataAdapter(cmd1);
                            DataSet ds1 = new DataSet();
                            da1.Fill(ds1);
                            if (ds1.Tables[0].Rows.Count != 0)
                            {
                                for (int i = 0; i < ds1.Tables[0].Rows.Count; i++)
                                {
                                    userLevelViewAouthenticationDetail.Add(new UserLevelViewAouthentication
                                    {
                                        FormId = Convert.ToInt32(ds1.Tables[0].Rows[i]["AuthenticationId"].ToString()),
                                        MainMenu = ds1.Tables[0].Rows[i]["MenuName"].ToString(),
                                        Displayvalue = ds1.Tables[0].Rows[i]["SectionName"].ToString(),
                                        Showform = '0',
                                        Saveform = '0',
                                        UpdateForm = '0',
                                        DeleteForm = '0',
                                        printFrom = '0'


                                        //Showform = Convert.ToInt16(ds1.Tables[0].Rows[i]["view"].ToString()),
                                        //Saveform = Convert.ToInt16(ds1.Tables[0].Rows[i]["Save"].ToString()),
                                        //UpdateForm = Convert.ToInt16(ds1.Tables[0].Rows[i]["Update"].ToString()),
                                        //DeleteForm = Convert.ToInt16(ds1.Tables[0].Rows[i]["Delete"].ToString()),
                                        //printFrom = Convert.ToInt16(ds1.Tables[0].Rows[i]["Print"].ToString())

                                    });
                                }
                                //}
                                model.userLevelViewAouthenticationlList = userLevelViewAouthenticationDetail;
                                return View(model);

                                //return RedirectToAction("UserTypeList", "DynamicMenu", new { FormId = 36 });
                            }
                        }
                    }
                    else
                    {
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }

                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
            return View(model);
        }

        [HttpPost]
        public ActionResult UserViewAuthentication(string gridData)
        {
            int SuccessId = 0;
            int UserTypeId = Session["SelectedUserId"] != null ? Convert.ToInt32(Session["SelectedUserId"].ToString()) : 0;
            DataTable dtValue = (DataTable)JsonConvert.DeserializeObject(gridData, (typeof(DataTable)));
            FormCollection form = new FormCollection();
            GetPatientInformation.ErrorMessage = "";

            try
            {
                string Query = "", MainMenu;

                int UTId, Mid, ShV, SaV, UpV, DeV, PrV;
                if (Session["UserIdentityForLayOut"] != null)
                {

                    for (int i = 0; i <= dtValue.Rows.Count - 1; i++)
                    {
                        UTId = Convert.ToInt16(Connection.UserId.ToString());
                        Mid = Convert.ToInt16(dtValue.Rows[i][1].ToString());

                        ShV = Convert.ToInt16(dtValue.Rows[i]["Show"].ToString() == "on" ? "1" : "0");
                        SaV = Convert.ToInt16(dtValue.Rows[i]["Save"].ToString() == "on" ? "1" : "0");
                        UpV = Convert.ToInt16(dtValue.Rows[i]["Update"].ToString() == "on" ? "1" : "0");
                        DeV = Convert.ToInt16(dtValue.Rows[i]["Delete"].ToString() == "on" ? "1" : "0");
                        PrV = Convert.ToInt16(dtValue.Rows[i]["Print"].ToString() == "on" ? "1" : "0");
                        MainMenu = dtValue.Rows[i]["MainMenu"].ToString();
                          MySqlCommand cmd = new MySqlCommand("Select  'view','Update','Delete','Save','Print' from userauthentication WHERE `AuthenticationId` = '" + Mid + "' and `R_id`='" + UserTypeId + "'", obj.con);
                        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            for (int j = 0; j < dt.Rows.Count; j++)
                            {
                                MySqlCommand cmd1 = new MySqlCommand("UPDATE `userauthentication` SET `view`=" + ShV + ", `Update`=" + UpV + ", `Delete`=" + DeV + ", `Save`=" + SaV + ", `Print`=" + PrV + " WHERE `AuthenticationId` = " + Mid + " and `R_id`=" + UserTypeId + "", obj.con);
                                obj.OpenDbConnection();
                                SuccessId = cmd1.ExecuteNonQuery();
                                obj.CloseDbConnection();
                            }
                        }
                        else
                        {
                            //MySqlCommand cmd1 = new MySqlCommand("insert into userauthentication(R_id, 'view', 'Update', 'Delete', 'Save', 'Print')values('" + UserTypeId + "','" + ShV + "','" + UpV + "','" + DeV + "','" + SaV + "','" + PrV + "' )", obj.con);
                            //obj.OpenDbConnection();
                            //SuccessId = cmd1.ExecuteNonQuery();
                            //obj.CloseDbConnection();
                        }
                    }
                    GetPatientInformation.ErrorMessage = "User Permission are Modified Successfully";
                    return Json(SuccessId);
                }
                else
                {
                    GetPatientInformation.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch
            {
                GetPatientInformation.ErrorMessage = "Some thing is not right Please Contact with Developer Team";
                return RedirectToAction("UserLevel", "Admin");

            }
        }

        [HttpPost]
        public ActionResult UsertypeAuthentications(string gridData)
        {
            int SuccessId = 0;

            int UserTypeId = Session["SelectedUserId"] != null ? Convert.ToInt32(Session["SelectedUserId"].ToString()) : 0;
            DataTable dtValue = (DataTable)JsonConvert.DeserializeObject(gridData, (typeof(DataTable)));
            FormCollection form = new FormCollection();
            GetPatientInformation.ErrorMessage = "";

            try
            {
                int UTId, Mid, ShV;

                if (Session["UserIdentityForLayOut"] != null)
                {
                    

                    for (int i = 0; i <= dtValue.Rows.Count - 1; i++)
                    {


                        UTId = Convert.ToInt16(Connection.UserId.ToString());
                        Mid = Convert.ToInt16(dtValue.Rows[i][0].ToString());
                        ShV = Convert.ToInt16(dtValue.Rows[i][3].ToString() == "on" ? "1" : "0");

                        MySqlCommand cmd = new MySqlCommand("select view from mainnavigationauthentication WHERE `MainMenuId` = " + Mid + " and `R_id` =" + UserTypeId + "", obj.con);
                        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            MySqlCommand cmd1 = new MySqlCommand("UPDATE `mainnavigationauthentication`  SET `view` =" + ShV + " WHERE `MainMenuId` = " + Mid + " and `R_id` =" + UserTypeId + "", obj.con);
                            obj.OpenDbConnection();
                            SuccessId = cmd1.ExecuteNonQuery();
                            obj.CloseDbConnection();
                        }
                        else
                        {
                            MySqlCommand cmd2 = new MySqlCommand("insert into mainnavigationauthentication(view,MainMenuId,R_id)values('" + ShV + "','" + Mid + "','" + UserTypeId + "')", obj.con);
                            obj.OpenDbConnection();
                            SuccessId = cmd2.ExecuteNonQuery();
                            obj.CloseDbConnection();
                       
                        }
                    }

                    GetPatientInformation.ErrorMessage = "User Permission are Modified Successfully";
                    return Json(SuccessId);
                }
                else
                {
                    GetPatientInformation.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch
            {
                GetPatientInformation.ErrorMessage = "Some thing is not right Please Contact with Developer Team";
                return RedirectToAction("UserLevel", "Admin");

            }
        }

        [HttpGet]
        public ActionResult UserLogDetail(int FacilityId = 0)

        {
           
                if (FacilityId == 0)
                {
                    FacilityId = Convert.ToInt16(Session["LoggedInFacilityId"].ToString());
                }

                var tupleModel = new Tuple<UserList, UserLogDetailList>(GetuserDetail(FacilityId), GetuserLogDetail(FacilityId));

                return View(tupleModel);
            
        }

        public UserList GetuserDetail(int FacilityId)
        {
            int Num = 0;
            UserList UL = new UserList();
            try
            {
                List<UserDetail> userDetail = new List<UserDetail>();

                string location = GetFacilityName(FacilityId);
                ViewBag.LocationName = location;

                MySqlCommand cmd = new MySqlCommand("select t1.U_Id,t1.F_Name,t1.L_Name,t1.EmailId,t3.Location,t2.R_id,t2.R_name from userregister t1 inner join userrole t2 on t1.R_id=t2.R_id inner join facility t3 on t1.FacilityId=t3.FacilityId where t1.FacilityId='" + FacilityId + "' and t1.R_id!='" + "10" + "'", obj.con);

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataSet ds1 = new DataSet();
                da.Fill(ds1);
                if (ds1.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < ds1.Tables[0].Rows.Count; i++)
                    {
                        Num++;
                        string UN = SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["L_Name"].ToString());
                        userDetail.Add(new UserDetail
                        {
                            SNo = Num,
                            UserId = SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["U_Id"].ToString()),
                            UserTypeId = Convert.ToInt32(ds1.Tables[0].Rows[i]["R_id"].ToString()),
                            UserType = ds1.Tables[0].Rows[i]["R_name"].ToString(),
                            Email = SecurityManager.Decrypt(ds1.Tables[0].Rows[i]["EmailId"].ToString()),
                            FirstName = UN,
                            LocationName = ds1.Tables[0].Rows[i]["Location"].ToString()
                        });
                    }
                }
                UL.userList = userDetail;
            }
            catch (Exception e)
            {
            }
            return UL;
        }

        public UserLogDetailList GetuserLogDetail(int FacilityId)
        {
            int No = 0;
            DbConnection obj = new DbConnection();
            UserLogDetailList ULD = new UserLogDetailList();
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    string UserEmailId = Session["UserIdentityForLayOut"].ToString();
                    Connection.FacilityId = FacilityId;
                    List<UserLogDetail> userLogDetailList = new List<UserLogDetail>();
                    MySqlCommand cmd = new MySqlCommand("select distinct t3.LogId,t1.FacilityId,t3.U_Id,t3.R_id,t2.R_name,t3.LoginOn,t3.LogTime,t3.ViewName,t3.OperationName,t3.Detail,t3.System_IP,t3.ModifiedRecord,t3.DetailForUserView from userregister t1 inner join userrole t2 on t1.R_id=t2.R_id inner join userlogdetails t3 on t1.R_id=t3.R_id where t1.FacilityId='" + FacilityId + "' group by t3.LogId ", obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        Connection.LoginUserTypeId = Convert.ToInt32(dt.Rows[0]["R_id"].ToString());
                        Connection.LoginUserId = dt.Rows[0]["U_Id"].ToString();
                        Connection.Email = UserEmailId;
                        

                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            No++;

                            userLogDetailList.Add(new UserLogDetail
                            {
                                SrNo = No,
                                Sno = Convert.ToInt32(dt.Rows[i]["LogId"].ToString()),
                                UserTypeId = Convert.ToInt32(dt.Rows[i]["R_id"].ToString()),
                                UserId = SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                UserEmailId = UserEmailId,
                                Date = Convert.ToDateTime(dt.Rows[i]["LoginOn"].ToString()).ToString("MMM-dd-yyyy"),
                                Time = Convert.ToDateTime(dt.Rows[i]["LogTime"].ToString()).ToString("HH:mm:ss"),
                                ViewName = dt.Rows[i]["ViewName"].ToString(),
                                OperationName = dt.Rows[i]["OperationName"].ToString(),
                                Detail = dt.Rows[i]["Detail"].ToString(),
                                SystemIP = dt.Rows[i]["System_IP"].ToString(),
                                ModifiedRecord = SecurityManager.Decrypt(dt.Rows[i]["ModifiedRecord"].ToString()),
                                DetailForUserView = dt.Rows[i]["DetailForUserView"].ToString()
                            });
                        }
                    }
                    ULD.userLogDetailList = userLogDetailList;
                }
            }
            catch (Exception e)
            {
            }
            return ULD;
        }

        [HttpGet]
        public JsonResult GetOperationList()
        {

            List<SelectListItem> OperationList = new List<SelectListItem>();
            MySqlCommand cmd = new MySqlCommand("select Distinct OperationName from userlogdetails", obj.con);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    OperationList.Add(new SelectListItem { Text = dt.Rows[i]["OperationName"].ToString(), Value = dt.Rows[i]["OperationName"].ToString() });
                }
            }
            ViewBag.PolicyList = OperationList;
            return Json(OperationList, JsonRequestBehavior.AllowGet);
        }


        public ActionResult UserTypeDelete(int TypeId)
        {
            try
            {
                MySqlCommand cmd = new MySqlCommand("UPDATE  `userrole`  SET   `Isactive`=0  where  `R_id`= '" + TypeId + "'", obj.con);
                obj.OpenDbConnection();
                cmd.ExecuteNonQuery();
                obj.OpenDbConnection();
            }
            catch (Exception)
            {
                obj.OpenDbConnection();
            }

            return RedirectToAction("UserTypeList", "DynamicMenu", new { FormId = 36 });
        }

        [HttpPost]
        public ActionResult UserLogDetail(UserLogDetail Model, string param1, string param2, string FilterId)
        {


            int No = 0;
            UserLogDetailList ULD = new UserLogDetailList();
            DateTime time =Convert.ToDateTime(Model.DateFrom);
            DateTime time1 = Convert.ToDateTime(Model.DateTo);// Use current time.
            string format = "yyyy-mm-dd";   // Use this format.
          //  Console.WriteLine();
            var date = time.Day;
            var mon = time.Month;
            var year = time.Year;
            var dateform = year + "-" + mon + "-" + date;

            var date1 = time1.Day;
            var mon1 = time1.Month;
            var year1 = time1.Year;
            var datato = year1 + "-" + mon1 + "-" + date1;

            var s = time.ToString(format);
            try
            {
                GetPatientInformation.ErrorMessage = "Last 20 Log's About All Users";
                if (FilterId == "5")
                {

                }
                if (FilterId == "7")
                {
                    List<UserLogDetail> userLogDetailList = new List<UserLogDetail>();
                    MySqlCommand cmd = new MySqlCommand("select distinct t3.LogId,t1.FacilityId,t3.U_Id,t3.R_id,t2.R_name,t3.LoginOn,t3.LogTime,t3.ViewName,t3.OperationName,t3.Detail,t3.System_IP,t3.ModifiedRecord,t3.DetailForUserView from userregister t1 inner join userrole t2 on t1.R_id=t2.R_id inner join userlogdetails t3 on t1.R_id=t3.R_id where t1.FacilityId='" + Connection.FacilityId + "' and t3.LoginOn between'" + dateform + "' and '" + datato + "' group by t3.LogId ", obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            No++;
                            userLogDetailList.Add(new UserLogDetail
                            {
                                SrNo = No,
                                Sno = Convert.ToInt32(dt.Rows[i]["LogId"].ToString()),
                                UserTypeId = Convert.ToInt32(dt.Rows[i]["R_id"].ToString()),
                                UserId = SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                UserEmailId = Connection.Email,
                                Date = Convert.ToDateTime(dt.Rows[i]["LoginOn"].ToString()).ToString("MMM-dd-yyyy"),
                                Time = Convert.ToDateTime(dt.Rows[i]["LogTime"].ToString()).ToString("HH:mm:ss"),
                                ViewName = dt.Rows[i]["ViewName"].ToString(),
                                OperationName = dt.Rows[i]["OperationName"].ToString(),
                                Detail = dt.Rows[i]["Detail"].ToString(),
                                SystemIP = dt.Rows[i]["System_IP"].ToString(),
                                ModifiedRecord = SecurityManager.Decrypt(dt.Rows[i]["ModifiedRecord"].ToString()),
                                DetailForUserView = dt.Rows[i]["DetailForUserView"].ToString()
                            });
                        }

                        ULD.userLogDetailList = userLogDetailList;
                    }
                }
                if (FilterId == "10")
                {
                    List<UserLogDetail> userLogDetailList = new List<UserLogDetail>();
                    MySqlCommand cmd = new MySqlCommand("select distinct t3.LogId,t1.FacilityId,t3.U_Id,t3.R_id,t2.R_name,t3.LoginOn,t3.LogTime,t3.ViewName,t3.OperationName,t3.Detail,t3.System_IP,t3.ModifiedRecord,t3.DetailForUserView from userregister t1 inner join userrole t2 on t1.R_id=t2.R_id inner join userlogdetails t3 on t1.R_id=t3.R_id where t1.FacilityId='" + Connection.FacilityId + "' and t3.OperationName ='" + Model.OperationName + "' group by t3.LogId ", obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {

                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            No++;
                            userLogDetailList.Add(new UserLogDetail
                            {
                                SrNo = No,
                                Sno = Convert.ToInt32(dt.Rows[i]["LogId"].ToString()),
                                UserTypeId = Convert.ToInt32(dt.Rows[i]["R_id"].ToString()),
                                UserId = SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                UserEmailId = Connection.Email,
                                Date = Convert.ToDateTime(dt.Rows[i]["LoginOn"].ToString()).ToString("MMM-dd-yyyy"),
                                Time = Convert.ToDateTime(dt.Rows[i]["LogTime"].ToString()).ToString("HH:mm:ss"),
                                ViewName = dt.Rows[i]["ViewName"].ToString(),
                                OperationName = dt.Rows[i]["OperationName"].ToString(),
                                Detail = dt.Rows[i]["Detail"].ToString(),
                                SystemIP = dt.Rows[i]["System_IP"].ToString(),
                                ModifiedRecord = SecurityManager.Decrypt(dt.Rows[i]["ModifiedRecord"].ToString()),
                                DetailForUserView = dt.Rows[i]["DetailForUserView"].ToString()
                            });
                        }

                        ULD.userLogDetailList = userLogDetailList;
                    }
                }
            }
            catch (Exception e)
            {
            }
            return PartialView("_UserLogDetailList", ULD);
        }

    }
}