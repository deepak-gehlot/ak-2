﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.BussinessLayer;
using NewAPGApplication.Models;
using System.Web.Security;


namespace NewAPGApplication.Controllers
{
    public class PatientController : Controller
    {
        DbConnection obj = new DbConnection();

        string Success = null;
        string UserID, EmailID;
        int RoleId = 10;
        bool RememberMe = true;

        public int CheckSession(int CheckNo)
        {
            int returnValue = 0;
            if (CheckNo == 1)
            {
                if ((Session["UserIdentityForLayOut"] != null) || (Session["UserId"] != null))
                {
                    if (Session["LoginUserId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            if (CheckNo == 2)
            {
                if ((Session["UserIdentityForLayOut"] != null) || (Session["UserId"] != null))
                {
                    if (Session["UserTypeId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            return returnValue;
        }


        public ActionResult MyIndex() //- old Registration Page (Not Use
        {
            return View();
        }

        public ActionResult NewIndex() //- New Registration
        {
            return View();
        }

        public ActionResult NewIndex_PatientInfo(string param) //- New Registration Second Part
        {
            param = param == null ? "Patient Platform Setting" : param;

            try
            {
                PatientRegistration ob = new PatientRegistration();
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    string tempUserLoginType = Session["LoginUserType"].ToString();
                    int Allowed = 1;
                    if (Allowed == 1)
                    {
                        string tempemail = Session["EmailId"] != null ? Session["EmailId"].ToString() : "";
                        string tempUserNameId = Session["UserId"] != null ? Session["UserId"].ToString() : "";

                        if (tempUserLoginType == "Patient")
                        {
                            Session["PatientIsActive"] = false;
                        }
                        Session["UserIsActive"] = null;
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "User Session TimeOut";
                        return RedirectToAction("LogOut", "Account");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
                return View(ob);
            }
            catch
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        public ActionResult Insurence()
        {
              int SessionState = CheckSession(1);
              if (SessionState == 1)
              {

                  string tempUserNameId = Session["TempPatientId"] != null ? SecurityManager.Encrypt(Session["TempPatientId"].ToString()) : SecurityManager.Encrypt(Session["UserId"].ToString());

                  MySqlCommand cmd1 = new MySqlCommand("SELECT * FROM userregister where U_Id=@U_Id", obj.con);
                  cmd1.Parameters.AddWithValue("@U_Id", tempUserNameId);
                  MySqlDataAdapter asd1 = new MySqlDataAdapter(cmd1);
                  DataTable dt1 = new DataTable();
                  asd1.Fill(dt1);
                  if (dt1.Rows.Count > 0)
                  {
                      return View();
                  }
                  else
                  {
                      return View();
                  }
              }
              else
              {
                  return RedirectToAction("LogOut", "Account");
              }
        }

        public ActionResult ThankYou()
        {
            string tempemail = Session["EmailId"] != null ? Session["EmailId"].ToString() : "";
            string tempUserNameId = Session["UserId"] != null ? Session["UserId"].ToString() : "";

            FormsAuthentication.SetAuthCookie(tempUserNameId.ToLower(), RememberMe);

            MySqlCommand cmd1 = new MySqlCommand("SELECT * FROM userregister where U_Id=@U_Id", obj.con);
            cmd1.Parameters.AddWithValue("@U_Id", SecurityManager.Decrypt(tempUserNameId));
            MySqlDataAdapter asd1 = new MySqlDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            asd1.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                Session["LoginUserId"] = SecurityManager.Decrypt(dt1.Rows[0]["U_Id"].ToString());
                if (dt1.Rows[0][1].ToString() == "10")        // 10 is RoleId Of Patient
                {
                    //Session["UserIdentityForLayOut"] = tempUserNameId;

                    Session["UserNameId"] = tempUserNameId;
                    Session["UserEmailId"] = tempemail;
                    Session["HeaderType"] = "10";
                    Session["UserTypeId"] = dt1.Rows[0]["R_Id"].ToString();
                    Session["UserId"] = SecurityManager.Decrypt(dt1.Rows[0]["U_Id"].ToString());
                    Session["UserType"] = "Patient";
                    Session["LoginUserType"] = "Patient";
                }
            }

            return View();
        }

        public ActionResult PatientInformation(string param)
        {
            param = param == null ? "Patient Platform Setting" : param;

            try
            {
                PatientRegistration ob = new PatientRegistration();
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    string tempUserLoginType = Session["LoginUserType"].ToString();
                    int Allowed = 1;
                    if (Allowed == 1)
                    {
                        string tempemail = Session["EmailId"] != null ? Session["EmailId"].ToString() : "";
                        string tempUserNameId = Session["UserId"] != null ? Session["UserId"].ToString() : "";

                        if (tempUserLoginType == "Patient")
                        {
                            Session["PatientIsActive"] = false;
                        }
                        Session["UserIsActive"] = null;
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "User Session TimeOut";
                        return RedirectToAction("LogOut", "Account");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
                return View(ob);
            }
            catch
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        [HttpPost]
        public ActionResult PutPatientInfo(PatientRegistration ObjPi)
        {
            var ret = Success;
         int SessionState = CheckSession(1);
         if (SessionState == 1)
         {
             try
             {
                 //string Patentemail = null;
                 //if (Session["patientEmailid"] != null)
                 //{
                 //    Patentemail = Session["patientEmailid"].ToString();
                 //}

                 PatientInfoPut ob = new PatientInfoPut();
                 string result = ob.PatientInfoData(ObjPi);
                 string RID = Session["UserTypeId"].ToString();

                 string Access = RID != "10" ? "1" : "2";
                 Session["patientEmailid"] = null;
                 ViewData["result"] = Access;
                 Success = Access;
                 ret = Success;
                 return Json(ret);
             }
             catch (Exception)
             {
                 ret = Success;
                 return Json(ret);
             }
         }
         else
         {
             return RedirectToAction("LogOut", "Account");
         }
        }

        [HttpPost]
        public ActionResult PatientInsurance(Insurance ObjI)
        {
            var ret = Success;
            try
            {
                PatientInfoPut ob = new PatientInfoPut();
                string result = ob.PutPatientInsurance(ObjI);
                ViewData["result"] = result;
                Success = result;
                ret = Success;
                return Json(ret);
            }
            catch (Exception)
            {
                ret = Success;
                return Json(ret);
            }
        }

        public ActionResult PatientProfileIndex(string param)
        {
            return View(1);           
        }

        public ActionResult PatientActivation(FormCollection From,int FormId,string Filtername)
        { 
            PatientList model = new PatientList();
            try
            {
                 int SessionState = CheckSession(1);
                 if (SessionState == 1)
                 {
                       int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                       int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                       if (Allowed == 1)
                       {
                           Session["AccessFormId"] = FormId;
                           int tempFacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                         //  int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                           if (Session["SuccessActivation"] != null)
                           {
                               if (Session["SuccessActivation"].ToString() == "True")
                               {
                                   Session["SuccessActivation"] = "False";
                               }
                           }
                           //  var Name = From["Name"];
                           var Name = Filtername;
                           ViewBag.searchname = Name;
                           if (!String.IsNullOrEmpty(Name))
                           {
                               model = GetFilterRecord.GetPatientListForActive(Name, FormId, tempFacilityId, LUTypeId);
                           }
                           else
                           {
                               model = GetPatientInformation.GetPatientListForActive(FormId, tempFacilityId, LUTypeId);
                           }
                           return View(model);
                       }
                       else
                       {
                           ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                           return RedirectToAction("AdminIndex", "Admin");
                       }
                 }
                 else
                 {
                     return RedirectToAction("LogOut", "Account");
                 }
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }
        public ActionResult PatientActivationReset(FormCollection From, int FormId, string Filtername)
        {
            PatientList model = new PatientList();
            try
            {
                Session["AccessFormId"] = FormId;
                int tempFacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                if (Session["SuccessActivation"] != null)
                {
                    if (Session["SuccessActivation"].ToString() == "True")
                    {
                        Session["SuccessActivation"] = "False";
                    }
                }
                //  var Name = From["Name"];
                var Name = Filtername;
                ViewBag.searchname = Name;
                {
                    model = GetPatientInformation.GetPatientListForActive(FormId, tempFacilityId, LUTypeId);
                }
                return View("PatientActivation", model);

            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }
       

        public ActionResult PatientActivated(string PatientId)
        {
            DateTime ActivateDate = DateTime.Parse(DateTime.Now.ToString());
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    int SuccessId = 0;
                    MySqlCommand cmd = new MySqlCommand("update userregister set IsActive='" + 1 + "' where U_Id='" +SecurityManager.Encrypt( PatientId )+ "'", obj.con);                  
                    obj.OpenDbConnection();
                    SuccessId = cmd.ExecuteNonQuery();                   
                    obj.CloseDbConnection();
                    Session["SuccessActivation"] = "True";

                    // Activation Date 

                    MySqlCommand cmd1 = new MySqlCommand("update patient_otherinfo set ActivatedOn='" + Convert.ToDateTime(ActivateDate).ToString("yyyy-MM-dd") + "' where PatientId='" +SecurityManager.Encrypt( PatientId) + "'", obj.con);
                    obj.OpenDbConnection();
                    cmd1.ExecuteNonQuery();
                    obj.CloseDbConnection();

                    // User Logged Detail Start

                    string UserNameId = Session["LoginUserId"].ToString() != null ? Session["LoginUserId"].ToString() : Session["UserNameId"].ToString();
                    UserLogDetail ULD = new UserLogDetail();
                    ULD.UserTypeId = Convert.ToInt16(Session["UserTypeId"].ToString() != "" ? Convert.ToInt16(Session["UserTypeId"].ToString()) : 0);
                    ULD.UserId = SecurityManager.Encrypt(UserNameId);
                    ULD.ViewName = "Admin/PatientActivation";
                    ULD.OperationName = "Activation";
                    ULD.ModifiedRecord = PatientId;
                    ULD.Detail = "Patient Activated Successfully!";
                    ULD.DetailForUserView = "Patient Activated Successfully!";

                    int SuccessId1 = AdminClass.UserLogDetail(ULD);       // User Log Details Insert

                    // User Logged Detail End

                    return RedirectToAction("PatientActivation", new { FormId = "18" });
                }
                else
                {
                    return RedirectToAction("AdminIndex", "Admin");
                }
            }
            catch
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

        [HttpGet]
        public ActionResult UpdatePatientDetail(string PatientId)
        {
            try
            {
                PatientId = PatientId != null ? PatientId : SecurityManager.Encrypt(Session["UserId"].ToString());

                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());

                    int FormId = 31; // Update Profile detail

                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    if (Allowed == 1)
                    {
                        Session["PatientIsActive"] = "False";
                        MySqlCommand cmd2 = new MySqlCommand("select IsActive from userregister where U_Id='" + PatientId + "'", obj.con);
                        MySqlDataAdapter da = new MySqlDataAdapter(cmd2);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        if (dt.Rows.Count != 0)
                        {
                            Session["PatientIsActive"] = dt.Rows[0][0].ToString() == "1" ? "1" : "0";
                        }

                        Session["UpdateUser"] = Connection.AllowUpdate; //== "True" ? 1 : 0;
                        Session["DeleteUser"] = Connection.AllowDelete; //== "True" ? 1 : 0;
                        Session["SelectedUserId"] = PatientId;

                        return View();
                    }
                    else
                    {
                        return RedirectToAction("LogOut", "Account");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        public ActionResult UpdatePatientDetails(string PatientId)
        {
            try
            {
                PatientId = PatientId != null ? PatientId : SecurityManager.Encrypt(Session["UserId"].ToString());

                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());

                    int FormId = 4; // Update Profile detail

                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    if (Allowed == 1)
                    {
                        Session["PatientIsActive"] = "False";
                        MySqlCommand cmd2 = new MySqlCommand("select IsActive from userregister where U_Id='" +SecurityManager.Encrypt(PatientId) + "'", obj.con);
                        MySqlDataAdapter da = new MySqlDataAdapter(cmd2);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        if (dt.Rows.Count != 0)
                        {
                            Session["PatientIsActive"] = dt.Rows[0][0].ToString() == "1" ? "1" : "0";
                        }
                        Session["UpdateUser"] = string.Empty;
                        Session["UpdateUser"] = Connection.AllowUpdate; //== "True" ? 1 : 0;
                        Session["DeleteUser"] = Connection.AllowDelete; //== "True" ? 1 : 0;
                        Session["SelectedUserId"] = PatientId;

                        return View("UpdatePatientDetails");
                    }
                    else
                    {
                        return RedirectToAction("LogOut", "Account");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("LogOut", "Account");
            }
        }
                

        // --------Patient Deactivation

        public ActionResult PatientDeactive()
        {
            string PatientId=  Session["SelectedUserId"].ToString() ;
                     
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int Success = GetPatientInformation.PatientDeactive(PatientId);
                    if (Success >= 1)
                    {
                        //User Logged Detail Start

                        string UserNameId = Session["LoginUserId"].ToString() != null ? Session["LoginUserId"].ToString() : Session["UserNameId"].ToString();
                        UserLogDetail ULD = new UserLogDetail();
                        ULD.UserTypeId = Convert.ToInt16(Session["UserTypeId"].ToString() != "" ? Convert.ToInt16(Session["UserTypeId"].ToString()) : 0);
                        ULD.UserId = SecurityManager.Encrypt(UserNameId);
                        ULD.ViewName = "Admin/PatientDeactivate";
                        ULD.OperationName = "Deactivate Patient";
                        ULD.ModifiedRecord = PatientId;
                        ULD.Detail = "Patient Deactivated Successfully!";
                        ULD.DetailForUserView = "Patient Deactivated Successfully!";

                        int SuccessId1 = AdminClass.UserLogDetail(ULD);       // User Log Details Insert

                        //User Logged Detail End

                        Session.Remove("SelectedUserId");
                        return RedirectToAction("AdminIndex", "Admin");                                           
                    }
                    else
                    {
                        return RedirectToAction("AdminIndex", "Admin");                                         
                    }
                }
                else
                {
                    return RedirectToAction("AdminIndex", "Admin");                                 
                }
            }
            catch (Exception e)
            {
                string a = e.Message;
                return RedirectToAction("AdminIndex", "Admin");
            }
          
        }

        // --------Patient Deactivate List
       
        public ActionResult DeactivatePatientList(int FormId, FormCollection From,string Filtername)
        {
            PatientList model = new PatientList();
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    int FacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    Session["AccessFormId"] = FormId;

                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    if (Allowed == 1)
                    {
                        Session["CreateUser"] = Connection.AllowSave == "1" ? 1 : 0;
                       // var Name = From["Name"];
                        var Name = Filtername;
                        ViewBag.searchname = Name;
                        if (!String.IsNullOrEmpty(Name))
                        {
                             model = GetFilterRecord.GetDeactivePatientList(Name, FacilityId);
                        }
                        else
                        {
                            model = GetPatientInformation.GetDeactivePatientList(FacilityId);
                        }
                        return View(model);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

        [HttpPost]
        public ActionResult DeactivatePatientList_reset(int FormId,int reset)
        {
            PatientList model = new PatientList();
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    int FacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    Session["AccessFormId"] = FormId;

                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    if (Allowed == 1)
                    {
                        Session["CreateUser"] = Connection.AllowSave == "1" ? 1 : 0;
                        model = GetPatientInformation.GetDeactivePatientList(FacilityId);
                        return View("DeactivatePatientList", model);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                        return RedirectToAction("DashBoard", "Home");
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("DashBoard", "Home");
            }
        }
        // Patient Delete

        public ActionResult PatientDelete()
        {
             try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    string PatientId = Session["SelectedUserId"].ToString();
                    int Success = GetPatientInformation.PatientDelete(PatientId);
                    if (Success >= 1)
                    {
                        //User Logged Detail Start

                        string UserNameId = Session["LoginUserId"].ToString() != null ? Session["LoginUserId"].ToString() : Session["UserNameId"].ToString();
                        UserLogDetail ULD = new UserLogDetail();
                        ULD.UserTypeId = Convert.ToInt16(Session["UserTypeId"].ToString() != "" ? Convert.ToInt16(Session["UserTypeId"].ToString()) : 0);
                        ULD.UserId = SecurityManager.Encrypt(UserNameId);
                        ULD.ViewName = "Admin/PatientDelete";
                        ULD.OperationName = "Delete Patient";
                        ULD.ModifiedRecord = PatientId;
                        ULD.Detail = "Patient Delete Successfully!";
                        ULD.DetailForUserView = "Patient Delete Successfully!";

                        int SuccessId1 = AdminClass.UserLogDetail(ULD);       // User Log Details Insert

                        //User Logged Detail End
                        //Admin/PatientList?FormId=4
                        Session.Remove("SelectedUserId");
                        return RedirectToAction("PatientList", "Admin", new { FormId =4});
                    }
                    else
                    {
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }
                else
                {
                    return RedirectToAction("AdminIndex", "Admin");
                }
            }
            catch (Exception e)
            {
                string a = e.Message;
                return RedirectToAction("AdminIndex", "Admin");
            }

        }

        // --------Patient Reactivate

        [HttpGet]
        public ActionResult ReActivation(string PatientId)
        {
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    Session["SelectedUserId"] = PatientId;
                    Session["UpdateUser"] = Connection.AllowUpdate == "1" ? 1 : 0;
                    Session["DeleteUser"] = Connection.AllowDelete == "1" ? 0 : 0;
                    return View();
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("LogOut", "Account");
            }
        }


        // --------Patient Reactive List

        public ActionResult ReActivatePatientList(int FormId, FormCollection From,string Filtername)
            {           
            PatientList model = new PatientList();
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    int FacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    Session["AccessFormId"] = FormId;
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    if (Allowed == 1)
                    {
                        Session["CreateUser"] = Connection.AllowSave == "1" ? 1 : 0;
                       // string  Name =From["Name"];
                        string Name = Filtername;
                        ViewBag.searchname = Name;
                        if (!String.IsNullOrEmpty(Name))
                        {
                            model = GetFilterRecord.GetReActivePatientList(Name, FacilityId);
                        }
                      
                        else
                        {
                            model = GetPatientInformation.GetReActivePatientList(FacilityId);
                        }
                        return View(model);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

        public ActionResult ReActivatePatientListReset(int FormId)
        {
            PatientList model = new PatientList();
            try
            {

                if (Session["UserIdentityForLayOut"] != null)
                {
                    int FacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    Session["AccessFormId"] = FormId;
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    if (Allowed == 1)
                    {
                        Session["CreateUser"] = Connection.AllowSave == "1" ? 1 : 0;
                        model = GetPatientInformation.GetReActivePatientList(FacilityId);

                        return View("ReActivatePatientList", model);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                        return RedirectToAction("DashBoard", "Home");
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("DashBoard", "Home");
            }
        }

        [HttpGet]
        [ActionName("PatientReactivation")]
        public ActionResult PatientReactivation(string PatientId)
        {
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    string query = "update userregister set IsActive='" + 1 + "',Is_Reactive='" + 1 + "' where U_Id='" +SecurityManager.Encrypt(PatientId) + "'";
                    string query1 = "update patient_otherinfo set IsDeactive='" + 0 + "' where PatientId ='" +SecurityManager.Encrypt(PatientId) + "'";
                    MySqlCommand cmd = new MySqlCommand(query,obj.con);
                    MySqlCommand cmd1 = new MySqlCommand(query1,obj.con);
                    if (obj.con.State == ConnectionState.Closed)
                    {
                        obj.con.Open();
                    }
                    cmd.ExecuteNonQuery();
                    cmd1.ExecuteNonQuery();
                    if (obj.con.State == ConnectionState.Open)
                    {
                        obj.con.Close();
                    }
                    
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch
            {
                 return RedirectToAction("LogOut", "Account");
            }
            return RedirectToAction("DeactivatePatientList", new { FormId = "9" });
        }

        [HttpPost]
        public ActionResult ReActivation(ReActivation Model)
        {
            int SuccessId = -1;
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    string SelectedUserId = Session["SelectedUserId"] != null ? Session["SelectedUserId"].ToString() : "0";
                    string ChangedLoginUserId = Session["UserId"] != null ? Session["UserId"].ToString() : "0";
                    string Id = SelectedUserId == "0" ? ChangedLoginUserId : SelectedUserId;

                    int Success = 1;
                  //  APGBussinessClass.PatientReActivationDetail(Model, Id);
                    if (SuccessId == 1)
                    {
                        return View();
                    }
                    else
                    {
                        return View();
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        // --------Patient List For New Complain

        public ActionResult PatientListForNewComplain(int FormId, FormCollection From,string Filtername)
        {
            PatientList model = new PatientList();
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    int FacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    Session["AccessFormId"] = FormId;
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    if (Allowed == 1)
                    {
                        Session["CreateUser"] = Connection.AllowSave == "1" ? 1 : 0;
                    //    var Name = From["Name"];
                        var Name = Filtername;
                        ViewBag.searchname = Name;
                        if (!String.IsNullOrEmpty(Name))
                        {
                            model = GetFilterRecord.GetPatientListForNewComplain(Name,FacilityId);
                        }
                        else
                        {
                            model = GetPatientInformation.GetPatientListForNewComplain(FacilityId); //Reactivated Patient List Id=26,27
                        }
                        return View(model);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

        public ActionResult PatientListForNewComplain_reset(int FormId)
        {
            int SessionState = CheckSession(1);
            if (SessionState == 1)
            {
                PatientList model = new PatientList();
                int FacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;

                int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                if (Allowed == 1)
                {
                    model = GetPatientInformation.GetPatientListForNewComplain(FacilityId); //Reactivated Patient List Id=26,27
                    return View("PatientListForNewComplain", model);
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            else 
            {
                ViewBag.ErrorMessage = "User Session TimeOut";
                return RedirectToAction("LogOut", "Account");
            }
            return View();
        }


        // --------Patient NewComplaint

        [HttpGet]
        public ActionResult NewComplaint(int FormId, string patientid,string viewed="")
        {
            ViewBag.backview=viewed;
            try
            {
                string PatientId = null;
                if (!String.IsNullOrEmpty(patientid))
                {
                    PatientId = SecurityManager.Encrypt(patientid);
                }
                PatientId = PatientId != null ? PatientId : SecurityManager.Encrypt(Session["UserId"].ToString());
                var ret = Success;

                Session["AccessFormId"] = FormId;
                if (Session["UserIdentityForLayOut"] != null)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int Allowed = UserPermission.UserFormAuthenticationDetail( LUTypeId,FormId);
                    if (Allowed == 1)
                    {
                        Session["SelectedUserId"] = PatientId;
                        Session["UpdateUser"] = Connection.AllowUpdate == "1" ? 1 : 0;
                        Session["DeleteUser"] = Connection.AllowDelete == "1" ? 0 : 0;
                        return View();
                    }
                    else
                    {
                        if (LUTypeId != 10)
                        {
                            return RedirectToAction("AdminIndex", "Admin");
                        }
                        else
                        {
                            return RedirectToAction("PatientIndex", "PatientDeshboard");
                        }
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        [HttpPost]
        public ActionResult NewCompliant(NewPatientCompliant Model)
        {
            var ret = Success;
            string Result = "";
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    string SelectedUserId = Session["SelectedUserId"].ToString();
                    string LogedUserId = Session["UserId"] != null ? Session["UserId"].ToString() : "0";
                    string PatientID = SelectedUserId == "0" ? LogedUserId : SelectedUserId;
                    Result = PatientInfoPut.NewCompliantDetail(Model, PatientID);

                    if (Result == "1")
                    {
                        ViewData["result"] = Result;
                    }

                }

                Session["SelectedUserId"] = 0;

                if (Convert.ToInt32(Session["UserTypeId"].ToString()) != 10)
                {
                    Success = Result;
                    ret = Success;
                    return Json(ret);
                }
                else
                {
                    Success = Result;
                    ret = "10";
                    return Json(ret);
                }

            }
            catch (Exception)
            {
                Session["SelectedUserId"] = 0;

                if (Convert.ToInt32(Session["UserTypeId"].ToString()) != 10)
                {
                    return RedirectToAction("AdminIndex", "Admin");
                }
                else
                {
                    return RedirectToAction("PatientIndex", "PatientDeshboard");
                }
            }
        }


        //------- Patient Medical Authorization

        [HttpGet]
        public ActionResult PatientMedicalAuthorization()
        {
            try
            {
                int SessionState =  CheckSession(1);
                if (SessionState == 1)
                {
                    return View();
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (MembershipCreateUserException e)
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        [HttpPost]
        public ActionResult PatientMedicalAuthorization(MedicalInformation model)
        {
            var ret = Success;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    string SelectedUserId = Session["SelectedUserId"] != null ? Session["SelectedUserId"].ToString() : "0";
                    string LoggedUserId = Session["UserId"] != null ? Session["UserId"].ToString() : "0";
                    string PatientID = SelectedUserId == "0" ? LoggedUserId : SelectedUserId;

                    string SuccessID = PatientInfoPut.MedicalInformationDetail(model, PatientID);
                    if (SuccessID == "1")
                    {
                        ViewData["result"] = SuccessID;
                        Success = SuccessID;
                    }
                    else
                    {
                        ViewData["result"] = SuccessID;
                        Success = SuccessID;
                    }
                    ret = Success;
                    return Json(ret);
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";

                    if (Convert.ToInt32(Session["UserTypeId"].ToString()) != 10)
                    {
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                    else
                    {
                        return RedirectToAction("PatientIndex", "PatientDeshboard");
                    }
                }
            }
            catch (MembershipCreateUserException e)
            {

                if (Convert.ToInt32(Session["UserTypeId"].ToString()) != 10)
                {
                    return RedirectToAction("AdminIndex", "Admin");
                }
                else
                {
                    return RedirectToAction("PatientIndex", "PatientDeshboard");
                }
            }
        }

        [HttpGet]
        public ActionResult PatientConsentForm()
        {
            return View();
        }

        [HttpPost]
        public ActionResult PatientConsentForm(PatientAcknowledgement model)
        {
            string SuccessID = "0";
            var ret = Success;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    string SelectedUserId = Session["SelectedUserId"] != null ? Session["SelectedUserId"].ToString() : "0";
                    string LoggedUserId = Session["UserId"] != null ? Session["UserId"].ToString() : "0";
                    string PatientId = SelectedUserId == "0" ? LoggedUserId : SelectedUserId;
                     SuccessID = PatientInfoPut.PatientAcknowledgementDetail(model, PatientId);
                    if (SuccessID == "1")
                    {
                        string UserType = !String.IsNullOrEmpty(Session["LoginUserType"].ToString()) ? Session["LoginUserType"].ToString() : "";                       

                        if (UserType.ToLower() == "patient")
                        {
                            SuccessID = "10";
                        }
                    }
                    Success = SuccessID;
                    ret = Success;
                    return Json(ret);
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (MembershipCreateUserException e)
            {
                return RedirectToAction("LogOut", "Account");
            }
        }
    }
}