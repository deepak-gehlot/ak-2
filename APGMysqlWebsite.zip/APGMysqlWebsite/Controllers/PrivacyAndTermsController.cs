﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NewAPGApplication.Controllers
{
    public class PrivacyAndTermsController : Controller
    {
        //
        // GET: /PrivacyAndTerms/

        public ActionResult Index()
        {
            return View();
        }
      
        public ActionResult Privacy()
        {
            return View();
        }
     
        public ActionResult Terms()
        {
            return View();
        }
    }
}
