﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.BussinessLayer;
using NewAPGApplication.Models;
using System.Web.Security;


namespace NewAPGApplication.Controllers
{

    public class AccountController : Controller
    {
        DbConnection obj = new DbConnection();
        GetOperatorName objj = new GetOperatorName();

        string Success = "3";   // ' 3 ' Indicate Your Are not Login ..Your Id And Passwoed Are Not MAtch ....Plz Enter right Id And Password 

        string UserID = string.Empty, EmailID = string.Empty;
        string uname = string.Empty;
        string paswword = string.Empty;
        string EncryptEmail = string.Empty;

        int RoleId = 10;
        bool RememberMe = true;

        [HttpGet]
        public ActionResult LogOut()
        {
            System.Web.Security.FormsAuthentication.SignOut();
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.Now.AddSeconds(-1));
            Response.Cache.SetNoStore();
            Session.Clear();
            Session.Abandon();
            Session.RemoveAll();
            Session.Remove("LoggedInFacilityId");
            Session.Remove("LoginUserId");
            Session.Remove("UserIdentityForLayOut");
            Session.Remove("UserNameId");
            Session.Remove("HeaderType");
            Session.Remove("UserTypeId");
            Session.Remove("UserId");
            Session.Remove("UserType");
            Session.Remove("Password");
            Session.Remove("LoginUserType");
            Session.Remove("IsActive");
            Session.Remove("tempDiseaseId");
            Session.Remove("DiseaseTypeId");
            Session.Remove("Gender");
            Session.Remove("TestDone");
            Session.Remove("EmailId");
            Session.Remove("username");
            Session.Remove("locationid");
            Session.Remove("patientEmailid");
            Session["UserID"] = "remove";
            FormsAuthentication.SignOut();         

            return RedirectToActionPermanent("MyIndex", "Patient", new { area = "" });
        }

        public int CheckSession(int CheckNo)
        {
            int returnValue = 0;
            if (CheckNo == 1)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["LoginUserId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            if (CheckNo == 2)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["UserTypeId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            return returnValue;
        }


       [HttpPost]
        public ActionResult LogOff()
        {
            System.Web.Security.FormsAuthentication.SignOut();
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.Now.AddSeconds(-1));
            Response.Cache.SetNoStore();
            Session.Clear();
            Session.Abandon();
            Session.RemoveAll();
            Session.Remove("LoggedInFacilityId");
            Session.Remove("LoginUserId");
            Session.Remove("UserIdentityForLayOut");
            Session.Remove("UserNameId");
            Session.Remove("HeaderType");
            Session.Remove("UserTypeId");
            Session.Remove("UserId");
            Session.Remove("UserType");
            Session.Remove("Password");
            Session.Remove("LoginUserType");
            Session.Remove("IsActive");
            Session.Remove("tempDiseaseId");
            Session.Remove("DiseaseTypeId");
            Session.Remove("Gender");
            Session.Remove("TestDone");
            Session.Remove("EmailId");

            Session["UserID"] = "remove";

            FormsAuthentication.SignOut();
          

            return RedirectToActionPermanent("MyIndex", "Patient", new { area = "" });
        }

     

       public ActionResult UserRegistration(PatientRegistration objp) //Patient Registration
       {
           var ret = Success;
           int rett = 0;

           if (ModelState.IsValid)
           {
               try
               {
                   if (!String.IsNullOrEmpty(objp.UserNameId))
                   {
                       UserID = objp.UserNameId;
                       uname = SecurityManager.Encrypt(objp.UserNameId);
                       Success = "1";
                   }
                   else
                   {
                       UserID = "";
                   }
                   if (!String.IsNullOrEmpty(objp.EmailId))
                   {
                       EmailID = objp.EmailId;
                       EncryptEmail = SecurityManager.Encrypt(objp.EmailId);
                       Success = "2";
                   }
                   else
                   {
                       EmailID = "";
                   }
                   if (objp.UserNameId != null)
                   {
                       Session["SelectedUserId"] = objp.UserNameId;
                   }
                   
                   var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                   var random = new Random();
                   string PasswordResetString1 = new string(
                       Enumerable.Repeat(chars, 8)
                                 .Select(s => s[random.Next(s.Length)])
                                 .ToArray());
                   paswword = SecurityManager.Encrypt(objp.Password);

                   FormsAuthentication.SetAuthCookie(objp.UserNameId.ToLower(), RememberMe);
                   string birthdate = Convert.ToDateTime(objp.BirthDate).ToString("yyyy-MM-dd");
                   DateTime createddate=Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss tt"));
                   MySqlCommand cmd = new MySqlCommand("insert into userregister (U_Id,R_Id,FacilityId,F_Name,L_Name,EmailId,Password,Gender,DOB,EthnicityId,MobileNo,OtherContactNo,Soc_Security,Zipcode,CreatedDate,IsActive,ForgetPasswordString,Is_Reactive,Inactive,InactiveDate) values (@U_Id,@R_Id,@FacilityId,@F_Name,@L_Name,@EmailId,@Password,@Gender,@DOB,@EthnicityId,@MobileNo,@OtherContactNo,@Soc_Security,@Zipcode,@CreatedDate,IsActive,@ForgetPasswordString,@Is_Reactive,@Inactive,@InactiveDate)", obj.con);
                                  
                   cmd.Parameters.AddWithValue("@U_Id", SecurityManager.Encrypt(objp.UserNameId));
                   cmd.Parameters.AddWithValue("@R_Id", RoleId);
                   cmd.Parameters.AddWithValue("@FacilityId", objp.FacilityId);
                   cmd.Parameters.AddWithValue("@F_Name", SecurityManager.Encrypt(objp.FirstName));
                   cmd.Parameters.AddWithValue("@L_Name", SecurityManager.Encrypt(objp.LastName));
                   cmd.Parameters.AddWithValue("@DOB", birthdate);
                   cmd.Parameters.AddWithValue("@Gender", objp.Gender);                 
                   cmd.Parameters.AddWithValue("@EthnicityId", objp.EthnicityId);
                   cmd.Parameters.AddWithValue("@EmailId", EncryptEmail);
                   cmd.Parameters.AddWithValue("@Password", SecurityManager.Encrypt(objp.Password));
                   cmd.Parameters.AddWithValue("@MobileNo", objp.MobileNo);
                   cmd.Parameters.AddWithValue("@OtherContactNo", objp.OtherContactNo);
                   cmd.Parameters.AddWithValue("@Soc_Security", objp.Soc_Security);
                   cmd.Parameters.AddWithValue("@Zipcode", objp.PIN);
                   cmd.Parameters.AddWithValue("@CreatedDate", createddate);
                   cmd.Parameters.AddWithValue("@IsActive", objp.IsActive);
                   cmd.Parameters.AddWithValue("@Is_Reactive", objp.IsActive);
                   cmd.Parameters.AddWithValue("@ForgetPasswordString", PasswordResetString1);
                   cmd.Parameters.AddWithValue("@Inactive", objp.IsActive);
                   cmd.Parameters.AddWithValue("@InactiveDate", createddate);
                   // string Query = "";
                   obj.OpenDbConnection();
                   cmd.ExecuteNonQuery();
                   obj.CloseDbConnection();

                   MySqlCommand cmd1 = new MySqlCommand("insert into patient_otherinfo (PatientId,NickName,R_Id,PINNO,Height,Weight,BMI,CreatedOn,IsDeactive,IsDeleted,IsReactive) values ( @PatientId,@NickName,@R_Id,@PINNO,@Height,@Weight,@BMI,@CreatedOn,@IsDeactive,@IsDeleted,@IsReactive)", obj.con);
                   cmd1.Parameters.AddWithValue("@PatientId", SecurityManager.Encrypt(objp.UserNameId));
                   cmd1.Parameters.AddWithValue("@NickName", objp.NickName);
                   cmd1.Parameters.AddWithValue("@R_Id", RoleId);
                   cmd1.Parameters.AddWithValue("@PINNO", objp.PIN);
                   cmd1.Parameters.AddWithValue("@Height", objp.Height);
                   cmd1.Parameters.AddWithValue("@Weight", objp.Weight);

                   double BMI = 703.0 * Convert.ToInt32(objp.Weight) / Convert.ToInt32(objp.Height) / Convert.ToInt32(objp.Height); // BMI Calculate
                   double BMIValue = Math.Round(BMI, 2, MidpointRounding.AwayFromZero);

                   cmd1.Parameters.AddWithValue("@BMI", BMIValue);
                   cmd1.Parameters.AddWithValue("@CreatedOn", Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss tt")));
                   cmd1.Parameters.AddWithValue("@IsDeactive", objp.IsActive);  // objp.IsActive =0
                   cmd1.Parameters.AddWithValue("@IsDeleted", objp.IsActive);  // objp.IsActive =0
                   cmd1.Parameters.AddWithValue("@IsReactive", objp.IsActive); // objp.IsActive =0
                   obj.OpenDbConnection();
                   cmd1.ExecuteNonQuery();
                   obj.CloseDbConnection();

                   if (EncryptEmail == null || EncryptEmail == "")
                   { }
                   else
                   {
                     //  string emailid = "widevision@gmail.com";
                     //  string mailbody = "This is first alert mail";
                     //  string mailsub = "mail alert";
                     //  int scheduledday = 45;
                     //  string status = "Active";
                     //  string query = "insert into alert_mail (`AlertFor`,`AlertTo`,`AlertFrom`,`ScheduleDay`,`Mail_Body`,`Mail_Subject`,`CreatedOn`,`status`)values('" + "Womac-1" + "','" + SecurityManager.Decrypt(EncryptEmail) + "','" + emailid + "','" + scheduledday + "','" + mailbody + "','" + mailsub + "','" + Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd")) + "','" + status + "')";
                     //  MySqlCommand cmd2 = new MySqlCommand(query, obj.con);
                     //  obj.OpenDbConnection();
                     ////  cmd2.ExecuteNonQuery();
                     //  obj.CloseDbConnection();
                   
                   }

                   //--------------------------- BMI Entry ------------------------------------

                   if ((Convert.ToInt32(objp.Height) != 0) && (objp.Height != "") && (Convert.ToInt32(objp.Weight) != 0) && (objp.Weight.ToString() != ""))
                   {
                       PatientInfoPut ob = new PatientInfoPut();
                       string result = ob.PutPatientBMI(objp);
                   }
                
                   if (Success == "1")
                   {
                       string qq = SecurityManager.Encrypt(objp.UserNameId);

                       MySqlCommand cmd2 = new MySqlCommand("SELECT * FROM userregister where U_Id=@U_Id and Password=@Password", obj.con);
                       cmd2.Parameters.AddWithValue("@U_Id", SecurityManager.Encrypt(objp.UserNameId));
                       cmd2.Parameters.AddWithValue("@Password", SecurityManager.Encrypt(objp.Password));
                       MySqlDataAdapter asd1 = new MySqlDataAdapter(cmd2);
                       DataTable dt1 = new DataTable();
                       asd1.Fill(dt1);
                       if (dt1.Rows.Count > 0)
                       {
                           Session["LoggedInFacilityId"] = objp.FacilityId;
                           Session["LoginUserId"] = SecurityManager.Decrypt(dt1.Rows[0]["U_Id"].ToString());
                           if (dt1.Rows[0][1].ToString() == RoleId.ToString()) //Contain RoleId Of Patient
                           {
                               // Session["UserIdentityForLayOut"] = objp.UserNameId.ToLower();

                               Session["UserNameId"] = SecurityManager.Decrypt(objp.UserNameId.ToLower());
                               Session["PatientId"] = SecurityManager.Decrypt(objp.UserNameId.ToLower());
                               //  Session["EncryptUserNameId"] = PwdSequrityManager.Encrypt(model.UserNameId.ToLower());
                               Session["HeaderType"] = "10";

                               Session["UserTypeId"] = dt1.Rows[0]["R_Id"].ToString();
                               Session["UserId"] = SecurityManager.Decrypt(dt1.Rows[0]["U_Id"].ToString());

                               DataTable dtt = objj.GetOperator(RoleId.ToString());      //  Get Role Name By Role ID 

                               Session["UserType"] = dtt.Rows[0]["R_name"].ToString();
                               Session["Password"] = objp.Password;
                               Session["LoginUserType"] = dtt.Rows[0]["R_name"].ToString();
                               Session["IsActive"] = "0";
                           }
                       }

                   }

                   if (Success == "2")
                   {
                       string qq = SecurityManager.Encrypt(objp.UserNameId);

                       MySqlCommand cmd2 = new MySqlCommand("SELECT * FROM userregister where EmailId=@EmailId and Password=@Password", obj.con);
                       cmd2.Parameters.AddWithValue("@EmailId", SecurityManager.Encrypt(objp.EmailId));
                       cmd2.Parameters.AddWithValue("@Password", SecurityManager.Encrypt(objp.Password));
                       MySqlDataAdapter asd1 = new MySqlDataAdapter(cmd2);
                       DataTable dt1 = new DataTable();
                       asd1.Fill(dt1);
                       if (dt1.Rows.Count > 0)
                       {
                           Session["LoggedInFacilityId"] = objp.FacilityId;
                           Session["LoginUserId"] = SecurityManager.Decrypt(dt1.Rows[0]["U_Id"].ToString());
                           if (dt1.Rows[0][1].ToString() == RoleId.ToString()) //Contain RoleId Of Patient
                           {
                               // Session["UserIdentityForLayOut"] = objp.UserNameId.ToLower();
                               Session["EmailId"] = objp.EmailId.ToLower();
                               Session["UserNameId"] = objp.EmailId.ToLower();
                               Session["PatientId"] = SecurityManager.Decrypt(objp.UserNameId.ToLower());
                               //  Session["EncryptUserNameId"] = PwdSequrityManager.Encrypt(model.UserNameId.ToLower());
                               Session["HeaderType"] = "10";

                               Session["UserTypeId"] = dt1.Rows[0]["R_Id"].ToString();
                               Session["UserId"] = SecurityManager.Decrypt(dt1.Rows[0]["U_Id"].ToString());

                               DataTable dtt = objj.GetOperator(RoleId.ToString());      //  Get Role Name By Role ID 

                               Session["UserType"] = dtt.Rows[0]["R_name"].ToString();
                               Session["Password"] = objp.Password;
                               Session["LoginUserType"] = dtt.Rows[0]["R_name"].ToString();
                               Session["IsActive"] = "0";
                           }
                       }

                   }

                   if (!String.IsNullOrEmpty(objp.EmailId))
                   {
                       Success = "2";
                       //Sending Mail to User
                       string strname = string.Empty;
                       string strPracticename = string.Empty;
                       string strEmailid = string.Empty;
                       string strpassword = string.Empty;
                       strEmailid = objp.EmailId.ToString();
                       string Subject = "APG Portal Registration:-";
                       string MailTo = objp.EmailId.ToLower();
                       string Body = "Hello:" + Environment.NewLine + @"Please click the link to complete the Registration process ";
                       //Body += "Please <a href=\"http://portal.associatedphysicians.com/Patient/WelcomeIndex\">Click here</a>";

                       Body += "Please <a href=\"http://localhost:63849/Account/VarificationIndex\">Click here</a>";

                       Body += Environment.NewLine + @"Verification Code :- " + PasswordResetString1;
                       MailHelper objhelper = new MailHelper();
                       //string mailConfirm = objhelper.SendEmail(MailTo, Subject, Body);
                   }

               }

               catch (Exception)
               {
                   return Json(rett);
               }
           }
           ret = Success;
           return Json(ret);
       }
               
    

       public ActionResult ThanksIndex()
       {
           return View();
       }
       [HttpPost]
       public ActionResult GoingOnLogin(patientloginmodel ObjLogg)
       {
           PatientRegistration ObjLog = new PatientRegistration();
           var ret = Success;
           Session["UserId"] = null;
           var chackbrowser = Session["UserId"];
           
           if (chackbrowser == null)
           {

               if (ModelState.IsValid)
               {
                   try
                   {
                       string LogEmailId = string.Empty;
                       string LogPassword = string.Empty;

                       string LogEmailId1 = string.Empty;
                       string LogPassword1 = string.Empty;

                       LogEmailId = SecurityManager.Encrypt(ObjLogg.LoginEmail);
                       LogPassword = SecurityManager.Encrypt(ObjLogg.LoginPassword);

                       LogEmailId1 = SecurityManager.Encryptdata(ObjLogg.LoginEmail);
                       LogPassword1 = SecurityManager.Encryptdata(ObjLogg.LoginPassword);

                       FormsAuthentication.SetAuthCookie(ObjLogg.LoginEmail.ToLower(), RememberMe);

                       ObjLog.IsActive = 1; // 1 Means IsActive True and 0 False
                       //string query = "SELECT * FROM userregister where U_Id='" + LogEmailId + "' and Password='" + LogPassword + "' and IsActive='" + ObjLog.IsActive + "'";
                       string query = "SELECT IFNULL(FacilityId, '0') AS FacilityId, IFNULL(U_Id, '0') AS U_Id, IFNULL(EmailId, '') AS EmailId, IFNULL(R_Id, '0') AS R_Id, IFNULL(Password, '') AS Password,IsActive FROM userregister where U_Id=@U_Id and Password=@Password and IsActive=@IsActive";
                       MySqlCommand cmd1 = new MySqlCommand(query, obj.con);
                       cmd1.Parameters.AddWithValue("@U_Id", LogEmailId);
                       cmd1.Parameters.AddWithValue("@Password", LogPassword);
                       cmd1.Parameters.AddWithValue("@IsActive", ObjLog.IsActive);
                       MySqlDataAdapter asd1 = new MySqlDataAdapter(cmd1);
                       DataTable dt1 = new DataTable();
                       asd1.Fill(dt1);
                       if (dt1.Rows.Count > 0)
                       {
                           Session["LogEmailid"] = LogEmailId.ToString();
                           // int IsPatientActive = GetOperatorName.GetPatientIsActive(dt1.Rows[0]["U_Id"].ToString());
                           DataTable dtt = objj.GetOperator(dt1.Rows[0]["R_Id"].ToString());   //    Get Role Name By Role ID 
                           string Usertype = dtt.Rows[0]["R_name"].ToString();
                           if ((Usertype.ToString() == "Patient"))
                           {
                               Session["LoggedInFacilityId"] = dt1.Rows[0]["FacilityId"].ToString();
                               Session["LoginUserId"] = SecurityManager.Decrypt(dt1.Rows[0]["U_Id"].ToString());
                               Session["UserIdentityForLayOut"] = ObjLogg.LoginEmail.ToLower();
                               Session["UserNameId"] = SecurityManager.Decrypt(dt1.Rows[0]["U_Id"].ToString());
                               Session["HeaderType"] = dt1.Rows[0]["R_Id"].ToString();
                               Session["UserTypeId"] = dt1.Rows[0]["R_Id"].ToString();
                               Session["UserId"] = SecurityManager.Decrypt(dt1.Rows[0]["U_Id"].ToString());
                               Session["Password"] = SecurityManager.Decrypt(dt1.Rows[0]["Password"].ToString());
                               Session["IsActive"] = dt1.Rows[0]["IsActive"].ToString();

                               Session["EmailId"] = dt1.Rows[0]["EmailId"].ToString() != "" ? SecurityManager.Decrypt(dt1.Rows[0]["EmailId"].ToString()) : null;

                               Session["UserType"] = Usertype.ToString();
                               Session["LoginUserType"] = Usertype.ToString();

                               Success = "1";   // 1 is for Patient

                           }
                           else
                           {
                               Session["LoggedInFacilityId"] = dt1.Rows[0]["FacilityId"].ToString();
                               Session["LoginUserId"] = SecurityManager.Decrypt(dt1.Rows[0]["U_Id"].ToString());
                               Session["UserIdentityForLayOut"] = ObjLogg.LoginEmail.ToLower();
                               Session["UserNameId"] = SecurityManager.Decrypt(dt1.Rows[0]["U_Id"].ToString());
                               Session["HeaderType"] = dt1.Rows[0]["R_Id"].ToString();
                               Session["UserTypeId"] = dt1.Rows[0]["R_Id"].ToString();
                               Session["UserId"] = SecurityManager.Decrypt(dt1.Rows[0]["U_Id"].ToString());
                               Session["Password"] = SecurityManager.Decrypt(dt1.Rows[0]["Password"].ToString());
                               Session["IsActive"] = dt1.Rows[0]["IsActive"].ToString();
                               Session["EmailId"] = dt1.Rows[0]["EmailId"].ToString() != "" ? SecurityManager.Decrypt(dt1.Rows[0]["EmailId"].ToString()) : null;
                               Session["UserType"] = Usertype.ToString();
                               Session["LoginUserType"] = Usertype.ToString();

                               Success = "2";   // 2 is for Admin
                           }

                       }

                       query = "SELECT IFNULL(FacilityId, '0') AS FacilityId,IFNULL(U_Id, '0') AS U_Id,IFNULL(EmailId, '') AS EmailId,IFNULL(R_Id, '0') AS R_Id,IFNULL(Password, '') AS Password,IsActive FROM userregister where EmailId='" + LogEmailId + "' and Password='" + LogPassword + "' and IsActive='" + ObjLog.IsActive + "'";
                       MySqlCommand cmd2 = new MySqlCommand(query, obj.con);
                       cmd2.Parameters.AddWithValue("@EmailId", LogEmailId);
                       cmd2.Parameters.AddWithValue("@Password", LogPassword);
                       cmd2.Parameters.AddWithValue("@IsActive", ObjLog.IsActive);
                       // cmd2.Parameters.AddWithValue("@IsActive", 0);
                       MySqlDataAdapter asd2 = new MySqlDataAdapter(cmd2);
                       DataTable dt2 = new DataTable();
                       asd2.Fill(dt2);
                       if (dt2.Rows.Count > 0)
                       {
                           Session["LogEmailid"] = LogEmailId.ToString();
                           // int IsPatientActive = GetOperatorName.GetPatientIsActive(dt2.Rows[0]["U_Id"].ToString());
                           DataTable dtt = objj.GetOperator(dt2.Rows[0]["R_Id"].ToString());   //    Get Role Name By Role ID 
                           string Usertype = dtt.Rows[0]["R_name"].ToString();

                           if ((Usertype.ToString() == "Patient"))
                           {
                               Session["LoggedInFacilityId"] = dt2.Rows[0]["FacilityId"].ToString();
                               Session["LoginUserId"] = SecurityManager.Decrypt(dt2.Rows[0]["U_Id"].ToString());
                               Session["UserIdentityForLayOut"] = ObjLogg.LoginEmail.ToLower();
                               Session["EmailId"] = SecurityManager.Decrypt(dt2.Rows[0]["EmailId"].ToString());
                               Session["UserNameId"] = SecurityManager.Decrypt(dt2.Rows[0]["U_Id"].ToString());
                               Session["HeaderType"] = dt2.Rows[0]["R_Id"].ToString();
                               Session["UserTypeId"] = dt2.Rows[0]["R_Id"].ToString();
                               Session["UserId"] = SecurityManager.Decrypt(dt2.Rows[0]["U_Id"].ToString());
                               Session["Password"] = SecurityManager.Decrypt(dt2.Rows[0]["Password"].ToString());
                               Session["IsActive"] = dt2.Rows[0]["IsActive"].ToString();

                               Session["UserType"] = Usertype.ToString();
                               Session["LoginUserType"] = Usertype.ToString();

                               Success = "1";   // 1 is for Patient
                               Userlog();
                           }
                           else
                           {
                               Session["LoggedInFacilityId"] = dt2.Rows[0]["FacilityId"].ToString();
                               Session["LoginUserId"] = SecurityManager.Decrypt(dt2.Rows[0]["U_Id"].ToString());
                               Session["UserIdentityForLayOut"] = ObjLogg.LoginEmail.ToLower();
                               Session["EmailId"] = SecurityManager.Decrypt(dt2.Rows[0]["EmailId"].ToString());
                               Session["UserNameId"] = SecurityManager.Decrypt(dt2.Rows[0]["U_Id"].ToString());
                               Session["HeaderType"] = dt2.Rows[0]["R_Id"].ToString();
                               Session["UserTypeId"] = dt2.Rows[0]["R_Id"].ToString();
                               Session["UserId"] = SecurityManager.Decrypt(dt2.Rows[0]["U_Id"].ToString());
                               Session["Password"] = SecurityManager.Decrypt(dt2.Rows[0]["Password"].ToString());
                               Session["IsActive"] = dt2.Rows[0]["IsActive"].ToString();
                               Session["UserType"] = Usertype.ToString();
                               Session["LoginUserType"] = Usertype.ToString();

                               Success = "2";   // 2 is for Admin
                               Userlog();
                           }
                       }
                   }

                   catch (Exception)
                   {
                       ret = Success;
                       return Json(ret);
                   }
               }
           }
           else
           {
               var uid = Session["UserID"].ToString();

               string LogEmailId = string.Empty;
               string LogPassword = string.Empty;

               LogEmailId = SecurityManager.Encrypt(ObjLogg.LoginEmail);
               LogPassword = SecurityManager.Encrypt(ObjLogg.LoginPassword);

               FormsAuthentication.SetAuthCookie(ObjLogg.LoginEmail.ToLower(), RememberMe);

               ObjLog.IsActive = 1; // 1 Means IsActive True and 0 False

               MySqlCommand cmd1 = new MySqlCommand("SELECT FacilityId,U_Id,EmailId,R_Id,Password,IsActive FROM userregister where EmailId=@EmailId and Password=@Password and IsActive=@IsActive", obj.con);
               cmd1.Parameters.AddWithValue("@EmailId", LogEmailId);
               cmd1.Parameters.AddWithValue("@Password", LogPassword);
               cmd1.Parameters.AddWithValue("@IsActive", ObjLog.IsActive);
               MySqlDataAdapter asd1 = new MySqlDataAdapter(cmd1);
               DataTable dt1 = new DataTable();
               asd1.Fill(dt1);
               if (dt1.Rows.Count > 0)
               {
                   // int IsPatientActive = GetOperatorName.GetPatientIsActive(dt1.Rows[0]["U_Id"].ToString());
                   DataTable dtt = objj.GetOperator(dt1.Rows[0]["R_Id"].ToString());   //    Get Role Name By Role ID 
                   string Usertype = dtt.Rows[0]["R_name"].ToString();
                   if ((Usertype.ToString() == "Patient"))
                   {

                       Success = "1";   // 1 is for Patient

                   }
                   else
                   {


                       Success = "2";   // 2 is for Admin
                   }

               }

               ret = Success;

               if (ret == null || ret == "1" || ret == "\"1\"")
               {
                   Response.Redirect(Url.Action("PatientIndex", "PatientDeshboard"));
               }
               else if (ret == null || ret == "2" || ret == "\"2\"")
               {

                   Response.Redirect(Url.Action("AdminIndex", "Admin"));

               }


               // ret = "User Already Login";

           }


           ret = Success;
           return Json(ret);
       }




        public void Userlog()
        {
            // User Logged Detail Start

            string UserID = Session["LoginUserId"].ToString();
            PatientRegistration ObjLog = new PatientRegistration();
            UserLogDetail ULD = new UserLogDetail();
            ULD.UserTypeId = Convert.ToInt16(Session["UserTypeId"]);
            ULD.UserId = SecurityManager.Encrypt(UserID);
            ULD.ViewName = "Login View";
            ULD.OperationName = "User Login";
            ULD.Detail = "User Login Successfully!";
            ULD.ModifiedRecord = "NA";
            ULD.DetailForUserView = "User Login Successfully!";
            int SuccessId1 = AdminClass.UserLogDetail(ULD);
            // User Logged Detail End

        }

        public ActionResult VarificationIndex()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Varification(PatientRegistration model)
        {
            string VarificationString ="0";
            try
            {
                MySqlCommand cmd = new MySqlCommand("select * from userregister where EmailId=@EmailId and Password=@Password and IsActive='" + 0 + "'", obj.con);
                cmd.Parameters.AddWithValue("@EmailId", SecurityManager.Encrypt(model.EmailId));
                cmd.Parameters.AddWithValue("@Password", SecurityManager.Encrypt(model.Password));
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
               
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count != 0)
                {
                    int SuccessId = 0;
                    if (ds.Tables[0].Rows[0]["ForgetPasswordString"].ToString() == model.ForgetPasswordString.ToString())
                    {
                        //string PatientId = ds.Tables[0].Rows[0]["U_Id"].ToString();
                        //MySqlCommand cmd11 = new MySqlCommand("update patient_otherinfo set IsDeleted='" + 1 + "' where PatientId='" + PatientId + "'", obj.con);

                        MySqlCommand cmd1 = new MySqlCommand("update userregister set IsActive='" + 1 + "' where EmailId=@EmailId and Password=@Password", obj.con);
                        cmd1.Parameters.AddWithValue("@EmailId", SecurityManager.Encrypt(model.EmailId));
                        cmd1.Parameters.AddWithValue("@Password", SecurityManager.Encrypt(model.Password));
                                        
                        obj.OpenDbConnection();
                        SuccessId = cmd1.ExecuteNonQuery();
                        //SuccessId = cmd11.ExecuteNonQuery();
                        obj.CloseDbConnection();
                        VarificationString = "1";
                        SetSessionvalues(model.EmailId, model.Password);
                        return Json(VarificationString);
                    }
                    else
                    {
                        MySqlCommand cmd2 = new MySqlCommand("select * from userregister where EmailId=@EmailId and Password=@Password and IsActive='" + 1 + "'", obj.con);
                        cmd.Parameters.AddWithValue("@EmailId", SecurityManager.Encrypt(model.EmailId));
                        cmd.Parameters.AddWithValue("@Password", SecurityManager.Encrypt(model.Password));
                        MySqlDataAdapter asd = new MySqlDataAdapter(cmd2);                       
                        DataSet ds1 = new DataSet();
                        asd.Fill(ds1);
                        if (ds1.Tables[0].Rows.Count != 0)
                        {
                            VarificationString = "-3";
                        }
                        else
                        {
                            VarificationString = "-1";
                        }                       
                        return Json(VarificationString);
                    }
                }

               
                return Json(VarificationString);
            }

            catch (MembershipCreateUserException e)
            {
                ModelState.AddModelError("", ErrorCodeToString(e.StatusCode));
                VarificationString = "-2";
                return Json(VarificationString);
            }
        }

        public void SetSessionvalues(string EmailAddress, string PasswordValue)
        {            
            FormsAuthentication.SetAuthCookie(EmailAddress.ToLower(), true);
            string Email1 = null;
            string Password = string.Empty;
            
            Connection.Email = EmailAddress.ToLower();
            Email1 = EmailAddress.ToLower();
            Connection.Pass = PasswordValue;
            Session["IsActive"] = "True";
            Session["UserEmailId"] = EmailAddress.ToLower();

            MySqlCommand cmd3 = new MySqlCommand("SELECT * FROM userregister where EmailId=@EmailId and Password=@Password and IsActive='" + 1 + "'", obj.con);
            cmd3.Parameters.AddWithValue("@EmailId", SecurityManager.Encrypt(Connection.Email));
            cmd3.Parameters.AddWithValue("@Password", SecurityManager.Encrypt(Connection.Pass));
            MySqlDataAdapter asd1 = new MySqlDataAdapter(cmd3);
            DataTable dt1 = new DataTable();
            asd1.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                Session["LoginUserId"] =SecurityManager.Decrypt(dt1.Rows[0]["U_Id"].ToString());
                if (dt1.Rows[0][1].ToString() == RoleId.ToString()) //Contain RoleId Of Patient
                {
                    Session["UserIdentityForLayOut"] = Connection.Email;
                    Session["EmailId"] = Connection.Email;
                    //Session["EncryptUserNameId"] = PwdSequrityManager.Encrypt(model.UserNameId.ToLower());
                    Session["HeaderType"] = RoleId;
                    Session["UserTypeId"] = dt1.Rows[0]["R_Id"].ToString();
                    Session["UserId"] = SecurityManager.Decrypt(dt1.Rows[0]["U_Id"].ToString());

                    DataTable dtt = objj.GetOperator(RoleId.ToString());         //    Get Role Name By Role ID

                    Session["UserType"] = dtt.Rows[0]["R_name"].ToString();
                    Session["Password"] = SecurityManager.Decrypt(Connection.Pass);
                    Session["LoginUserType"] = dtt.Rows[0]["R_name"].ToString();
                }
            }

        }

        private static string ErrorCodeToString(MembershipCreateStatus createStatus)
        {
            // See http://go.microsoft.com/fwlink/?LinkID=177550 for
            // a full list of status codes.
            switch (createStatus)
            {
                case MembershipCreateStatus.DuplicateUserName:
                    return "User name already exists. Please enter a different user name.";

                case MembershipCreateStatus.DuplicateEmail:
                    return "A user name for that e-mail address already exists. Please enter a different e-mail address.";

                case MembershipCreateStatus.InvalidPassword:
                    return "The password provided is invalid. Please enter a valid password value.";

                case MembershipCreateStatus.InvalidEmail:
                    return "The e-mail address provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.InvalidAnswer:
                    return "The password retrieval answer provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.InvalidQuestion:
                    return "The password retrieval question provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.InvalidUserName:
                    return "The user name provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.ProviderError:
                    return "The authentication provider returned an error. Please verify your entry and try again. If the problem persists, please contact your system administrator.";

                case MembershipCreateStatus.UserRejected:
                    return "The user creation request has been canceled. Please verify your entry and try again. If the problem persists, please contact your system administrator.";

                default:
                    return "An unknown error occurred. Please verify your entry and try again. If the problem persists, please contact your system administrator.";
            }
        }


        [HttpGet]
        public ActionResult ForgetPassword()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Forgetpassword(PatientRegistration model)
        {
            string Ret = "";
            var Redirect = Ret; 

            try
            {
               //int SessionState = CheckSession(1);
               //if (SessionState == 1)
               //{

                   Session["ForgetPasswordEmail"] = model.EmailId;
                   ViewBag.EmailID = model.EmailId;
                   string Success = AdminClass.ForgetPassword(model);

                   if (Success == "Mail Sent Successfully")
                   {
                       //Redirect = Success.ToString();   
                       Redirect = "1";
                   }
                   else
                   {
                       Redirect = "0";
                   }
               //}
               //else
               //{
               //    return RedirectToAction("LogOut", "Account");
               //}
            }
            catch (Exception e)
            {
                string a = e.Message;
                Redirect = "-2";       
            }
            return Json(Redirect);
        }

        [HttpGet]
        public ActionResult Resetpassword()
        {
            string EmailId = Session["ForgetPasswordEmail"].ToString();
            ViewBag.EmailID = EmailId;
            return View();
        }

        [HttpPost]
        public ActionResult Resetpassword(PatientRegistration model)
        {
            string Ret = "";
            var Redirect = Ret; 

            try
            {
                 //int SessionState = CheckSession(1);
                 //if (SessionState == 1)
                 //{

                     string email = Session["ForgetPasswordEmail"].ToString();
                     model.EmailId = email;
                     int Success = AdminClass.ResetPassword(model);

                     if (Success == 1)
                     {
                         Redirect = Success.ToString();
                     }
                     else
                     {
                         Redirect = "0";
                     }
                // }
                //else
                // {
                //       return RedirectToAction("LogOut", "Account");
                // }
            }
            catch
            { }
           
            return Json(Redirect);
        }

    }
}