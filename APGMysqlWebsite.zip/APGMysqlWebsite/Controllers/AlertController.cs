﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NewAPGApplication.BussinessLayer;
using NewAPGApplication.Controllers;
using System.Transactions;
using System.Web.Security;
using DotNetOpenAuth.AspNet;
using Microsoft.Web.WebPages.OAuth;
using WebMatrix.WebData;
using NewAPGApplication.Filters;
using MySql.Data.MySqlClient;

using System.Data;
using System.Configuration;
using System.Data.Entity;
using System.Dynamic;
using PagedList
;
using PagedList.Mvc;
using System.IO;
using System.Web.UI;
using NewAPGApplication.Models;
using Rotativa;
using System.Net.Mail;
using System.Text.RegularExpressions;
using APGWebsite.BussinessLayer;

namespace NewAPGApplication.Controllers
{
    public class AlertController : Controller
    {
        DbConnection obj = new DbConnection();
        public ActionResult SecurityReminder(string Remindertype, string ReminderId, FormCollection frm, string AdminSearch = "user")
        {
            try
            {
            }
            catch (Exception e)
            {
            }
            return View();
        }

        public int CheckSession(int CheckNo)
        {
            int returnValue = 0;
            if (CheckNo == 1)
            {
                if ((Session["UserIdentityForLayOut"] != null) || (Session["UserId"] != null))
                {
                    if (Session["LoginUserId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            if (CheckNo == 2)
            {
                if ((Session["UserIdentityForLayOut"] != null) || (Session["UserId"] != null))
                {
                    if (Session["UserTypeId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            return returnValue;
        }
        public ActionResult ScheduledReminderInsert()
        {            
            return View();
        }

        [HttpPost]
        public JsonResult UpdateAlertList(PatientDetail model)
        {
            int success = 0;
            success = AdminClass.Updatealertstatus(model);
            return Json(success);
        }

        [HttpPost]
        public JsonResult GetPatientNotes(int alertid)
        {

            ShowUserDetailsModel patientstatus = new ShowUserDetailsModel();
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    string patientid = Session["PatientId"].ToString();
          
                    if (alertid == 1 || alertid == 2 || alertid == 3)
                    {
                        string query2 = "select body from alert_update_tbl where patient_id='" + patientid + "' and alert_day_id='" + alertid + "'";
                        MySqlCommand cmd2 = new MySqlCommand(query2, obj.con);
                        MySqlDataAdapter da2 = new MySqlDataAdapter(cmd2);
                        DataTable dt2 = new DataTable();
                        da2.Fill(dt2);
                        if (dt2.Rows.Count > 0)
                        {
                            patientstatus.SecurityBody = dt2.Rows[0]["body"].ToString();
                            patientstatus.AlertTo = Session["PatientEmailId"].ToString();
                        }
                        else
                        {
                            string query3 = "select body from alert_day_tbl where  AlertMailId='" + alertid + "'";
                            MySqlCommand cmd3 = new MySqlCommand(query3, obj.con);
                            MySqlDataAdapter da3 = new MySqlDataAdapter(cmd3);
                            DataTable dt3 = new DataTable();
                            da3.Fill(dt3);
                            if (dt3.Rows.Count > 0)
                            {
                                patientstatus.SecurityBody = dt3.Rows[0]["body"].ToString();
                                patientstatus.AlertTo = Session["PatientEmailId"].ToString();
                            }
                        }
                    }
                    else
                    {
                        MySqlCommand cmd = new MySqlCommand("select status,Mail_Body,AlertTo from alert_mail where AlertMailId='" + alertid + "'", obj.con);
                        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        //string body = dt.Rows[0]["Mail_Body"].ToString();
                        //string []mailbody=body.Split('>','<');
                        //string body1 = mailbody[2];
                        if (dt.Rows.Count > 0)
                        {
                            patientstatus.SecurityBody = dt.Rows[0]["Mail_Body"].ToString();
                            patientstatus.Status = dt.Rows[0]["status"].ToString();
                            patientstatus.AlertTo = dt.Rows[0]["AlertTo"].ToString();
                        }

                        //  Session["PatientEmailId"] = null;

                    }
                }
                else
                {
                    return Json(patientstatus);
                }
            }
            catch
            { 
            
            }
            return Json(patientstatus);

        }



        public ActionResult FirstAlertStatus(FormCollection From,string Filtername)
        {
           
            alertlist model = new alertlist();
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int tempLoggedinFacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;

                    int alertid = 1;
                    //var Name = From["Name"];
                    var Name = Filtername;
                    ViewBag.searchname = Name;
                    if (!String.IsNullOrEmpty(Name))
                    {
                       
                        model = GetFilterRecord.GetPatientfirstAlertList(Name,alertid);
                    }
                    else
                    {
                        model = GetPatientInformation.GetPatientFirstAlertList(alertid);
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
                return View(model);
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

        public ActionResult FirstAlertStatusreset()
        {

            alertlist model = new alertlist();
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int tempLoggedinFacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                    int alertid = 1;
                    model = GetPatientInformation.GetPatientFirstAlertList(alertid);  }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
                return View("FirstAlertStatus", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

        public ActionResult SecondAlertStatus(FormCollection From,string Filtername)
        {
            alertlist model = new alertlist();
        
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int tempLoggedinFacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;

                    int alertid = 2;
                   // var Name = From["Name"];
                    var Name = Filtername;
                    ViewBag.searchname = Name;
                    if (!String.IsNullOrEmpty(Name))
                    {
                        model = GetFilterRecord.GetPatientfirstAlertList(Name, alertid);
                    }
                    else
                    {
                        model = GetPatientInformation.GetPatientFirstAlertList(alertid);
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
                return View(model);


            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }
        public ActionResult SecondAlertStatusreset()
        {

            alertlist model = new alertlist();
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int tempLoggedinFacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                    int alertid = 2;
                    model = GetPatientInformation.GetPatientFirstAlertList(alertid);
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
                return View("SecondAlertStatus", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }


        public ActionResult ThirdAlertStatus(FormCollection From,string Filtername)
        {
            
            alertlist model = new alertlist();
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int tempLoggedinFacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;

                    int alertid = 3;
                    //var Name = From["Name"];
                    var Name = Filtername;
                    ViewBag.searchname = Name;
                    if (!String.IsNullOrEmpty(Name))
                    {
                        model = GetFilterRecord.GetPatientfirstAlertList(Name, alertid);
                    }
                    else
                    {
                        model = GetPatientInformation.GetPatientFirstAlertList(alertid);
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
                return View(model);
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

        public ActionResult ThirdAlertStatusreset()
        {
            alertlist model = new alertlist();
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int tempLoggedinFacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                    int alertid = 3;
                    model = GetPatientInformation.GetPatientFirstAlertList(alertid);
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
                return View("ThirdAlertStatus", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

    }
}
