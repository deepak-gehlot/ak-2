﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.BussinessLayer;
using NewAPGApplication.Models;
using System.Web.Security;
using System.Web.Services;

namespace NewAPGApplication.Controllers
{
    public class HomeController : Controller
    {
        DbConnection obj = new DbConnection();

        [HttpGet]
        public ActionResult DigitalSignature()
        {
            return View();
        }

        public int CheckSession(int CheckNo)
        {
            int returnValue = 0;
            if (CheckNo == 1)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["LoginUserId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            if (CheckNo == 2)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["UserTypeId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            return returnValue;
        }


        public ActionResult FacilityLogDetails(string  facilityid, FormCollection From)
        {
            ViewBag.Facilityid = facilityid.ToString();
            string DateFrom = From["DateFrom"];
            string DateTo = From["DateTo"];
            ViewBag.datefrom = From["DateFrom"];
            ViewBag.dateto = From["DateTo"];
            string Operation_Name = From["OperationName"];
            ViewData["OperationName"] = Operation_Name;
          
            List<SelectListItem> li = new List<SelectListItem>();
            List<FacilityList2> linew = new List<FacilityList2>();
                  
            FacilityLogList model = new FacilityLogList();
            if (Session["UserId"] != null)
            {
                if ((!String.IsNullOrEmpty(Operation_Name)) || ((!String.IsNullOrEmpty(DateFrom)) && (!String.IsNullOrEmpty(DateTo))))
                {
                    if (!String.IsNullOrEmpty(Operation_Name))
                    {
                        Session["OperationName"] = Operation_Name.ToString();
                    }
                    if (!String.IsNullOrEmpty(DateFrom))
                    {
                        Session["datefrom"] = DateFrom.ToString();
                    }
                    if (!String.IsNullOrEmpty(DateTo))
                    {
                        Session["datato"] = DateTo.ToString();
                    }
                    model = GetFilterRecord.GetFilterFacilityList(facilityid, Operation_Name, DateFrom, DateTo);
                  //  ViewData["OperationName"] = Operation_Name;
                }
                else if ((Session["OperationName"] != null) || (Session["datefrom"] != null && Session["datato"] != null))
                {
                    string facilitid = ViewBag.Facilityid;
                    string datefrom1 = null;
                    string dateto1 = null;
                    string operaion = null;
                    if (Session["OperationName"] != null)
                    {
                        operaion = Session["OperationName"].ToString();
                        //ViewData["OperationName"] = Session["OperationName"].ToString();
                        Operation_Name = Session["OperationName"].ToString();
                    }
                    if ((Session["datefrom"] != null && Session["datato"] != null))
                    {
                        datefrom1 = Session["datefrom"].ToString();
                        dateto1 = Session["datato"].ToString();
                    }
                    model = GetFilterRecord.GetFilterFacilityList(facilitid, operaion, datefrom1, dateto1);
                    ViewBag.datefrom = datefrom1;
                    ViewBag.dateto = dateto1;
                   
                }
                else
                { 
                model = GetFilterRecord.GetFacilityList(facilityid);
              //  ViewData["OperationName"] = model.facilitylist;
                }

                MySqlCommand cmd3 = new MySqlCommand("select IFNULL(OperationName, 'NA') AS OperationName from userlogdetails group by OperationName", obj.con);
                MySqlDataAdapter da3 = new MySqlDataAdapter(cmd3);
                DataTable dt3 = new DataTable();
                da3.Fill(dt3);
                if (dt3.Rows.Count != 0)
                {

                    for (int i = 0; i < dt3.Rows.Count; i++)
                    {
                        string operationname = dt3.Rows[i]["OperationName"].ToString();
                        if (operationname == "")
                        {
                            operationname = "NA";
                        }

                        li.Add(new SelectListItem { Text = dt3.Rows[i]["OperationName"].ToString(), Value = dt3.Rows[i]["OperationName"].ToString(), Selected = true });
                        linew.Add(new FacilityList2 { Text = dt3.Rows[i]["OperationName"].ToString(), Value = dt3.Rows[i]["OperationName"].ToString() });
                    }
                }
                //  ViewData["OperationName"] = model.facilitylist;
                model.FacilityList2 = linew;
                ViewData["OperationName"] = li;
                if (!String.IsNullOrEmpty(Operation_Name))
                {
                    model.OperationName = Operation_Name;
                    ViewBag.OperationName1 = Operation_Name;
                }
                else
                {
                    model.OperationName = "--Select Operation Name--";
                    ViewBag.OperationName1 = "0";
                }
                return View(model);
            }
            else
            {
                ViewBag.ErrorMessage = "User Session TimeOut";
                return RedirectToAction("LogOut", "Account");
            }
            return View(model);
            
        }

      
        public ActionResult FacilityLogDetailsReset(string facilityid)
        {
            Session["OperationName"] = null;
            Session["datefrom"] = null;
            Session["datato"] = null;
            ViewBag.OperationName1 = "0";
             FacilityLogList model = new FacilityLogList();
           //  List<SelectListItem> li = new List<SelectListItem>();
             List<FacilityList2> linew = new List<FacilityList2>();
           
            int SessionState = CheckSession(1);
            if (SessionState == 1)
            {
                model = GetFilterRecord.GetFacilityList(facilityid);
                ViewData["OperationName"] = model.facilitylist;
                MySqlCommand cmd3 = new MySqlCommand("select IFNULL(OperationName, 'NA') AS OperationName from userlogdetails group by OperationName", obj.con);
                MySqlDataAdapter da3 = new MySqlDataAdapter(cmd3);
                DataTable dt3 = new DataTable();
                da3.Fill(dt3);
                if (dt3.Rows.Count != 0)
                {
                    for (int i = 0; i < dt3.Rows.Count; i++)
                    {
                        string operationname = dt3.Rows[i]["OperationName"].ToString();
                        if (operationname == "")
                        {
                            operationname = "NA";
                        }
                      //  li.Add(new SelectListItem { Text = dt3.Rows[i]["OperationName"].ToString(), Value = dt3.Rows[i]["OperationName"].ToString(), Selected = dt3.Rows[i]["OperationName"].ToString() == Operation_Name });
                        linew.Add(new FacilityList2 { Text = dt3.Rows[i]["OperationName"].ToString(), Value = dt3.Rows[i]["OperationName"].ToString() });
                    }
                }
                model.FacilityList2 = linew;
                return View("FacilityLogDetails", model);
            }
            else
            {
                return RedirectToAction("LogOut", "Account");

            }
            return View();
        }
     
        [HttpGet]      
        public ActionResult FacilityList(int FormId,FormCollection Frm)
        {
            ViewBag.searchname = Frm["Name"];
         
            ViewBag.FormID = FormId;
            Session["OperationName"] = null;
            Session["datefrom"] = null;
            Session["datato"] = null;
            string locationname = Frm["Name"];
            Session["AccessFormId"] = FormId;
            FacilityList model = new FacilityList();
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    Session["CreateUser"] = Connection.AllowSave == "1" ? 1 : 0;
                    if (Allowed == 1)
                    {
                        if (locationname == ""|| locationname==null)
                        {
                            model = UserPermission.GetFacilityList();
                            return View(model);
                        }
                        else
                        {
                            model = UserPermission.GetFacilityList_Search(locationname);
                            return View(model);
                        }
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }
        [HttpPost]
        public ActionResult FacilityList(FormCollection Form)
        {
             ViewBag.searchname = Form["Name"];
            string locationname = Form["Name"];
            int FormID =Convert.ToInt32( Form["FormID"]);
            ViewBag.FormID = FormID;
            FacilityList model = new FacilityList();
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormID);
                    Session["CreateUser"] = Connection.AllowSave == "1" ? 1 : 0;
                    if (Allowed == 1)
                    {
                            model = UserPermission.GetFacilityList_Search(locationname);
                            return View(model);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
            return View(model);

        }

        public ActionResult UserList(int FormId, FormCollection From,string Filtername,int  LocationId=0)
        {
            DbConnection obj = new DbConnection();
            int No = 0;
           // var Name = From["Name"];
            var Name = Filtername;
            var FaclityID = LocationId;
            var Location = LocationId.ToString();
            ViewBag.searchname = Name;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int LoggedFacilityId;
                    Session["AccessFormId"] = FormId;
                    LoggedFacilityId = Convert.ToInt32(LocationId) != 0 ? Convert.ToInt32(LocationId) : Convert.ToInt32(Session["LoggedInFacilityId"].ToString());               
                        //int LoggedFacilityId = Session["LoggedInFacilityId"].ToString() != "0" ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                    if (LoggedFacilityId == 0)
                    {
                        string Uid = Session["UserId"].ToString() != "0" ? Session["UserId"].ToString() : "0";
                        LoggedFacilityId = GraphicReport.GetFacilityId(Uid);
                    }
                     UserList model = new UserList();
                    List<SelectListItem> li = new List<SelectListItem>();
                    List<FacilityList1> linew = new List<FacilityList1>();
                    List<UserDetail> userDetail = new List<UserDetail>();
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    Session["CreateUser"] = Connection.AllowSave == "1" ? 1 : 0;
                    if (Allowed == 1)
                    {
                        if (!String.IsNullOrEmpty(Name) || Location!="0")
                        { 
                            model = AdminClass.Getfilteruserlist(Location, Name);
                        }
                        else
                        {
                            model = AdminClass.Getalluserlist();
                        }

                        DataTable dtt = GetOperatorName.GetLocationList();
                        if (dtt.Rows.Count != 0)
                        {
                            for (int i = 0; i < dtt.Rows.Count; i++)
                            {
                                li.Add(new SelectListItem { Text = dtt.Rows[i]["Location"].ToString(), Value = dtt.Rows[i]["FacilityId"].ToString(), Selected = dtt.Rows[i]["FacilityId"].ToString() == Location });
                                linew.Add(new FacilityList1 { Text = dtt.Rows[i]["Location"].ToString(), Value = Convert.ToInt32(dtt.Rows[i]["FacilityId"].ToString()) });
                            }
                        }
                        model.FacilityList = linew;
                        ViewData["FacilityList"] = li;
                        if (Location != "")
                        {
                            model.FacilityID = Convert.ToInt32(Location);
                        }
                        else
                        {
                            model.FacilityID = 0;
                        }
                        return View(model);
                    }
                    else
                    {
                         ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                         return RedirectToAction("DashBoard", "Home");
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("LogOut", "Account");
            }
 
        }
        [HttpPost]
        public ActionResult UserList1(int FormId)
        {
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    UserList model = new UserList();
                    List<SelectListItem> li = new List<SelectListItem>();
                    List<FacilityList1> linew = new List<FacilityList1>();
                    Session["CreateUser"] = Connection.AllowSave == "1" ? 1 : 0;
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    if (Allowed == 1)
                    {
                        model = AdminClass.Getalluserlist();
                        DataTable dtt = GetOperatorName.GetLocationList();
                        if (dtt.Rows.Count != 0)
                        {
                            for (int i = 0; i < dtt.Rows.Count; i++)
                            {
                               // li.Add(new SelectListItem { Text = dtt.Rows[i]["Location"].ToString(), Value = dtt.Rows[i]["FacilityId"].ToString(), Selected = dtt.Rows[i]["FacilityId"].ToString() == Location });
                                linew.Add(new FacilityList1 { Text = dtt.Rows[i]["Location"].ToString(), Value = Convert.ToInt32(dtt.Rows[i]["FacilityId"].ToString()) });
                            }
                        }
                        model.FacilityList = linew;
                        return View("UserList", model);
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch
            {
               
            }
            return View();
        }
        private DataTable getlocation(string Location)
        {
            throw new NotImplementedException();
        }

        private DataTable getlocation()
        {
            throw new NotImplementedException();
        }

        public ActionResult Register()         // ----- User Registration 
        {
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int FormId = Session["AccessFormId"] != null ? Convert.ToInt32(Session["AccessFormId"].ToString()) : 0;
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    if (Connection.AllowSave.ToLower() == "1")
                    {
                        return View();
                    }
                    else
                    {
                        return RedirectToAction("DashBoard", "Home");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("DashBoard", "Home");
            }
        }

        [HttpPost]
        public ActionResult UserRegistrationByAdmin(AdminRegisterModel Model)
        {
            string Ret = "";
            var Redirect = Ret;
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    int Success = AdminClass.CreateNewUser(Model);
                    if (Success == 1)
                    {
                        int FormId = Session["AccessFormId"] != null ? Convert.ToInt32(Session["AccessFormId"].ToString()) : 0;
                        Redirect = FormId.ToString();   //User Add Successful!    
                    }
                    else
                    {
                        Redirect = "0";        //User Already Exist!     
                    }
                }
                else
                {
                    Redirect = "-1";           //Session Timeout!  
                }
            }
            catch (Exception e)
            {
                string a = e.Message;
                Redirect = "-2";               //Exception    
            }
            return Json(Redirect);
        }

        // ------------------------- USER LEVEL LIST
        [Authorize]
        [HttpGet]
        public ActionResult UserLevel(int FormId)                    // UserLevel List
        {
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    Session["AccessFormId"] = FormId;
                    UserLevelList model = new UserLevelList();
                    ViewBag.ErrorMessage = GetPatientInformation.ErrorMessage;
                   
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    ViewBag.save = Connection.AllowSave;
                    Session["CreateUser"] = Connection.AllowSave == "True" ? 1 : 0;
                    if (Allowed == 1)
                    {
                        model = AdminClass.GetuserLevelList();
                        return View(model);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }



        // ------------------------- REFERAL LIST

        public ActionResult ReferralList(int FormId, FormCollection From)
        {
            ReferralList model = new ReferralList();
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    Session["AccessFormId"] = FormId;
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    Session["CreateUser"] = Connection.AllowSave == "1" ? 1 : 0;
                    if (Allowed == 1)
                    {
                        model = AdminClass.GetReferralList();
                        return View(model);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        public ActionResult ReferralUpdate(int Referral_Id)
        {
             int SessionState = CheckSession(1);
             if (SessionState == 1)
             {
                 Session["Referral_Id"] = Referral_Id;
                 int FormId = 24;
                 int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                 int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                 ViewBag.edit = Connection.AllowUpdate;
                 ViewBag.delete = Connection.AllowDelete;
               
             }
             else
             {
                 return RedirectToAction("LogOut", "Account");
             }
            return View();
        }

        public JsonResult Referral_Update_Delete()
        {
            ReferralList model = new ReferralList();
            try
            {
                List<ReferralDetail> referralDetail = new List<ReferralDetail>();
                MySqlCommand cmd1 = new MySqlCommand("SELECT IFNULL(ReferralId, '') AS ReferralId, ReferralName, Description FROM referrallist WHERE IsActive=" + 1 + " and ReferralId='" + Session["Referral_Id"] + "'", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd1);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        model.ReferralId = Convert.ToInt32(dt.Rows[i]["ReferralId"].ToString());
                        model.ReferralName = dt.Rows[i]["ReferralName"].ToString();
                        model.ReferralDescription = dt.Rows[i]["Description"].ToString();
                     }
                }
            }
            catch (Exception e)
            {
                
            }

            return Json(model, JsonRequestBehavior.AllowGet);
        }
        public JsonResult Referral_Update(string referalname, string referaldescription)
        {
            ReferralList model = new ReferralList();
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    var referalid = Session["Referral_Id"].ToString();
                    List<ReferralDetail> referralDetail = new List<ReferralDetail>();
                    MySqlCommand cmd1 = new MySqlCommand("update referrallist set ReferralName='" + referalname + "', Description='" + referaldescription + "'  WHERE   ReferralId='" + referalid + "'", obj.con);
                    if (obj.con.State == ConnectionState.Open)
                    {
                        cmd1.ExecuteNonQuery();
                    }
                    if (obj.con.State == ConnectionState.Closed)
                    {
                        obj.con.Open();
                        int success = cmd1.ExecuteNonQuery();
                    }
                    obj.con.Close();
                }
                else
                {
                    return Json(SessionState, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception e)
            {

            }
            return Json(model, JsonRequestBehavior.AllowGet);
        }
        public JsonResult Referral_Delete(int ReferralId)
        {
            ReferralList model = new ReferralList();
            try
            {
                List<ReferralDetail> referralDetail = new List<ReferralDetail>();
                MySqlCommand cmd1 = new MySqlCommand("delete  from  referrallist  WHERE   ReferralId='" + ReferralId + "'", obj.con);
                if (obj.con.State == ConnectionState.Open)
                {
                    cmd1.ExecuteNonQuery();
                }
                if (obj.con.State == ConnectionState.Closed)
                {
                    obj.con.Open();
                    cmd1.ExecuteNonQuery();
                }
                obj.con.Close();
            }
            catch (Exception e)
            {

            }
            return Json(model, JsonRequestBehavior.AllowGet);
        }

        //-------------------------- Womac Quetionaries

        [Authorize]
        [HttpGet]
        public ActionResult WomacQuestionType(int FormId)
        {
            Session["AccessFormId"] = FormId;
            DiseaseList model = new DiseaseList();
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    Connection.FormId = FormId;
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    Session["CreateUser"] = Connection.AllowSave == "1" ? 1 : 0;
                    ViewBag.edit = Connection.AllowUpdate;
                    if (Allowed == 1)
                    {
                        List<Disease> DiseaseDetail = new List<Disease>();
                        MySqlCommand cmd = new MySqlCommand("Select * from womac_questype where QuesTypeId in (8,9,10) ", obj.con);
                        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                DiseaseDetail.Add(new Disease
                                {
                                    DiseaseTypeId = Convert.ToInt32(dt.Rows[i]["QuesTypeId"].ToString()),
                                    DiseaseTypeName = dt.Rows[i]["QuestionType"].ToString()
                                });
                            }
                        }
                        model.diseaseList = DiseaseDetail;
                        return View(model);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

        [HttpGet]
        public ActionResult WomacQuestionList(int DiseaseTypeId)
        {
            DiseaseQuestionList model = new DiseaseQuestionList();
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    int FormId = Session["AccessFormId"] != null ? Convert.ToInt32(Session["AccessFormId"].ToString()) : 0;
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    Session["CreateUser"] = Connection.AllowSave == "1" ? 1 : 0;
                    if (Allowed == 1)
                    {
                        List<DiseaseQuestion> DiseaseDetail = new List<DiseaseQuestion>();
                        MySqlCommand cmd = new MySqlCommand("SELECT t1.QuesId,t1.QuesTypeId,t2.QuestionType,t1.Question FROM womac_question t1 inner join womac_questype t2 on t1.QuesTypeId=t2.QuesTypeId where t1.QuesTypeId='" + DiseaseTypeId + "' and t1.IsActive='" + 1 + "'", obj.con);
                        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                DiseaseDetail.Add(new DiseaseQuestion
                                {
                                    SrNo = i+1,
                                    DiseaseTypeId = Convert.ToInt32(dt.Rows[i]["QuesTypeId"].ToString()),
                                    DiseaseId = Convert.ToInt32(dt.Rows[i]["QuesId"].ToString()),
                                    DiseaseName = dt.Rows[i]["Question"].ToString(),
                                    Edit = Connection.AllowUpdate,
                                    Delete = Connection.AllowDelete
                                });
                            }
                            Session["Question"] = dt.Rows[0]["QuestionType"].ToString();
                            ViewBag.DiseaseTypeName = Session["Question"].ToString();
                        }
                        model.DiseaseList = DiseaseDetail;
                        model.DiseaseTypeID = DiseaseTypeId;
                        return View(model);
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "you Don't Have Permision to Access these Records!";
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }


        //----------------  Edit Facility Details

        public ActionResult EditFacilityDetails(int FacilityId)
        {
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    int FormId = Session["AccessFormId"] != null ? Convert.ToInt32(Session["AccessFormId"].ToString()) : 0;
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    if (Allowed == 1)
                    {
                        Session["UpdateUser"] = Connection.AllowUpdate == "1" ? 1 : 0;
                        Session["DeleteUser"] = Connection.AllowDelete == "1" ? 1 : 0;
                        Session["selectedFacilityId"] = Convert.ToInt32(FacilityId.ToString());
                        return View();
                    }
                    else
                    {
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

        [HttpPost]
        public ActionResult EditFacilityData(Facility model, string ButtonType,int num)
        {
            string Ret = "";
           
            var Redirect = Ret;
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    int tempId = Session["selectedFacilityId"] != null ? Convert.ToInt32(Session["selectedFacilityId"].ToString()) : 0;
                    int Success = UpdateFacility(model, ButtonType, tempId,num);
                    if (Success == 1)
                    {
                        Session.Remove("UpdateUser");
                        Session.Remove("DeleteUser");
                        int FormId = Session["AccessFormId"] != null ? Convert.ToInt32(Session["AccessFormId"].ToString()) : 0;
                        Redirect = FormId.ToString();
                    }
                    else
                    {
                        Redirect = "0";
                    }
                }
                else
                {
                    Redirect = "-1";
                }
            }
            catch (Exception e)
            {
                string a = e.Message;
                Redirect = "-2";
            }
            return Json(Redirect);
        }
       

        public int UpdateFacility(Facility model, string ButtonType, int tempId, int num)
        {
           
            try
            {
                int Num = num;
                int SuccessId = 0;

                //User Logged Detail Start

                UserLogDetail ULD = new UserLogDetail();
                ULD.ViewName = "Home/EditFacility";
                ULD.ModifiedRecord = model.LocationName;
                ULD.UserTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                ULD.UserId = SecurityManager.Encrypt(Session["UserIdentityForLayOut"].ToString());
                //User Logged Detail End

                if (Num == 1)
                {
                    int cityid = 0,stateid = 0;
                    string cityname = null;
                    MySqlCommand cmdd = new MySqlCommand("insert into city(C_Name,StateId)values('" + model.CityName + "','" + model.State + "')", obj.con);
                    obj.OpenDbConnection();
                    int success = cmdd.ExecuteNonQuery();
                    obj.CloseDbConnection();

                    if (success == 1)
                    {
                        MySqlCommand cmd = new MySqlCommand("select  CityId,C_Name,StateId from city order by CityId desc LIMIT 1", obj.con);
                        obj.OpenDbConnection();
                        MySqlDataReader dr = cmd.ExecuteReader();
                        while (dr.Read())
                        {
                            cityid = Convert.ToInt32(dr["CityId"].ToString());
                            cityname = dr["C_Name"].ToString();
                            stateid = Convert.ToInt32(dr["StateId"].ToString());
                        }
                        dr.Close();
                        obj.CloseDbConnection();

                        if (cityname == model.CityName)
                        {
                            string Query = "";
                            if (ButtonType == "1")
                            {
                                Query = @"update facility set Location='" + model.LocationName + "',Street='" + model.Address + "',CityId='" + cityid + "',StateId='" + stateid + "',Zipcode='" + model.Zipcode + "',ContactNo='" + model.PhoneNumber + "',FaxNo='" + model.FaxNumber + "',ManagerId='" + SecurityManager.Encrypt(model.Manager) + "',EmailId='" + SecurityManager.Encrypt(model.EmailAddress) + "',IsActive='" + "1" + "' where FacilityId='" + tempId + "'";

                                ULD.OperationName = "Update";
                                ULD.Detail = "Location Detail Updated Successfully!";
                                ULD.DetailForUserView = "Location Detail Update Successfully!";
                            }
                            else if (ButtonType == "2")
                            {
                                Query = @"update `facility` set `IsActive` =0 where `FacilityId`='" + tempId + "'";

                                ULD.OperationName = "Delete";
                                ULD.Detail = "Location Detail Deleted Successfully!";
                                ULD.DetailForUserView = "Location Detail Deleted Successfully!";
                            }

                            MySqlCommand cmddd = new MySqlCommand(Query, obj.con);
                            obj.OpenDbConnection();
                            SuccessId = cmddd.ExecuteNonQuery();
                            obj.CloseDbConnection();
                            int Result = AdminClass.UserLogDetail(ULD);
                            return SuccessId;
                        }
                    }

                }
                else if (Num == 0)
                {
                    string Query = "";
                    if (ButtonType == "1")
                    {
                        Query = @"update facility set Location='" + model.LocationName + "',Street='" + model.Address + "',CityId='" + model.City + "',StateId='" + model.State + "',Zipcode='" + model.Zipcode + "',ContactNo='" + model.PhoneNumber + "',FaxNo='" + model.FaxNumber + "',ManagerId='" + SecurityManager.Encrypt(model.Manager) + "',EmailId='" + SecurityManager.Encrypt(model.EmailAddress) + "',IsActive='" + "1" + "' where FacilityId='" + tempId + "'";
                        ULD.OperationName = "Update";
                        ULD.Detail = "Location Detail Updated Successfully!";
                        ULD.DetailForUserView = "Location Detail Update Successfully!";
                    }

                    else if (ButtonType == "2")
                    {
                        Query = @"update `facility` set `IsActive` =0 where `FacilityId`='" + tempId + "'";
                        ULD.OperationName = "Delete";
                        ULD.Detail = "Location Detail Deleted Successfully!";
                        ULD.DetailForUserView = "Location Detail Deleted Successfully!";
                    }

                    MySqlCommand cmd = new MySqlCommand(Query, obj.con);
                    obj.OpenDbConnection();
                    SuccessId = cmd.ExecuteNonQuery();
                    obj.CloseDbConnection();
                    int Result = AdminClass.UserLogDetail(ULD);
                    return SuccessId;
                }
            }
            catch(Exception ex)
            {
                
            }
            return 0;
        
          
        }

        public ActionResult UserTypeDelete(int TypeId)
        {
            try
            {
                MySqlCommand cmd = new MySqlCommand("UPDATE  `userrole`  SET   `Isactive`=0  where  `R_id`= '" + TypeId + "'", obj.con);
                obj.OpenDbConnection();
                cmd.ExecuteNonQuery();
                obj.OpenDbConnection();
            }
            catch (Exception)
            {
                obj.OpenDbConnection();
            }

            return RedirectToAction("UserLevel", "Home", new { FormId = 34 });
        }
    }
}
