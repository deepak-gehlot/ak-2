﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.BussinessLayer;
using NewAPGApplication.Models;
using System.Web.Security;
using PagedList;
using PagedList.Mvc;
using System.IO;

namespace NewAPGApplication.Controllers
{
    public class PatientDeshboardController : Controller
    {
        //
        // GET: /PatientDeshboard/

        DbConnection obj = new DbConnection();
        string WomacName;

        public int CheckSession(int CheckNo)
        {
            int returnValue = 0;
            if (CheckNo == 1)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["LoginUserId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            if (CheckNo == 2)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["UserTypeId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            return returnValue;
        }
               
        public ActionResult PatientIndex(int? Page)
        {
            var userid = Session["UserID"] ;
            if (userid == "remove")
            {

                return RedirectToAction("MyIndex", "Patient");
            }
            else
            {
                try
                {
                    int SessionState = CheckSession(1);
                    if (SessionState == 1)
                    {
                        string LoginUserId = Session["LoginUserId"].ToString();
                        int Allowed = 1;
                        if (Allowed == 1)
                        {
                            ViewBag.Message = "Welcome to my demo!";
                            var tupleModel = new Tuple<IPagedList<PatientWomacReport>, IPagedList<PatientWomacReport>, IPagedList<PatientWomacReport>, IPagedList<PatientInjectionReport>>(GetPatient(LoginUserId, Page), GetWomacComparison(LoginUserId, Page), GetPatientBMIHistory(LoginUserId, Page), GetInjectionInformation(LoginUserId, Page));
                            return View(tupleModel);
                        }
                        else
                        {
                            ViewBag.ErrorMessage = "User Session TimeOut";
                            return RedirectToAction("LogOut", "Account");
                        }
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "User Session TimeOut";
                        return RedirectToAction("LogOut", "Account");
                    }
                }
                catch
                {
                    return RedirectToAction("LogOut", "Account");
                }
            
            }
           
           
        }

        public IPagedList<PatientWomacReport> GetPatient(string tempLoginUserId, int? Page)
        {
            PatientWomacReportList model = new PatientWomacReportList();
            try
            {
                string UserId = SecurityManager.Encrypt(tempLoginUserId);

                List<PatientWomacReport> PatientWomacReportDetail = new List<PatientWomacReport>();
               // MySqlCommand cmd = new MySqlCommand("SELECT distinct t2.PatientId,t1.F_Name,t1.L_Name,t2.Knee,t2.WOMAC_TestOn,t2.WOMAC_Name,t2.WOMAC_NexttestOn,t2.Complete FROM userregister t1 INNER JOIN  womac_test t2 ON t1.U_Id=t2.PatientId where t1.U_Id='" +SecurityManager.Encrypt(UserId) + "' and t1.IsActive='" + 1 + "'", obj.con);

                MySqlCommand cmd = new MySqlCommand("SELECT distinct IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee FROM userregister t1 INNER JOIN womac_test t2 ON t2.PatientId = t1.U_Id  where t1.U_Id='" + UserId + "' and t1.IsActive='" + 1 + "'", obj.con);

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                //string FName = Name;   
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string Kneevalue = dt.Rows[i]["Knee"].ToString() == "Left Knee,Right Knee" ? "Left Knee,Right Knee" : dt.Rows[i]["Knee"].ToString();
                        string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());

                        string WomacTestDate1 = null, WomacTestDate2 = null, WomacTestDate3 = null, IsComplete1 = null, IsComplete2 = null, IsComplete3 = null;

                        DataTable Dtw1 = WomacCalender.GetPatientWomacNo(UserId, 1);
                        DataTable Dtw2 = WomacCalender.GetPatientWomacNo(UserId, 2);
                        DataTable Dtw3 = WomacCalender.GetPatientWomacNo(UserId, 3);

                        int WomacNo = 0;
                        if (Dtw3.Rows.Count > 0)
                        {
                            WomacNo = Convert.ToInt16(Dtw3.Rows[0]["WOMAC_Name"].ToString());
                        }
                        else if (Dtw2.Rows.Count > 0)
                        {
                            WomacNo = Convert.ToInt16(Dtw2.Rows[0]["WOMAC_Name"].ToString());
                        }
                        else if (Dtw1.Rows.Count > 0)
                        {
                            WomacNo = Convert.ToInt16(Dtw1.Rows[0]["WOMAC_Name"].ToString());
                        }

                        if (WomacNo == 1)
                        {

                            WomacTestDate1 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw1.Rows[0]["Complete"].ToString());
                            WomacTestDate2 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_NexttestOn"].ToString().Replace("12:00:00 AM", " "), IsComplete2);
                            WomacTestDate3 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_NexttestOn"].ToString().Replace("12:00:00 AM", " "), IsComplete3);

                            if (WomacTestDate2 == WomacTestDate3)
                            {
                                // WomacTestDate3 = WomacCalender.WoMacTestDate_III(WmcNxtdate, IsComplete3);
                                WomacTestDate3 = WomacCalender.WoMacTestDate_III(Dtw1.Rows[0]["WOMAC_NexttestOn"].ToString().Replace("12:00:00 AM", " "), IsComplete3);
                            }

                        }
                        else if (WomacNo == 2)
                        {
                            WomacTestDate1 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw1.Rows[0]["Complete"].ToString());
                            WomacTestDate2 = WomacCalender.WoMacTestDate(Dtw2.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw2.Rows[0]["Complete"].ToString());
                            WomacTestDate3 = WomacCalender.WoMacTestDate(Dtw2.Rows[0]["WOMAC_NexttestOn"].ToString().Replace("12:00:00 AM", " "), IsComplete3);
                        
                        }
                        else if (WomacNo == 3)
                        {
                            WomacTestDate1 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw1.Rows[0]["Complete"].ToString());
                            WomacTestDate2 = WomacCalender.WoMacTestDate(Dtw2.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw2.Rows[0]["Complete"].ToString());
                            WomacTestDate3 = WomacCalender.WoMacTestDate(Dtw3.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw3.Rows[0]["Complete"].ToString());
                        }
                        if (WomacTestDate1 == "Due Date")
                        {
                            WomacTestDate2 = "-";
                            WomacTestDate3 = "-";
                        }
                        else if (WomacTestDate2 == "Due Date")
                        {
                            WomacTestDate3 = "-";
                        }
                        else if (WomacTestDate2 == "-")
                        {
                            WomacTestDate3 = "-";
                        }
                      

                        PatientWomacReportDetail.Add(new PatientWomacReport
                         {
                             PatientId = dt.Rows[i]["U_Id"].ToString(),
                             PatientName = PN,
                             Knee = Kneevalue, //dt.Rows[i]["Knee"].ToString(),
                             Womac1 = WomacTestDate1,
                             Womac2 = WomacTestDate2,
                             Womac3 = WomacTestDate3
                         });                        
                       
                    }
                }
                model.PatientWomacRepotList = PatientWomacReportDetail;
            }
            catch
            {
            }
            return model.PatientWomacRepotList.ToList().ToPagedList(Page ?? 1, 2);
        }

        public IPagedList<PatientWomacReport> GetWomacComparison(string tempLoginUserId, int? Page)
        {

            PatientWomacReportList model = new PatientWomacReportList();
            try
            {
                int wmcscor = 0;
                string UserId = tempLoginUserId;

                List<PatientWomacReport> PatientWomacReportDetail = new List<PatientWomacReport>();


                MySqlCommand cmd = new MySqlCommand("SELECT distinct IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee FROM userregister t1 INNER JOIN womac_test t2 ON t2.PatientId = t1.U_Id  where t1.U_Id='" + SecurityManager.Encrypt(UserId) + "' and t1.IsActive='" + 1 + "'", obj.con);

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count != 0)
                {
                    if (ds.Tables[0].Rows.Count != 0)
                    {
                        for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                        {
                            string Pid = ds.Tables[0].Rows[i]["U_Id"].ToString();
                            DataSet dset1 = WomacCalender.GetPatientWomacScore(Pid, 1);
                            DataSet dset2 = WomacCalender.GetPatientWomacScore(Pid, 2);
                            DataSet dset3 = WomacCalender.GetPatientWomacScore(Pid, 3);

                            if (dset1.Tables[0].Rows.Count != 0)
                            {
                                wmcscor = 0;
                                for (int a1 = 0; a1 < dset1.Tables[0].Rows.Count; a1++)
                                {
                                    wmcscor = wmcscor + Convert.ToInt16(dset1.Tables[0].Rows[a1]["TotalScore"]);
                                    WomacName = "Womac-1";
                                }
                                PatientWomacReportDetail.Add(new PatientWomacReport
                                {
                                    Knee = ds.Tables[0].Rows[i]["Knee"].ToString(),
                                    Womac1 = WomacName.ToString(),   // Womac Name
                                    Womac2 = wmcscor.ToString(),    //  Total Score
                                    Womac3 = i.ToString()
                                });
                            }

                            if (dset2.Tables[0].Rows.Count != 0)
                            {
                                wmcscor = 0;
                                for (int a1 = 0; a1 < dset2.Tables[0].Rows.Count; a1++)
                                {
                                    wmcscor = wmcscor + Convert.ToInt16(dset2.Tables[0].Rows[a1]["TotalScore"]);
                                    WomacName = "Womac-2";
                                }

                                PatientWomacReportDetail.Add(new PatientWomacReport
                                {
                                    Knee = ds.Tables[0].Rows[i]["Knee"].ToString(),
                                    Womac1 = WomacName.ToString(),    // Womac Name
                                    Womac2 = wmcscor.ToString(),     //  Total Score
                                    Womac3 = i.ToString()
                                });
                            }

                            if (dset3.Tables[0].Rows.Count != 0)
                            {
                                wmcscor = 0;
                                for (int a1 = 0; a1 < dset3.Tables[0].Rows.Count; a1++)
                                {
                                    wmcscor = wmcscor + Convert.ToInt16(dset3.Tables[0].Rows[a1]["TotalScore"]);
                                    WomacName = "Womac-3";
                                }

                                PatientWomacReportDetail.Add(new PatientWomacReport
                                {
                                    Knee = ds.Tables[0].Rows[i]["Knee"].ToString(),
                                    Womac1 = WomacName.ToString(),  //   Womac Name
                                    Womac2 = wmcscor.ToString(),   //    Total Score
                                    Womac3 = i.ToString()
                                });
                            }



                        }
                    }
                }
                model.PatientWomacRepotList = PatientWomacReportDetail;
            }
            catch
            {
            }
            return model.PatientWomacRepotList.ToList().ToPagedList(Page ?? 1, 6);
        }

        public IPagedList<PatientWomacReport> GetPatientBMIHistory(string tempLoginUserId, int? Page)
        {
            PatientWomacReportList model = new PatientWomacReportList();
            try
            {
                string UserId = tempLoginUserId;

                List<PatientWomacReport> PatientWomacReportDetail = new List<PatientWomacReport>();

                MySqlCommand cmd = new MySqlCommand("SELECT distinct IFNULL(t2.BMIId, '') AS BMIId,IFNULL(t2.CreatedOn, '') AS CreatedOn,IFNULL(t2.U_Id, '') AS U_Id,IFNULL(t2.BMI, '') AS BMI,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name FROM userregister t1 INNER JOIN  bmi_record t2 ON t1.U_Id=t2.U_Id where t1.U_Id='" + SecurityManager.Encrypt(UserId) + "' and t1.IsActive='" + 1 + "'", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);              
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count != 0)
                {
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {
                        PatientWomacReportDetail.Add(new PatientWomacReport
                        {
                            PatientName = "BMI " + Convert.ToDateTime(ds.Tables[0].Rows[i]["CreatedOn"].ToString()).ToString("MMM dd,yyyy"),
                            Womac1 = ds.Tables[0].Rows[i]["BMI"].ToString(),
                           
                        });
                    }
                }
                model.PatientWomacRepotList = PatientWomacReportDetail;
            }
            catch
            {
            }
            return model.PatientWomacRepotList.ToList().ToPagedList(Page ?? 1, 3);
        }

        public IPagedList<PatientInjectionReport> GetInjectionInformation(string tempLoginUserId, int? Page)
        {
            PatientInjectionReportList model = new PatientInjectionReportList();
            try
            {
                string UserId = tempLoginUserId;
                             
                List<PatientInjectionReport> PatientInjectionReportDetail = new List<PatientInjectionReport>();

                MySqlCommand cmd = new MySqlCommand("SELECT distinct IFNULL(t2.InjectionId, '') AS InjectionId,IFNULL(t2.PatientId, '') AS PatientId,IFNULL(t2.WOMAC_Name, '') AS WOMAC_Name,IFNULL(t2.InjectionNumber, '') AS InjectionNumber,IFNULL(t2.TheraphyOn, '') AS TheraphyOn,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee FROM userregister t1 INNER JOIN  injectiondetails t2 ON t1.U_Id=t2.PatientId where t2.PatientId='" + SecurityManager.Encrypt(UserId) + "' and t1.IsActive='" + 1 + "'", obj.con);

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);                
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count != 0)
                {
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {
                        PatientInjectionReportDetail.Add(new PatientInjectionReport
                        {
                            InjectionNo = "Injection Date: " + (i + 1),
                            InjectionDate = Convert.ToDateTime(ds.Tables[0].Rows[i]["TheraphyOn"].ToString()).ToString("MMM dd,yyyy"),
                            Knee = "Left knee"
                        });
                    }
                    int TotalRows = ds.Tables[0].Rows.Count;
                    int Count = 1;
                    for (int i = ds.Tables[0].Rows.Count; i < 6; i++)
                    {
                        string InjectionDate = null;
                        InjectionDate = WomacCalender.CheckInjectionTestDate(ds.Tables[0].Rows[TotalRows - 1]["TheraphyOn"].ToString(), 14 * Count);
                        Count++;
                        PatientInjectionReportDetail.Add(new PatientInjectionReport
                        {
                            InjectionNo = "Injection Date: " + (i + 1),
                            InjectionDate = InjectionDate,
                            Knee ="Left knee"
                        });
                    }
                }
                //if (ds.Tables[0].Rows.Count != 0)
                //{
                //    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                //    {
                //        PatientInjectionReportDetail.Add(new PatientInjectionReport
                //        {
                //            InjectionNo = "Injection Date -" + (i + 1),
                //            InjectionDate = "Injected " + Convert.ToDateTime(ds.Tables[1].Rows[i]["TheraphyOn"].ToString()).ToString("MMM-dd-yyyy"),
                //            Knee = "Right knee"
                //        });
                //    }
                //    int TotalRows = ds.Tables[0].Rows.Count;
                //    int Count = 1;
                //    for (int i = ds.Tables[0].Rows.Count; i < 6; i++)
                //    {
                //        string InjectionDate = null;
                //        InjectionDate = WomacCalender.CheckInjectionTestDate(ds.Tables[0].Rows[TotalRows - 1]["TheraphyOn"].ToString(), 14 * Count);
                //        Count++;
                //        PatientInjectionReportDetail.Add(new PatientInjectionReport
                //        {
                //            InjectionNo = "Injection Date -" + (i + 1),
                //            InjectionDate = InjectionDate,
                //            Knee = "Right knee"
                //        });
                //    }
                //}
                model.patientInjectionRepotList = PatientInjectionReportDetail;
            }
            catch (Exception e)
            {
            }
            return model.patientInjectionRepotList.ToList().ToPagedList(Page ?? 1, 12);
        }

        public ActionResult PatientBMI()
        {
            Session["AccessFormId"] = 3;
            PatientBMIList model = new PatientBMIList();
            try
            {              
                if (Session["UserId"] != null)
                {
                    string UserID = Session["UserId"].ToString();
                   

                    List<PatientBMI> patientBMIDetail = new List<PatientBMI>();
                    MySqlCommand cmd = new MySqlCommand("SELECT distinct t2.U_Id,t1.F_Name,t1.L_Name,t2.BMIId,t2.Height,t2.Weight,t2.CreatedOn,t2.BMI FROM userregister t1 INNER JOIN  bmi_record t2 ON t1.U_Id=t2.U_Id where t1.U_Id='" + SecurityManager.Encrypt(UserID) + "' and t1.IsActive='" + 1 + "'", obj.con);
                  
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            string PN =  SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());
                            int Height = String.IsNullOrEmpty(dt.Rows[i]["Height"].ToString()) ? 0 : Convert.ToInt32(dt.Rows[i]["Height"].ToString());
                            int HeightFeet = Height / 12;
                            int HeightInch = Height % 12;
                            patientBMIDetail.Add(new PatientBMI
                            {
                                PatientId = SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                FirstName = PN,
                                Height = Height,
                                HeightFeet = HeightFeet,
                                HeightInch = HeightInch,
                                Weight = String.IsNullOrEmpty(dt.Rows[i]["Weight"].ToString()) ? 0 : Convert.ToDouble(dt.Rows[i]["Weight"].ToString()),
                                BMI = String.IsNullOrEmpty(dt.Rows[i]["BMI"].ToString()) ? 0 : Convert.ToDouble(dt.Rows[i]["BMI"].ToString()),
                                BMIDate = dt.Rows[i]["CreatedOn"].ToString(),
                             
                            });
                        }
                    }
                    model.patientBMIList = patientBMIDetail;
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch
            {
            }
            return View(model);
        }
    }
}
