﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.BussinessLayer;
using NewAPGApplication.Models;
using System.Web.Security;

namespace NewAPGApplication.Controllers
{
    public class PatientQuestionnaireController : Controller
    {
        DbConnection obj = new DbConnection();
        string Success, UserID, EmailID;
        bool RememberMe;

        public int CheckSession(int CheckNo)
        {
            int returnValue = 0;
            if (CheckNo == 1)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["LoginUserId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            if (CheckNo == 2)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["UserTypeId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            return returnValue;
        }

        public ActionResult HealthQuestionnaire_1(string param)
        {
            param = param == null ? "Patient Platform Setting" : param;

            try
            {
                //PatientRegistration ob = new PatientRegistration();
                //int SessionState = CheckSession(1);
                //if (SessionState == 1)
                //{
                //    string tempUserLoginType = Session["LoginUserType"].ToString();
                //    int Allowed = 1;
                //    if (Allowed == 1)
                //    {
                //        string tempemail = Session["EmailId"] != null ? Session["EmailId"].ToString() : "";
                //        string tempUserNameId = Session["UserId"] != null ? Session["UserId"].ToString() : "";

                //        if (tempUserLoginType == "Patient")
                //        {
                //            Session["PatientIsActive"] = false;
                //        }
                //        Session["UserIsActive"] = null;
                //        // return RedirectToAction("GetPatientInfo");
                //    }
                //    else
                //    {
                //        ViewBag.ErrorMessage = "User Session TimeOut";
                //        return RedirectToAction("LogOut", "Account");
                //    }
                //}
                //else
                //{
                //    return RedirectToAction("LogOut", "Account");
                //}
                //return View(ob);
                return View();
            }
            catch
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        [HttpPost]
        public ActionResult PutPatientQuestionnaire(PatientQuestionnaire ObjPi)
        {
            string Gender = "";
            var ret = Gender;

            try
            {
                PatientInfoPut ob = new PatientInfoPut();
                string result = ob.PatientQuestionnaire(ObjPi);
                ViewData["result"] = result;
                Success = result;
                if (Success == "1")
                {
                    MySqlCommand cmd = new MySqlCommand("select * from  userregister where U_Id= '" + SecurityManager.Encrypt(ObjPi.UserNameId) + "'", obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count != 0)
                    {
                        if (dt.Rows[0]["Gender"].ToString().Trim() == "Male")
                        {
                            Gender = "Male";
                        }
                        else if (dt.Rows[0]["Gender"].ToString().Trim() == "Female")
                        {
                            Gender = "Female";
                        }
                    }
                }
                else
                {
                    return RedirectToAction("HealthQuestionnaire_1", "PatientQuestionnaire");
                }

            }
            catch (Exception)
            {
                ret = Gender;
                return Json(ret);
            }
            ret = Gender;
            return Json(ret);

        }

        [HttpGet]
        public ActionResult MaleBodyTest(string param)
        {
            param = param == null ? "Patient Platform Setting" : param;

            try
            {
                PatientRegistration ob = new PatientRegistration();
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    string tempUserLoginType = Session["LoginUserType"].ToString();
                    int Allowed = 1;
                    if (Allowed == 1)
                    {
                        string UserNameId = Session["UserId"] != null ? Session["UserId"].ToString() : "";

                        if (tempUserLoginType == "Patient")
                        {
                            Session["PatientIsActive"] = false;
                        }
                        Session["UserIsActive"] = null;
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "User Session TimeOut";
                        return RedirectToAction("LogOut", "Account");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
                return View(ob);
            }
            catch
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        [HttpGet]
        public ActionResult FemaleBodyTest(string param)
        {
            param = param == null ? "Patient Platform Setting" : param;

            try
            {
                PatientRegistration ob = new PatientRegistration();
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    string tempUserLoginType = Session["LoginUserType"].ToString();
                    int Allowed = 1;
                    if (Allowed == 1)
                    {
                        string UserNameId = Session["UserId"] != null ? Session["UserId"].ToString() : "";

                        if (tempUserLoginType == "Patient")
                        {
                            Session["PatientIsActive"] = false;
                        }
                        Session["UserIsActive"] = null;
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "User Session TimeOut";
                        return RedirectToAction("LogOut", "Account");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
                return View(ob);
            }
            catch
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        [HttpGet]
        public ActionResult MalePainReport()
        {
            int SessionState = CheckSession(1);
            if (SessionState == 1)
            {
                return View();
            }
            else
            {
                ViewBag.ErrorMessage = "User Session TimeOut";
                return RedirectToAction("LogOut", "Account");
            }
        }

        [HttpGet]
        public ActionResult FemalePainReport()
        {
            int SessionState = CheckSession(1);
            if (SessionState == 1)
            {
                return View();
            }
            else
            {
                ViewBag.ErrorMessage = "User Session TimeOut";
                return RedirectToAction("LogOut", "Account");
            }
        }

        [HttpPost]
        public ActionResult PutPainSelection(BodyTest ObjBd)
        {
            string UserNameId = "", Gender = "";
            var ret = Gender;

            try
            {

                PutPatientDetails ob = new PutPatientDetails();
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    UserNameId = Session["UserId"] != null ? Session["UserId"].ToString() : "";
                }
                string result = ob.PutPainInfo(ObjBd, SecurityManager.Encrypt(UserNameId));
                ViewData["result"] = result;
                Success = result;
                if (Success == "1")
                {
                    MySqlCommand cmd = new MySqlCommand("select * from  userregister where U_Id= '" + SecurityManager.Encrypt(UserNameId) + "'", obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count != 0)
                    {
                        if (dt.Rows[0]["Gender"].ToString().Trim() == "Male")
                        {
                            Gender = "Male";
                        }
                        else if (dt.Rows[0]["Gender"].ToString().Trim() == "Female")
                        {
                            Gender = "Female";
                        }
                    }
                }
                else
                {
                    return RedirectToAction("MaleBodyTest", "PatientQuestionnaire");
                }

            }
            catch (Exception)
            {
                ret = Gender;
                return Json(ret);
            }
            ret = Gender;
            return Json(ret);

        }


        [HttpPost]
        public ActionResult PutPainDetails(BodyTest ObjBd)
        {
            string UserNameId = "0", Gender = "", result = "0";
            var ret = Gender;


            try
            {

                PutPatientDetails ob = new PutPatientDetails();
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    UserNameId = Session["UserId"] != null ? Session["UserId"].ToString() : "";
                }

                MySqlCommand cmd = new MySqlCommand("select * from  userregister where U_Id= '" + UserNameId + "'", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count != 0)
                {
                    if (dt.Rows[0]["Gender"].ToString().Trim() == "Male")
                    {
                        Gender = "Male";
                        result = ob.PutMalePainInfo(ObjBd, SecurityManager.Encrypt(UserNameId));
                        ViewData["result"] = result;
                    }
                    else if (dt.Rows[0]["Gender"].ToString().Trim() == "Female")
                    {
                        Gender = "Female";
                        result = ob.PutFeMalePainInfo(ObjBd, SecurityManager.Encrypt(UserNameId));
                        ViewData["result"] = result;
                    }
                }

                if (result == "1")
                {
                    Success = result;
                }
            }

            catch (Exception)
            {
                ret = Success;
                return Json(ret);
            }
            ret = Success;
            return Json(ret);

        }
    }
}