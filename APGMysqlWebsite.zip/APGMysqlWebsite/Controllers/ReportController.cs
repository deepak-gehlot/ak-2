﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using MySql.Data.MySqlClient;
using NewAPGApplication.BussinessLayer;
using NewAPGApplication.Models;
using System.Web.Security;

namespace NewAPGApplication.Controllers
{
    public class ReportController : Controller
    {
        [Authorize]
        public ActionResult AgeGraphicReport1(int FacilityId = 0)
        {
            return View();
        }

        public int CheckSession(int CheckNo)
        {
            int returnValue = 0;
            if (CheckNo == 1)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["LoginUserId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            if (CheckNo == 2)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["UserTypeId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            return returnValue;
        }


        [HttpGet]
        public JsonResult AgeGraphicReport(int Facility)
         {
             int FacilityId = Facility;
            AgeGraphReportOne model = new AgeGraphReportOne();
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {

                    int LoggedFacilityId = Session["LoggedInFacilityId"].ToString() != "0" ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                    if (LoggedFacilityId == 0)
                    {
                        string Uid = Session["UserId"].ToString() != "0" ? Session["UserId"].ToString() : "0";
                        LoggedFacilityId = GraphicReport.GetFacilityId(Uid);
                    }
                    if (LoggedFacilityId != 0)
                    {
                        if (FacilityId == 0 || FacilityId == null)
                        {
                            model = GraphicReport.AgeGraphicReporting(LoggedFacilityId);
                            model.FacilityId = LoggedFacilityId;
                        }
                        else
                        {
                            model = GraphicReport.AgeGraphicReporting(FacilityId);
                            model.FacilityId = FacilityId;
                        }
                    }
                }
                else
                {
                    return Json(SessionState, JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
            }
            return Json(model, JsonRequestBehavior.AllowGet);
        }


        public ActionResult Charts()
        {

            ChartData model = new ChartData();

             int SessionState = CheckSession(1);
             if (SessionState == 1)
             {

                 int LoggedFacilityId = Session["LoggedInFacilityId"].ToString() != "0" ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                 if (LoggedFacilityId == 0)
                 {
                     string Uid = Session["UserId"].ToString() != "0" ? Session["UserId"].ToString() : "0";
                     LoggedFacilityId = GraphicReport.GetFacilityId(Uid);
                 }
                 if (LoggedFacilityId != 0)
                 {
                     model = GraphicReport.ChartReportData(LoggedFacilityId);
                 }
             }
             else
             {
                 return RedirectToAction("LogOut", "Account");
             }
            return View(model);
        }

    }
}
