﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using NewAPGApplication.BussinessLayer;
using NewAPGApplication.Controllers;
using System.Transactions;
using System.Web.Security;
using DotNetOpenAuth.AspNet;
using Microsoft.Web.WebPages.OAuth;
using WebMatrix.WebData;
using NewAPGApplication.Filters;
using MySql.Data.MySqlClient;

using System.Data;
using System.Configuration;
using System.Data.Entity;
using System.Dynamic;
using PagedList;
using PagedList.Mvc;
using System.IO;
using System.Web.UI;
using NewAPGApplication.Models;
using Rotativa;
using System.Net.Mail;
using System.Text.RegularExpressions;
using APGWebsite.BussinessLayer;

namespace NewAPGApplication.Controllers
{
    public class AdminController : Controller
    {
        DbConnection obj = new DbConnection();
        // string Wmcdate1, Wmcdate2, Wmcdate3, WmcNxtdate1, WmcNxtdate2, WmcNxtdate3;

        string Wmcdate, WmcNxtdate;

        

        public int CheckSession(int CheckNo)
        {
            int returnValue = 0;
            if (CheckNo == 1)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["LoginUserId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            if (CheckNo == 2)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["UserTypeId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            return returnValue;
        }

        //---------------- ADMIN DASHBOARD

        [HttpGet]
        public ActionResult AdminIndex(int? Page)
        {
           string fname = SecurityManager.Encrypt("MARIE").ToString();
            string Lname = SecurityManager.Encrypt("CLARK").ToString();
            Session["patientEmailid"] = null;
            var userid = Session["UserID"] ;
            if (userid == "remove")
            {
                return RedirectToAction("MyIndex", "Patient");
            }
            else
            {
                try
                {
                    int SessionState = CheckSession(1);
                    if (SessionState == 1)
                    {
                        int Allowed = 1;//APGBussinessClass.UserFormAuthenticationDetail(101, Connection.LoginUserTypeId);
                        if (Allowed == 1)
                        {
                            ViewBag.Message = "Welcome to my demo!";
                            var tupleModel = new Tuple<IPagedList<PatientWomacReport>, WomacAlert, Notification, PatientRegistration>(GetPatient(Page), WomacAlertCount(), NotificationAlertCount(), UserDetail());
                            // tupleModel=model

                            return View(tupleModel);
                        }
                        else
                        {
                            ViewBag.ErrorMessage = "User Session TimeOut";
                            return RedirectToAction("LogOut", "Account");
                        }
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "User Session TimeOut";
                        return RedirectToAction("LogOut", "Account");
                    }
                }
                catch(Exception ex)
                {
                }
                ViewBag.Name = "Admin";
                return RedirectToAction("LogOut", "Account");
            }
        }

        private IPagedList<PatientWomacReport> GetPatient(int? Page)
        {
            Session["AccessFormId"] = 101;
            PatientWomacReportList model = new PatientWomacReportList();
            try
            {
                string Name = "";
                model = GetWomacList(Name);
            }
            catch
            {
            }
            return model.PatientWomacRepotList.ToList().ToPagedList(Page ?? 1, 3);
        }

        public PatientWomacReportList GetWomacList(string Name)
        {
            PatientWomacReportList model = new PatientWomacReportList();
            try
            {
                int LoggedFacilityId = Session["LoggedInFacilityId"].ToString() != "0" ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;

                if (LoggedFacilityId != 0)
                {
                    List<PatientWomacReport> PatientWomacReportDetail = new List<PatientWomacReport>();
                    // MySqlCommand cmd = new MySqlCommand("SELECT distinct t2.PatientId,t1.F_Name,t1.L_Name,t2.Knee,t2.WOMAC_TestOn,t2.WOMAC_Name,t2.WOMAC_NexttestOn,t2.Complete FROM userregister t1 INNER JOIN  womac_test t2 ON t1.U_Id=t2.PatientId where t1.FacilityId='" + LoggedFacilityId + "' and t1.R_Id='" + 10 + "' and t1.IsActive='" + 1 + "'", obj.con);

                    MySqlCommand cmd = new MySqlCommand("SELECT IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.FacilityId, '') AS FacilityId,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee,IFNULL(WOMAC_TestOn, '') AS WOMAC_TestOn, IFNULL(WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,max(case when t2.WOMAC_Name = '1' then t2.Complete else ' 'end) as '1', max(case when t2.WOMAC_Name = '2' then t2.Complete else ' 'end) as '2',max(case when t2.WOMAC_Name = '3' then t2.Complete else ' 'end) as '3' FROM userregister t1 INNER JOIN  womac_test t2 ON t2.PatientId = t1.U_Id where t1.IsActive = 1 and t1.R_Id =10 and t1.Inactive=0 group by  t1.U_Id order by WOMAC_TestOn desc", obj.con);

                 //   MySqlCommand cmd = new MySqlCommand("SELECT IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.FacilityId, '') AS FacilityId,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee,IFNULL(WOMAC_TestOn, '') AS WOMAC_TestOn, IFNULL(WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,max(case when t2.WOMAC_Name = '1' then t2.Complete else ' 'end) as '1', max(case when t2.WOMAC_Name = '2' then t2.Complete else ' 'end) as '2',max(case when t2.WOMAC_Name = '3' then t2.Complete else ' 'end) as '3' FROM userregister t1 INNER JOIN  womac_test t2 ON t2.PatientId = t1.U_Id where t1.IsActive = 1 and t1.R_Id =10 group by  t1.U_Id order by WOMAC_TestOn desc", obj.con);

                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);

                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            string PatientID = dt.Rows[i]["U_Id"].ToString();

                            string WomacTestDate1_temp = DateTime.Now.ToString(), WomacTestDate2_temp = DateTime.Now.ToString();

                            string Kneevalue = dt.Rows[i]["Knee"].ToString() == "Left Knee,Right Knee" ? "Left Knee,Right Knee" : dt.Rows[i]["Knee"].ToString();

                            string PN = SecurityManager.Decrypt(dt.Rows[i]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[i]["L_Name"].ToString());

                            string WomacTestDate1 = null, WomacTestDate2 = null, WomacTestDate3 = null, IsComplete1 = null, IsComplete2 = null, IsComplete3 = null;

                         
                                DataTable Dtw1 = WomacCalender.GetWomacNo(PatientID, 1, Convert.ToInt16(LoggedFacilityId));
                                DataTable Dtw2 = WomacCalender.GetWomacNo(PatientID, 2, Convert.ToInt16(LoggedFacilityId));
                                DataTable Dtw3 = WomacCalender.GetWomacNo(PatientID, 3, Convert.ToInt16(LoggedFacilityId));

                                DataTable Dtw = WomacCalender.GetAllWomac(PatientID, Convert.ToInt16(LoggedFacilityId));

                                if (Dtw.Rows.Count >= 2)
                                {
                                    for (int j = 0; j < Dtw.Rows.Count; j++)
                                    {
                                        Kneevalue = null;
                                        Kneevalue = Dtw.Rows[j]["Knee"].ToString();

                                        WomacTestDate1 = WomacCalender.WoMacTestDate(Dtw.Rows[j]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw.Rows[j]["1"].ToString());
                                        if (Dtw2.Rows.Count != 0)
                                        {
                                            WomacTestDate2 = WomacCalender.WoMacTestDate(Dtw.Rows[j]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw.Rows[j]["2"].ToString());
                                        }
                                        if (Dtw3.Rows.Count != 0)
                                        {
                                            WomacTestDate3 = WomacCalender.WoMacTestDate(Dtw.Rows[j]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw.Rows[j]["3"].ToString());
                                        }

                                        if (WomacTestDate2 == null || WomacTestDate2 == "")
                                        {
                                            WomacTestDate2 = Convert.ToDateTime(Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " ")).AddDays(15).ToString("MMM-dd-yyyy");

                                        }
                                        if (WomacTestDate3 == null || WomacTestDate3 == "")
                                        {
                                            if (WomacTestDate2 == "Complete")
                                            {
                                                WomacTestDate3 = Convert.ToDateTime(WomacTestDate2).AddDays(15).ToString("MMM-dd-yyyy");
                                            }
                                            if (WomacTestDate2 == "Due Date")
                                            {
                                                WomacTestDate3 = "-";
                                            }
                                        }

                                        if (WomacTestDate1 == "Due Date")
                                        {
                                            WomacTestDate2 = "-";
                                            WomacTestDate3 = "-";
                                        }

                                        if (WomacTestDate2 == "Due Date")
                                        {
                                            WomacTestDate3 = "-";

                                        }

                                        PatientWomacReportDetail.Add(new PatientWomacReport
                                        {
                                            PatientId =SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                            PatientName = PN,
                                            Knee = Kneevalue,
                                            Womac1 = WomacTestDate1,
                                            Womac2 = WomacTestDate2,
                                            Womac3 = WomacTestDate3
                                        });
                                    }
                                }

                            int WomacNo = 0;
                            if (Dtw3.Rows.Count > 0)
                            {
                                WomacNo = Convert.ToInt16(Dtw3.Rows[0]["WOMAC_Name"].ToString());
                            }
                            else if (Dtw2.Rows.Count > 0)
                            {
                                WomacNo = Convert.ToInt16(Dtw2.Rows[0]["WOMAC_Name"].ToString());
                            }
                            else if (Dtw1.Rows.Count > 0)
                            {
                                WomacNo = Convert.ToInt16(Dtw1.Rows[0]["WOMAC_Name"].ToString());
                            }


                            if (WomacNo == 1)
                            {
                                try
                                {
                                    string womacstatus=Dtw1.Rows[0]["Complete"].ToString();
                                    WomacTestDate1 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "),womacstatus);
                                    WomacTestDate2 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_NexttestOn"].ToString(), IsComplete2);
                                    WomacTestDate3 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_NexttestOn"].ToString(), IsComplete3);

                                    if ((WomacTestDate2 == WomacTestDate3) && (WomacTestDate2 != "" && WomacTestDate3 != "") && (WomacTestDate2 != null && WomacTestDate3 != null))
                                    {
                                        WomacTestDate3 = Convert.ToDateTime(WomacTestDate2).AddDays(15).ToString("MMM-dd-yyyy");
                                    }

                                }
                                catch (Exception ex) { }
                               

                            }
                            else if (WomacNo == 2)
                            {
                                try
                                {
                                    WomacTestDate2_temp = Dtw2.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " ");
                                    WomacTestDate1_temp = Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " ");
                                    WomacTestDate1 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw1.Rows[0]["Complete"].ToString());
                                    WomacTestDate2 = WomacCalender.WoMacTestDate(Dtw2.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw2.Rows[0]["Complete"].ToString());
                                    WomacTestDate3 = WomacCalender.WoMacTestDate(Dtw2.Rows[0]["WOMAC_NexttestOn"].ToString().Replace("12:00:00 AM", " "), IsComplete3);
                                }
                                catch(Exception ex){}
                                if (WomacTestDate3 == "" && WomacTestDate2 == "Completed")
                                {

                                    WomacTestDate3 = Convert.ToDateTime(Dtw2.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " ")).AddDays(15).ToString("MMM-dd-yyyy");
                                    // WomacTestDate3 = "-";
                                }
                                if (WomacTestDate1 == "Completed" && WomacTestDate2 == "Completed")
                                {
                                    WomacTestDate3 = Convert.ToDateTime(Dtw2.Rows[0]["WOMAC_TestOn"].ToString()).AddDays(15).ToString("MMM-dd-yyyy");
                               
                                }

                            }
                            else if (WomacNo == 3)
                            {
                                WomacTestDate1 = WomacCalender.WoMacTestDate(Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw1.Rows[0]["Complete"].ToString());
                                if (Dtw2.Rows.Count != 0)
                                {
                                    WomacTestDate2 = WomacCalender.WoMacTestDate(Dtw2.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw2.Rows[0]["Complete"].ToString());
                                }
                                if (Dtw3.Rows.Count != 0)
                                {
                                    WomacTestDate3 = WomacCalender.WoMacTestDate(Dtw3.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " "), Dtw3.Rows[0]["Complete"].ToString());
                                }
                            }


                            if (WomacTestDate2 == null || WomacTestDate2 == "")
                            {
                                if (WomacTestDate1 == "Completed")
                                {
                                    WomacTestDate2 = Convert.ToDateTime(Dtw1.Rows[0]["WOMAC_TestOn"].ToString().Replace("12:00:00 AM", " ")).AddDays(15).ToString("MMM-dd-yyyy");
                                }
                                else if (WomacTestDate1 == "Due Date")
                                {
                                    WomacTestDate2 = "-";
                                }
                                if (WomacTestDate2 != "")
                                {
                                    if (WomacTestDate2 == "-" || WomacTestDate2 == "Due Date")
                                    {
                                        WomacTestDate3 = "-";
                                    }
                                    else
                                    {
                                        WomacTestDate3 = Convert.ToDateTime(WomacTestDate2).AddDays(15).ToString("MMM-dd-yyyy");
                                    }
                                }

                            }
                            if (WomacTestDate3 == null || WomacTestDate3 == "")
                            {
                                if (WomacTestDate2 == "Completed")
                                {
                                    WomacTestDate3 = Convert.ToDateTime(WomacTestDate2).AddDays(15).ToString("MMM-dd-yyyy");
                                }
                                else if (WomacTestDate2 == "Due Date")
                                {
                                    WomacTestDate3 = "-";
                                }
                                else if (WomacTestDate2 == "" || WomacTestDate2 == null)
                                {
                                    WomacTestDate3 = "-";
                                }
                            }
                            if (WomacTestDate1 == "Due Date")
                            {
                                WomacTestDate2 = "-";
                                WomacTestDate3 = "-";
                            }
                            if (WomacTestDate2 == "Due Date")
                            {
                                WomacTestDate3 = "-";

                            }

                            PatientWomacReportDetail.Add(new PatientWomacReport
                            {
                                PatientId =SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                PatientName = PN,
                                Knee = Kneevalue,
                                Womac1 = WomacTestDate1,
                                Womac2 = WomacTestDate2,
                                Womac3 = WomacTestDate3
                            });

                        }
                    }
                    model.PatientWomacRepotList = PatientWomacReportDetail;
                }
            }
            catch (Exception e)
            {

            }
            return model;
        }

        private WomacAlert WomacAlertCount()
        {
            WomacAlert WA = new WomacAlert();
            try
            {
                string tempLoginUserId = Session["LoginUserId"].ToString() != null ? Session["LoginUserId"].ToString() : "0";
                int tempLoggedinFacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                Session["LoggedInFacilityId"] = tempLoggedinFacilityId;
                if (tempLoggedinFacilityId != 0)
                {
                    MySqlCommand cmd = new MySqlCommand("SELECT IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.FacilityId, '') AS FacilityId,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee,IFNULL(WOMAC_TestOn, '') AS WOMAC_TestOn, IFNULL(WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,max(case when t2.WOMAC_Name = '1' then t2.Complete else ' 'end) as '1', max(case when t2.WOMAC_Name = '2' then t2.Complete else ' 'end) as '2',max(case when t2.WOMAC_Name = '3' then t2.Complete else ' 'end) as '3' FROM userregister t1 INNER JOIN  womac_test t2 ON t2.PatientId = t1.U_Id where t1.IsActive = 1 and t1.R_Id =10 group by  t1.U_Id  order by WOMAC_TestOn desc", obj.con);
                  //  MySqlCommand cmd = new MySqlCommand("SELECT distinct IFNULL(t2.PatientId, '0') AS PatientId, IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee ,IFNULL(t2.WOMAC_TestOn, '') AS WOMAC_TestOn ,IFNULL(t2.WOMAC_Name, '') AS WOMAC_Name,IFNULL(t2.WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,IFNULL(t2.Complete, '') AS Complete FROM userregister t1 INNER JOIN  womac_test t2 ON t1.U_Id=t2.PatientId where t1.FacilityId= '" + tempLoggedinFacilityId + "' and t1.R_Id=10  and t1.IsActive= 1  and (t2.WOMAC_Name =1  OR  t2.WOMAC_Name =2) and  t2.Complete ='FALSE' group by t2.PatientId ", obj.con);  
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count != 0)
                    {
                        int No = 0;
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            if ((dt.Rows[i]["1"].ToString() == "True" || dt.Rows[i]["1"].ToString() == "False" || dt.Rows[i]["2"].ToString() == "False") && (dt.Rows[i]["1"].ToString() != "True" || dt.Rows[i]["2"].ToString() != "True"))
                            {
                                 No =No+1;
                                WA.ProgrssWomacDue = No;
                            }
                        }
                    }
                    else
                    {
                        WA.ProgrssWomacDue = 0;
                    }
                    MySqlCommand cmdd = new MySqlCommand("select * from (SELECT IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.FacilityId, '') AS FacilityId,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t2.Knee, '') AS Knee,IFNULL(DATE_FORMAT(t2.WOMAC_TestOn, '%b-%e-%Y '), '') AS WOMAC_TestOn, IFNULL(t2.WOMAC_NexttestOn, '') AS WOMAC_NexttestOn,max(case when t2.WOMAC_Name = '1' then t2.Complete else ' 'end) as '1', max(case when t2.WOMAC_Name = '2' then t2.Complete else ' 'end) as '2',max(case when t2.WOMAC_Name = '3' then t2.Complete else ' 'end) as '3' FROM userregister t1 INNER JOIN  womac_test t2 ON t2.PatientId = t1.U_Id where  t1.IsActive = 1 and t1.R_Id =10 group by  t1.U_Id  order by WOMAC_TestOn desc) as TTTT where TTTT.1 = 'True' and  TTTT.2 = 'True'  and  TTTT.3 != 'True'", obj.con);
                 
                   // MySqlCommand cmdd = new MySqlCommand("SELECT distinct t2.PatientId,t2.WOMAC_Name,t1.IsActive FROM userregister t1 INNER JOIN  womac_test t2 ON t1.U_Id=t2.PatientId WHERE t2.WOMAC_Name = '" + 2 + "' and t2.FacilityId='" + tempLoggedinFacilityId + "' and t1.IsActive='" + 1 + "' group by WOMAC_Id ", obj.con);
                    MySqlDataAdapter daa = new MySqlDataAdapter(cmdd);
                    DataTable dtt = new DataTable();
                    daa.Fill(dtt);
                    if (dtt.Rows.Count != 0)
                    {
                        int No = 0;
                        No = dtt.Rows.Count;
                       WA.FinalWomacDue = No;
                    }
                    else
                    {
                        WA.FinalWomacDue = 0;
                    }
                }
            }
            catch (Exception e)
            {

            }

            return WA;
        }

        private Notification NotificationAlertCount()
        {
            Notification NA = new Notification();
            try
            {
                string ChangedLoginUserId = Session["UserId"].ToString() != null ? Session["UserId"].ToString() : "0";
                int tempLoggedinFacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0; //As on Super User Feb-23-2015
                Session["LoggedInFacilityId"] = tempLoggedinFacilityId;
                if (tempLoggedinFacilityId != 0)
                {
                    string query = "SELECT  IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t1.EmailId, '') AS EmailId,IFNULL(t1.MobileNo, '') AS MobileNo,t1.CreatedDate,t1.InactiveDate,t1.IsActive,t1.Inactive  FROM  userregister as t1 inner join alert_complete_tbl as t2 on t1.U_Id=t2.patient_id where t1.R_Id=10 and t1.Inactive=1 and t2.alert_day_id=1 and t2.status!='" + "True" + "'";
                     MySqlCommand cmd = new MySqlCommand(query, obj.con);
                     MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                     DataTable dt = new DataTable();
                     da.Fill(dt);
                     if (dt.Rows.Count != 0)
                     {
                         NA._45DayesNotification = dt.Rows.Count;
                     }
                     else
                     {
                         NA._45DayesNotification = 0;
                     }
                     string query1 = "SELECT  IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t1.EmailId, '') AS EmailId,IFNULL(t1.MobileNo, '') AS MobileNo,t1.CreatedDate,t1.InactiveDate,t1.IsActive,t1.Inactive  FROM  userregister as t1 inner join alert_complete_tbl as t2 on t1.U_Id=t2.patient_id where t1.R_Id=10 and t1.Inactive=1 and t2.alert_day_id=2 and t2.status!='" + "True" + "'";
                     MySqlCommand cmd1 = new MySqlCommand(query1, obj.con);
                     MySqlDataAdapter da1 = new MySqlDataAdapter(cmd1);
                     DataTable dt1 = new DataTable();
                     da1.Fill(dt1);
                     if (dt1.Rows.Count != 0)
                     {
                         NA._90DayesNotification = dt1.Rows.Count;
                         //NA._120DayesNotification = 0;
                     }
                     else
                     {
                         NA._90DayesNotification = 0;
                     }
                     string query2 = "SELECT  IFNULL(t1.U_Id, '') AS U_Id,IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t1.EmailId, '') AS EmailId,IFNULL(t1.MobileNo, '') AS MobileNo,t1.CreatedDate,t1.InactiveDate,t1.IsActive,t1.Inactive  FROM  userregister as t1 inner join alert_complete_tbl as t2 on t1.U_Id=t2.patient_id where t1.R_Id=10 and t1.Inactive=1 and t2.alert_day_id=3 and t2.status!='" + "True" + "'";
                     MySqlCommand cmd2 = new MySqlCommand(query2, obj.con);
                     MySqlDataAdapter da2 = new MySqlDataAdapter(cmd2);
                     DataTable dt2 = new DataTable();
                     da2.Fill(dt2);
                     if (dt2.Rows.Count != 0)
                     {
                        
                         NA._120DayesNotification =dt2.Rows.Count;
                     }
                     else
                     {
                         NA._120DayesNotification = 0;
                     }
                }
            }
            
            catch
            {
            }
            return NA;
        }

        private PatientRegistration UserDetail()
        {
            PatientRegistration PR = new PatientRegistration();

            try
            {
                string ChangedLoginUserId = Session["UserId"].ToString() != null ? Session["UserId"].ToString() : "0";
                MySqlCommand cmd = new MySqlCommand(" select IFNULL(U_Id, '') AS U_Id,IFNULL(F_Name, '') AS F_Name,IFNULL(L_Name, '') AS L_Name,IFNULL(CityId, '') AS CityId from userregister where U_Id='" + SecurityManager.Decrypt(ChangedLoginUserId) + "' and IsActive='" + 1 + "'", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count != 0)
                {
                    PR.FirstName = SecurityManager.Decrypt(dt.Rows[0]["F_Name"].ToString());
                    PR.LastName = SecurityManager.Decrypt(dt.Rows[0]["L_Name"].ToString());
                    PR.CityId = dt.Rows[0]["CityId"].ToString();
                    PR.CityName = GetPatientInformation.GetCityName(Convert.ToInt16(dt.Rows[0]["CityId"].ToString()));
                }
            }
            catch
            {
            }

            return PR;
        }

        //---------------- Patient List

        public ActionResult PatientList(int FormId, FormCollection From,string Filtername)
        { 
            PatientList model = new PatientList();
            try
            {
               // string email = SecurityManager.Decrypt("M5WJzz8ZDQsafmaiaqMryMqmRn7iYYwVPgJ7lCQGcWQ");
               // string pass = SecurityManager.Decrypt("ISnLfHPrdHNYtLN1eRVn4ebGEGmfhuNlzQ8CQ0");

                   if (Session["UserId"] != null)
                {
                    int tempLoggedinFacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                    Session["AccessFormId"] = FormId;
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId); // If Allow 1 Means...You can See Patient List Otherwise you Cant See 
                    Session["CreateUser"] = Connection.AllowSave;

                    if (Allowed == 1)
                    {
                        if (tempLoggedinFacilityId != 0)
                        {
                            var Name = Filtername;
                            ViewBag.searchname = Name;
                            if (!String.IsNullOrEmpty(Name))
                            {
                                model = GetFilterRecord.GetPatientList(tempLoggedinFacilityId, Name);
                            }
                            else
                            {
                                model = GetPatientInformation.GetPatientList(tempLoggedinFacilityId);
                            }
                        }
                        return View(model);
                    }
                    else
                    {
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }
        public ActionResult PatientListreset(int FormId)
        {
             PatientList model = new PatientList();
            if (Session["UserId"] != null)
                {
                    int tempLoggedinFacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;

                    Session["AccessFormId"] = FormId;
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId); // If Allow 1 Means...You can See Patient List Otherwise you Cant See 
                    Session["CreateUser"] = Connection.AllowSave;

                    if (Allowed == 1)
                    {
                        if (tempLoggedinFacilityId != 0)
                        {
                            model = GetPatientInformation.GetPatientList(tempLoggedinFacilityId);                           
                        }
                        return View("PatientList",model);
                    }
                    else
                    {
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }

        //-------------upload CSV file
        [HttpGet]
        public ActionResult PatientDetailUpaload(int FormId)
        {
            int SessionState = CheckSession(1);
            if (SessionState == 1)
            {
                int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId); // If Allow 1 Means...You can See Patient List Otherwise you Cant See 
                ViewBag.save = Connection.AllowSave;
            }
            else {
                return RedirectToAction("LogOut", "Account");
            }
            return View();
        }

        [HttpPost]
        public JsonResult PatientDetailUpaload(List<UploadCsvFile> model)
        {
              AdminClass admin = new AdminClass();
              List<UploadCsvFile> errormodel = new List<UploadCsvFile>();
            int SessionState = CheckSession(1);
            if (SessionState == 1)
            {
                errormodel = admin.UploadPatientRecord(model);
            }
            else
            {
                return Json(SessionState);
            }
            return Json(errormodel);
        }


        public ActionResult AlertStatus(FormCollection From, string Filtername)  //get patient alert list
        {
           
            alertlist model = new alertlist();
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int FormId = 42;
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId); // If Allow 1 Means...You can See Patient List Otherwise you Cant See 
                    ViewBag.save = Connection.AllowSave;
                    ViewBag.edit = Connection.AllowUpdate;

                    int tempLoggedinFacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;

                  //  var Name = From["Name"];
                    var Name = Filtername;
                    ViewBag.searchname = Name;
                    if (!String.IsNullOrEmpty(Name))
                    {
                        model = GetFilterRecord.GetPatientAllAlertList(tempLoggedinFacilityId,Name);
                    }
                    else
                    {
                        model = GetPatientInformation.GetPatientAllAlertList(tempLoggedinFacilityId);
                    }
                    return View(model);
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
               
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

        public ActionResult AlertStatusreset() 
        {

            alertlist model = new alertlist();
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int tempLoggedinFacilityId = Session["LoggedInFacilityId"] != null ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;
                    model = GetPatientInformation.GetPatientAllAlertList(tempLoggedinFacilityId);

                    return View("AlertStatus", model);
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }

            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }
        public JsonResult GetPatientaltername(alertlist model, string id, int alertid)
        {
            //var Pid = SecurityManager.Encrypt(id);
            alertlist model1=new alertlist();
            List<PatientAlertList> patientalertlist = new  List<PatientAlertList>();
            List<patientalertlist1> patientalertlist1 = new List<patientalertlist1>();
            try
            {

                string Email = null;
                MySqlCommand cmd = new MySqlCommand("select IFNULL(F_Name, '') AS F_Name,IFNULL(L_Name, '') AS L_Name,IFNULL(EmailId, '') AS EmailId from userregister where U_Id='" + SecurityManager.Encrypt(id) + "'", obj.con);
                MySqlDataAdapter da=new MySqlDataAdapter(cmd);
                DataTable dt=new DataTable();
                da.Fill(dt);
                if(dt.Rows.Count>0)
                {
                    patientalertlist.Add( new PatientAlertList
                    {
                     FirstName = SecurityManager.Decrypt(dt.Rows[0]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[0]["L_Name"].ToString()),
                     PatientId = id,
                     alertid = alertid,
                     Email = SecurityManager.Decrypt(dt.Rows[0]["EmailId"].ToString())
                });
                    Session["PatientEmailId"] = SecurityManager.Decrypt(dt.Rows[0]["EmailId"].ToString());
                }
                model1.patientalertlistt = patientalertlist;
                if (alertid != 1)
                {
                    patientalertlist1 = AdminClass.GetNotes(id, alertid);
                }
               
                model1.patientalertlistt1 = patientalertlist1;
            }
            catch (Exception ex)
            {
            }
            return Json(model1, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetPatientName(PatientDetail model, string id)
        {
            Session["PatientEmailId"] = null;
                var Pid = SecurityManager.Encrypt(id);

                Session["PatientId"] = Pid.ToString();
                PatientDetail patient = new PatientDetail();
                try
                {
                    int SessionState = CheckSession(1);
                    if (SessionState == 1)
                    {
                        string Email = null;
                        MySqlCommand cmd = new MySqlCommand("select IFNULL(t1.F_Name, '') AS F_Name,IFNULL(t1.L_Name, '') AS L_Name,IFNULL(t1.EmailId, '') AS EmailId,t1.IsActive,t1.Inactive,t2.IsDeactive from userregister as t1 inner join patient_otherinfo as t2 on t1.U_Id=t2.PatientId where t1.U_Id='" + Pid + "'", obj.con);
                        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                        DataTable dt1 = new DataTable();
                        da.Fill(dt1);

                        if (dt1.Rows.Count > 0)
                        {
                            {
                                string strr = "";
                                int strReactive = Convert.ToInt32(dt1.Rows[0]["Inactive"].ToString());
                                int strInActive = Convert.ToInt16(dt1.Rows[0]["Inactive"].ToString());
                                int strDeactive = Convert.ToInt32(dt1.Rows[0]["IsDeactive"].ToString());
                                int strActiv = Convert.ToInt32(dt1.Rows[0]["IsActive"].ToString());
                                if (strInActive == 1 && strActiv == 1)
                                {
                                    strr = "2";
                                }
                                else if (strInActive == 0 && strDeactive == 1 && strActiv == 0)
                                {
                                    strr = "0";
                                }
                                else if ((strInActive == 0 && strDeactive == 0 && strActiv == 1))
                                {
                                    strr = "1";
                                }
                                else
                                { }
                                patient.FirstName = SecurityManager.Decrypt(dt1.Rows[0]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt1.Rows[0]["L_Name"].ToString());
                                patient.Pid =SecurityManager.Decrypt(Pid);
                                patient.status = strr;
                                //patient.Email = dr["EmailId"].ToString();
                                Email = SecurityManager.Decrypt(dt1.Rows[0]["EmailId"].ToString());
                                Session["PatientEmailId"] = Email.ToString();
                            }
                        }
                        DataTable dt = null;
                        GetPatientInformation getpatient = new GetPatientInformation();
                        dt = getpatient.GetAlertMail(Email);
                        if (dt.Rows.Count > 0)
                        {
                            patient.ScheduleDay = dt.Rows[0]["ScheduleDay"].ToString() + " " + "Days Alert";
                            patient.mailbody = dt.Rows[0]["Mail_Body"].ToString();

                        }
                    }
                    else
                    {
                        return Json(SessionState,JsonRequestBehavior.AllowGet);
                    }
                // return Json(PatientName,JsonRequestBehavior.AllowGet);
            }
            catch(Exception ex)
            {
            
            }
                return Json(patient, JsonRequestBehavior.AllowGet);
        }

        //---------------Get alertlist


        public JsonResult GetAlertList()
        {
            List<SelectListItem> alertlist = new List<SelectListItem>();
            try
            {
               // var email = Session["PatientEmailId"].ToString();
              //  string query = "SELECT  `AlertMailId`,`ScheduleDay`  FROM `alert_day_tbl`  union select  `AlertMailId`, `ScheduleDay` from alert_mail where AlertTo='" + email + "' group by ScheduleDay";
                string query = "SELECT  `AlertMailId`,`ScheduleDay`  FROM `alert_day_tbl`";
                MySqlCommand cmd = new MySqlCommand(query, obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        alertlist.Add(new SelectListItem { Text = dt.Rows[i]["ScheduleDay"].ToString() + " " + "Days Alert", Value = dt.Rows[i]["AlertMailId"].ToString() });
                    }
                }
            }
            catch(Exception ex)
            {
            
            }
            //Session["PatientEmailId"] = null;
            return Json(alertlist, JsonRequestBehavior.AllowGet);
          
        
        }
        [HttpPost]
        public JsonResult GetPatientStatus(int alertid)
        {
           
            ShowUserDetailsModel patientstatus = new ShowUserDetailsModel();
            string patientid = Session["PatientId"].ToString();
            if (alertid == 1 || alertid == 2 || alertid == 3)
            {
                string query2 = "select body from alert_update_tbl where patient_id='" + patientid + "' and alert_day_id='" + alertid + "'";
                MySqlCommand cmd2 = new MySqlCommand(query2,obj.con);
                MySqlDataAdapter da2 = new MySqlDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);
                if (dt2.Rows.Count > 0)
                {
                    patientstatus.SecurityBody = dt2.Rows[0]["body"].ToString();
                    patientstatus.AlertTo = Session["PatientEmailId"].ToString();
                }
                else
                {
                    string query3 = "select body from alert_day_tbl where  AlertMailId='" + alertid + "'";
                    MySqlCommand cmd3 = new MySqlCommand(query3, obj.con);
                    MySqlDataAdapter da3 = new MySqlDataAdapter(cmd3);
                    DataTable dt3 = new DataTable();
                    da3.Fill(dt3);
                    if (dt3.Rows.Count > 0)
                    {
                        patientstatus.SecurityBody = dt3.Rows[0]["body"].ToString();
                        patientstatus.AlertTo = Session["PatientEmailId"].ToString();
                    }
                }
            }
            else
            {
                MySqlCommand cmd = new MySqlCommand("select status,Mail_Body,AlertTo from alert_mail where AlertMailId='" + alertid + "'", obj.con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                //string body = dt.Rows[0]["Mail_Body"].ToString();
                //string []mailbody=body.Split('>','<');
                //string body1 = mailbody[2];
                if (dt.Rows.Count > 0)
                {
                    patientstatus.SecurityBody = dt.Rows[0]["Mail_Body"].ToString();
                    patientstatus.Status = dt.Rows[0]["status"].ToString();
                    patientstatus.AlertTo =dt.Rows[0]["AlertTo"].ToString();
                }

                //  Session["PatientEmailId"] = null;

            }

             return Json(patientstatus);

        }

        [HttpPost]
        public JsonResult UpdateAlertList(ShowUserDetailsModel model)
        {
            int success = 0;
            string status = model.Status;
            string alertid = model.Alertid;
           // string emailid = SecurityManager.Encrypt(model.AlertTo).ToString();
            string email = Session["PatientEmailId"].ToString();
            string emailid = SecurityManager.Encrypt(email);
            int deactive=0;
            bool active = false;
            bool reactive=false;
            bool inactive = false;
            try
            {
                if (status == "0")
                {
                    deactive = 1;
                }
                else if (status == "1")
                {
                    active = true;
                    inactive = false;
                    reactive = true;
                    deactive = 0;
                }
                else if (status == "2")
                {
                    active = true;
                    inactive = true;
                    deactive = 0;
                    success = AdminClass.Insertalertstatus(model);

                }
             // string date=Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss tt")).ToString();
                string query = "update  `userregister` set `IsActive`= " + active + ",Inactive=" + inactive + ",Is_Reactive=" + reactive + ", `InactiveDate`=@inactivedate  where `U_Id`='" +SecurityManager.Encrypt( model.Pid) + "'";
                
                // string query = "update `userregister` set `IsActive`= " + active + ",Inactive=" + inactive + " ,InactiveDate='" + date + "' where `U_Id`='" + model.Pid + "'";
                string query1 = "update  `patient_otherinfo` set `IsDeactive`= '" + deactive + "' where `PatientId`='" +SecurityManager.Encrypt( model.Pid )+ "'";
                MySqlCommand cmd1 = new MySqlCommand(query, obj.con);
                cmd1.Parameters.AddWithValue("@inactivedate", Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss tt")));
                MySqlCommand cmd2 = new MySqlCommand(query1, obj.con);
                if (obj.con.State == ConnectionState.Closed)
                {
                    obj.OpenDbConnection();
                }
                cmd1.ExecuteNonQuery();
                cmd2.ExecuteNonQuery();

                 string patinetid = model.Pid;
                 if (alertid == "1" || alertid == "2" || alertid == "3")
                 {
                    if (patinetid == null || patinetid == "")
                    {

                    }
                    else
                    {
                            success = AdminClass.UpdatePatientNote(patinetid, model);
                       //   success = AdminClass.DeactivalteAlert(patinetid, model);
                    }
                }
                else
                {
                        AdminClass.UpdatePatientalert(model);
                }

                }
            //}
            catch (Exception ex)
            {

            }
            finally {
                      obj.CloseDbConnection();
                     }
            //  Session["PatientEmailId"] = null;
            return Json(success);
        
        }

        [HttpPost]
        public JsonResult CompleteAlertList(PatientDetail model)
        {
            int success = 0;
            success = AdminClass.completealertstatus(model);
            return Json(success);
       }



        //---------------- DASHBOARD  SETTING INDEX

       // [Authorize] 
        [HttpGet]
        public ActionResult Index(string param)
        {
            string fa = ViewBag.facility;
            if (Session["UserIdentityForLayOut"] == null)
            {
                return RedirectToAction("LogOut", "Account");
            }
            Session["Paitent_deactive"] = null;

            try
            {
                FormAuthentication objmodel = new FormAuthentication();
                List<UserFormAuthentication> formList = new List<UserFormAuthentication>();
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    string tempUserLoginType = Session["LoginUserType"].ToString();
                    int Allowed = 1;
                    if (Allowed == 1)
                    {
                        string tempemail = Session["EmailId"] != null ? Session["EmailId"].ToString() : "";
                        string tempUserNameId = Session["LoginUserId"] != null ? Session["LoginUserId"].ToString() : "";

                        objmodel.FormList = UserPermission.UserPlatForm(tempemail, param, tempUserLoginType, tempUserNameId);

                        Session["UserIsActive"] = Connection.UserIsActive;              //MaintainNewSession                    
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "User Session TimeOut";
                        return RedirectToAction("LogOut", "Account");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
                return View(objmodel);
            }
            catch
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        //-------------------- Patient BMI 



        //public ActionResult Paitentalertslist(FormCollection From)
        //{
            
        //}




        [HttpGet]
        public ActionResult PatientBMI(string PatientId)
        {
            if (PatientId == null)
            { }
            else
            {
                Session["Bmipid"] = PatientId;
                PatientId = PatientId.Replace(" ", "+");
            }
            try
            {
                PatientRegistration PRM = new PatientRegistration();
                if (Session["LoginUserType"] != null)
                {
                    Session["SelectedUserId"] = PatientId;
                    return View();
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch
            {
                return RedirectToAction("Index", "Admin");
            }
        }

        //-------------------- Get Patient BMI History

        [HttpGet]
        public JsonResult GetPatientBMI()
        {
            PatientRegistration PR = new PatientRegistration();
            try
            {
                string SelecedUserId = Session["SelectedUserId"] != null ? Session["SelectedUserId"].ToString() : "0";
                Session["SelectedUserId"] = 0;
                if (SelecedUserId != "0")
                {
                   // MySqlCommand cmd = new MySqlCommand("SELECT DISTINCT  IFNULL(t2.PatientId, '') AS PatientId, IFNULL(t1.F_Name, '') AS F_Name, IFNULL(t1.L_Name, '') AS L_Name, IFNULL(t2.Height, '0') AS Height, IFNULL(t2.Weight, '0') AS Weight, IFNULL(t2.BMI, '0') AS BMI FROM userregister t1 INNER JOIN patient_otherinfo t2 ON t1.U_Id = t2.PatientId WHERE t1.U_Id='" + SelecedUserId + "' and t1.IsActive='" + 1 + "'", obj.con);
                    MySqlCommand cmd = new MySqlCommand("SELECT DISTINCT  IFNULL(t2.PatientId, '') AS PatientId,IFNULL(t1.U_Id, '')AS U_Id, IFNULL(t1.F_Name, '') AS F_Name, IFNULL(t1.L_Name, '') AS L_Name FROM userregister t1 INNER JOIN patient_otherinfo t2 ON t1.U_Id = t2.PatientId WHERE t1.U_Id='" +SecurityManager.Encrypt( SelecedUserId) + "' and t1.IsActive='" + 1 + "'", obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        string PN = SecurityManager.Decrypt(dt.Rows[0]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[0]["L_Name"].ToString());
                        PR.FirstName = PN;
                        PR.PatientId = SecurityManager.Decrypt(dt.Rows[0]["U_Id"].ToString());
                        PR.PatientId = dt.Rows[0]["PatientId"].ToString();
                        //PR.Height = dt.Rows[0]["Height"].ToString();

                        //Int16 TempHeight = Convert.ToInt16(dt.Rows[0]["Height"]);

                        //PR.HeightFeet = Convert.ToInt16(TempHeight / 12);
                        //PR.HeightInch = Convert.ToInt16(TempHeight % 12);

                        //PR.Weight = Convert.ToInt16(dt.Rows[0]["Weight"].ToString());
                        //PR.BMI = float.Parse(dt.Rows[0]["BMI"].ToString()) != 0 ? float.Parse(dt.Rows[0]["BMI"].ToString()):0; 

                    }
                }
            }
            catch
            {
            }
            return Json(PR, JsonRequestBehavior.AllowGet);
        }

      //  ---------------CreateNewPatientBMI-----------
        [HttpPost]
        public ActionResult CreateNewBMI(CreatePatinetBMI model)
        {
            try
            {
                int success = 0;
                DateTime BmiDate = DateTime.Parse(DateTime.Now.ToString());
                string str =SecurityManager.Encrypt(Session["UserNameId"].ToString());
               // var value = SecurityManager.Encrypt(str).ToString();
                if (Session["UserNameId"] != null)
                {
                    string Query = "Insert into bmi_record (U_Id,Height,Weight,CreatedOn,BMI) values ('" + str + "','" + model.Height + "','" + model.Weight + "','" + Convert.ToDateTime(BmiDate).ToString("yyyy-MM-dd H:mm:ss") + "','" + model.BMI + "')";
                    MySqlCommand cmd = new MySqlCommand(Query, obj.con);
                    obj.OpenDbConnection();
                    success=  cmd.ExecuteNonQuery();
                    obj.CloseDbConnection();
                    if (success == 1)
                    {
                        return Json(success);
                    }   
                }
            }
            catch (Exception ex)
            { 
            
            }
            return View();
        }


        [HttpGet]
        public ActionResult CreatePatientBMI(CreatePatinetBMI model)
        {
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {

                    string strr = Session["UserId"].ToString();
                    var value = SecurityManager.Encrypt(strr).ToString(); ;

                    if (strr != "")
                    {

                        string query = "SELECT F_Name,U_Id FROM userregister where U_Id=@U_Id";
                        MySqlCommand cmd = new MySqlCommand(query, obj.con);
                        cmd.Parameters.AddWithValue("@U_Id", value);
                        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            model.FirstName = SecurityManager.Decrypt(dt.Rows[0]["F_Name"].ToString());
                            model.PatientId = SecurityManager.Decrypt(dt.Rows[0]["U_Id"].ToString());
                        }
                    }
                    else
                    { }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception ex)
            { 
            
            }
            return View(model);
        }

       // -------------------- Post Patient BMI

        [HttpPost]
        public ActionResult PatientBMI(PatientRegistration model)
        {
            int SuccessId = -1;
             try
            {
                string patientid = Session["Bmipid"].ToString();
               
                    if (Session["UserId"] != null)
                    {
                        int Success = GetPatientInformation.PatientBMIDetail(model);
                        Session["BmiPatientId"] = Connection.BmiPatientId.ToString();
                        if (Success == 1)
                        {
                            ViewBag.ErrorMessage = GetPatientInformation.ErrorMessage;
                            return Json(Success);
                        }

                        else if (Success == 2)
                        {
                            ViewBag.ErrorMessage = GetPatientInformation.ErrorMessage;
                            return Json(Success);
                        }

                        else
                        {
                            ViewBag.ErrorMessage = GetPatientInformation.ErrorMessage;
                            return Json(SuccessId);
                        }
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "User Session TimeOut";
                        return Json(SuccessId);
                    }
                }
            
            catch (Exception ex)
            {
                SuccessId = -2;
                return Json(SuccessId);
            }
        }
        //--------------------Create New BMI-----------

        public ActionResult CreatPatientBMI(string PatientId)
        {
            return View();
        }


        //------------BMIUpdate------------
        public ActionResult BMIUpdate()
        {            
            
            int SuccessId = -1;
            int Success = 0;

            try
            {
                DateTime BmiDate = DateTime.Parse(DateTime.Now.ToString());

                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    if (Session["BmiPatientId"] != null )
                    {
                        string PID = Session["BmiPatientId"].ToString();

                        string Query = "update patient_otherinfo set Height='" + Connection.height + "',Weight='" + Connection.weight + "',BMI='" + Connection.BMI + "' where PatientId='" + PID + "'";
                        MySqlCommand cmd12 = new MySqlCommand(Query, obj.con);
                        obj.OpenDbConnection();
                        cmd12.ExecuteNonQuery();
                        obj.CloseDbConnection();

                        string Query1 = "Insert into bmi_record (U_Id,Height,Weight,CreatedOn,BMI) values ('" + PID + "','" + Connection.height + "','" + Connection.weight + "','" + Convert.ToDateTime(BmiDate).ToString("yyyy-MM-dd H:mm:ss") + "','" + Connection.BMI + "')";
                        MySqlCommand cmd1 = new MySqlCommand(Query1, obj.con);
                        obj.OpenDbConnection();
                        Success = cmd1.ExecuteNonQuery();
                        obj.CloseDbConnection();

                        Session.Remove("BmiPatientId");

                        if (Success == 1)
                        {
                            ViewBag.ErrorMessage = GetPatientInformation.ErrorMessage;
                            return RedirectToAction("PatientBMI", "Admin", new { patientId = PID });
                        }                       
                        else
                        {
                            ViewBag.ErrorMessage = GetPatientInformation.ErrorMessage;
                            return RedirectToAction("PatientBMI", "Admin", new { patientId = PID });
                        }
                    }                    
                }
                return RedirectToAction("AdminIndex", "Admin");
            }
            catch
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

        //-------------------- Get Patient BMI List

        [HttpGet]
        public ActionResult PatientBMIList(string PatientId, int ShowID = 0, string viewid="")
        {
            ViewBag.viewed = viewid;
            if (PatientId == null)
            {

            }
            else
            {
                Session["Bmipid"] = PatientId;
                PatientId = PatientId.Replace(" ", "+");
            }


          
            int FormId = 20;
            int No = 0;
            Session["AccessFormId"] = FormId;
            Session["ShowId"] = ShowID;
            PatientBMIList model = new PatientBMIList();
            try
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    PatientId = PatientId != null ? PatientId : SecurityManager.Encrypt(Session["UserId"].ToString());
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());

                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    Session["CreateUser"] = Connection.AllowSave;

                    List<PatientBMI> patientBMIDetail = new List<PatientBMI>();
                    MySqlCommand cmd = new MySqlCommand("SELECT distinct t2.BMIId,t2.U_Id,t1.F_Name,t1.L_Name,t2.Height,t2.Weight,t2.BMI,t2.CreatedOn FROM userregister t1 INNER JOIN  bmi_record t2 ON t1.U_Id=t2.U_Id WHERE t2.U_Id='" + PatientId.ToString() + "' order by t2.BMIId desc", obj.con);

                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            No++;
                            int HeightFeet = 0, HeightInch = 0;
                            int Height = String.IsNullOrEmpty(dt.Rows[i]["Height"].ToString()) ? 0 : Convert.ToInt32(dt.Rows[i]["Height"].ToString());

                            HeightFeet = Height / 12;
                            HeightInch = Height % 12;

                            string PN = SecurityManager.Decrypt(dt.Rows[0]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[0]["L_Name"].ToString());
                            Int16 TempHeight = Convert.ToInt16(dt.Rows[0]["Height"]);

                            //HeightFeet = Convert.ToInt16(TempHeight / 12);
                            //HeightInch = Convert.ToInt16(TempHeight % 12);

                            double BMIno = String.IsNullOrEmpty(dt.Rows[i]["BMI"].ToString()) ? 0 : Convert.ToDouble(dt.Rows[i]["BMI"].ToString());
                            double BMIValue = Math.Round(BMIno, 2, MidpointRounding.AwayFromZero);

                            patientBMIDetail.Add(new PatientBMI
                            {
                                //PatientId = SecurityManager.Decrypt(dt.Rows[i]["U_Id"].ToString()),
                                SrNo=No,
                                PatientId = dt.Rows[i]["U_Id"].ToString(),
                                FirstName = PN,
                                Height = Height,
                                HeightFeet = HeightFeet,
                                HeightInch = HeightInch,
                                Weight = String.IsNullOrEmpty(dt.Rows[i]["Weight"].ToString()) ? 0 : Convert.ToDouble(dt.Rows[i]["Weight"].ToString()),
                                BMI = BMIValue,
                                BMIDate = Convert.ToDateTime(dt.Rows[i]["CreatedOn"].ToString()).ToString("MM-dd-yyyy H:mm"),
                            });
                        }
                    }
                    model.patientBMIList = patientBMIDetail;
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch
            {
            }
            return View(model);
        }

        //-------------------- Patient Injection

        [HttpGet]
        public ActionResult NewInjection(string PatientId)
        {
            int SuccessId = -1;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    Session["SelectedUserId"] = PatientId;
                    return View();
                }
                else
                {
                    return Json(SuccessId);
                }
            }
            catch (Exception)
            {
            }
            return View();
        }

        //-------------------- Get Patient Injection 

        [HttpGet]
        public JsonResult GetPatientInjection()
        {
            PatientRegistration PR = new PatientRegistration();
            GetPatientInformation ob = new GetPatientInformation();

            try
            {
                string SelecedUserId = Session["SelectedUserId"] != null ? Session["SelectedUserId"].ToString() : "0";
                Session["SelectedUserId"] = 0;
                if (SelecedUserId != "0")
                {
                    //MySqlCommand cmd = new MySqlCommand("SELECT distinct t2.PatientId,t1.F_Name,t1.L_Name,t1.DOB,t2.PhysicianTherapist,t2.Physician,t2.IsPhysicalTherapist,t2.Knee,t2.Injected,t2.InjectionNumber,t2.TheraphyOn FROM userregister t1 INNER JOIN  injectiondetails t2 ON t1.U_Id=t2.PatientId WHERE t1.U_Id='" + SecurityManager.Encrypt(SelecedUserId) + "' and t1.IsActive='" + 1 + "'", obj.con);
                    DataTable dt1 = AdminClass.GetInjKneeDetail(SelecedUserId);
                    MySqlCommand cmd = new MySqlCommand("SELECT distinct U_Id,F_Name,L_Name,DOB FROM userregister  WHERE U_Id='" +SecurityManager.Encrypt( SelecedUserId) + "' and IsActive='" + 1 + "'", obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        PR.FirstName = SecurityManager.Decrypt(dt.Rows[0]["F_Name"].ToString()) + " " + SecurityManager.Decrypt(dt.Rows[0]["L_Name"].ToString());
                        PR.PatientId = dt.Rows[0]["U_Id"].ToString();

                        if (dt.Rows[0]["DOB"].ToString() != null)
                        {
                            PR.BirthDate = Convert.ToDateTime(dt.Rows[0]["DOB"].ToString()).ToString("MMMM-dd-yyyy");
                        }

                        PR.InjDate = DateTime.Now.ToString("MMM-dd-yyyy");
                        PR.AgeOnDate = ob.AgeCalculator(Convert.ToDateTime(dt.Rows[0]["DOB"].ToString()));
                        Session["UpdatedUserId"] = "0";

                        if (dt1.Rows.Count > 0)
                        {
                            PR.Knee = dt1.Rows[0]["Knee"].ToString();
                            PR.Phy_Therapy = dt1.Rows[0]["Injected"].ToString();
                            PR.PhysicianId = SecurityManager.Decrypt(dt1.Rows[0]["Physician"].ToString());
                            PR.PhysicalTherapistId = SecurityManager.Decrypt(dt1.Rows[0]["PhysicianTherapist"].ToString());
                        }
                    }
                }
            }
            catch
            {
            }
            return Json(PR, JsonRequestBehavior.AllowGet);
        }

        //-------------------- Post Patient Injection Details

        [HttpPost]
        public ActionResult NewInjection(PhysicalTherapyDetail Model)
        {
            int SuccessId = -1;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    Model.FacilityId = !String.IsNullOrEmpty(Session["LoggedInFacilityId"].ToString()) ? Convert.ToInt32(Session["LoggedInFacilityId"].ToString()) : 0;

                    string PhyTheraphy = String.IsNullOrEmpty(Model.Phy_Therapy) ? "no" : Model.Phy_Therapy.ToString().ToLower();
                    if (PhyTheraphy == "yes")
                    {
                        Model.Injected = "Yes";
                        SuccessId = GetPatientInformation.SavePhysicalTherapyDetail(Model);
                    }
                    //SuccessId = APGBussinessClass.SaveInjectionDetail(Model);
                    if (SuccessId == 1)
                    {
                        ViewBag.ErrorMessage = GetPatientInformation.ErrorMessage;
                    }
                    else
                    {
                        ViewBag.ErrorMessage = GetPatientInformation.ErrorMessage;
                    }
                    return Json(SuccessId);
                }
                else
                {
                    return Json(SuccessId);
                }
            }
            catch (Exception)
            {
            }
            return View();
        }


        //--------------------  Create Patient By Admin 

        [HttpGet]
        public ActionResult CreatePatient(int FormId)
        {
            try
            {
                Session["AccessFormId"] = FormId;

                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    Session["SaveUser"] = string.Empty;

                    Session["SaveUser"] = Connection.AllowSave;
                   
                   return View();
                  
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

        [HttpPost]
        public ActionResult CreatePatientRegister(PatientRegistration model)
        {
            string Ret = "";
            var Redirect = Ret;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    string Success = AdminClass.CreatePatientDetail(model);
                    Session["SelectedUserId"] = Connection.UserId;
                    Session["PatientIsActive"] = Connection.PatientIsActive;
                    if (Success == "1")
                    {
                        //ViewBag.ErrorMessage = GetPatientInformation.ErrorMessage;     
                        Session["TempPatientId"] = SecurityManager.Encrypt(model.UserNameId);
                        var PatientId = SecurityManager.Encrypt(model.UserNameId);
                        ViewBag.NewPatientId = PatientId;
                        ViewBag.PatientId = PatientId;
                        return Json(PatientId, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        Redirect = "0";  //User Already Exist!     
                    }
                }
                else
                {
                    Redirect = "-1";     //Session Timeout!  
                }
            }
            catch (Exception e)
            {
                string a = e.Message;
                Redirect = "-2";         //Exception    
            }
            return Json(Redirect);
        }

        [HttpGet]
        public ActionResult AdminSelectWomacKNee(string PatientId)
        {
            try
            {
                string PId = Session["TempPatientId"].ToString();

                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    MySqlCommand cmd = new MySqlCommand("select U_Id,Gender from  userregister where U_Id= '" + PId.ToString() + "'", obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count != 0)
                    {
                        if (dt.Rows[0]["Gender"].ToString().Trim() == "Male")
                        {
                            Session["Gender"] = dt.Rows[0]["Gender"].ToString();
                        }
                        else if (dt.Rows[0]["Gender"].ToString().Trim() == "Female")
                        {
                            Session["Gender"] = dt.Rows[0]["Gender"].ToString();
                        }

                        ViewBag.PatientId = PatientId;
                    }
                    string KneeType = AdminClass.GetKneeType(PId.ToString());
                    Session["TestDone"] = KneeType;
                    return View();
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch
            {
                return RedirectToAction("MyIndex", "Patient");
            }
        }


        public ActionResult EditUserProfile(int FormId)
        {
            Session["AccessFormId"] = FormId;

            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    string ChangedLoginUserId = Session["UserId"] != null ? Session["UserId"].ToString() : "0";
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    if (Allowed == 1)
                    {
                        Session["UpdateUser"] = Connection.AllowUpdate == "1" ? 1 : 0;
                        Session["DeleteUser"] = Connection.AllowDelete == "1" ? 1 : 0;
                        Session["SelectedUserId"] = SecurityManager.Encrypt(ChangedLoginUserId);

                        return View();
                    }
                    else
                    {
                        return RedirectToAction("LogOut", "Account");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        [HttpPost]
        public ActionResult EditUserProfile(AdminRegisterModel model, string ButtonType)
        {
            string Ret = "";
            var Redirect = Ret;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    string SelectedUserId = Session["SelectedUserId"] != null ? Session["SelectedUserId"].ToString() : "0";
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    model.UserTypeID = LUTypeId.ToString();
                    int Success = AdminClass.UpdateAdminProfile(model, ButtonType, SelectedUserId, LUTypeId);
                    if (Success == 1 || Success == 2)
                    {
                        Session.Remove("UpdateUser");
                        Session.Remove("DeleteUser");
                        Redirect = "1";          //User Add Successful!                                                          
                    }
                    else
                    {
                        Redirect = "0";          //User Already Exist!                                                 
                    }
                }
                else
                {
                    Redirect = "-1";             //Session Timeout!                                              
                }
            }
            catch (Exception e)
            {
                string a = e.Message;
                Redirect = "-2";                 //Exception    
            }
            return Json(Redirect);
        }
        
        [HttpGet]
        public ActionResult ChangePassword(int FormId)
        {
            Session["AccessFormId"] = FormId;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    ViewBag.edit = Connection.AllowUpdate;
                    if (Allowed == 1)
                    {
                        string SelectedUserId = Session["SelectedUserId"] != null ? Session["SelectedUserId"].ToString() : "0";
                        string ChangedLoginUserId = Session["UserId"] != null ? SecurityManager.Encrypt(Session["UserId"].ToString()) : "0";
                        string UserId = SelectedUserId == "0" ? ChangedLoginUserId : SelectedUserId;

                        MySqlCommand cmd = new MySqlCommand("select U_Id,F_Name,L_Name,EmailId from userregister where U_Id='" + UserId + "'", obj.con);
                        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        if (dt.Rows.Count != 0)
                        {
                            string Email = dt.Rows[0]["EmailId"].ToString();
                            string UId = dt.Rows[0]["U_Id"].ToString();

                            string UserAccessId = Email != "" ? Email : UId;
                            ViewBag.EmailID = SecurityManager.Decrypt(UserAccessId);
                        }
                        return View();
                    }
                    else
                    {
                        return RedirectToAction("LogOut", "Account");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        [HttpPost]
        public ActionResult ChangePassword(PatientRegistration PR, string Email )
        {
            string Ret = "0";
            var Redirect = Ret;
            int Success = 0;
            try
            {
               
              //  string Logid = Session["LogEmailid"].ToString();
                string Logid = PR.EmailId;
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    Success = AdminClass.ChangePassword(PR, Logid, LUTypeId);
                 // Ret = Success.ToString();
                    if (Success == 1) 
                    {
                        Ret = LUTypeId.ToString();
                    }
                    else
                    {
                        Ret = "No";
                    }
                                                          
                    Redirect = Ret;
                    return Json(Redirect);
                }
                else
                {
                    //ViewBag.ErrorMessage = "User Session TimeOut";
                    //return RedirectToAction("LogOut", "Account");
                    return Json(SessionState);
                }
            }
            catch
            {
                return RedirectToAction("Index", "Admin");
            }
        }

        [HttpGet]
        public ActionResult ChangeDigitPinNo(int FormId)
        {
            Session["AccessFormId"] = FormId;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId,FormId);
                    if (Allowed == 1)
                    {
                        string LoggedUserId = Session["LoginUserId"] != null ?SecurityManager.Encrypt(Session["LoginUserId"].ToString()) : "0";
                        int LoggedTypeId = Session["UserTypeId"] != null ? Convert.ToInt32(Session["UserTypeId"]) : 0;
                        string tempemail = Session["EncryptEmail"] != null ? Session["EncryptEmail"].ToString() : "";
                        string tempUserNameId = Session["EncryptUserNameId"] != null ? Session["EncryptUserNameId"].ToString() : "";

                        MySqlCommand cmd = new MySqlCommand("select U_Id,EmailId,F_Name,L_Name,Password,R_Id from userregister where U_Id='" + LoggedUserId + "' and R_Id='" + LoggedTypeId + "'", obj.con);
                        MySqlDataAdapter da = new MySqlDataAdapter(cmd);                                            
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        if (dt.Rows.Count != 0)
                        {
                            string UserEmailId = dt.Rows[0]["EmailId"].ToString();
                            string UId = dt.Rows[0]["U_Id"].ToString();

                            ViewBag.UserNameId = UId != "" ? SecurityManager.Decrypt(UId) : "";
                            ViewBag.EmailId = UserEmailId != "" ? SecurityManager.Decrypt(UserEmailId) : "";
                        }
                        return View();
                    }
                    else
                    {
                        return RedirectToAction("PatientIndex", "PatientDeshboard");
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "User Session TimeOut";
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch
            {
                return RedirectToAction("PatientIndex", "PatientDeshboard");
            }
        }
                

        [HttpPost]
        public ActionResult PinNoChange(PatientRegistration model, string UserNameId)
        {
            string Ret = "";
            var Redirect = Ret;
            int Success = 0;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    // int Success = APGBussinessClass.ChangePIN(PRM);

                    MySqlCommand cmd = new MySqlCommand("select t1.PatientId,t1.PINNO,t1.R_id,t2.Password from patient_otherinfo t1 INNER JOIN userregister t2 on t1.PatientId=t2.U_Id where t1.PatientId='" + SecurityManager.Encrypt(UserNameId) + "'", obj.con);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        string UserPassword = SecurityManager.Decrypt(dt.Rows[0]["Password"].ToString());

                        if (model.Password == UserPassword)
                        {
                            MySqlCommand cmd1 = new MySqlCommand("update patient_otherinfo set PINNO ='" + model.PIN + "' where PatientId='" + SecurityManager.Encrypt(UserNameId) + "'", obj.con);
                            obj.OpenDbConnection();
                            Success = cmd1.ExecuteNonQuery();
                            obj.CloseDbConnection();
                        }
                        else
                        {
                            Success = 2;
                        }
                    }
                    if (Success == 1)
                    {
                        Redirect = "1";//User Add Successful!                     
                    }
                    else if (Success == 2)
                    {
                        Redirect = "No";//User Add Successful!                     
                    }
                    else
                    {
                        Redirect = "0";//User Already Exist!                      
                    }
                }
                else
                {
                    Redirect = "-1";//Session Timeout!                       
                }
            }
            catch (Exception e)
            {
                string Error = e.Message;
                Redirect = "-2";//Exception    
            }
            return Json(Redirect);
        }

        [HttpGet]
        public ActionResult PatientDetailUpaloads(int FormId)
        {
            Session["AccessFormId"] = FormId;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {                
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId,FormId);
                    if (Allowed == 1)
                    {
                        return View();
                    }
                    else
                    {
                        return RedirectToAction("LogOut", "Account");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        [HttpPost]
        public ActionResult PatientDetailUpaloads(HttpPostedFileBase FileUpload)
        {
            //Upload and save the file            
            try
            {
                //if (Session["EmailAddress"] != null)
                //{
                    DataTable dt = new DataTable();
                    if (FileUpload != null)
                    {
                        if (FileUpload.ContentLength > 0)
                        {
                            string fileName = Path.GetFileName(FileUpload.FileName);
                            string path = Path.Combine(Server.MapPath("~/Content/CSV"), fileName);
                            try
                            {
                                FileUpload.SaveAs(path);
                                dt = APGBussinessAdmin.ProcessCSV(path);
                                DataTable dt1 = new DataTable();
                                ViewData["Feedback"] = APGBussinessAdmin.ProcessBulkCopy(dt);
                            }
                            catch (Exception ex)
                            {
                                ViewData["Feedback"] = ex.Message;
                            }
                        }
                        else
                        {
                            ViewData["Feedback"] = "Please select a file";
                        }
                    }
                    dt.Dispose();
                //}
                //else
                //{
                //    return RedirectToAction("LogOut", "Account");
                //}
            }
            catch (Exception e)
            {
                return RedirectToAction("LogOut", "Account");
            }
            return View("PatientDetailUpaload", ViewData["Feedback"]);
        }

    


      

        [HttpGet]
        public ActionResult ChangeUserPassword(int FormId)
        {
           
            Session["AccessFormId"] = FormId;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                { 
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());

                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    ViewBag.edit = Connection.AllowUpdate;
                    if (Allowed == 1)
                    {
                        return View();
                    }
                    else
                    {
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }

        }
        [Authorize]
        [HttpGet]
        public ActionResult CreateDiseaseQuestion(int DiseaseTypeID)
        {
            DiseaseQuestion DQ = new DiseaseQuestion();
            DQ.DiseaseTypeId = DiseaseTypeID;
            string Query = "select * from womac_questype where QuesTypeId='" + DiseaseTypeID + "'";
            MySqlCommand cmd = new MySqlCommand(Query, obj.con);
            MySqlDataAdapter asd = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            asd.Fill(dt);
            ViewBag.DiseaseTypeName = dt.Rows[0]["QuestionType"].ToString();
            return View(DQ);
        }

        [HttpPost]
        public ActionResult CreateDiseaseQuestion(DiseaseQuestion model)
        {
            int Success = 0;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    if (!String.IsNullOrEmpty(model.DiseaseName))
                    {
                        MySqlCommand cmd = new MySqlCommand("insert into  womac_question (QuesTypeId,Question,IsActive) values ('" + model.DiseaseTypeId + "','" + model.DiseaseName + "','" + "1" + "')", obj.con);
                        obj.OpenDbConnection();
                        int Result = cmd.ExecuteNonQuery();
                        obj.CloseDbConnection();
                        Success = model.DiseaseTypeId;
                    }
                    return Json(Success);
                }
                else
                {
                    Success = -1;
                    return Json(Success);
                }
            }
            catch
            {
                return Json(Success);
            }

        }
        [Authorize]
        [HttpGet]
        public ActionResult EditDiseaseQuestion(int DiseaseTypeId, int DiseaseId)
        {
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    Session["DiseaseId"] = DiseaseId;
                    Session["DiseaseTypeId"] = DiseaseTypeId;
                }
                else
                {
                    Session["DiseaseId"] = DiseaseId;
                    Session["DiseaseTypeId"] = DiseaseTypeId;
                }
            }
            catch
            {
            }
            return View();
        }

        [HttpGet]
        public JsonResult GetDiseaseQuestion()
        {
            DiseaseQuestion DQ = new Models.DiseaseQuestion();
            try
            {
                int DiseaseId =  Convert.ToInt32(Session["DiseaseId"].ToString());
                int DiseaseTypeId = Convert.ToInt32(Session["DiseaseTypeId"].ToString());

                MySqlCommand cmd = new MySqlCommand("select t1.QuestionType,t1.QuesTypeId,t2.QuesId,t2.QuesTypeId,t2.Question from womac_questype t1 inner join womac_question t2 on t1.QuesTypeId=t2.QuesTypeId where t2.QuesId='" + DiseaseId + "' and t2.QuesTypeId='" + DiseaseTypeId + "'", obj.con);             
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    DQ.DiseaseId = Convert.ToInt32(dt.Rows[0]["QuesId"].ToString());
                    DQ.DiseaseTypeId = Convert.ToInt32(dt.Rows[0]["QuesTypeId"].ToString());
                    DQ.DiseaseName = dt.Rows[0]["Question"].ToString();
                    DQ.DiseaseTypeName = dt.Rows[0]["QuestionType"].ToString();
                }
            }
            catch
            {
            }
            return Json(DQ, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult EditDiseaseQuestion(DiseaseQuestion model, string ButtonType)
        {
            string Ret = "";
            var Redirect = Ret;

            string Query = "";
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int QuestionId = 0;
                                       
                    if (ButtonType == "1")
                    {
                        Query = "update womac_question set Question='" + model.DiseaseName + "' where QuesId='" + model.DiseaseId + "' and QuesTypeId='" + model.DiseaseTypeId + "'";
                    }
                    else if (ButtonType == "2")
                    {
                        Query = "UPDATE  `womac_question`  SET   `IsActive`= 0  WHERE  `QuesId`='" + model.DiseaseId + "'  and  `QuesTypeId`='" + model.DiseaseTypeId + "'";
                    }
                    MySqlCommand cmd = new MySqlCommand(Query, obj.con);
                    obj.OpenDbConnection();
                    QuestionId = cmd.ExecuteNonQuery();
                    obj.CloseDbConnection();

                    Redirect = model.DiseaseTypeId.ToString();
                }
                else
                {
                    Redirect="0";
                }
            }
            catch
            {
                 Redirect="0";
            }
            return Json(Redirect);
        }

        public ActionResult EditUser(string UserId)
        {            
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int FormId = Session["AccessFormId"] != null ? Convert.ToInt32(Session["AccessFormId"].ToString()) : 0;
                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                    if (Allowed == 1)
                    {
                        Session["UpdateUser"] = Connection.AllowUpdate == "1" ? 1 : 0;
                        Session["DeleteUser"] = Connection.AllowDelete == "1" ? 1 : 0;
                        Session["SelectedUserId"] = SecurityManager.Encrypt(UserId);
                        return View();
                    }
                    else
                    {
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        [HttpPost]
        public ActionResult EditUser(AdminRegisterModel model, string ButtonType)
        {
            string Ret = "";
            var Redirect = Ret;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    string SelectedUserId = Session["SelectedUserId"] != "" ? Session["SelectedUserId"].ToString() : "0";
                    int Success = AdminClass.UpdateUser(model, ButtonType, SelectedUserId, LUTypeId);
                    if (Success == 1 || Success == 2)
                    {
                        Session.Remove("UpdateUser");
                        Session.Remove("DeleteUser");
                       
                        Redirect = "1";                                                           
                    }
                    else
                    {
                        Redirect = "0";                                                  
                    }
                }
                else
                {
                    Redirect = "-1";                                               
                }
            }
            catch (Exception e)
            {
                string a = e.Message;
                Redirect = "-2";//Exception    
            }
            return Json(Redirect);
        }

        [HttpGet]
        public ActionResult Facility()
        {
            FormAuthentication objmodel = new FormAuthentication();
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int FormId = Session["AccessFormId"] != null ? Convert.ToInt32(Session["AccessFormId"].ToString()) : 0;

                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                
                    if (Connection.AllowSave.ToLower() == "1")
                    {
                        return View();
                    }
                    else
                    {
                        return RedirectToAction("AdminIndex", "Admin");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("AdminIndex", "Admin");
            }
        }

        [HttpPost]
        public ActionResult Facility(Facility model)
        {
            string Ret = "";
            var Redirect = Ret;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    string SelectedUserId = Session["UserNameId"].ToString() != "" ? Session["UserNameId"].ToString() : "0";

                    int Success = AdminClass.SaveFacility(model, SelectedUserId, LUTypeId);
                    if (Success == 1)
                    {
                        int FormId = Session["AccessFormId"] != null ? Convert.ToInt32(Session["AccessFormId"].ToString()) : 0;
                        Redirect = FormId.ToString(); //User Add Successful!                                                          
                    }
                    else
                    {
                        Redirect = "0"; //User Already Exist!                                                 
                    }
                }
                else
                {
                    Redirect = "-1"; //Session Timeout!                                              
                }
            }
            catch (Exception e)
            {
                string a = e.Message;
                Redirect = "-2"; //Exception    
            }
            return Json(Redirect);
        }

        
        [HttpGet]
        public ActionResult CreateReferral(string AN, string CN)
        {
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    int FormId = Session["AccessFormId"] != null ? Convert.ToInt32(Session["AccessFormId"].ToString()) : 0;

                    int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);

                    if (Connection.AllowSave.ToLower() == "1")
                    {
                        ViewBag.FormId = FormId;
                        ViewBag.AN = AN;
                        ViewBag.CN = CN;

                        return View();
                    }
                    else
                    {
                        return RedirectToAction("CreateReferral", "Admin");
                    }
                }
                else
                {
                    return RedirectToAction("LogOut", "Account");
                }
            }
            catch (Exception e)
            {
                return RedirectToAction("LogOut", "Account");
            }
        }

        [HttpPost]
        public ActionResult CreateReferralSave(Referral model)
        {
            string Ret = "";
            var Redirect = Ret;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    string SelectedUserId = Session["UserNameId"].ToString() != "" ? Session["UserNameId"].ToString() : "0";

                    int Success = AdminClass.SaveNewReferral(model, SelectedUserId, LUTypeId);
                    if (Success == 1)
                    {
                        int FormId = Session["AccessFormId"] != null ? Convert.ToInt32(Session["AccessFormId"].ToString()) : 0;
                        Redirect = FormId.ToString();//User Add Successful!      
                    }
                    else
                    {
                        Redirect = "0";//User Already Exist!        
                    }
                }
                else
                {
                    Redirect = "-1";//Session Timeout!      
                }
            }
            catch (Exception e)
            {
                string Error = e.Message;
                Redirect = "-2";//Exception   
            }
            return Json(Redirect);
        }
        [Authorize]
        public ActionResult CreateUserLevel(int id)
        {
            ViewBag.id = id;
            return View();
        }

        [HttpPost]
        public ActionResult NewUserType(UserLevel model)
        {
            string Ret = "";
            var Redirect = Ret;
            try
            {
                int SessionState = CheckSession(1);
                if (SessionState == 1)
                {
                    int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                    string SelectedUserId = Session["UserNameId"].ToString() != "" ? Session["UserNameId"].ToString() : "0";

                    int Success = AdminClass.SaveNewUserType(model, SelectedUserId, LUTypeId);
                    if (Success == 1)
                    {
                        int FormId = Session["AccessFormId"] != null ? Convert.ToInt32(Session["AccessFormId"].ToString()) : 0;
                        Redirect = FormId.ToString(); //User Add Successful!      
                    }
                    else
                    {
                        Redirect = "0"; //User Already Exist!        
                    }
                }
                else
                {
                    Redirect = "-1"; //Session Timeout!      
                }
            }
            catch (Exception e)
            {
                string Error = e.Message;
                Redirect = "-2";//Exception   
            }
            return Json(Redirect);
        }

        //Working Start By DPK..........................................................................
        public ActionResult SecurityReminder(string Remindertype, string ReminderId, FormCollection frm, string AdminSearch = "user")
        {

             ShowUserDetailsModel model = new ShowUserDetailsModel();
             int SessionState = CheckSession(1);
             if (SessionState == 1)
             {
                 int FormId = 3;
                 int LUTypeId = Convert.ToInt32(Session["UserTypeId"].ToString());
                 int Allowed = UserPermission.UserFormAuthenticationDetail(LUTypeId, FormId);
                 ViewBag.save = Connection.AllowSave;
                 ViewBag.edit = Connection.AllowUpdate;
                 ViewBag.delete = Connection.AllowDelete;
                 var alertform = Session["LoginUserId"].ToString();
                 var search = frm["serachvalue"];
                 ViewBag.searchname = search;
                 if (Remindertype == "Delete")
                 {
                     MySqlCommand cmd = new MySqlCommand("Delete from alert_mail where  AlertMailId = '" + ReminderId + "'", obj.con);
                     obj.con.Open();
                     cmd.CommandType = CommandType.Text;
                     cmd.ExecuteNonQuery();
                     obj.con.Close();
                 }

                 string Ret = "";
                 var Redirect = Ret;
                 var query = "";
                 try
                 {
                     if (search == null || search == "")
                     {
                          query = "select IFNULL(AlertMailId, '') AS  AlertMailId, IFNULL( AlertFor, '') AS  AlertFor,  IFNULL(AlertTo , '') AS AlertTo , IFNULL( AlertFrom, '') AS AlertFrom , IFNULL(MailIng_CC , 'NA') AS MailIng_CC , IFNULL(ScheduleDay , '') AS  ScheduleDay, IFNULL( Mail_Body, 'NA') AS Mail_Body , IFNULL(Mail_Subject, 'NA')AS Mail_Subject , IFNULL(CreatedOn, 'NA') AS CreatedOn, IFNULL( ModifiedBy, 'NA') AS  ModifiedBy,  IFNULL(ModifiedOn , '00:00:00') AS  ModifiedOn from alert_mail where AlertFrom='" + alertform + "'  ORDER BY AlertMailId DESC";
                     }
                     else
                     {
                         query = "select IFNULL(AlertMailId, '') AS  AlertMailId, IFNULL(AlertFor, '') AS  AlertFor,  IFNULL(AlertTo , '') AS AlertTo , IFNULL( AlertFrom, '') AS AlertFrom , IFNULL(MailIng_CC , '') AS MailIng_CC , IFNULL(ScheduleDay , '') AS  ScheduleDay, IFNULL( Mail_Body, '') AS Mail_Body , IFNULL(  	Mail_Subject, 'NA') AS  	Mail_Subject , IFNULL( Template_Type, 'NA') AS  Template_Type, IFNULL(CreatedOn, 'NA') AS CreatedOn, IFNULL( ModifiedBy, 'NA') AS  ModifiedBy,  IFNULL(ModifiedOn , 'NA') AS  ModifiedOn from alert_mail where AlertFrom='" + alertform + "' and Mail_Subject LIKE '" + search + "%' ORDER BY AlertMailId DESC";
                     }
                     MySqlCommand cmd1 = new MySqlCommand(query, obj.con);
                     MySqlDataAdapter da1 = new MySqlDataAdapter(cmd1);
                     if (search == null || search == "")
                     {
                         // cmd1.CommandType = CommandType.StoredProcedure;
                         cmd1.CommandType = CommandType.Text;
                     }
                     else
                     {
                         cmd1.CommandType = CommandType.Text;
                     }
                     SessionState = CheckSessionValues(1);
                     if (SessionState == 1)
                     {
                         Session["AdminGrid"] = AdminSearch;
                         var SecuritySub = "";
                         var SecurityBody = "";
                         var SecurityID = "";
                         if (AdminSearch == "back" && search != null)
                         {
                             AdminSearch = "";
                         }
                         if (Remindertype == null)
                         {
                             Remindertype = "Birthday";
                         }
                         // var email = SecurityManager.Decrypt(Connection.Email.ToString()); //Session["EmailAddress"];            
                         List<ShowUserDetailsModelList> UserList = new List<ShowUserDetailsModelList>();
                         List<SecurityRemindetr> Securityreminderlist = new List<SecurityRemindetr>();
                         var qury = "";
                         DataTable dt1 = new DataTable();
                         da1.Fill(dt1);
                         if (dt1.Rows.Count > 0)
                         {
                             for (int i = 0; i < dt1.Rows.Count; i++)
                             {
                                 Securityreminderlist.Add(new SecurityRemindetr
                                 {
                                     srno = i + 1,
                                     ReminderId = String.IsNullOrEmpty(dt1.Rows[i]["AlertMailId"].ToString()) ? 0 : Convert.ToInt32(dt1.Rows[i]["AlertMailId"].ToString()),
                                     NoofDays = String.IsNullOrEmpty(dt1.Rows[i]["ScheduleDay"].ToString()) ? 0 : Convert.ToInt32(dt1.Rows[i]["ScheduleDay"].ToString()),
                                     // AssignUser = dt1.Rows[i]["AssignUser"].ToString(),
                                     AssignUser = "NUll",
                                     AlertFor = dt1.Rows[i]["AlertFor"].ToString(),
                                     ReminderSubject = dt1.Rows[i]["Mail_Subject"].ToString(),
                                     ReminderBody = dt1.Rows[i]["Mail_Body"].ToString(),
                                     ReminderCreateDate = (Convert.ToDateTime(dt1.Rows[i]["CreatedOn"].ToString())).ToString("dd-MM-yyyy"),
                                     ReminderModifyDate = (Convert.ToDateTime(dt1.Rows[i]["ModifiedOn"].ToString())).ToString("dd-MM-yyyy"),
                                 });
                             }
                         }

                         model.UserList = UserList;
                         Session["ReminderId"] = SecurityID;
                         model.SecurityList = Securityreminderlist;
                         model.SecuritySub = SecuritySub;
                         model.SecurityBody = SecurityBody;
                         model.SecurityID = SecurityID;
                         model.AdminSearch = "admin";
                         // model.AdminSearch = AdminSearch;
                         Session["SecurityName"] = Remindertype;
                         search = "";
                     }
                     else
                     {
                         Redirect = "-1";//Session Timeout!  
                     }
                 }
                 catch (Exception e)
                 {
                 }
             }
             else
             {
                 return RedirectToAction("LogOut", "Account");
             }
            return View(model);

        }
        public int CheckSessionValues(int CheckConditionNumber)
        {
            int returnValue = 0;
            if (CheckConditionNumber == 1)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["LoginUserId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            if (CheckConditionNumber == 2)
            {
                if (Session["UserIdentityForLayOut"] != null)
                {
                    if (Session["UserTypeId"] != null)
                    {
                        returnValue = 1;
                    }
                }
            }
            return returnValue;
        }

        //insert Alert Data.........
        public ActionResult ScheduledReminderInsert()
        {
            ShowUserDetailsModel model = new ShowUserDetailsModel();
            int SessionState = CheckSession(1);
            if (SessionState == 1)
            {
                List<alertRoleList> alertRoleList = new List<alertRoleList>();
                MySqlCommand cmd3 = new MySqlCommand("select * from userrole where Isactive=1", obj.con);
                MySqlDataAdapter da2 = new MySqlDataAdapter(cmd3);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);
                if (dt2.Rows.Count > 0)
                {
                    for (int i = 0; i < dt2.Rows.Count; i++)
                    {
                        alertRoleList.Add(new alertRoleList
                        {
                            UserTypeId = Convert.ToInt32(dt2.Rows[i]["R_id"].ToString()),
                            UserType = dt2.Rows[i]["R_name"].ToString(),
                        });
                    }
                }
                List<EmailIDList> HeadingList = new List<EmailIDList>();
                model.EmailIDList1 = HeadingList;
                model.RoleList = alertRoleList;
                // model.SecurityList = Securityreminderlist;
            }
            else
            {
                return RedirectToAction("LogOut", "Account");
            }
            return View(model);
            /// return View();
        }

        [Authorize]
        [ActionName("ScheduledReminder")]
        public ActionResult ScheduledReminder(string ReminderId, string AssignUser1, string Remindertype = "Hipaa")
        {
            Session["Remindertype1"] = Remindertype;
            Session["alertid"] = ReminderId;
            var sub = "";
            var body = "";
            var SId = "";
            var AssignUser = "";
            var noofDays = "";
            string Ret = "";
            var Redirect = Ret;
            var ToEmailID = "";
            var CCmail = "";
            var AlertFor = "";
            ShowUserDetailsModel model = new ShowUserDetailsModel();
            try
            {
                if (Remindertype == "Edit" || Remindertype == "Edit123")
                {
                    MySqlCommand cmd12 = new MySqlCommand("select IFNULL(AlertMailId, '') AS  AlertMailId, IFNULL( AlertFor, '') AS  AlertFor,  IFNULL(AlertTo , '') AS AlertTo , IFNULL( AlertFrom, '') AS AlertFrom , IFNULL(MailIng_CC , '') AS MailIng_CC , IFNULL(ScheduleDay , '') AS  ScheduleDay, IFNULL( Mail_Body, '') AS Mail_Body , IFNULL(  	Mail_Subject, '') AS  	Mail_Subject , IFNULL( Template_Type, '') AS  Template_Type, IFNULL(  	CreatedOn, '') AS CreatedOn, IFNULL( ModifiedBy, '') AS  ModifiedBy,  IFNULL(ModifiedOn , '') AS  ModifiedOn  from alert_mail where AlertMailId='" + ReminderId + "'", obj.con);
                    obj.con.Open();
                    MySqlDataReader dr = cmd12.ExecuteReader();
                    while (dr.Read())
                    {
                        sub = dr["Mail_Subject"].ToString();
                        body = dr["Mail_Body"].ToString();
                        SId = dr["AlertMailId"].ToString();
                        ToEmailID = dr["AlertTo"].ToString();
                        CCmail = dr["MailIng_CC"].ToString();
                        AlertFor = dr["AlertFor"].ToString();
                        //AssignUser = dr["AssignUser"].ToString();
                        noofDays = (dr["ScheduleDay"].ToString());
                    }
                    obj.con.Close();
                    Remindertype = "";
                }


                model.SecuritySub = sub;
                model.SecurityBody = body;
                model.Alertid = SId;
                model.ToEmailID = ToEmailID;
                model.CCmail = CCmail;
                model.AlertFor = AlertFor;
                // model.SecurityList = Securityreminderlist;
                // model.AssignUser = AssignUser;
                model.NoofDays = noofDays;

            }
            catch (Exception e)
            {
            }


            return View(model);
        }




        public JsonResult Getroll()
        {
            ShowUserDetailsModel model = new ShowUserDetailsModel();

            List<alertRoleList> alertRoleList = new List<alertRoleList>();
            MySqlCommand cmd3 = new MySqlCommand("select * from userrole where Isactive=1", obj.con);
            MySqlDataAdapter da2 = new MySqlDataAdapter(cmd3);
            DataTable dt2 = new DataTable();
            da2.Fill(dt2);
            if (dt2.Rows.Count > 0)
            {
                for (int i = 0; i < dt2.Rows.Count; i++)
                {
                    alertRoleList.Add(new alertRoleList
                    {
                        UserTypeId = Convert.ToInt32(dt2.Rows[i]["R_id"].ToString()),
                        UserType = dt2.Rows[i]["R_name"].ToString(),
                    });
                }
            }
            List<EmailIDList> HeadingList = new List<EmailIDList>();
            model.EmailIDList1 = HeadingList;
            model.RoleList = alertRoleList;
            // model.SecurityList = Securityreminderlist;
            return Json(model, JsonRequestBehavior.AllowGet);
        
        }

        public JsonResult UpdateScheduleReminder(string AlertFor, string ToEmailID, string CCmail,string SecuritySub, string SecurityBody, string NoOfDays = "Hipaa")
        {
           

            long alertid = Convert.ToInt32(Session["alertid"]);
            MySqlCommand cmd = new MySqlCommand("UPDATE alert_mail SET AlertFor=@AlertFor,AlertTo=@ToEmailID,MailIng_CC=@CCmail,ScheduleDay=@ScheduleDay,Mail_Body=@Mail_Body ,Mail_Subject=@Mail_Subject,ModifiedBy= @ModifiedBy,ModifiedOn=CURRENT_DATE() WHERE AlertMailId = @AlertMailId ", obj.con);
            obj.con.Open();
            cmd.CommandType = CommandType.Text;

            cmd.Parameters.AddWithValue("@AlertFor", AlertFor);
            cmd.Parameters.AddWithValue("@ToEmailID", ToEmailID);
            cmd.Parameters.AddWithValue("@CCmail",  CCmail);
            cmd.Parameters.AddWithValue("@ScheduleDay", NoOfDays );
            cmd.Parameters.AddWithValue("@Mail_Body",SecurityBody );
            cmd.Parameters.AddWithValue("@Mail_Subject", SecuritySub );
            cmd.Parameters.AddWithValue("@ModifiedBy", Session["UserId"] );
            cmd.Parameters.AddWithValue("@AlertMailId",alertid );
            cmd.ExecuteNonQuery();
            obj.con.Close();
            return Json('a', JsonRequestBehavior.AllowGet);
        }

        public JsonResult DeleteforAlert()
        {


            long alertid = Convert.ToInt32(Session["alertid"]);
            MySqlCommand cmd = new MySqlCommand("Delete from Alert_Mail  WHERE AlertMailId = @AlertMailId ", obj.con);
            cmd.Parameters.Add("@AlertMailId", alertid);
            obj.con.Open();
            cmd.CommandType = CommandType.Text;

           
            cmd.ExecuteNonQuery();
            obj.con.Close();
            return Json('a', JsonRequestBehavior.AllowGet);
        }
       
        
        [HttpPost]
        public ActionResult ScheduledReminder(string SecuritySub,string Status, string SecurityBody, string EmailID, string ButtonType, string ModifiedBy, string AssignUser, string CCmail = "", int emailids = 0, int SecurityID = 0, string SelectedAlertFor = "", int NoOfDays = 0)
        {
            string Ret = "";
            var Redirect = Ret;
            ShowUserDetailsModel model = new ShowUserDetailsModel();
            try
            {
                int SessionState = CheckSessionValues(1);
                if (SessionState == 1)
                {
                    //User Logged Detail Start
                    UserLogDetail ULD = new UserLogDetail();
                    ULD.ViewName = "Admin/ScheduledReminder";
                    ULD.OperationName = "Save";
                    //User Logged Detail End
                    // string email = SecurityManager.Decrypt(Connection.Email.ToString()); //Session["EmailAddress"];

                    DateTime dt3 = DateTime.Now;     //string date1 = (dt3.ToString("yyyy-MM-dd"));                   
                    string remiderId = Session["ReminderId"].ToString();

                    //User Logged Detail Start              
                    ULD.Detail = "Alert Template Saved Successfully. To:-{" + AssignUser + "},CC:-{" + CCmail + "} Successfully!";
                    ULD.DetailForUserView = "Alert Template Saved Successfully. To:-{" + AssignUser + "},CC:-{" + CCmail + "} Successfully!";
                    //User Logged Detail End               
                    // int SuccessId = APGBussinessClass.SaveRemainder(AssignUser, SecuritySub, SecurityBody, email, NoOfDays, CCmail, SelectedAlertFor, remiderId, "4");
                    int SuccessId = 0;
                    string currentdate=DateTime.Now.ToString("yyyy:MM:dd");
                    //  MySqlConnection con = APGBussinessClass.ConnectionState();
                  //  MySqlCommand cmd = new MySqlCommand("InsertAlertMail_Sp", obj.con);
                    MySqlCommand cmd = new MySqlCommand("insert into alert_mail(AlertFor,AlertTo,AlertFrom,MailIng_CC,ScheduleDay,Mail_Body,Mail_Subject,Template_Type,CreatedOn,ModifiedBy,ModifiedOn,status)values(@AlertFor,@AlertTo,@AlertFrom,@MailIng_CC,@ScheduleDay,@Mail_Body,@Mail_Subject,@Template_Type,@CreatedOn,@ModifiedBy,@ModifiedOn,@status)", obj.con);
                    // cmd = APGBussinessClass.MailRemainder(cmd);
                    cmd.Parameters.AddWithValue("@AlertFor", SelectedAlertFor);
                    cmd.Parameters.AddWithValue("@AlertTo", AssignUser);
                    cmd.Parameters.AddWithValue("@AlertFrom", Session["LoginUserId"]);
                    cmd.Parameters.AddWithValue("@MailIng_CC", CCmail);
                    cmd.Parameters.AddWithValue("@ScheduleDay", NoOfDays);
                    cmd.Parameters.AddWithValue("@Mail_Body", SecurityBody);
                    cmd.Parameters.AddWithValue("@Mail_Subject", SecuritySub);

                    cmd.Parameters.AddWithValue("@Template_Type", "Save");
                    cmd.Parameters.AddWithValue("@CreatedOn",currentdate);
                    cmd.Parameters.AddWithValue("@ModifiedBy", Session["UserId"]);
                    cmd.Parameters.AddWithValue("@ModifiedOn", currentdate);
                    cmd.Parameters.AddWithValue("@status",Status);
                   
                    obj.con.Open();
                    SuccessId = cmd.ExecuteNonQuery();            
                    obj.con.Close();

                    //MySqlCommand cmd1 = new MySqlCommand("select alert_name from alert_tbl where alert_name='" + NoOfDays + "'", obj.con);
                    //MySqlDataAdapter da = new MySqlDataAdapter(cmd1);
                    //DataTable dt = new DataTable();
                    //da.Fill(dt);
                    //if (dt.Rows.Count == 0)
                    //{
                    //    MySqlCommand cmd2 = new MySqlCommand("insert into alert_tbl(alert_name,note)values(@alertname,@note)",obj.con);
                    //    cmd2.Parameters.AddWithValue("@alertname",NoOfDays);
                    //    cmd2.Parameters.AddWithValue("@note",SecurityBody);
                    //    obj.OpenDbConnection();
                    //    cmd2.ExecuteNonQuery();
                    //    obj.CloseDbConnection();                   
                    //}
                    // return SuccessId;


                    //int SuccessId1 = APGBussinessClass.UserLogDetail(ULD);
                    Redirect = "1";//User Add Successful! \                                     
                }
            }
            catch (Exception e)
            {
                return Json(Redirect);
            }
            return Json(Redirect);
        }

        public JsonResult AlertMailSend(string SecuritySub, string SecurityBody, string EmailID, string ModifiedBy, string AssignUser, string CCmail = "", int emailids = 0, int SecurityID = 0, string SelectedAlertFor = "", int NoOfDays = 0)
        {
            string Ret = "";
            var Redirect = Ret;
            ShowUserDetailsModel model = new ShowUserDetailsModel();
            try
            {
                int SessionState = CheckSessionValues(1);
                if (SessionState == 1)
                {
                    UserLogDetail ULD = new UserLogDetail();
                    ULD.ViewName = "Admin/ScheduledReminder";
                    ULD.OperationName = "Save";
                    DateTime dt3 = DateTime.Now;     //string date1 = (dt3.ToString("yyyy-MM-dd"));                   
                    string remiderId = Session["ReminderId"].ToString();
                    ULD.Detail = "Alert Template Saved Successfully. To:-{" + AssignUser + "},CC:-{" + CCmail + "} Successfully!";
                    ULD.DetailForUserView = "Alert Template Saved Successfully. To:-{" + AssignUser + "},CC:-{" + CCmail + "} Successfully!";
                    int SuccessId = 0;
                    MySqlCommand cmd = new MySqlCommand("InsertAlertMail_Sp", obj.con);
                    cmd.Parameters.AddWithValue("@AlertFor", SelectedAlertFor);
                    cmd.Parameters.AddWithValue("@AlertTo", AssignUser);
                    cmd.Parameters.AddWithValue("@AlertFrom", Session["LoginUserId"]);
                    cmd.Parameters.AddWithValue("@MailIng_CC", CCmail);
                    cmd.Parameters.AddWithValue("@ScheduleDay", NoOfDays);
                    cmd.Parameters.AddWithValue("@Mail_Body", SecurityBody);
                    cmd.Parameters.AddWithValue("@Mail_Subject", SecuritySub);
                    cmd.Parameters.AddWithValue("@Template_Type", "Send");
                    cmd.Parameters.AddWithValue("@ModifiedBy", Session["UserId"]);
                    cmd.CommandType = CommandType.StoredProcedure;
                    obj.con.Open();
                    SuccessId = cmd.ExecuteNonQuery();
                    obj.con.Close();

                    Redirect = "1";//User Add Successful! \

                    MailMessage Msg = new MailMessage();
                    MailAddress fromMail = new MailAddress("apgportal@associatedphysicians.com");
                    Msg.From = fromMail;
                   // Msg.To.Add(AssignUser);
                    if (AssignUser != "")
                    {
                        string[] AssignUsers = AssignUser.Split(',');
                        foreach (string NewAssignUsers in AssignUsers)
                        {
                            Msg.To.Add(new MailAddress(NewAssignUsers));
                        }
                    }

                    if (CCmail != "")
                    {
                        string[] CCmails = CCmail.Split(',');
                        foreach (string NewCCMail in CCmails)
                        {
                            Msg.CC.Add(new MailAddress(NewCCMail));
                        }
                    }
                    Msg.Subject = SecuritySub;
                    Msg.Body += SecurityBody;
                    Msg.IsBodyHtml = true;
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = "mail.associatedphysicians.com";
                    smtp.Port = 25;
                    smtp.Credentials = new System.Net.NetworkCredential("apgportal@associatedphysicians.com", "P0rt@l@cce555!");
                    smtp.EnableSsl = true;
                    smtp.Send(Msg);
                    Msg = null;
                }
            }
            catch (Exception e)
            {
                return Json(Redirect);
            }
            return Json(Redirect);
        }

        [HttpPost]
        public ActionResult GetEmaillist(int UserTypeId)
        {
            List<EmailIDList> EmailList = new List<EmailIDList>();
            try
            {
                ShowUserDetailsModel model = new ShowUserDetailsModel();
                int active = 1;
                MySqlCommand cmd = new MySqlCommand("Select U_Id,EmailId from userregister where R_Id=@R_Id and IsActive=@active", obj.con);
                cmd.Parameters.AddWithValue("@R_Id", UserTypeId);
                cmd.Parameters.AddWithValue("@active", active);



                cmd.CommandType = CommandType.Text;
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        EmailList.Add(new EmailIDList
                        {
                            //TypeID = SecurityManager.Decrypt(ds.Tables[0].Rows[i]["F_Name"].ToString()),
                            TypeID = SecurityManager.Decrypt(ds.Tables[0].Rows[i]["U_Id"].ToString()),
                            EmailID = SecurityManager.Decrypt(ds.Tables[0].Rows[i]["EmailId"].ToString()),
                        });
                    }
                }
                return Json(EmailList);
            }
            catch (Exception e)
            {
                return RedirectToAction("Dashboard", "Home");
            }
        }


        //Code for csv file upload............

       

        //End
    }
}