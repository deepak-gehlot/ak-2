﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;
using MySql.Data.MySqlClient;
using System.Data.OleDb;

namespace NewAPGApplication
{
    public class DbConnection
    {
       // public MySqlConnection con = new MySqlConnection("server=192.168.0.50;user id=APGHospital;password=TXTPSBdKZTnXEqED;database=APGHospital");

       public MySqlConnection con = new MySqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ToString());

        public void OpenDbConnection()
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
            }
            catch (Exception)
            {
            }
        }

        public void CloseDbConnection()
        {
            try
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            catch (Exception)
            {
            }
        }
    }
}