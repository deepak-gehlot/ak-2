﻿$('.date').datepicker({autoclose: true,todayHighlight: true});
