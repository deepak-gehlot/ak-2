﻿$(document).ready(
  /* This is the function that will get executed after the DOM is fully loaded */
  function () {
      $("#datepicker").datepicker({
          changeMonth: true,//this option for allowing user to select month
          changeYear: true //this option for allowing user to select from year range
      });
  }
);

//function DateFormat(DateValue) {
//    alert(DateValue);
//    var s = document.getElementById("datepicker").value;    
//    var i = 0;
//    if (s.charCodeAt(0) >= 48 && s.charCodeAt(0) <= 57) {
//        document.getElementById("datepicker").maxLength = "10";
//        for (i = 0; i <= s.length - 1; i++) {
//            if (i == 1 && s.length == 2) {
//                s = s + "-";
//            }
//            if (i == 4 && s.length == 5) {
//                s = s + "-";
//            }
//        }
//        document.getElementById("datepicker").value = s;
//    }
//    if (s.charCodeAt(0) >= 97 && s.charCodeAt(0) <= 122) {
//        if (s && s.length >= 1) {
//            var firstChar = s.charAt(0);
//            var remainingStr = s.slice(1);
//            s = firstChar.toUpperCase() + remainingStr;
//        }
//        document.getElementById("datepicker").value = s;
//    }
//}