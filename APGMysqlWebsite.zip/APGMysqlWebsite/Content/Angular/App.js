﻿//Appjs
var app = angular.module("myapp", []);
app.controller('RegistrationConformation', ['$scope', '$http', function ($scope, $http) {
    $scope.onsubmit = function (alldetails) {
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $("#divLoading").show();
            var forgetPasswordString = data.ForgetPasswordString;
            var email = data.Email;
            var password = data.Password;
            var AddPatientModule = { ForgetPasswordString: forgetPasswordString, Email: email, Password: password }
            $http({
                method: 'POST',
                url: '/Patient/WelcomeIndex',
                data: AddPatientModule
            }).success(function (data) {
                $scope.VarificationString = data;
                if ($scope.VarificationString == "\"1\"") {
                    method: 'get';
                    location.href = '/Patient/PatientDashboard';
                    $("#divLoading").hide();
                    alert('Verification Successful!');
                    $http({
                        method: 'get',
                        url: '/Patient/PatientDashboard',
                        data: AddPatientModule
                    })
                }
                else if ($scope.VarificationString == "\"2\"") {
                        method: 'get';
                    $("#divLoading").hide();
                    alert('Invalid Verification String!');
                    location.href = '/Patient/WelcomeIndex';
                }
                else if ($scope.VarificationString == "\"-1\"") {
                        method: 'get';
                    $("#divLoading").hide();
                    alert('Email-id Not Exist!');
                    location.href = '/Patient/WelcomeIndex';
                }
                else if ($scope.VarificationString == "\"-3\"") {
                        method: 'get';
                    alert('Already Verified!');
                    location.href = '/Patient/WelcomeIndex';
                }
                else {
                    $("#divLoading").hide();
                }
            });
        }
    }
}]);
  
function NewPatientRegistration($scope) {
    $scope.email = 'enter email';
    //$scope.word = /^[a-z]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/;
    $scope.word = /^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
}

app.controller('PatientRegistrationDetailcontroller', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    GetEducationList();
    function GetEducationList() {
        $http({
            method: 'Get',
            url: '/Patient/GetEducationList'
        }).success(function (data, status, headers, config) {
            $scope.GetEducationList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetEthnicityList();
    function GetEthnicityList() {
        $http({
            method: 'Get',
            url: '/Patient/GetEthnicityList'
        }).success(function (data, status, headers, config) {
            $scope.GetEthnicityList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetFailictyList();
    function GetFailictyList() {
        $http({
            method: 'Get',
            url: '/admin/GetFailictyList'
        }).success(function (data, status, headers, config) {
            $scope.GetFailictyList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetStateList();
    function GetStateList() {
        $http({
            method: 'Get',
            url: '/admin/GetStateList'
        }).success(function (data, status, headers, config) {
            $scope.GetStateList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetUserDetail();
    function GetUserDetail() {
        $http({
            method: 'Get',
            url: '/Patient/GetUserDetail'
        }).success(function (data, status, headers, config) {
            $scope.Patientmodel = data
            console.log(data);
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };
    $scope.onsubmit = function (alldetails, ButtonType) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $("#divLoading").show();
            $scope.Validation = false;
            $scope.FacilityId = false;
            $scope.FirstName = false;
            $scope.LastName = false;
            $scope.DOB = false;
            $scope.Gender = false;
            $scope.Height = false;
            //$scope.HeightFeet = false;
            //$scope.HeightInch = false;
            $scope.Weight = false;
            $scope.Ethnicity = false;
            $scope.PIN = false;
            $scope.PINLength = false;
            $scope.PrimaryContactNo = false;
            $scope.SocSec = false;
            $scope.EducationId = false;
            $scope.WorkType = false;
            var GetErrors = '';
            var buttonType = ButtonType;
            var facilityId = data.FacilityId;
            var firstName = data.FirstName;
            var lastname = data.LastName;
            var nickName = data.NickName;
            var dOB = document.getElementById("datepicker").value;
            var gender = data.Gender;
            var street = data.Street;
            var city = data.City;
            var state = data.State;
            var zipCode = data.ZipCode;
            var email = data.Email;
            var pin = data.PIN;
            var heightFeet = data.HeightFeet;
            var heightInch = data.HeightInch;
            var height = data.Height;
            var weight = data.Weight;
            var primaryContactNo = data.PrimaryContactNo;
            var additionalContactNo = data.AdditionalContactNo;
            var socSec = data.SocSec;
            var educationId = data.EducationId;
            var occupation = data.Occupation;
            var workType = data.WorkType;
            var employer = data.Employer;
            var workPhone = data.WorkPhone;
            var contactAtWork = data.ContactAtWork
            var employerStreet = data.EmployerStreet;
            var employerCity = data.EmployerCity;
            var employerState = data.EmployerState;
            var employerZipCode = data.EmployerZipCode;
            var howKnowAboutUs = data.HowKnowAboutUs;
            var mCity = data.MCity;
            var mState = data.MState;
            var mZipCode = data.MZipCode;
            var referral = '';
            if (howKnowAboutUs == 'referral') {
                referral = data.Referral;
            }
            var currentlyHaveCP = data.CurrentlyHaveCP;
            var cPName = '';
            if (currentlyHaveCP == 'True') {
                cPName = data.CPName;
            }
            var currentlyHavePCP = data.CurrentlyHavePCP;
            var pCPName = '';
            if (currentlyHavePCP == 'True') {
                pCPName = data.PCPName;
            }
            var mailingAddress = data.MailingAddress;
            var ethnicityId = data.EthnicityId;
            $('.errorMsg').remove();
            if (facilityId == null || facilityId == '') {
                $scope.FacilityId = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (firstName == null || firstName == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (lastname == null || lastname == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (dOB == null || dOB == '') {
                $scope.DOB = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (gender == null || gender == '') {
                $scope.Gender = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (height == null || height == '') {
                $scope.Height = { color: 'red' };
                GetErrors += '6' + '\n';
            }
           
            if (height > 100 || height < 24) {
                $('#Height').append('<div class="errorMsg" style="color:red">Invalid Height</div>');               
                GetErrors += '7' + '\n';
            }
           
            if (weight == null || weight == '') {
                $scope.Weight = { color: 'red' };
                GetErrors += '10' + '\n';
            }
            if (ethnicityId == null || ethnicityId == '') {
                $scope.Ethnicity = { color: 'red' };
                GetErrors += '11' + '\n';
            }
            if (pin == null || pin == '') {
                $scope.PIN = { color: 'red' };
                GetErrors += '12' + '\n';
            }
            if (pin != null && pin != '' && pin.length != 4) {
                $('#PINLength').append('<div class="errorMsg" style="color:red">Pin No Lenght Must be 4 Digit</div>');
                GetErrors += '13' + '\n';
            }
            if (primaryContactNo == null || primaryContactNo == '') {
                $scope.PrimaryContactNo = { color: 'red' };
                GetErrors += '14' + '\n';
            }
            if (primaryContactNo != null || primaryContactNo != undefined) {
                var re = /^\(?[(. ]{1}\)?([0-9]{3})?[). ]{1}?([0-9]{3})?[-. ]{1}?([0-9]{4})$/;
                if (!re.test(primaryContactNo)) {
                    $('#PrimaryContactNo').append('<div class="errorMsg" style="color:red">Format is not valid</div>');
                    GetErrors += '14' + '\n';
                }
            }
            if (socSec == null || socSec == '') {
                $scope.SocSec = { color: 'red' };
                GetErrors += '15' + '\n';
            }
            if (socSec != null || socSec != undefined) {
                var re = /^\ ?([0-9]{3})?[-. ]?([0-9]{2})[-. ]?([0-9]{4})$/;
                if (!re.test(socSec)) {
                    $('#SocSecNo').append('<div class="errorMsg" style="color:red">Format is not valid</div>');
                    GetErrors += '14' + '\n';
                }
            }

            if (workType == null || workType == '') {
                $scope.WorkType = { color: 'red' };
                GetErrors += '10' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = {
                    FirstName: firstName, LastName: lastname, NickName: nickName, DOB: dOB, Gender: gender, Street: street, City: city, State: state, ZipCode: zipCode, Email: email, PIN: pin,
                    HeightFeet: heightFeet, HeightInch: heightInch, Height: height, Weight: weight, PrimaryContactNo: primaryContactNo, AdditionalContactNo: additionalContactNo, SocSec: socSec,
                    EducationId: educationId, Occupation: occupation, WorkType: workType, Employer: employer, WorkPhone: workPhone, ContactAtWork: contactAtWork, EmployerStreet: employerStreet,
                    EmployerCity: employerCity, EmployerState: employerState, EmployerZipCode: employerZipCode, HowKnowAboutUs: howKnowAboutUs, CurrentlyHaveCP: currentlyHaveCP, CPName: cPName,
                    CurrentlyHavePCP: currentlyHavePCP, PCPName: pCPName, MailingAddress: mailingAddress, EthnicityId: ethnicityId, FacilityId: facilityId, Referral: referral,
                    MCity: mCity, MState: mState, MZipCode: mZipCode
                }
                $http({
                    method: 'POST',
                    url: '/Patient/PatientRegistrationDetail',
                    data: AddPatientModule
                }).success(function (data) {
                    $("#divLoading").hide();
                    UserType = data;
                    //alert('Register Successfully');
                    if (buttonType == 1) {
                        if (UserType == "\"-1\"") {
                            location.href = '/Account/LogOut';
                        }
                        else if (UserType == "\"1\"") {
                            //$scope.UserRegisterModel = '';
                            alert("Registration Detail Updated Successfully!");
                            //location.href = '/Admin/UserList?FormId=101';
                        }
                        else if (UserType == "\"0\"") {
                            alert('Operation Not Executed Please Check Properly!');
                        }
                    }
                    else if (buttonType == 2) {
                        location.href = '/Patient/PatientInsuranceOne';
                    }
                    //Patient/Index?param=Patient%20Platform%20Setting
                });
            }
            else {
                $("#divLoading").hide();
                $scope.Validation = true;
                //alert(GetErrors);
            }
        }
    }
}]);

app.controller('InsuranceController', ['$scope', '$http', function ($scope, $http) {
    $scope.Insurance = {}
    GetUserDetail();
    function GetUserDetail() {
        $http({
            method: 'Get',
            url: '/Patient/GetInsuranceOneDetail'
        }).success(function (data, status, headers, config) {
            $scope.Insurance = data
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };
    $scope.onsubmit = function (alldetails, ButtonType) {
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $("#divLoading").show();
            $scope.Validation = false;
            $scope.Name = false;
            $scope.Policy = false;
            $scope.Group = false;
            var GetErrors = '';
            //First Insurance
            var buttonType = ButtonType;
            var name = data.Name;
            var address = data.Address;
            var city = data.City;
            var state = data.State;
            var zipCode = data.ZipCode;
            var policy = data.Policy;
            var insuranceName = data.InsuranceName;
            var relation = data.Relation;
            var socSec = data.SocSec;
            var dOB = document.getElementById("datepicker").value;
            var groupName = data.GroupName;
            var employeeName = data.EmployeeName;
            //First Insurance
            var s_name = data.S_Name;
            var s_address = data.S_Address;
            var s_city = data.S_City;
            var s_state = data.S_State;
            var s_zipCode = data.S_ZipCode;
            var s_policy = data.S_Policy;
            var s_insuranceName = data.S_InsuranceName;
            var s_relation = data.S_Relation;
            var s_socSec = data.S_SocSec;
            var s_dOB = document.getElementById("datepicker1").value;
            var s_groupName = data.S_GroupName;
            var s_employeeName = data.S_EmployeeName;
            //End           
            if (name == null || name == '') {
                $scope.Name = true;
                $scope.Validation = true;
                GetErrors += 'Please enter Location Name' + '\n';
            }
            if (policy == null || policy == '') {
                $scope.Policy = true;
                $scope.Validation = true;
                GetErrors += 'Please enter Fax No' + '\n';
            }
            if (groupName == null || groupName == '') {
                $scope.Group = true;
                $scope.Validation = true;
                GetErrors += 'Please enter Manager E-Mail Address' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddInsuranceModule = {
                    Name: name, Address: address, City: city, State: state, ZipCode: zipCode, Policy: policy, InsuranceName: insuranceName,
                    Relation: relation, SocSec: socSec, DOB: dOB, GroupName: groupName, EmployeeName: employeeName,
                    S_Name: s_name, S_Address: s_address, S_City: s_city, S_State: s_state, S_ZipCode: s_zipCode, S_Policy: s_policy, S_InsuranceName: s_insuranceName,
                    S_Relation: s_relation, S_SocSec: s_socSec, S_DOB: s_dOB, S_GroupName: s_groupName, S_EmployeeName: s_employeeName
                }
                $http({
                    method: 'POST',
                    url: '/Patient/PatientInsuranceOne',
                    data: AddInsuranceModule
                }).success(function (data) {
                    $("#divLoading").hide();
                    if (buttonType == 1) {
                        alert("Insurance Detail Updated Successfully!");
                    }
                    else if (buttonType == 2) {
                        location.href = '/Patient/HEALTHQuestionaireReport';
                    }
                });
            }
            else {
                $("#divLoading").hide();
                //alert(*All Fields are Required);
            }
        }
    }
}]);

app.controller('HEALTHQuestionaireController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.Patientmodel = {}
    GetHealthHistoryDetail();
    function GetHealthHistoryDetail() {
        $http({
            method: 'Get',
            url: '/Patient/GetHealthHistoryDetail'
        }).success(function (data, status, headers, config) {
            $scope.Patientmodel = data
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $("#divLoading").show();
            var GetErrors = '';
            var name = data.Name;
            var dOB = data.DOB;
            var medicalValues = document.getElementById("MedicalValues").value;
            var surgeriesValues = document.getElementById("SurgeriesValues").value;
            var medications = data.Medications;
            var food = data.Food;
            var allergies = document.getElementById("Allergies").value;
            var smoke = data.Smoke;
            var packsInaday = data.PacksInaday;
            var drink = data.Drink;
            var drinksInaday = data.DrinksInaday;
            var drugs = data.Drugs;
            var drugsName = data.DrugsName;
            var victimofAbouse = data.VictimofAbouse;
            var conmpensation = data.Conmpensation;
            var personalInjury = data.PersonalInjury;
            var other = data.Other;
            var otherDetail = data.OtherDetail;
            var disability = data.Disability;
            var review = document.getElementById("Review").value;
            var painHistory = data.PainHistory;
            var treatments = document.getElementById("Treatments").value;
            var currentMedications = document.getElementById("CurrentMedications").value;
            var familyHistory = document.getElementById("FamilyHistory").value;
            var patientSignature = document.getElementById("Patientmodel.SignatureValue").value;
            var submitDate = data.SubmitDate;
            var xRay = "Date:-" + data.DateXRay + ", Place :-" + data.PlaceXRay;
            var cTMRI = "Date:-" + data.DateCTMRI + ", Place :-" + data.PlaceCTMRI;
            var myelogram = "Date:-" + data.DateMyelogram + ", Place :-" + data.PlaceMyelogram;
            var ultrasound = "Date:-" + data.DateUltrasound + ", Place :-" + data.PlaceUltrasound;
            var eMG = "Date:-" + data.DateEMG + ", Place :-" + data.PlaceEMG;
            var anotherPhysician = "Date:-" + data.DateAnotherPhysician + ", Place :-" + data.PlaceAnotherPhysician;
            var treatmentForWhat = data.TreatmentForWhat;
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = {
                    Name: name, DOB: dOB, MedicalValues: medicalValues, SurgeriesValues: surgeriesValues, Medications: medications, Food: food, Allergies: allergies, Smoke: smoke, PacksInaday: packsInaday,
                    Drink: drink, DrinksInaday: drinksInaday, Drugs: drugs, DrugsName: drugsName, VictimofAbouse: victimofAbouse, Conmpensation: conmpensation, PersonalInjury: personalInjury, Other: other,
                    OtherDetail: otherDetail, Disability: disability, Review: review, PainHistory: painHistory, Treatments: treatments, CurrentMedications: currentMedications, FamilyHistory: familyHistory,
                    PatientSignature: patientSignature, SubmitDate: submitDate, XRay: xRay, CTMRI: cTMRI, Myelogram: myelogram, Ultrasound: ultrasound, EMG: eMG, AnotherPhysician: anotherPhysician, TreatmentForWhat: treatmentForWhat
                }
                $http({
                    method: 'POST',
                    url: '/Patient/HEALTHQuestionaireReport',
                    data: AddPatientModule
                }).success(function (data) {
                    $("#divLoading").hide();
                    $scope.Gender = data;
                    if ($scope.Gender == "\"Male\"") {
                        method: 'get',
                        location.href = '/Patient/BodyTest';
                    }
                    else if ($scope.Gender == "\"Female\"") {
                            method: 'get',
                            location.href = '/Patient/FemaleBodyTest';
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }
    }
}]);

app.controller('NewCompliantController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.NewComplaint = {}
    GetUserDetail();
    function GetUserDetail() {
        $http({
            method: 'Get',
            url: '/Patient/GetUserDetail'
        }).success(function (data, status, headers, config) {
            document.getElementById("PatientName").value = data.FirstName + " " + data.LastName;
            if (data.Gender == "Male") {
                document.getElementById("FrontImage").src = "../Content/images/MaleFronthalfcuts/male_silhouette.png";
                document.getElementById("FrontImage").useMap = "#FrontMaleBody";
                document.getElementById("myImage").src = "../Content/images/MaleBack/male_silhouette_back.png";
                document.getElementById("myImage").useMap = "#BackMaleBody";
            }
            else if (data.Gender == "Female") {
                document.getElementById("FrontImage").src = "../Content/images/FemaleFronthalfcuts/female_silhouette.png";
                document.getElementById("FrontImage").useMap = "#FrontFemaleBody";
                document.getElementById("myImage").src = "../Content/images/FemaleBackhalfcuts/female_back_silhouette.png";
                document.getElementById("myImage").useMap = "#BackFemaleBody";
            }
            //$scope.Patientmodel = data         
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $("#divLoading").show();
            var GetErrors = '';
            var PatientId = data.PatientId;
            var NewComplaintId = data.NewComplaintId;
            var NewInjuryDate = data.NewInjuryDate;
            var Cause = document.getElementById("Cause").value;
            var NewInjuryDescription = data.NewInjuryDescription;
            var LastCheckUp = data.LastCheckUp;
            var LastCheckUpDetail = data.LastCheckUpDetail;
            var FrontPainArea = document.getElementById("NewComplaint.FrontPainArea").value;
            var BackPainArea = document.getElementById("NewComplaint.BackPainArea").value;
            var PainScale = data.PainScale;
            var PainDescription = document.getElementById("PainDescription").value;
            var CurrentMobility = data.CurrentMobility;
            var CurrentEmployeement = data.CurrentEmployeement;
            var WokingStatus = data.WokingStatus;
            var LastFullDayWork = data.LastFullDayWork;
            //if (Accountmodel.FirstName != "" && Accountmodel.LastName != ""
            //    && Accountmodel.EmailAddress != "" && Accountmodel.GenderId != ""
            //    && Accountmodel.Password != "" && Accountmodel.ConfirmPassword != ""
            //    && Accountmodel.Feet != "" && Accountmodel.Inches != ""
            //    && Accountmodel.RaceId != "" && Accountmodel.DOB != "")
            if (GetErrors == null || GetErrors == '') {
                var NewCompliant = {
                    PatientId: PatientId, NewComplaintId: NewComplaintId, NewInjuryDate: NewInjuryDate, Cause: Cause, NewInjuryDescription: NewInjuryDescription,
                    LastCheckUp: LastCheckUp, LastCheckUpDetail: LastCheckUpDetail, FrontPainArea: FrontPainArea, BackPainArea: BackPainArea, PainScale: PainScale,
                    PainDescription: PainDescription, CurrentMobility: CurrentMobility, CurrentEmployeement: CurrentEmployeement, WokingStatus: WokingStatus, LastFullDayWork: LastFullDayWork
                }
                $http({
                    method: 'POST',
                    url: '/Patient/NewCompliant',
                    data: NewCompliant
                }).success(function (data) {
                    $("#divLoading").hide();
                });
            }
            else {
                $("#divLoading").hide();
            }
        }
    }
}]);

app.controller('ReActivationController', ['$scope', '$http', function ($scope, $http) {

    $scope.submitted = false;
    $scope.ReActivation = {}
    CalculateAgeInQC('1988/07/03')
    function CalculateAgeInQC(DOB) {
        var today = new Date();
        var birthDate = new Date(DOB);
        var age = today.getFullYear() - birthDate.getFullYear();
        var m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
    }

    GetUserDetail();
    function GetUserDetail() {
        $http({
            method: 'Get',
            url: '/Admin/GetPatientDetail'
        }).success(function (data, status, headers, config) {
            var today = new Date();
            var birthDate = new Date(data.DOB);
            var age = today.getFullYear() - birthDate.getFullYear();
            var m = today.getMonth() - birthDate.getMonth();
            if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                age--;
            }
            data.AgeOnReActivation = age;
            $scope.ReActivation = data

            document.getElementById("PatientName").value = data.FirstName + " " + data.LastName;
            if (data.Gender == "Male") {
                document.getElementById("FrontImage").src = "../Content/images/MaleFronthalfcuts/male_silhouette.png";
                document.getElementById("FrontImage").useMap = "#FrontMaleBody";
                document.getElementById("myImage").src = "../Content/images/MaleBack/male_silhouette_back.png";
                document.getElementById("myImage").useMap = "#BackMaleBody";
                document.getElementById("RightImage").src = "../Content/images/Male%20Side_Right_Assets/male_Right_Blank.png";
                document.getElementById("RightImage").useMap = "#MaleSideRight";
                document.getElementById("LeftImage").src = "../Content/images/Male%20Side_Left_Assets/male_Left_Blank.png";
                document.getElementById("LeftImage").useMap = "#MaleSideLeft";
            }
            else if (data.Gender == "Female") {
                document.getElementById("FrontImage").src = "../Content/images/FemaleFronthalfcuts/female_silhouette.png";
                document.getElementById("FrontImage").useMap = "#FrontFemaleBody";
                document.getElementById("myImage").src = "../Content/images/FemaleBackhalfcuts/female_back_silhouette.png";
                document.getElementById("myImage").useMap = "#BackFemaleBody";
                document.getElementById("RightImage").src = "../Content/images/Female%20Side_Right_Assets/female_Right_Blank.png";
                document.getElementById("RightImage").useMap = "#FemaleSideRight";
                document.getElementById("LeftImage").src = "../Content/images/Female%20Side_Left_Assets/female_Left_Blank.png";
                document.getElementById("LeftImage").useMap = "#FemaleSideLeft";
            }
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails) {
       
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $("#divLoading").show();
            var GetErrors = '';
            $scope.ReferringPhysician = false;
            $scope.PrimaryPhysician = false;
            $scope.Pharmacy = false;
            $scope.CityState = false;
            $scope.PainHistoryOne = false;
            $scope.PainHistoryTwo = false;
            var PatientId = data.PatientId;
            var AgeOnReActivation = data.AgeOnReActivation;
            var ReferringPhysician = data.ReferringPhysician;
            var PrimaryPhysician = data.PrimaryPhysician;
            var Pharmacy = data.Pharmacy;
            var CityState = data.CityState;
            var PainHistoryOne = data.PainHistoryOne;
            var PainHistoryTwo = data.PainHistoryTwo;
            var RightPainArea = document.getElementById("ReActivation.RightPainArea").value;
            var BackPainArea = document.getElementById("ReActivation.BackPainArea").value;
            var FrontPainArea = document.getElementById("ReActivation.FrontPainArea").value;
            var LeftPainArea = document.getElementById("ReActivation.LeftPainArea").value;
            var PainDescription = document.getElementById("PainDescription").value;
            var LastInjectionDate = document.getElementById("datepicker1").value;
            var TypeOfInjection = document.getElementById("TypeOfInjection").value + " ," + data.Other;
            var Helpful = data.Helpful;
            var PercentRelief = data.PercentRelief;
            var HowLong = data.HowLong;
            var MedicationsPrescription = data.MedicationsPrescription;
            var MedicationsPrescriptionDetail = data.MedicationsPrescriptionDetail;
            var MedicalConditions = data.MedicalConditions;
            var Surgeries = data.Surgeries;
            var CurrentMedications = data.CurrentMedications;
            var ALLERGIESMedications = data.ALLERGIESMedications;
            var ALLERGIESFood = data.ALLERGIESFood;
            var ALLERGIES = document.getElementById("ALLERGIES").value;//data.ALLERGIES;         
            var REVIEWList = document.getElementById("REVIEW").value;
            var PatientSignature = document.getElementById("SignatureValue").value;
            var SignatureDate = data.SubmitDate;
            $('.errorMsg').remove();
            if (ReferringPhysician == null || ReferringPhysician == '') {
                $scope.ReferringPhysician = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (PrimaryPhysician == null || PrimaryPhysician == '') {
                $scope.PrimaryPhysician = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (Pharmacy == null || Pharmacy == '') {
                $scope.Pharmacy = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (CityState == null || CityState == '') {
                $scope.CityState = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (PainHistoryOne == null || PainHistoryOne == '') {
                $scope.PainHistoryOne = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (PainHistoryTwo == null || PainHistoryTwo == '') {
                $scope.PainHistoryTwo = { color: 'red' };
                GetErrors += '6' + '\n';
            }
            var PainDescription = RightPainArea + BackPainArea + FrontPainArea + LeftPainArea;
            if (PainDescription == null || PainDescription == '') {
                GetErrors += 'Please select Pain Area' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var ReActivation = {
                    PatientId: PatientId, AgeOnReActivation: AgeOnReActivation, ReferringPhysician: ReferringPhysician, PrimaryPhysician: PrimaryPhysician, Pharmacy: Pharmacy,
                    CityState: CityState, PainHistoryOne: PainHistoryOne, PainHistoryTwo: PainHistoryTwo, RightPainArea: RightPainArea, BackPainArea: BackPainArea,
                    FrontPainArea: FrontPainArea, LeftPainArea: LeftPainArea, PainDescription: PainDescription, LastInjectionDate: LastInjectionDate, TypeOfInjection: TypeOfInjection,
                    Helpful: Helpful, PercentRelief: PercentRelief, HowLong: HowLong, MedicationsPrescription: MedicationsPrescription, MedicationsPrescriptionDetail: MedicationsPrescriptionDetail,
                    MedicalConditions: MedicalConditions, Surgeries: Surgeries, CurrentMedications: CurrentMedications, ALLERGIESMedications: ALLERGIESMedications, ALLERGIESFood: ALLERGIESFood,
                    ALLERGIES: ALLERGIES, REVIEWList: REVIEWList, PatientSignature: PatientSignature, SignatureDate: SignatureDate
                }
                console.log('ReActivation', ReActivation);

                $http({
                    method: 'POST',
                    url: '/Admin/ReActivation',
                    data: ReActivation
                }).success(function (data) {
                    $("#divLoading").hide();
                });
            }
            else {
                alert("Fill Required Data");
                $("#divLoading").hide();
            }
        }
    }
}]);

app.controller('BodyTestController', ['$scope', '$http', function ($scope, $http) {
    $scope.BodyTest = {}
    GetBodyTestDetail();
    function GetBodyTestDetail() {
        $http({
            method: 'Get',
            url: '/Patient/GetBodyTestDetail'
        }).success(function (data, status, headers, config) {
            $scope.BodyTest = data
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails) {
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $("#divLoading").show();
            var GetErrors = '';
            var frontPainArea = document.getElementById("BodyTest.FrontPainArea").value;
            var backPainArea = document.getElementById("BodyTest.BackPainArea").value;
            var rightPainArea = document.getElementById("BodyTest.RightPainArea").value;
            var leftPainArea = document.getElementById("BodyTest.LeftPainArea").value;
            var PainDescription = frontPainArea + backPainArea + rightPainArea + leftPainArea;
            if (PainDescription == null || PainDescription == '') {
                GetErrors += 'Please select Pain Area' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = { FrontPainArea: frontPainArea, BackPainArea: backPainArea, RightPainArea: rightPainArea, LeftPainArea: leftPainArea }
                $http({
                    method: 'POST',
                    url: '/Patient/BodyTest',
                    data: AddPatientModule
                }).success(function (data) {
                    $("#divLoading").hide();
                    $scope.Patientmodel = '';
                    $scope.Gender = data;
                    if ($scope.Gender == "\"Male\"") {
                        method: 'get',
                        location.href = '/Patient/MalePainReport';
                    }
                    else if ($scope.Gender == "\"Female\"") {
                            method: 'get',
                            location.href = '/Patient/FemalePainReport';
                    }
                });
            }
            else {
                alert(GetErrors);
            }
        }
    }
}]);

app.controller('PainReportController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.Patientmodel = {}
    $scope.onsubmit = function (alldetails) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $("#divLoading").show();
            var GetErrors = '';
            var painDescription = document.getElementById("PainDescription").value;
            var havePregnant = data.HavePregnant;
            var pregnant = data.Pregnant;
            var lastPeriodDate = data.LastPeriodDate;
            var normalLastPeriod = data.NormalLastPeriod;
            var lastMammogramDate = data.LastMammogramDate;
            var normalLastMammogram = data.NormalLastMammogram;
            var lastPapSmearDate = data.LastPapSmearDate;
            var normalLastPapSmear = data.NormalLastPapSmear;
            var signaturePhysician = document.getElementById("SignatureValue1").value;
            var dateSignaturePhysician = data.DateSignaturePhysician;
            var signatureNurse = document.getElementById("SignatureValue2").value;
            var dateSignatureNurse = data.DateSignatureNurse;
            var signaturePatient = document.getElementById("SignatureValue3").value;
            var dateSignaturePatient = data.DateSignaturePatient;
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = {
                    PainDescription: painDescription, HavePregnant: havePregnant, Pregnant: pregnant, LastPeriodDate: lastPeriodDate, NormalLastPeriod: normalLastPeriod,
                    LastMammogramDate: lastMammogramDate, NormalLastMammogram: normalLastMammogram, LastPapSmearDate: lastPapSmearDate, NormalLastPapSmear: normalLastPapSmear,
                    SignaturePhysician: signaturePhysician, DateSignaturePhysician: dateSignaturePhysician, SignatureNurse: signatureNurse,
                    DateSignatureNurse: dateSignatureNurse, SignaturePatient: signaturePatient, DateSignaturePatient: dateSignaturePatient
                }
                $http({
                    method: 'POST',
                    url: '/Patient/FemalePainReport',
                    data: AddPatientModule
                }).success(function (data) {
                    $("#divLoading").hide();
                    location.href = '/Patient/ArteryDiseaseQuestion';
                });
            }
            else {
                //alert(GetErrors);
            }
        }
    }
}]);

app.controller('HIPPAInsuranceReportController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.Patientmodel = {}
    GetHIPPAInsuranceReportDetail();
    function GetHIPPAInsuranceReportDetail() {
        $http({
            method: 'Get',
            url: '/Patient/GetHIPPAInsuranceReportDetail'
        }).success(function (data, status, headers, config) {
            $scope.Patientmodel = data
            document.getElementById("Signature1").src = data.Signature1;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $("#divLoading").show();
            $scope.PrintName1 = false;
            $scope.PrintName2 = false;
            $scope.PrintName3 = false;
            $scope.Signature1 = false;
            $scope.Signature2 = false;
            $scope.Signature3 = false;
            var GetErrors = '';
            var printName1 = data.PrintName1;
            var printName2 = data.PrintName2;
            var printName3 = data.PrintName3;
            var signature1 = document.getElementById("SignatureValue1").value;
            var signature2 = data.Signature2;
            var signature3 = data.Signature3;
            var dob = data.DOB;
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = { DOB: dob, PrintName1: printName1, PrintName2: printName2, PrintName3: printName3, Signature1: signature1, Signature2: signature2, Signature3: signature3 }
                $http({
                    method: 'POST',
                    url: '/Patient/HIPPAInsuranceReport',
                    data: AddPatientModule
                }).success(function (data) {
                    $("#divLoading").hide();
                    $scope.Patientmodel = '';
                    location.href = '/Patient/PatientMedicalAuthorization';
                });
            }
            else {
                //alert(GetErrors);
            }
        }

    }
}]);

app.controller('PatientMedicalAuthorizationController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.Patientmodel = {}
    GetPatientMedicalAuthorizationDetail();
    function GetPatientMedicalAuthorizationDetail() {
        $http({
            method: 'Get',
            url: '/Patient/GetPatientMedicalAuthorizationDetail'
        }).success(function (data, status, headers, config) {
            $scope.Patientmodel = data
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $("#divLoading").show();
            $scope.PatientName = false;
            $scope.Street = false;
            $scope.SocSec = false;
            $scope.City = false;
            $scope.ContactNo = false;
            $scope.OrgName = false;
            $scope.OrgAddress = false;
            $scope.OrgContactNo = false;
            var GetErrors = '';
            var patientName = data.PatientName;
            var dob = data.DOB;
            var street = data.Street;
            var socSec = data.SocSec;
            var city = data.City;
            var contactNo = data.ContactNo;
            var releaseTo = data.ReleaseTo;
            var obtainFrom = data.ObtainFrom;
            var orgName = data.OrgName;
            var orgAddress = data.OrgAddress;
            var orgContactNo = data.OrgContactNo;
            var appliesTo = data.AppliesTo;
            if (appliesTo == "Other") {
                appliesTo = data.TextAppliesTo;
            }
            var validTill = data.ValidTill;
            var signature = document.getElementById("SignatureValue1").value;
            var signDate = document.getElementById("SignDate").value;
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = {
                    PatientName: patientName, DOB: dob, Street: street, SocSec: socSec, City: city, ContactNo: contactNo, ReleaseTo: releaseTo, ObtainFrom: obtainFrom,
                    OrgName: orgName, OrgAddress: orgAddress, OrgContactNo: orgContactNo, AppliesTo: appliesTo, ValidTill: validTill, Signature: signature, SignDate: signDate
                }
                $http({
                    method: 'POST',
                    url: '/Patient/PatientMedicalAuthorization',
                    data: AddPatientModule
                }).success(function (data) {
                    $("#divLoading").hide();
                    $scope.Patientmodel = '';
                    location.href = '/Patient/PatientConsentForm';
                });
            }
            else {
            }
        }

    }
}]);

app.controller('PatientConsentController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.Patientmodel = {}
    $scope.onsubmit = function (alldetails) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $("#divLoading").show();
            $scope.Signature = false;
            $scope.AkgDate = false;
            var GetErrors = '';
            var signature = document.getElementById("SignatureValue1").value;
            var akgDate = document.getElementById("AkgDate").value;
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = { Signature: signature, AkgDate: akgDate }
                $http({
                    method: 'POST',
                    url: '/Patient/PatientConsentForm',
                    data: AddPatientModule
                }).success(function (data) {
                    if (data == 0) {

                    }
                    else if (data == 1) {
                        alert('Registration Completed!')
                        location.href = '/Home/DashBoard';
                    }
                    else if (data == 10) {
                        //alert('Registration Completed! Please Verify your Email or contact with APG Admin to Access APG')
                        alert('Registration Completed!')
                        location.href = '/Account/LogOut'
                        //Temparari Changes For New Requirwnt
                        //location.href = '/Patient/SelectWomacKNee';
                    }
                    $("#divLoading").hide();
                });
            }
            else {
                //alert(GetErrors);
            }
        }
    }
}]);

app.controller('WomacScoreController', ['$scope', '$http', function ($scope, $http) {
    GetUserDetail();
    function GetUserDetail() {
        $http({
            method: 'Get',
            url: '/Patient/GetWoMacScoreDetail'
        }).success(function (data, status, headers, config) {
            $scope.WomacScore = data
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };
}]);

app.controller('AlertMailController', ['$scope', '$http', function ($scope, $http) {
    $scope.onsubmit = function (alldetails) {
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            var subject = data.Subject;
            var bodyText = data.BodyText;
            var AddMailModule = {
                Subject: subject, BodyText: bodyText
            }
            $http({
                method: 'POST',
                url: '/Admin/AlertMail',
                data: AddMailModule
            }).success(function (data) {
                alert('Mail Sent Successfully!');
                location.href = '/Admin/AlertMail';
            });
        }
    }
}]);

app.controller('DiseaseQuestionController', ['$scope', '$http', function ($scope, $http) {
    $scope.onsubmit = function (alldetails) {
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            var GetErrors = '';
            var diseaseName = data.DiseaseName;
            var diseaseTypeId = document.getElementById("TypeId").value;
            if (diseaseName == null || diseaseName == '') {
                GetErrors += 'Please enter Question Name' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = { DiseaseName: diseaseName, DiseaseTypeId: diseaseTypeId }
                $http({
                    method: 'POST',
                    url: '/Admin/CreateDiseaseQuestion',
                    data: AddPatientModule
                }).success(function (data) {
                    var SuccessId = data;
                    if (SuccessId == 1) {
                        $scope.DiseaseQuestion = '';
                        alert('New Question added Successfully');
                        location.href = '/Admin/Womac?FormId=106';
                    }
                    else if (UserType == -1) {
                        location.href = '/Account/LogOut';
                    }
                });
            }
            else {
                alert(GetErrors);
            }
        }
    }
}]);

app.controller('EditQuestionController', ['$scope', '$http', function ($scope, $http) {
    GetDiseaseQuestion();
    function GetDiseaseQuestion() {
        $http({
            method: 'Get',
            url: '/Admin/GetDiseaseQuestion'
        }).success(function (data, status, headers, config) {
            $scope.DiseaseQuestion = data
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails, ButtonType) {
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            var buttonType = ButtonType;
            var diseaseId = data.DiseaseId;
            var diseaseTypeId = data.DiseaseTypeId;
            var diseaseTypeName = data.DiseaseTypeName;
            var diseaseName = data.DiseaseName;
            if (buttonType == 1) {
                if (confirm("Please Click Ok to Confirm the Changes!") == true) {
                    var AddPatientModule = {
                        DiseaseId: diseaseId, DiseaseTypeId: diseaseTypeId, DiseaseTypeName: diseaseTypeName, DiseaseName: diseaseName, ButtonType: buttonType
                    }
                    $http({
                        method: 'POST',
                        url: '/Admin/EditDiseaseQuestion',
                        data: AddPatientModule
                    }).success(function (data) {
                        location.href = '/Admin/Womac';
                    });
                } else {
                }
            } else if (buttonType == 2) {
                if (confirm("Please Click Ok to Confirm the Delete!") == true) {
                    var AddPatientModule = {
                        DiseaseId: diseaseId, DiseaseTypeId: diseaseTypeId, DiseaseTypeName: diseaseTypeName, DiseaseName: diseaseName, ButtonType: buttonType
                    }
                    $http({
                        method: 'POST',
                        url: '/Admin/EditDiseaseQuestion',
                        data: AddPatientModule
                    }).success(function (data) {
                        location.href = '/Admin/Womac';
                    });
                } else {
                }
            }
        }
    }
}]);

app.controller('Searching', ['$scope', '$http', function ($scope, $http) {
    $scope.onsubmit = function (ButtonType, UserTypeId) {
        insertonsubmit(ButtonType);
        function insertonsubmit(data) {
            var buttonType = ButtonType;
            var userTypeId = UserTypeId;
            if (buttonType == 2) {
                if (confirm("Please Click Ok to Confirm the Delete!") == true) {
                    var AddPatientModule = { ButtonType: buttonType, UserTypeId: userTypeId }
                    $http({
                        method: 'POST',
                        url: '/Admin/UserLevel',
                        data: AddPatientModule
                    }).success(function (data) {
                        location.href = '/Admin/UserLevel';
                    });
                } else {
                }
            }
        }
    }
}]);

app.controller('CreatePatientcontroller', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.Patientmodel = {}
    GetEducationList();
    function GetEducationList() {
        $http({
            method: 'Get',
            url: '/Patient/GetEducationList'
        }).success(function (data, status, headers, config) {
            $scope.GetEducationList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetEthnicityList();
    function GetEthnicityList() {
        $http({
            method: 'Get',
            url: '/Patient/GetEthnicityList'
        }).success(function (data, status, headers, config) {
            $scope.GetEthnicityList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetFailictyList();
    function GetFailictyList() {
        $http({
            method: 'Get',
            url: '/admin/GetFailictyList'
        }).success(function (data, status, headers, config) {
            $scope.GetFailictyList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetStateList();
    function GetStateList() {
        $http({
            method: 'Get',
            url: '/admin/GetStateList'
        }).success(function (data, status, headers, config) {
            $scope.GetStateList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetReferralList();
    function GetReferralList() {
        $http({
            method: 'Get',
            url: '/Patient/GetReferralList'
        }).success(function (data, status, headers, config) {
            $scope.GetReferralList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onLostFocusUserId = function (Email) {
        CheckUserIdExist(Email);
        function CheckUserIdExist(data) {
            var GetErrors = '';
            $('.errorMsg').remove();
            if (data != null || data != undefined) {
                if (data.match("@") || data.match(" ")) {
                    $('#UserNameId').append('<div class="errorMsg" style="color:red">In User Id @ and Blanked Spcace is not Allowed!</div>');
                    document.getElementById("UserNameIdAvailable").value = "-1";
                }
                else if (data != '') {
                    $http({
                        method: 'Get',
                        url: '/NewHome/GetUserNameIdExist?UserNameId=' + data
                    }).success(function (Success, status, headers, config) {
                        if (Success == 1) {
                            document.getElementById("UserNameIdAvailable").value = "1";
                        }
                        else {
                            $('#UserNameId').append('<div class="errorMsg" style="color:red">This User Id Already Exist!</div>');
                            document.getElementById("UserNameIdAvailable").value = "0";
                        }
                    }).error(function (data, status, headers, config) {
                        $scope.message = 'Unexpected Error';
                    });
                }
            }
        }
    }

    $scope.onLostFocusEmail = function (Email) {
        CheckEmailExist(Email);
        function CheckEmailExist(data) {
            var GetErrors = '';
            $('.errorMsg').remove();
            if (data != null || data != undefined) {
                if (data != '') {
                    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                    if (!re.test(data)) {
                        $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                        document.getElementById("EmailAvailable").value = "-1";
                    }
                    else {
                        $http({
                            method: 'Get',
                            url: '/NewHome/GetEmailExist?EmailId=' + data
                        }).success(function (Success, status, headers, config) {
                            if (Success == 1) {
                                document.getElementById("EmailAvailable").value = "1";
                            }
                            else {
                                $('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId Already Register Please Use Different EmailId</div>');
                                document.getElementById("EmailAvailable").value = "0";
                            }
                        }).error(function (data, status, headers, config) {
                            $scope.message = 'Unexpected Error';
                        });
                    }
                }
            }
        }
    }

    $scope.onsubmit = function (alldetails, ButtonType) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $("#divLoading").show();
            $scope.UserNameId = false;
            $scope.Validation = false;
            $scope.FacilityId = false;
            $scope.FirstName = false;
            $scope.LastName = false;
            $scope.DOB = false;
            $scope.Gender = false;
            $scope.Height = false;
            $scope.Weight = false;
            $scope.Ethnicity = false;
            $scope.PIN = false;
            $scope.PINLength = false;
            $scope.PrimaryContactNo = false;
            $scope.SocSec = false;
            $scope.EducationId = false;
            $scope.WorkType = false;
            $scope.Email = false;
            $scope.Password = false;
            $scope.Confirmpwd = false;
            $scope.PasswordLength = false;
            $scope.MaxFeet = false;
            $scope.MaxInch = false;
            $scope.WorkType = false;
            var GetErrors = '';
            var buttonType = ButtonType;
            var userNameId = data.UserNameId;
            var facilityId = data.FacilityId;
            var firstName = data.FirstName;
            var lastname = data.LastName;
            var nickName = data.NickName;
            var dOB = document.getElementById("datepicker").value;
            var gender = data.Gender;
            var street = data.Street;
            var city = data.City;
            var state = data.State;
            var zipCode = data.ZipCode;
            var email = data.Email;
            var pin = data.PIN;
            var password = data.Password;
            var confirmpwd = data.Confirmpwd;
            var heightFeet = data.HeightFeet;
            var heightInch = data.HeightInch;
            var height = data.Height;
            var weight = data.Weight;
            var primaryContactNo = data.PrimaryContactNo;
            var additionalContactNo = data.AdditionalContactNo;
            var socSec = data.SocSec;
            var educationId = data.EducationId;
            var occupation = data.Occupation;
            var workType = data.WorkType;
            var employer = data.Employer;
            var workPhone = data.WorkPhone;
            var contactAtWork = data.ContactAtWork
            var employerStreet = data.EmployerStreet;
            var employerCity = data.EmployerCity;
            var employerState = data.EmployerState;
            var employerZipCode = data.EmployerZipCode;
            var howKnowAboutUs = data.HowKnowAboutUs;
            var mCity = data.MCity;
            var mState = data.MState;
            var mZipCode = data.MZipCode;
            var referral = '';
            if (howKnowAboutUs == 'referral') {
                referral = data.Referral;
            }
            var currentlyHaveCP = data.CurrentlyHaveCP;
            var cPName = '';
            if (currentlyHaveCP == 'True') {
                cPName = data.CPName;
            }
            var currentlyHavePCP = data.CurrentlyHavePCP;
            var pCPName = '';
            if (currentlyHavePCP == 'True') {
                pCPName = data.PCPName;
            }
            var mailingAddress = data.MailingAddress;
            var ethnicityId = data.EthnicityId;
            $('.errorMsg').remove();
            if (document.getElementById("UserNameIdAvailable").value == "0") {
                $('#UserNameId').append('<div class="errorMsg" style="color:red">This User Id Already Exist!</div>');
                GetErrors += '1' + '\n';
            }
            if (document.getElementById("UserNameIdAvailable").value == "-1") {
                $('#UserNameId').append('<div class="errorMsg" style="color:red">In User Id @ and Blanked Spcace is not Allowed!</div>');
                GetErrors += '2' + '\n';
            }
            if (document.getElementById("EmailAvailable").value == "0") {
                $('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId Already Register Please Use Different EmailId</div>');
                GetErrors += '3' + '\n';
            }
            if (document.getElementById("EmailAvailable").value == "-1") {
                $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                GetErrors += '4' + '\n';
            }
            if ((userNameId == null || userNameId == '') && (email == null || email == '')) {
                alert("UserId or Email-Address any single one Is Required For Registration!");
                GetErrors += '5' + '\n';
            }
            if (facilityId == null || facilityId == '') {
                $scope.FacilityId = { color: 'red' };
                GetErrors += '6' + '\n';
            }
            if (firstName == null || firstName == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '7' + '\n';
            }
            if (lastname == null || lastname == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '8' + '\n';
            }
            if (dOB == null || dOB == '') {
                $scope.DOB = { color: 'red' };
                GetErrors += '9' + '\n';
            }
            var today = new Date();
            if (new Date(dOB).getTime() > today) {
                $('#Dateob').append('<div class="errorMsg" style="color:red">date of birth should not be future date</div>');
                $scope.DOB = { color: 'red' };
                GetErrors += '8' + '\n';
            }
            if (gender == null || gender == '') {
                $scope.Gender = { color: 'red' };
                GetErrors += '10' + '\n';
            }
            if (height == null || height == '') {
                $scope.Height = { color: 'red' };
                GetErrors += '11' + '\n';
            }
            if (height > 100 || height < 24) {
                $('#Height').append('<div class="errorMsg" style="color:red">Invalid Height</div>');
                GetErrors += '12' + '\n';
            }
            if (weight == null || weight == '') {
                $scope.Weight = { color: 'red' };
                GetErrors += '13' + '\n';
            }
            if (ethnicityId == null || ethnicityId == '') {
                $scope.Ethnicity = { color: 'red' };
                GetErrors += '14' + '\n';
            }
            //if (email == null || email == '') {
            //    $scope.Email = { color: 'red' };
            //    GetErrors += '15' + '\n';
            //}
            //if (email != null || email != undefined) {
            //    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            //    if (!re.test(email)) {
            //        $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
            //        GetErrors += '16' + '\n';
            //    }
            //}
            if (password == null || password == '') {
                $scope.Password = { color: 'red' };
                GetErrors += '17' + '\n';
            }
            if (confirmpwd == null || confirmpwd == '') {
                $scope.Confirmpwd = { color: 'red' };
                GetErrors += '18' + '\n';
            }
            if (password != null && password != undefined && password.length < 8) {
                $('#PwdLength').append('<div class="errorMsg" style="color:red">Password Lenght must be Minimum 8 character</div>');
                GetErrors += '19' + '\n';
            }
            if (password != confirmpwd) {
                $('#MatchPassword').append('<div class="errorMsg" style="color:red">Password and Confirm Password Should be Same</div>');
                GetErrors += '20' + '\n';
            }
            if (pin == null || pin == '') {
                $scope.PIN = { color: 'red' };
                GetErrors += '21' + '\n';
            }
            if (pin != null && pin != '' && pin.length != 4) {
                $('#PINLength').append('<div class="errorMsg" style="color:red">Pin No Lenght Must be 4 Digit</div>');
                GetErrors += '22' + '\n';
            }
            if (primaryContactNo == null || primaryContactNo == '') {
                $scope.PrimaryContactNo = { color: 'red' };
                GetErrors += '23' + '\n';
            }
            if (primaryContactNo != null || primaryContactNo != undefined) {
                var re = /^\(?[(. ]{1}\)?([0-9]{3})?[). ]{1}?([0-9]{3})?[-. ]{1}?([0-9]{4})$/;
                if (!re.test(primaryContactNo)) {
                    $('#PrimaryContactNo').append('<div class="errorMsg" style="color:red">Format is not valid</div>');
                    GetErrors += '24' + '\n';
                }
            }
            if (socSec == null || socSec == '') {
                $scope.SocSec = { color: 'red' };
                GetErrors += '25' + '\n';
            }
            if (socSec != null || socSec != undefined) {
                var re = /^\ ?([0-9]{3})?[-. ]?([0-9]{2})[-. ]?([0-9]{4})$/;
                if (!re.test(socSec)) {
                    $('#SocSecNo').append('<div class="errorMsg" style="color:red">Format is not valid</div>');
                    GetErrors += '26' + '\n';
                }
            }
            if (workType == null || workType == '') {
                $scope.WorkType = { color: 'red' };
                GetErrors += '27' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = {
                    UserNameId: userNameId, FirstName: firstName, LastName: lastname, NickName: nickName, DOB: dOB, Gender: gender, Street: street, City: city, State: state, ZipCode: zipCode, Email: email, PIN: pin, Password: password,
                    HeightFeet: heightFeet, HeightInch: heightInch, Height: height, Weight: weight, PrimaryContactNo: primaryContactNo, AdditionalContactNo: additionalContactNo, SocSec: socSec, EducationId: educationId,
                    Occupation: occupation, WorkType: workType, Employer: employer, WorkPhone: workPhone, ContactAtWork: contactAtWork, EmployerStreet: employerStreet,
                    EmployerCity: employerCity, EmployerState: employerState, EmployerZipCode: employerZipCode, HowKnowAboutUs: howKnowAboutUs, CurrentlyHaveCP: currentlyHaveCP,
                    CPName: cPName, CurrentlyHavePCP: currentlyHavePCP, PCPName: pCPName, MailingAddress: mailingAddress, EthnicityId: ethnicityId, FacilityId: facilityId, Referral: referral,
                    MCity: mCity, MState: mState, MZipCode: mZipCode
                }
                $http({
                    method: 'POST',
                    url: '/Admin/CreatePatient',
                    data: AddPatientModule
                }).success(function (data) {
                    $("#divLoading").hide();
                    var SuccessId = data;
                    if (SuccessId == "-1") {
                        location.href = '/Account/LogOut';
                    }
                    else if (SuccessId == "-2") {
                        alert('Operation Not Executed Please Check Properly!');
                    }
                    else {
                        if (buttonType == 1) {
                            console.log(SuccessId);
                            if (SuccessId == "\"0\"") {
                                //if (SuccessId == "0") {
                                alert('This Patient Type Already Exist!');
                            }
                            else {
                                document.getElementById("PatientId").value = data;
                                if (confirm("Patient Record Added Successfully! Do You Want To Take Womac?") == true) {
                                    if (data != 0) {
                                        location.href = '/Patient/SelectWomacKNee?PatientId=' + data;
                                    }
                                }
                                else {
                                    location.href = '/Admin/PatientList?FormId=107';
                                }
                            }
                        }
                        else if (buttonType == 2) {
                            location.href = '/Patient/PatientInsuranceOne';
                        }
                    }
                });
            }
            else {
                $("#divLoading").hide();
                $scope.Validation = true;
            }
        }
    }
}]);

app.controller('UpdatePatientDetailcontroller', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.Patientmodel = {}
    GetEducationList();
    function GetEducationList() {
        $http({
            method: 'Get',
            url: '/Patient/GetEducationList'
        }).success(function (data, status, headers, config) {
            $scope.GetEducationList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetEthnicityList();
    function GetEthnicityList() {
        $http({
            method: 'Get',
            url: '/Patient/GetEthnicityList'
        }).success(function (data, status, headers, config) {
            $scope.GetEthnicityList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetStateList();
    function GetStateList() {
        $http({
            method: 'Get',
            url: '/admin/GetStateList'
        }).success(function (data, status, headers, config) {
            $scope.GetStateList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetReferralList();
    function GetReferralList() {
        $http({
            method: 'Get',
            url: '/Patient/GetReferralList'
        }).success(function (data, status, headers, config) {
            $scope.GetReferralList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetPatientDetail();
    function GetPatientDetail() {
        $http({
            method: 'Get',
            url: '/Admin/GetPatientDetail'
        }).success(function (data, status, headers, config) {
            $scope.Patientmodel = data
            if (data.Email == "") {
                $scope.truefalse = false;
            }
            else {
                $scope.truefalse = true;
            }
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onLostFocus = function (Email) {
        if ($scope.truefalse == false) {
            CheckEmailExist(Email);
        }
        function CheckEmailExist(data) {
            var GetErrors = '';
           
            $('.errorMsg').remove();
            if (data != null || data != undefined) {
                if (data != '') {
                    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                    if (!re.test(data)) {
                        $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                        document.getElementById("EmailAvailable").value = "-1";
                    }
                    else {
                        $http({
                            method: 'Get',
                            url: '/NewHome/GetEmailExist?EmailId=' + data
                        }).success(function (Success, status, headers, config) {
                            if (Success == 1) {
                                // $scope.truefalse = true;
                                document.getElementById("EmailAvailable").value = "1";
                            }
                            else {
                              //  $('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId Already Register Please Use Different EmailId</div>');
                                document.getElementById("EmailAvailable").value = "0";
                            }
                        }).error(function (data, status, headers, config) {
                            $scope.message = 'Unexpected Error';
                        });
                    }
                }
            }
        }
    }

    $scope.Deactivate = function (userid) {
        $http({
            method: 'POST',
            url: '/Patient/DeactivatePatientDetail',
            data: AddPatientModule
        }).success(function (data) {
        }

    )
    }

    $scope.onsubmit = function (alldetails, ButtonType) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $scope.Validation = false;
            $scope.FirstName = false;
            $scope.LastName = false;
            $scope.DOB = false;
            $scope.Gender = false;
            $scope.Height = false;
            $scope.Weight = false;
            $scope.Ethnicity = false;
            $scope.PIN = false;
            $scope.PINLength = false;
            $scope.PrimaryContactNo = false;
            $scope.SocSec = false;
            $scope.EducationId = false;
            $scope.WorkType = false;
            var GetErrors = '';
            var buttonType = ButtonType;
            var userNameId = data.UserNameId;
            var patientId = data.PatientId;
            var facilityId = data.FacilityId;
            var firstName = data.FirstName;
            var lastname = data.LastName;
            var nickName = data.NickName;
            var dOB = document.getElementById("datepicker").value;
            var gender = data.Gender;
            var street = data.Street;
            var city = data.City;
            var state = data.State;
            var zipCode = data.ZipCode;
            var pin = data.PIN;
            var email = data.Email;
            if (email == null || email == '') {
                email = "";
            }
            var heightFeet = data.HeightFeet;
            var heightInch = data.HeightInch;
            var height = data.Height;
            var weight = data.Weight;
            var primaryContactNo = data.PrimaryContactNo;
            var additionalContactNo = data.AdditionalContactNo;
            var socSec = data.SocSec;
            var educationId = data.EducationId;
            var occupation = data.Occupation;
            var workType = data.WorkType;
            var employer = data.Employer;
            var workPhone = data.WorkPhone;
            var contactAtWork = data.ContactAtWork
            var employerStreet = data.EmployerStreet;
            var employerCity = data.EmployerCity;
            var employerState = data.EmployerState;
            var employerZipCode = data.EmployerZipCode;
            var howKnowAboutUs = data.HowKnowAboutUs;
            var mCity = data.MCity;
            var mState = data.MState;
            var mZipCode = data.MZipCode;
            var referral = '';
            if (howKnowAboutUs == 'referral') {
                referral = data.Referral;
            }
            var currentlyHaveCP = data.CurrentlyHaveCP;
            var cPName = '';
            if (currentlyHaveCP == 'True') {
                cPName = data.CPName;
            }
            var currentlyHavePCP = data.CurrentlyHavePCP;
            var pCPName = '';
            if (currentlyHavePCP == 'True') {
                pCPName = data.PCPName;
            }
            var mailingAddress = data.MailingAddress;
            var ethnicityId = data.EthnicityId;
            $('.errorMsg').remove();
            if (buttonType == 1) {
                //if (facilityId == null || facilityId == '') {
                //    $scope.FacilityId = { color: 'red' };
                //    GetErrors += '1' + '\n';
                //}
                //if (userNameId == null || userNameId == '') {
                //    $scope.UserNameId = { color: 'red' };
                //    GetErrors += '2' + '\n';
                //}
                if (document.getElementById("EmailAvailable").value == "0") {
                    $('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId Already Register Please Use Different EmailId</div>');
                    alert("Email Id already Exist!");
                    GetErrors += '1' + '\n';
                }
                if (document.getElementById("EmailAvailable").value == "-1") {
                    $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                    GetErrors += '1' + '\n';
                }
                if (firstName == null || firstName == '') {
                    $scope.FirstName = { color: 'red' };
                    GetErrors += '2' + '\n';
                }
                if (lastname == null || lastname == '') {
                    $scope.LastName = { color: 'red' };
                    GetErrors += '3' + '\n';
                }
                if (dOB == null || dOB == '') {
                    $scope.DOB = { color: 'red' };
                    GetErrors += '4' + '\n';
                }
                var today = new Date();
                if (new Date(dOB).getTime() > today) {
                    $('#Dateob').append('<div class="errorMsg" style="color:red">date of birth should not be future date</div>');
                    $scope.DOB = { color: 'red' };
                    GetErrors += '8' + '\n';
                }
                if (gender == null || gender == '') {
                    $scope.Gender = { color: 'red' };
                    GetErrors += '5' + '\n';
                }
                if (height == null || height == '') {
                    $scope.Height = { color: 'red' };
                    GetErrors += '6' + '\n';
                }
                if (height > 100 || height < 24) {
                    $('#Height').append('<div class="errorMsg" style="color:red">Invalid Height</div>');
                    GetErrors += '7' + '\n';
                }
                if (weight == null || weight == '') {
                    $scope.Weight = { color: 'red' };
                    GetErrors += '10' + '\n';
                }
                if (ethnicityId == null || ethnicityId == '') {
                    $scope.Ethnicity = { color: 'red' };
                    GetErrors += '11' + '\n';
                }
                if (pin == null || pin == '') {
                    $scope.PIN = { color: 'red' };
                    GetErrors += '12' + '\n';
                }
                if (pin != null && pin != '' && pin.length != 4) {
                    $('#PINLength').append('<div class="errorMsg" style="color:red">Pin No Lenght Must be 4 Digit</div>');
                    GetErrors += '13' + '\n';
                }
                if (primaryContactNo == null || primaryContactNo == '') {
                    $scope.PrimaryContactNo = { color: 'red' };
                    GetErrors += '14' + '\n';
                }
                if (primaryContactNo != null || primaryContactNo != undefined) {
                    var re = /^\(?[(. ]{1}\)?([0-9]{3})?[). ]{1}?([0-9]{3})?[-. ]{1}?([0-9]{4})$/;
                    if (!re.test(primaryContactNo)) {
                        $('#PrimaryContactNo').append('<div class="errorMsg" style="color:red">Format is not valid</div>');
                        GetErrors += '14' + '\n';
                    }
                }
                if (socSec == null || socSec == '') {
                    $scope.SocSec = { color: 'red' };
                    GetErrors += '15' + '\n';
                }
                if (socSec != null || socSec != undefined) {
                    var re = /^\ ?([0-9]{3})?[-. ]?([0-9]{2})[-. ]?([0-9]{4})$/;
                    if (!re.test(socSec)) {
                        $('#SocSecNo').append('<div class="errorMsg" style="color:red">Format is not valid</div>');
                        GetErrors += '14' + '\n';
                    }
                }
                if (workType == null || workType == '') {
                    $scope.WorkType = { color: 'red' };
                    GetErrors += '10' + '\n';
                }
            }
            var ErrorMessage = null;
            if (buttonType == 1) {
                ErrorMessage = 'Please Click Ok to Confirm the Changes!'
            }
            else if (buttonType == 2) {
                ErrorMessage = 'Please Click Ok to Confirm the Delete!'
            }
            else if (buttonType == 3) {
                ErrorMessage = 'Please Click Ok to Confirm the Deactivation of this User!'
            }
            if (GetErrors == null || GetErrors == '') {
                if (confirm(ErrorMessage) == true) {
                    var AddPatientModule = {
                        UserNameId: userNameId, PatientId: patientId, FacilityId: facilityId, FirstName: firstName, LastName: lastname, NickName: nickName, DOB: dOB, Gender: gender, Street: street, City: city, State: state,
                        ZipCode: zipCode, Email: email, PIN: pin, HeightFeet: heightFeet, HeightInch: heightInch, Height: height, Weight: weight, PrimaryContactNo: primaryContactNo,
                        AdditionalContactNo: additionalContactNo, SocSec: socSec, EducationId: educationId, Occupation: occupation, WorkType: workType, Employer: employer,
                        WorkPhone: workPhone, ContactAtWork: contactAtWork, EmployerStreet: employerStreet, EmployerCity: employerCity, EmployerState: employerState,
                        EmployerZipCode: employerZipCode, HowKnowAboutUs: howKnowAboutUs, CurrentlyHaveCP: currentlyHaveCP, CPName: cPName, CurrentlyHavePCP: currentlyHavePCP,
                        PCPName: pCPName, MailingAddress: mailingAddress, EthnicityId: ethnicityId, ButtonType: buttonType, Referral: referral,
                        MCity: mCity, MState: mState, MZipCode: mZipCode
                    }
                    $http({
                        method: 'POST',
                        url: '/Admin/UpdatePatientDetail',
                        data: AddPatientModule
                    }).success(function (data) {
                        UserType = data;
                        if (UserType == "\"-1\"") {
                            location.href = '/Account/LogOut';
                        }
                        else if (UserType == "\"1\"") {
                            $scope.Patientmodel = '';
                            alert('Patient Detail Updated!');
                            location.href = '/Admin/PatientList?FormId=107'; //call from multiple view's
                        }
                        else if (UserType == "\"0\"") {
                            alert('Operation Not Executed Please Check Properly!');
                        }
                    });
                } else {
                }
            }
            else {
                alert("Please Fill All Required Detail!");
            }
        }
    }

    $scope.onPrint = function (data) {
        $scope.submitted = true;
        DataPrint(data);
        function DataPrint(data) {
            $http({
                method: 'Get',
                url: '/Admin/PrintDetail?PrintedForm=' + data
            }).success(function (data, status, headers, config) {
                $scope.Patientmodel = data
            }).error(function (data, status, headers, config) {
                $scope.message = 'Unexpected Error';
            });
        }
    }
}]);

app.controller('PatientBMIController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.Patientmodel = {}
    $scope.Height = {}
    $scope.Weight = {}
    GetPatientBMI();
    function GetPatientBMI() {
        $http({
            method: 'Get',
            url: '/Admin/GetPatientBMI'
        }).success(function (data, status, headers, config) {
            $scope.Patientmodel = data
          
            for (var item in data) {
                if (item == "PatientId") {
                    document.getElementById("PatientId").value = data.PatientId;
                }
            }
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };
    $scope.onsubmit = function (alldetails) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            //console.log(data);          
            var GetErrors = '';
            //console.log(data);     
            //var dOB = document.getElementById("datepicker").value;
            var patientId = data.PatientId;
            //var email = data.Email;
            var height = data.Height;
            var heightFeet = data.HeightFeet;
            var heightInch = data.HeightInch;
            var weight = data.Weight;
            if (height == null || height == '') {
                $scope.Height = true;
                GetErrors += '6' + '\n';
            }
            //if (heightFeet == null || heightFeet == '') {
            //    $scope.HeightFeet = true;
            //    GetErrors += '6' + '\n';
            //}
            //if (heightInch == null || heightInch == '') {
            //    $scope.HeightInch = true;
            //    GetErrors += '12' + '\n';
            //}
            if (weight == null || weight == '') {
                $scope.Weight = true;
                GetErrors += '7' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = {
                    PatientId: patientId, Height: height, HeightFeet: heightFeet, HeightInch: heightInch, Weight: weight
                }
                $http({
                    method: 'POST',
                    url: '/Admin/PatientBMI',
                    data: AddPatientModule
                }).success(function (data) {
                    if (data == "\"-1\"") {
                        location.href = '/Account/LogOut';
                    }
                    else if (data >= "\"1\"") {
                        document.getElementById("PatientId").value = patientId;
                        alert('New BMI Record Saved!');
                        location.href = '/Admin/PatientBMI?PatientId=' + patientId;
                    }
                    else if (data == "\"0\"") {
                        alert('New BMI Record Not Saved!!');
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }
    }
}]);

app.controller('CreatePatientBMIController', ['$scope', '$http', function ($scope, $http) {
    $scope.Patientmodel = '';

    $scope.onsubmit = function (PatientModel) {
       
        $scope.submitted = true;
        PatientModel.BMI=document.getElementById("BMINo").value;              
        $http({
            method: 'POST',
            url: '/Admin/CreateNewBMI',
            data: PatientModel
        }).success(function (data) {
            alert("BMI Created Successfully.");
            $scope.PatientModel = '';
        })
       // alert("BMI Creation faild.");
    }
    
}]);





app.controller('ChangePasswordController', ['$scope', '$http', function ($scope, $http) {

    $scope.submitted = false;
    $scope.Patientmodel = {}
    $scope.onsubmit = function (alldetails) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $scope.Email = false;
            $scope.oldPassword = false;
            $scope.Password = false;
            $scope.Confirmpwd = false;
            $scope.PasswordLength = false;
            $scope.MatchPassword = false;
            var GetErrors = '';
            //console.log(data);
            var email = document.getElementById("Email").value;//data.Email;          
            //var oldPassword = data.OldPassword;
            var password = data.Password;
            var confirmpwd = data.Confirmpwd;
            if (email == null || email == '') {
                $scope.Email = true;
                GetErrors += 'Please enter email address' + '\n';
            }
            //if (oldPassword == null || oldPassword == '') {
            //    $scope.oldPassword = true;
            //    GetErrors += 'Please enter old Password' + '\n';
            //}
            if (password == null || password == '') {
                $scope.Password = true;
                GetErrors += 'Please enter password' + '\n';
            }
            if (confirmpwd == null || confirmpwd == '') {
                $scope.Confirmpwd = true;
                GetErrors += 'Please enter Confirm' + '\n';
            }
            if (password != null && password != '' && password.length < 8) {
                $scope.PasswordLength = true;
                GetErrors += 'Password Lenght must be Minimum 8 character' + '\n';
            }
            if (password != confirmpwd) {
                $scope.MatchPassword = true;
                GetErrors += 'Password and Confirm password not mached' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = { Email: email, Password: password, Confirmpwd: confirmpwd }
               
                $http({
                    method: 'POST',
                    url: '/Account/ChangeUserPassword',
                    data: AddPatientModule
                }).success(function (data) {
                    UserType = data;
                    console.log(UserType);
                    $scope.Patientmodel = '';
                    if (UserType == "\"User Not Exist!\"") {
                        alert("User Not Exist!");
                    }
                    else {
                        alert('Password Changed Successfully!');
                        if (UserType != "\"10\"") {//PatientId=10 as on date Feb-23-2015
                            location.href = '/Admin/Index?param=User Platform Setting';
                        }
                        else if (UserType == "\"10\"") {//PatientId=10 as on date Feb-23-2015
                            location.href = '/Admin/Index?param=User Platform Setting';
                        }
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }

    }
}]);

app.controller('PasswordResetController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.Patientmodel = {}
    $scope.onsubmit = function (alldetails) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $scope.Email = false;
            $scope.OldPassword = false;
            $scope.Password = false;
            $scope.Confirmpwd = false;
            $scope.PasswordLength = false;
            $scope.MatchPassword = false;
            var GetErrors = '';
            var email = document.getElementById("Email").value;//data.Email;          
            var oldPassword = data.OldPassword;
            var password = data.Password;
            var confirmpwd = data.Confirmpwd;
            $('.errorMsg').remove();
            //if (email != null || email != undefined) {
            //    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            //    if (!re.test(email)) {
            //        $('#EmailId1').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
            //        GetErrors += '1' + '\n';
            //    }
            //}
            if (email == null || email == '') {
                $scope.Email = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (oldPassword == null || oldPassword == '') {
                $scope.OldPassword = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (password == null || password == '') {
                $scope.Password = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (confirmpwd == null || confirmpwd == '') {
                $scope.Confirmpwd = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (password != null && password != undefined && password.length < 8) {
                $('#PwdLength').append('<div class="errorMsg" style="color:red">Password Lenght must be Minimum 8 character</div>');
                GetErrors += '6' + '\n';
            }
            if (password != confirmpwd) {
                $('#MatchPassword').append('<div class="errorMsg" style="color:red">Password and Confirm Password Should be Same</div>');
                GetErrors += '7' + '\n';
            }
            //if (email == null || email == '') {
            //    $scope.Email = true;
            //    GetErrors += 'Please enter email address' + '\n';
            //}
            //if (oldPassword == null || oldPassword == '') {
            //    $scope.oldPassword = true;
            //    GetErrors += 'Please enter old Password' + '\n';
            //}
            //if (password == null || password == '') {
            //    $scope.Password = true;
            //    GetErrors += 'Please enter password' + '\n';
            //}
            //if (confirmpwd == null || confirmpwd == '') {
            //    $scope.Confirmpwd = true;
            //    GetErrors += 'Please enter Confirm' + '\n';
            //}
            //if (password != null && password != '' && password.length < 8) {
            //    $scope.PasswordLength = true;
            //    GetErrors += 'Password Lenght must be Minimum 8 character' + '\n';
            //}
            //if (password != confirmpwd) {
            //    $scope.MatchPassword = true;
            //    GetErrors += 'Password and Confirm password not mached' + '\n';
            //}
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = { Email: email, OldPassword: oldPassword, Password: password, Confirmpwd: confirmpwd }
                $http({
                    method: 'POST',
                    url: '/Account/ChangePassword',
                    data: AddPatientModule
                }).success(function (data) {
                    UserType = data;
                    $scope.Patientmodel = '';
                    alert('Password Reset Successfully!');
                    if (UserType != "\"10\"") {//PatientId=10 as on date Feb-23-2015                      
                        location.href = '/Admin/Index?param=User Setting';
                    }
                    else if (UserType == "\"10\"") {//PatientId=10 as on date Feb-23-2015                        
                        location.href = '/Patient/Index?param=Patient Platform Setting';
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }

    }
}]);

app.controller('PINResetController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.Patientmodel = {}
    $scope.onsubmit = function (alldetails) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $scope.Email = false;
            $scope.Password = false;
            $scope.PIN = false;
            $scope.ConfirmPIN = false;
            $scope.PINLength = false;
            $scope.MatchPIN = false;
            var GetErrors = '';
            var email = document.getElementById("Email").value;//data.Email;          
            var password = data.Password;
            var pin = data.PIN;
            var confirmPIN = data.ConfirmPIN;
            $('.errorMsg').remove();
            //if (email != null || email != undefined) {
            //    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            //    if (!re.test(email)) {
            //        $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
            //        GetErrors += '1' + '\n';
            //    }
            //}
            if (email == null || email == '') {
                $scope.Email = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (password == null || password == '') {
                $scope.Password = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (pin == null || pin == '') {
                $scope.PIN = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (confirmPIN == null || confirmPIN == '') {
                $scope.ConfirmPIN = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (pin != null && pin != undefined && pin.length != 4) {
                $('#PINLength').append('<div class="errorMsg" style="color:red">New PIN No Length Must be 4 Digit</div>');
                GetErrors += '6' + '\n';
            }
            if (pin != confirmPIN) {
                $('#MatchPIN').append('<div class="errorMsg" style="color:red">New PIN and Confirm PIN should be same</div>');
                GetErrors += '7' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = { Email: email, Password: password, PIN: pin, ConfirmPIN: confirmPIN }
                $http({
                    method: 'POST',
                    url: '/Patient/ChangePIN',
                    data: AddPatientModule
                }).success(function (data) {
                    UserType = data;
                    if (UserType == "\"-1\"") {
                        location.href = '/Account/LogOut';
                    }
                    else if (UserType == "\"1\"") {
                        $scope.Patientmodel = '';
                        alert('PIN Reset Successfully!');
                        //location.href = '/Patient/PatientDashboard';
                        location.href = '/Patient/Index?param=Patient Platform Setting';
                    }
                    else if (UserType == "\"0\"") {
                        alert('Operation Not Executed Please Check Properly!');
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }

    }
}]);

app.controller('APGGraphicReport1', ['$scope', '$http', function ($scope, $http) {
    GetFailictyList();
    function GetFailictyList() {
        $http({
            method: 'Get',
            url: '/admin/GetFailictyList'
        }).success(function (data, status, headers, config) {
            $scope.GetFailictyList = data;
            //console.log(data);
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    ChangeFacilitysubmit1();
    function ChangeFacilitysubmit1() {
        $http({
            method: 'Get',
            url: '/Account/AgeGraphicReport'
        }).success(function (data, status, headers, config) {
            $scope.ReportData = data;
            document.getElementById("FId").value = data.FacilityId;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    }

    $scope.ChangeFacility = function (alldetails) {
        ChangeFacilitysubmit(alldetails);
        function ChangeFacilitysubmit(data) {
            var FacilityId = data.FacilityId;
            $http({
                method: 'Get',
                url: '/Account/AgeGraphicReport?FacilityId=' + FacilityId
            }).success(function (data, status, headers, config) {
                document.getElementById("FId").value = data.FacilityId;
                console.log(data);
                $scope.ReportData = data;
            }).error(function (data, status, headers, config) {
                $scope.message = 'Unexpected Error';
            });
        }
    }

    //$scope.ChangeFacility1 = function (alldetails) {
    //    ChangeFacilitysubmit(alldetails);
    //    function ChangeFacilitysubmit(data) {
    //        var FacilityId = data.FacilityId;
    //        var GetErrors = '';                  
    //        if (GetErrors == null || GetErrors == '') {
    //            var FacilitySelection = { FacilityId: FacilityId }
    //            $http({
    //                method: 'POST',
    //                url: '/Account/AgeGraphicReport1',
    //                data: FacilitySelection
    //            }).success(function (data) {

    //            });
    //        }
    //        else {
    //        }
    //    }
    //}
}]);
