﻿var app = angular.module("myAdmin", []); app.controller("UserLevel", ["$scope", "$http", function (e, r) {
    e.onsubmit = function (e, o, n) {
    
        function t() {
            var t = e, l = o, s = n; if (2 == t && 1 == confirm("Please Click Ok to Confirm the Delete!")) {
                var a = { ButtonType: t, UserTypeId: l, UserTypeName: s };
                r({ method: "POST", url: "/Admin/UserLevel", data: a }).success(function (e) { var r = e; location.href = "/Admin/UserLevel?FormId=" + r })
            }
        } t(e)
    }
}]), app.controller("UserRoleTypeController", ["$scope", "$http", function (e, r) {
    e.UserRoleType = {}, e.x = !0, e.onsubmit = function (o) {
        function n(o) {
            e.UserType = !1; var n = "", t = o.UserType; if ($(".errorMsg").remove(), (null == t || "" == t) && (e.UserType = { color: "red" }, n += "1\n"), null == n || "" == n) {
                var l = { UserType: t };
                1 == confirm("Do you want to add New User Type?") ? r({ method: "POST", url: "/Admin/CreateUserLevel", data: l }).success(function (r) {
                    var o = r, n = JSON.parse(r);
                    '"0"' == o ? alert("This User Type Already Exist!") : '"-1"' == o ? location.href = "/Account/LogOut" : '"-2"' == o ? alert("Operation Not Executed Please Check Properly!") : 1 == confirm("New User Type Added Successfully! \n Do you want to add Another New User Type?") ? e.UserRoleType = "" : location.href = "/Admin/UserLevel?FormId=" + n
                }) : location.href = "/Admin/CreateUserLevel"
            }
        } n(o)
    }
}]);