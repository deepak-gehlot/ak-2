﻿//Adminjs
var app = angular.module("myAdmin", []);

app.controller('CheckUserAuthentication', ['$scope', '$http', function ($scope, $http) {
    $scope.onsubmit = function (alldetails, FormId) {
        insertonsubmit(alldetails, FormId);
        function insertonsubmit(FormId, AccessView) {
            var GetErrors = '';
            var accessView = AccessView;
            var formId = FormId;
            if (GetErrors == null || GetErrors == '') {
                var AddUserRoleType = { FormId: formId }
                $http({
                    method: 'Post',
                    url: '/Admin/CheckUserAuthentication',
                    data: AddUserRoleType
                }).success(function (data) {
                    var SuccessId = data;
                    if (SuccessId == 0) {
                        alert('You dont have permission to Access These Records!');
                    }
                    else if (SuccessId == 1) {
                        location.href = accessView;
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }
    }

    $scope.OnSeaching = function (alldetails, AccessView) {
        Seachingonsubmit(alldetails, AccessView);
        function Seachingonsubmit(AccessView) {
            var GetErrors = '';
            var searchValue = document.getElementById("Name").value;
            alert(name);
            var accessView = AccessView + searchValue;
            alert(accessView);
            $http({
                url: accessView
            }).success(function (data) {
                var SuccessId = data;
                if (SuccessId == 0) {
                    alert('You dont have permission to Access These Records!');
                }
                else if (SuccessId == 1) {
                    location.href = accessView;
                }
            });

        }
    }
}]);

app.controller('UserRoleTypeController', ['$scope', '$http', function ($scope, $http) {
    $scope.UserRoleType = {}
    $scope.x = true;
    $scope.onsubmit = function (alldetails) {
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $scope.UserType = false;
            var GetErrors = '';
            var userType = data.UserType;
            $('.errorMsg').remove();
            if (userType == null || userType == '') {
                $scope.UserType = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddUserRoleType = { UserType: userType }
                if (confirm("Do you want to add New User Type?") == true) {
                    $http({
                        method: 'POST',
                        url: '/Admin/CreateUserLevel',
                        data: AddUserRoleType
                    }).success(function (data) {
                        var SuccessId = data;
                        var FormId = JSON.parse(data);
                        if (SuccessId == "\"0\"") {
                            alert('This User Type Already Exist!');
                        }
                        else if (SuccessId == "\"-1\"") {
                            location.href = '/Account/LogOut';
                        }
                        else if (SuccessId == "\"-2\"") {
                            alert('Operation Not Executed Please Check Properly!');
                        }
                        else {
                            if (confirm("New User Type Added Successfully! \n Do you want to add Another New User Type?") == true) {
                                $scope.UserRoleType = '';
                            } else {
                                location.href = '/Admin/UserLevel?FormId=' + FormId;
                            }
                        }
                    });
                } else {
                    location.href = '/Admin/CreateUserLevel';
                }
            }
            else {
                //alert(GetErrors);
            }
        }
    }
}]);

app.controller('UserLevel', ['$scope', '$http', function ($scope, $http) {
    $scope.onsubmit = function (ButtonType, UserTypeId) {
        insertonsubmit(ButtonType);
        function insertonsubmit(data) {
            var buttonType = ButtonType;
            var userTypeId = UserTypeId;
            if (buttonType == 2) {
                if (confirm("Please Click Ok to Confirm the Delete!") == true) {
                    var AddPatientModule = { ButtonType: buttonType, UserTypeId: userTypeId }
                    $http({
                        method: 'POST',
                        url: '/Admin/UserLevel',
                        data: AddPatientModule
                    }).success(function (data) {
                        var FormId = data;
                        location.href = '/Admin/UserLevel?FormId=' + FormId;
                    });
                } else {
                }
            }
        }
    }
}]);

app.controller('registrationbyadmin', ['$scope', '$http', function ($scope, $http) {
    $scope.UserRegisterModel = {}
    GetuserlevelList();
    function GetuserlevelList() {
        $http({
            method: 'Get',
            url: '/admin/GetuserlevelList'
        }).success(function (data, status, headers, config) {
            $scope.GetuserlevelList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetFailictyList();
    function GetFailictyList() {
        $http({
            method: 'Get',
            url: '/admin/GetFailictyList'
        }).success(function (data, status, headers, config) {
            $scope.GetFailictyList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails) {
        $scope.UserTypeID = false;
        $scope.FacilityId = false;
        $scope.FirstName = false;
        $scope.LastName = false;
        $scope.Email = false;
        $scope.Password = false;
        $scope.PasswordLength = false;
        $scope.Confirmpwd = false;
        $scope.MatchPassword = false;
        $scope.MobileNo = false;
        CreateUserByAdmin(alldetails);
        function CreateUserByAdmin(data) {
            var GetErrors = '';
            var userTypeID = data.UserTypeID;
            var facilityID = data.FacilityID;
            var firstname = data.Firstname;
            var lastname = data.Lastname;
            var email = data.Email;
            var password = data.Password;
            var confirmpwd = data.Confirmpwd;
            var mobileNo = data.MobileNo;
            if (userTypeID == null) {
                $scope.UserTypeID = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (facilityID == null) {
                $scope.FacilityId = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (firstname == null || firstname == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (lastname == null || lastname == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (email == null || email == '') {
                $scope.Email = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (password == null || password == '') {
                $scope.Password = { color: 'red' };
                GetErrors += '6' + '\n';
            }
            if (password != null && password != '' && password.length < 8) {
                $scope.PasswordLength = true;
                GetErrors += 'Password Lenght must be Minimum 8 character' + '\n';
            }
            if (confirmpwd == null || confirmpwd == '') {
                $scope.Confirmpwd = { color: 'red' };
                GetErrors += 'Please Enter Confirm Password' + '\n';
            }
            if (password != confirmpwd) {
                $scope.MatchPassword = true;
                GetErrors += 'Password and Confirm Password not Mached' + '\n';
            }
            if (mobileNo == null || mobileNo == '') {
                $scope.MobileNo = { color: 'red' };
                GetErrors += '7' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddNewUserModule = {
                    UserTypeID: userTypeID, FacilityID: facilityID, Firstname: firstname, Lastname: lastname, Email: email, Password: password, MobileNo: mobileNo
                }
                $http({
                    method: 'POST',
                    url: '/admin/CreateUserByAdmin',
                    data: AddNewUserModule
                }).success(function (data) {
                    var SuccessId = data;
                    var FormId = JSON.parse(data);
                    if (SuccessId == "\"0\"") {
                        alert('This User Already Exist!');
                    }
                    else if (SuccessId == "\"-1\"") {
                        location.href = '/Account/LogOut';
                    }
                    else if (SuccessId == "\"-2\"") {
                        alert('Operation Not Executed Please Check Properly!');
                    }
                    else {
                       
                        if (confirm("New User Added Successfully! \n Do you want to add Another New User?") == true) {
                            $scope.UserRegisterModel = '';
                        } else {
                            location.href = '/Admin/UserList?FormId=' + FormId;
                        }
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }
    }
}]);

app.controller('UpdateUserDetail', ['$scope', '$http', function ($scope, $http) {
    $scope.UserRegisterModel = {}
    GetuserlevelList();
    function GetuserlevelList() {
        $http({
            method: 'Get',
            url: '/admin/GetuserlevelList'
        }).success(function (data, status, headers, config) {
            $scope.GetuserlevelList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetFailictyList();
    function GetFailictyList() {
        $http({
            method: 'Get',
            url: '/admin/GetFailictyList'
        }).success(function (data, status, headers, config) {
            $scope.GetFailictyList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetUserDetail();
    function GetUserDetail() {
        $http({
            method: 'get',
            url: '/Admin/GetUserDetail'
        }).success(function (data, status, headers, config) {
            $scope.UserRegisterModel = data
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails, ButtonType) {
        $scope.UserTypeID = false;
        $scope.FacilityId = false;
        $scope.FirstName = false;
        $scope.LastName = false;
        $scope.Email = false;
        $scope.MobileNo = false;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            var GetErrors = '';
            var buttonType = ButtonType;
            var userTypeID = data.UserTypeID;
            var facilityID = data.FacilityID;
            var firstName = data.FirstName;
            var lastName = data.LastName;
            var email = data.Email;
            var mobileNo = data.MobileNo;
            if (userTypeID == null) {
                $scope.UserTypeID = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (facilityID == null) {
                $scope.FacilityId = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (firstName == null || firstName == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (lastName == null || lastName == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (email == null || email == '') {
                $scope.Email = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (mobileNo == null || mobileNo == '') {
                $scope.MobileNo = { color: 'red' };
                GetErrors += '6' + '\n';
            }
            var ErrorMessage = null;
            if (buttonType == 1) {
                ErrorMessage = 'Please Click Ok to Confirm the Changes!'
            }
            else if (buttonType == 2) {
                ErrorMessage = 'Please Click Ok to Confirm the Delete!'
            }
            if (GetErrors == null || GetErrors == '') {
                if (confirm(ErrorMessage) == true) {
                    var AddPatientModule = {
                        UserTypeID: userTypeID, FacilityID: facilityID, FirstName: firstName, LastName: lastName, Email: email, MobileNo: mobileNo, ButtonType: buttonType
                    }
                    $http({
                        method: 'POST',
                        url: '/Admin/EditUser',
                        data: AddPatientModule
                    }).success(function (data) {
                        UserType = data;
                        if (UserType == "\"-1\"") {
                            location.href = '/Account/LogOut';
                        }
                        else if (UserType == "\"1\"") {
                            $scope.UserRegisterModel = '';
                            //alert('User Records Updated!');
                            location.href = '/Admin/UserList?FormId=101';
                        }
                        else if (UserType == "\"0\"") {
                            alert('Operation Not Executed Please Check Properly!');
                        }
                    });
                } else {
                }
            }
        }
    }
}]);

app.controller('UpdateUserProfileDetail', ['$scope', '$http', function ($scope, $http) {
    $scope.UserRegisterModel = {}
    GetuserlevelList();
    function GetuserlevelList() {
        $http({
            method: 'Get',
            url: '/admin/GetuserlevelList'
        }).success(function (data, status, headers, config) {
            $scope.GetuserlevelList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetFailictyList();
    function GetFailictyList() {
        $http({
            method: 'Get',
            url: '/admin/GetFailictyList'
        }).success(function (data, status, headers, config) {
            $scope.GetFailictyList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetUserDetail();
    function GetUserDetail() {
        $http({
            method: 'get',
            url: '/Admin/GetUserDetail'
        }).success(function (data, status, headers, config) {
            $scope.UserRegisterModel = data
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails, ButtonType) {
        $scope.UserTypeID = false;
        $scope.FacilityId = false;
        $scope.FirstName = false;
        $scope.LastName = false;
        $scope.Email = false;
        $scope.MobileNo = false;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            var GetErrors = '';
            var buttonType = ButtonType;
            var userTypeID = data.UserTypeID;
            var facilityID = data.FacilityID;
            var firstName = data.FirstName;
            var lastName = data.LastName;
            var email = data.Email;
            var mobileNo = data.MobileNo;
            if (userTypeID == null) {
                $scope.UserTypeID = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (facilityID == null) {
                $scope.FacilityId = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (firstName == null || firstName == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (lastName == null || lastName == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (email == null || email == '') {
                $scope.Email = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (mobileNo == null || mobileNo == '') {
                $scope.MobileNo = { color: 'red' };
                GetErrors += '6' + '\n';
            }
            var ErrorMessage = null;
            if (buttonType == 1) {
                ErrorMessage = 'Please Click Ok to Confirm the Changes!'
            }
            else if (buttonType == 2) {
                ErrorMessage = 'Please Click Ok to Confirm the Delete!'
            }
            if (GetErrors == null || GetErrors == '') {
                if (confirm(ErrorMessage) == true) {
                    var AddPatientModule = {
                        UserTypeID: userTypeID, FacilityID: facilityID, FirstName: firstName, LastName: lastName, Email: email, MobileNo: mobileNo, ButtonType: buttonType
                    }
                    $http({
                        method: 'POST',
                        url: '/Admin/EditUserProfile',
                        data: AddPatientModule
                    }).success(function (data) {
                        UserType = data;
                        if (UserType == "\"-1\"") {
                            location.href = '/Account/LogOut';
                        }
                        else if (UserType == "\"1\"") {
                            $scope.UserRegisterModel = '';
                            alert('User Profile Updated!');
                            location.href = '/Admin/Index?param=User Setting';
                        }
                        else if (UserType == "\"0\"") {
                            alert('Operation Not Executed Please Check Properly!');
                        }
                        //location.href = '/Admin/UserList';
                    });
                } else {
                }
            }
        }
    }
}]);

app.controller('FacilityController', ['$scope', '$http', function ($scope, $http) {
    $scope.Facility = {}
    $scope.onsubmit = function (alldetails) {
        $scope.LocationName = false;
        $scope.Address = false;
        $scope.State = false;
        $scope.City = false;
        $scope.Zipcode = false;
        $scope.PhoneNumber = false;
        $scope.FaxNumber = false;
        $scope.Manager = false;
        $scope.EmailAddress = false;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            var GetErrors = '';
            var locationName = data.LocationName;
            var address = data.Address;
            var state = data.State;
            var city = data.City;
            var zipcode = data.Zipcode;
            var phoneNumber = data.PhoneNumber;
            var faxNumber = data.FaxNumber;
            var manager = data.Manager;
            var emailAddress = data.EmailAddress;
            if (locationName == null || locationName == '') {
                $scope.LocationName = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (address == null || address == '') {
                $scope.Address = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (state == null || state == '') {
                $scope.State = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (city == null || city == '') {
                $scope.City = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (zipcode == null || zipcode == '') {
                $scope.Zipcode = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (phoneNumber == null || phoneNumber == '') {
                $scope.PhoneNumber = { color: 'red' };
                GetErrors += '6' + '\n';
            }
            if (faxNumber == null || faxNumber == '') {
                $scope.FaxNumber = { color: 'red' };
                GetErrors += '7' + '\n';
            }
            if (manager == null || manager == '') {
                $scope.Manager = { color: 'red' };
                GetErrors += '8' + '\n';
            }
            if (emailAddress == null || emailAddress == '') {
                $scope.EmailAddress = { color: 'red' };
                GetErrors += '9' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = {
                    LocationName: locationName, Address: address, State: state, City: city, Zipcode: zipcode, PhoneNumber: phoneNumber, FaxNumber: faxNumber, Manager: manager,
                    EmailAddress: emailAddress
                }
                $http({
                    method: 'POST',
                    url: '/Admin/Facility',
                    data: AddPatientModule
                }).success(function (data) {
                    var SuccessId = data;
                    var FormId = JSON.parse(data);
                    if (SuccessId == "\"0\"") {
                        alert('This Location Name Already Exist!');
                    }
                    else if (SuccessId == "\"-1\"") {
                        location.href = '/Account/LogOut';
                    }
                    else if (SuccessId == "\"-2\"") {
                        alert('Operation Not Executed Please Check Properly!');
                    }
                    else {
                        $scope.Facility = '';
                        if (confirm("New Facility Location Added Successfully! \n Do you want to add Another New Facility Location?") == true) {
                        } else {
                            location.href = '/Admin/FacilityList?FormId=' + FormId;
                        }
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }
    }
}]);

app.controller('UpdateFacilityDetail', ['$scope', '$http', function ($scope, $http) {
    $scope.Facility = {}
    GetFacilityList();
    function GetFacilityList() {
        $http({
            method: 'get',
            url: '/Admin/GetFacilityDetail'
        }).success(function (data, status, headers, config) {
            $scope.Facility = data
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails, ButtonType) {
        $scope.LocationName = false;
        $scope.Address = false;
        $scope.State = false;
        $scope.City = false;
        $scope.Zipcode = false;
        $scope.PhoneNumber = false;
        $scope.FaxNumber = false;
        $scope.Manager = false;
        $scope.EmailAddress = false;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            var GetErrors = '';
            var buttonType = ButtonType;
            var locationName = data.LocationName;
            var address = data.Address;
            var state = data.State;
            var city = data.City;
            var zipcode = data.Zipcode;
            var phoneNumber = data.PhoneNumber;
            var faxNumber = data.FaxNumber;
            var manager = data.Manager;
            var emailAddress = data.EmailAddress;
            if (locationName == null || locationName == '') {
                $scope.LocationName = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (address == null || address == '') {
                $scope.Address = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (state == null || state == '') {
                $scope.State = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (city == null || city == '') {
                $scope.City = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (zipcode == null || zipcode == '') {
                $scope.Zipcode = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (phoneNumber == null || phoneNumber == '') {
                $scope.PhoneNumber = { color: 'red' };
                GetErrors += '6' + '\n';
            }
            if (faxNumber == null || faxNumber == '') {
                $scope.FaxNumber = { color: 'red' };
                GetErrors += '7' + '\n';
            }
            if (manager == null || manager == '') {
                $scope.Manager = { color: 'red' };
                GetErrors += '8' + '\n';
            }
            if (emailAddress == null || emailAddress == '') {
                $scope.EmailAddress = { color: 'red' };
                GetErrors += '9' + '\n';
            }
            var ErrorMessage = null;
            if (buttonType == 1) {
                ErrorMessage = 'Please Click Ok to Confirm the Changes!'
            }
            else if (buttonType == 2) {
                ErrorMessage = 'Please Click Ok to Confirm the Delete!'
            }
            if (GetErrors == null || GetErrors == '') {
                if (confirm(ErrorMessage) == true) {
                    var AddPatientModule = {
                        LocationName: locationName, Address: address, State: state, City: city, Zipcode: zipcode, PhoneNumber: phoneNumber, FaxNumber: faxNumber, Manager: manager,
                        EmailAddress: emailAddress, ButtonType: buttonType
                    }
                    $http({
                        method: 'POST',
                        url: '/Admin/EditFacility',
                        data: AddPatientModule
                    }).success(function (data) {
                        var SuccessId = data;
                        var FormId = JSON.parse(data);
                        if (SuccessId == "\"0\"") {
                            alert('Operation Not Executed Please Check Properly!');
                        }
                        else if (SuccessId == "\"-1\"") {
                            location.href = '/Account/LogOut';
                        }
                        else if (SuccessId == "\"-2\"") {
                            alert('Operation Not Executed Please Check Properly!');
                        }
                        else {
                            $scope.UserRegisterModel = '';
                            location.href = '/Admin/FacilityList?FormId=' + FormId;
                        }
                    });
                } else {
                }
            }
            else {
                //alert(GetErrors);
            }
        }
    }
}]);

app.controller('NewPhysicianController', ['$scope', '$http', function ($scope, $http) {
    $scope.Physician = {}
    $scope.submitted = false;
    GetFailictyList();
    function GetFailictyList() {
        $http({
            method: 'Get',
            url: '/admin/GetFailictyList'
        }).success(function (data, status, headers, config) {
            $scope.GetFailictyList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };
    $scope.onsubmit = function (alldetails) {
        $scope.submitted = true;
        $scope.FacilityId = false;
        $scope.FirstName = false;
        $scope.LastName = false;
        $scope.Email = false;
        $scope.MobileNo = false;
        AddNewPhysician(alldetails);
        function AddNewPhysician(data) {
            var GetErrors = '';
            var facilityId = data.FacilityId;
            var firstName = data.FirstName;
            var lastName = data.LastName;
            var email = data.Email;
            var mobileNo = data.MobileNo;
            if (facilityId == null || facilityId == '') {
                $scope.FacilityId = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (firstName == null || firstName == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (lastName == null || lastName == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (email == null || email == '') {
                $scope.Email = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (mobileNo == null || mobileNo == '') {
                $scope.MobileNo = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddNewPhysician = {
                    FacilityId: facilityId, FirstName: firstName, LastName: lastName, Email: email, MobileNo: mobileNo
                }
                $http({
                    method: 'POST',
                    url: '/Admin/NewPhysician',
                    data: AddNewPhysician
                }).success(function (data) {
                    $scope.Physician = '';
                    var SuccessId = data;
                    if (SuccessId == 1) {
                        alert('New Physicain Added Successfully!');
                        location.href = '/Home/DashBoard';
                    }
                    else if (SuccessId == 0) {
                        location.href = '/Admin/NewPhysician';
                    }
                    else if (SuccessId == -1) {
                        location.href = '/Account/LogOut';
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }
    }
}]);

app.controller('NewPhysicalTherapistController', ['$scope', '$http', function ($scope, $http) {
    $scope.PhysicalTherapist = {}
    $scope.submitted = false;
    GetFailictyList();
    function GetFailictyList() {
        $http({
            method: 'Get',
            url: '/admin/GetFailictyList'
        }).success(function (data, status, headers, config) {
            $scope.GetFailictyList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };
    $scope.onsubmit = function (alldetails) {
        $scope.submitted = true;
        $scope.FacilityId = false;
        $scope.FirstName = false;
        $scope.LastName = false;
        $scope.Email = false;
        $scope.MobileNo = false;
        AddNewPhysicalTherapist(alldetails);
        function AddNewPhysicalTherapist(data) {
            var GetErrors = '';
            var facilityId = data.FacilityId;
            var firstName = data.FirstName;
            var lastName = data.LastName;
            var email = data.Email;
            var mobileNo = data.MobileNo;
            if (facilityId == null || facilityId == '') {
                $scope.FacilityId = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (firstName == null || firstName == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (lastName == null || lastName == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (email == null || email == '') {
                $scope.Email = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (mobileNo == null || mobileNo == '') {
                $scope.MobileNo = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddNewPhysicalTherapist = {
                    FacilityId: facilityId, FirstName: firstName, LastName: lastName, Email: email, MobileNo: mobileNo
                }
                $http({
                    method: 'POST',
                    url: '/Admin/NewPhysicalTherapist',
                    data: AddNewPhysicalTherapist
                }).success(function (data) {
                    $scope.PhysicalTherapist = '';
                    var SuccessId = data;
                    if (SuccessId == 1) {
                        alert('New Physicain Added Successfully!');
                        location.href = '/Home/DashBoard';
                    }
                    else if (SuccessId == 0) {
                        location.href = '/Admin/NewPhysicalTherapist';
                    }
                    else if (SuccessId == -1) {
                        location.href = '/Account/LogOut';
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }
    }
}]);

app.controller('NewInjectionController', ['$scope', '$http', function ($scope, $http) {
    $scope.Injection = {}
    GetPhysicianList();
    function GetPhysicianList() {
        $http({
            method: 'Get',
            url: '/admin/GetPhysicianList'
        }).success(function (data, status, headers, config) {
            $scope.GetPhysicianList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetPhysicalTherapistList();
    function GetPhysicalTherapistList() {
        $http({
            method: 'Get',
            url: '/admin/GetPhysicalTherapistList'
        }).success(function (data, status, headers, config) {
            $scope.GetPhysicalTherapistList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetPhysicalTherapyDetail();
    function GetPhysicalTherapyDetail() {
        $http({
            method: 'Get',
            url: '/admin/GetPhysicalTherapyDetail'
        }).success(function (data, status, headers, config) {
            $scope.Injection = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails) {
        $scope.Email = false;
        $scope.MobileNo = false;
        AddNewInjection(alldetails);
        function AddNewInjection(data) {
            var GetErrors = '';
            var patientId = data.PatientId;
            var physicianName = data.PhysicianId;
            var phy_TherapistName = data.PhysicalTherapistId;
            var phy_Therapy = data.Phy_Therapy;
            var knee = data.Knee;
            var phy_Therapy_date = data.LastName;
            var ageOnDate = data.AgeOnDate;
            $('.errorMsg').remove();
            if (knee == null || knee == '') {
                $('#knee').append('<div class="errorMsg" style="color:red">Please Select Knee</div>');
                GetErrors += '1' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddNewInjection = {
                    PatientId: patientId, PhysicianName: physicianName, Phy_TherapistName: phy_TherapistName, Phy_Therapy: phy_Therapy, Knee: knee, Phy_Therapy_date: phy_Therapy_date, AgeOnDate: ageOnDate
                }
                $http({
                    method: 'POST',
                    url: '/admin/NewInjection',
                    data: AddNewInjection
                }).success(function (data) {
                    $scope.Injection = '';
                    alert('Injection Detail Saved!');
                    location.href = '/Home/DashBoard';
                });
            }
            else {
                //alert(GetErrors);
            }
        }
    }
}]);

app.controller('ReferralController', ['$scope', '$http', function ($scope, $http) {
    $scope.onsubmit = function (alldetails) {
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $scope.Name = false;
            //$scope.Description = false;
            var GetErrors = '';
            var name = data.Name;
            var description = data.Description;
            if (name == null || name == '') {
                $scope.Name = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            //if (description == null || description == '') {
            //    $scope.Description = { color: 'red' };
            //    GetErrors += '2' + '\n';
            //}    
            if (GetErrors == null || GetErrors == '') {
                var AddReferralModule = { Name: name, Description: description }
                $http({
                    method: 'POST',
                    url: '/Admin/CreateReferral',
                    data: AddReferralModule
                }).success(function (data) {
                    var SuccessId = data;
                    var FormId = JSON.parse(data);
                    if (SuccessId == "\"0\"") {
                        alert('Duplicate Referral Name!');
                    }
                    else if (SuccessId == "\"-1\"") {
                        location.href = '/Account/LogOut';
                    }
                    else if (SuccessId == "\"-2\"") {
                        alert('Operation Not Executed Please Check Properly!');
                    }
                    else {
                        if (confirm("New Referral Added Successfully! \n Do you want to add Another New Referral?") == true) {
                            $scope.UserRoleType = '';
                        } else {
                            location.href = '/Admin/ReferralList?FormId=' + FormId;
                        }
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }
    }
}]);

app.controller('UpdateReferralDetail', ['$scope', '$http', function ($scope, $http) {
    $scope.Referral = {}
    GetUpdateReferral();
    function GetUpdateReferral() {
        $http({
            method: 'get',
            url: '/Admin/GetUpdateReferral'
        }).success(function (data, status, headers, config) {
            $scope.Referral = data
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails, ButtonType) {
        $scope.Name = false;
        //$scope.Description = false;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            var GetErrors = '';
            var buttonType = ButtonType;
            var name = data.Name;
            var description = data.Description;
            if (name == null || name == '') {
                $scope.Name = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            //if (description == null || description == '') {
            //    $scope.Description = { color: 'red' };
            //    GetErrors += '2' + '\n';
            //}    
            var ErrorMessage = null;
            if (buttonType == 1) {
                ErrorMessage = 'Please Click Ok to Confirm the Changes!'
            }
            else if (buttonType == 2) {
                ErrorMessage = 'Please Click Ok to Confirm the Delete!'
            }
            if (GetErrors == null || GetErrors == '') {
                if (confirm(ErrorMessage) == true) {
                    var AddReferralModule = {
                        Name: name, Description: description, ButtonType: buttonType
                    }
                    $http({
                        method: 'POST',
                        url: '/Admin/UpdateReferral',
                        data: AddReferralModule
                    }).success(function (data) {
                        var SuccessId = data;
                        var FormId = JSON.parse(data);
                        if (SuccessId == "\"0\"") {
                            alert('Operation Not Executed Please Check Properly!');
                        }
                        else if (SuccessId == "\"-1\"") {
                            location.href = '/Account/LogOut';
                        }
                        else if (SuccessId == "\"-2\"") {
                            alert('Operation Not Executed Please Check Properly!');
                        }
                        else {
                            $scope.Referral = '';
                            location.href = '/Admin/ReferralList?FormId=' + FormId;
                        }
                    });
                } else {
                }
            }
            else {
                //alert(GetErrors);
            }
        }
    }
}]);

app.controller('NewCompliantController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.NewComplaint = {}
    GetUserDetail();
    function GetUserDetail() {
        $http({
            method: 'Get',
            url: '/Admin/GetPatientDetail'
        }).success(function (data, status, headers, config) {
            document.getElementById("PatientName").value = data.FirstName + " " + data.LastName;
            if (data.Gender == "Male") {
                document.getElementById("FrontImage").src = "../Content/images/MaleFronthalfcuts/male_silhouette.png";
                document.getElementById("FrontImage").useMap = "#FrontMaleBody";
                document.getElementById("myImage").src = "../Content/images/MaleBack/male_silhouette_back.png";
                document.getElementById("myImage").useMap = "#BackMaleBody";
            }
            else if (data.Gender == "Female") {
                document.getElementById("FrontImage").src = "../Content/images/FemaleFronthalfcuts/female_silhouette.png";
                document.getElementById("FrontImage").useMap = "#FrontFemaleBody";
                document.getElementById("myImage").src = "../Content/images/FemaleBackhalfcuts/female_back_silhouette.png";
                document.getElementById("myImage").useMap = "#BackFemaleBody";
            }
            //$scope.Patientmodel = data         
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onsubmit = function (alldetails) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $("#divLoading").show();
            var GetErrors = '';
            var PatientId = data.PatientId;
            var NewComplaintId = data.NewComplaintId;
            var NewInjuryDate = data.NewInjuryDate;
            var Cause = document.getElementById("Cause").value;
            var NewInjuryDescription = data.NewInjuryDescription;
            var LastCheckUp = data.LastCheckUp;
            var LastCheckUpDetail = data.LastCheckUpDetail;
            var FrontPainArea = document.getElementById("NewComplaint.FrontPainArea").value;
            var BackPainArea = document.getElementById("NewComplaint.BackPainArea").value;
            var PainScale = data.PainScale;
            var PainDescription = document.getElementById("PainDescription").value;
            var CurrentMobility = data.CurrentMobility;
            var CurrentEmployeement = data.CurrentEmployeement;
            var WokingStatus = data.WokingStatus;
            var LastFullDayWork = data.LastFullDayWork;
            if (GetErrors == null || GetErrors == '') {
                var NewCompliant = {
                    PatientId: PatientId, NewComplaintId: NewComplaintId, NewInjuryDate: NewInjuryDate, Cause: Cause, NewInjuryDescription: NewInjuryDescription,
                    LastCheckUp: LastCheckUp, LastCheckUpDetail: LastCheckUpDetail, FrontPainArea: FrontPainArea, BackPainArea: BackPainArea, PainScale: PainScale,
                    PainDescription: PainDescription, CurrentMobility: CurrentMobility, CurrentEmployeement: CurrentEmployeement, WokingStatus: WokingStatus, LastFullDayWork: LastFullDayWork
                }
                $http({
                    method: 'POST',
                    url: '/Admin/NewCompliant',
                    data: NewCompliant
                }).success(function (data) {
                    $("#divLoading").hide();
                });
            }
            else {
                $("#divLoading").hide();
            }
        }
    }
}]); 