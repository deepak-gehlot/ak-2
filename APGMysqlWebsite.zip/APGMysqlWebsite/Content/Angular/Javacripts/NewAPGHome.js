﻿//Loginjs
var app = angular.module("myAdmin", []);

app.controller('NewPatientRegistration', ['$scope', '$http', function ($scope, $http) {
    $scope.Patientmodel = {}
    $scope.submitted = false;

    GetFailictyList();
    function GetFailictyList() {
        $http({
            method: 'Get',
            url: '/admin/GetFailictyList'
        }).success(function (data, status, headers, config) {
            $scope.GetFailictyList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetEthnicityList();
    function GetEthnicityList() {
        $http({
            method: 'Get',
            url: '/Patient/GetEthnicityList'
        }).success(function (data, status, headers, config) {
            $scope.GetEthnicityList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onLostFocusUserId = function (Email) {
        CheckUserIdExist(Email);
        function CheckUserIdExist(data) {
            var GetErrors = '';
            $('.errorMsg').remove();
            if (data != null || data != undefined) {
                if (data.match("@") || data.match(" ")) {
                    $('#UserNameId').append('<div class="errorMsg" style="color:red">In User Id @ and Blanked Spcace is not Allowed!</div>');
                    document.getElementById("UserNameIdAvailable").value = "-1";
                }
                else if (data != '') {
                    $http({
                        method: 'Get',
                        url: '/NewHome/GetUserNameIdExist?UserNameId=' + data
                    }).success(function (Success, status, headers, config) {
                        if (Success == 1) {
                            document.getElementById("UserNameIdAvailable").value = "1";
                        }
                        else {
                            $('#UserNameId').append('<div class="errorMsg" style="color:red">This User Id Already Exist!</div>');
                            document.getElementById("UserNameIdAvailable").value = "0";
                        }
                    }).error(function (data, status, headers, config) {
                        $scope.message = 'Unexpected Error';
                    });
                }
            }
        }
    }

    $scope.onLostFocusEmail = function (Email) {
        CheckEmailExist(Email);
        function CheckEmailExist(data) {
            var GetErrors = '';
            $('.errorMsg').remove();
            if (data != null || data != undefined) {
                if (data != '') {
                    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                    if (!re.test(data)) {
                        $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                        document.getElementById("EmailAvailable").value = "-1";
                    }
                    else {
                        $http({
                            method: 'Get',
                            url: '/NewHome/GetEmailExist?EmailId=' + data
                        }).success(function (Success, status, headers, config) {
                            if (Success == 1) {
                                document.getElementById("EmailAvailable").value = "1";
                            }
                            else {
                                $('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId Already Register Please Use Different EmailId</div>');
                                document.getElementById("EmailAvailable").value = "0";
                            }
                        }).error(function (data, status, headers, config) {
                            $scope.message = 'Unexpected Error';
                        });
                    }
                }
            }
        }
    }

    $scope.onsubmit = function (alldetails, ButtonType) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $("#divLoading").show();
            $scope.Validation = false;
            $scope.FacilityId = false;
            $scope.UserNameId = false;
            $scope.FirstName = false;
            $scope.LastName = false;
            $scope.DOB = false;
            $scope.Gender = false;
            $scope.Height = false;
            $scope.Weight = false;
            $scope.Ethnicity = false;
            $scope.PIN = false;
            $scope.PINLength = false;
            $scope.PrimaryContactNo = false;
            $scope.SocSec = false;
            $scope.Email = false;
            $scope.Password = false;
            $scope.PasswordLength = false;
            $scope.Confirmpwd = false;
            $scope.MatchPassword = false;
            var GetErrors = '';
            var buttonType = ButtonType;
            var facilityId = data.FacilityId;
            var userNameId = data.UserNameId;
            var firstName = data.FirstName;
            var lastname = data.LastName;
            var dOB = document.getElementById("datepicker").value;
            var gender = data.Gender;
            var email = data.Email;
            var pin = data.PIN;
            var password = data.Password;
            var confirmpwd = data.Confirmpwd;
            var heightFeet = data.HeightFeet;
            var heightInch = data.HeightInch;
            var height = data.Height;
            var weight = data.Weight;
            var primaryContactNo = data.PrimaryContactNo;
            var socSec = data.SocSec;
            var ethnicityId = data.EthnicityId;
            $('.errorMsg').remove();
            if (document.getElementById("UserNameIdAvailable").value == "0") {
                $('#UserNameId').append('<div class="errorMsg" style="color:red">This User Id Already Exist!</div>');
                GetErrors += '1' + '\n';
            }
            if (document.getElementById("UserNameIdAvailable").value == "-1") {
                $('#UserNameId').append('<div class="errorMsg" style="color:red">In User Id @ and Blanked Spcace is not Allowed!</div>');
                GetErrors += '2' + '\n';
            }
            if (document.getElementById("EmailAvailable").value == "0") {
                $('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId Already Register Please Use Different EmailId</div>');
                GetErrors += '3' + '\n';
            }
            if (document.getElementById("EmailAvailable").value == "-1") {
                $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                GetErrors += '4' + '\n';
            }
            if ((userNameId == null || userNameId == '') && (email == null || email == '')) {
                alert("UserId or Email-Address any single one Is Required For Registration!");
                GetErrors += '5' + '\n';
            }
            if (facilityId == null || facilityId == '') {
                $scope.FacilityId = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (firstName == null || firstName == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '6' + '\n';
            }
            if (lastname == null || lastname == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '7' + '\n';
            }
            if (dOB == null || dOB == '') {
                $scope.DOB = { color: 'red' };
                GetErrors += '8' + '\n';
            }
            var today = new Date();
            if (new Date(dOB).getTime() > today) {
                $('#Dateob').append('<div class="errorMsg" style="color:red">date of birth should not be future date</div>');
                $scope.DOB = { color: 'red' };
                GetErrors += '8' + '\n';
            }
            if (gender == null || gender == '') {
                $scope.Gender = { color: 'red' };
                GetErrors += '9' + '\n';
            }
            if (height == null || height == '') {
                $scope.Height = { color: 'red' };
                GetErrors += '10' + '\n';
            }
            if (height > 100 || height < 24) {
                $('#Height').append('<div class="errorMsg" style="color:red">Invalid Height</div>');
                GetErrors += '11' + '\n';
            }
            if (weight == null || weight == '') {
                $scope.Weight = { color: 'red' };
                GetErrors += '12' + '\n';
            }
            if (ethnicityId == null || ethnicityId == '') {
                $scope.Ethnicity = { color: 'red' };
                GetErrors += '13' + '\n';
            }
            if (pin == null || pin == '') {
                $scope.PIN = { color: 'red' };
                GetErrors += '14' + '\n';
            }
            if (pin != null && pin != '' && pin.length != 4) {
                $('#PINLength').append('<div class="errorMsg" style="color:red">Pin No Lenght Must be 4 Digit</div>');
                GetErrors += '15' + '\n';
            }
            if (password == null || password == '') {
                $scope.Password = { color: 'red' };
                GetErrors += '16' + '\n';
            }
            if (password != null && password != '' && password.length < 8) {
                $('#PwdLength').append('<div class="errorMsg" style="color:red">Password Lenght must be Minimum 8 character</div>');
                GetErrors += '17' + '\n';
            }
            if (confirmpwd == null || confirmpwd == '') {
                $scope.Confirmpwd = { color: 'red' };
                GetErrors += '18' + '\n';
            }
            if (password != confirmpwd) {
                $('#MatchPassword').append('<div class="errorMsg" style="color:red">Password and Confirm Password not Mached</div>');
                GetErrors += '19' + '\n';
            }
            if (primaryContactNo == null || primaryContactNo == '') {
                $scope.PrimaryContactNo = { color: 'red' };
                GetErrors += '20' + '\n';
            }
            if (primaryContactNo != null || primaryContactNo != undefined) {
                var re = /^\(?[(. ]{1}\)?([0-9]{3})?[). ]{1}?([0-9]{3})?[-. ]{1}?([0-9]{4})$/;
                if (!re.test(primaryContactNo)) {
                    $('#PrimaryContactNo').append('<div class="errorMsg" style="color:red">Format is not valid</div>');
                    GetErrors += '21' + '\n';
                }
            }
            if (socSec == null || socSec == '') {
                $scope.SocSec = { color: 'red' };
                GetErrors += '22' + '\n';
            }
            if (socSec != null || socSec != undefined) {
                var re = /^\ ?([0-9]{3})?[-. ]?([0-9]{2})[-. ]?([0-9]{4})$/;
                if (!re.test(socSec)) {
                    $('#SocSecNo').append('<div class="errorMsg" style="color:red">Format is not valid</div>');
                    GetErrors += '23' + '\n';
                }
            }
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = {
                    FacilityId: facilityId, UserNameId: userNameId, FirstName: firstName, LastName: lastname, DOB: dOB, Gender: gender, Height: height,
                    Weight: weight, Email: email, PIN: pin, Password: password, PrimaryContactNo: primaryContactNo, SocSec: socSec, EthnicityId: ethnicityId
                }
                $http({
                    method: 'POST',
                    url: '/NewHome/PatientRegistration',
                    data: AddPatientModule
                }).success(function (data) {
                    $("#divLoading").hide();
                    $scope.ABC = data;
                    var Con = data;
                    console.log(data)
                    if (Con == null || Con == "\"1\"") {
                        method: 'get',
                        location.href = '/Patient/ThankYou';
                        alert('Register Successfully !');
                        data: AddPatientModule
                    }
                    else if (Con == null || Con == "\"2\"") {
                            method: 'get',
                            location.href = '/Patient/ThankYou';
                        alert('Register Successfully');
                        data: AddPatientModule
                    }
                    else if ($scope.ABC == "\"3\"") {
                        alert('This UserName/Email-id is already Registered!. Please enter different UserName/Email-id');
                    }
                }).error(function (serverResponse, status, headers, config) {
                    $scope.Patientmodel = '';
                    $("#divLoading").hide();
                });
            }
            else {
                $("#divLoading").hide();
                $scope.Validation = true;
            }
        }
    }
}]);

app.controller('NewUserLogin', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.Patientmodel = {}
    $scope.onsubmit2 = function (data) {
        $("#divLoading").show();
        console.log(data);
        $scope.submitted = true;
        $scope.LoginEmail = false;
        $scope.LoginPassword = false;
        var UserType = '';
        var GetErrors = '';
        var email = data.LoginEmail;
        var password = data.LoginPassword;
        $('.errorMsg').remove();
        //if (email != null || email != undefined) {
        //    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        //    if (!re.test(email)) {
        //        $('#EmailId2').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
        //        GetErrors += '1' + '\n';
        //    }
        //}
        if (email == null || email == '') {
            $scope.LoginEmail = { color: 'red' };
            GetErrors += '2' + '\n';
        }
        if (password == null || password == '') {
            $scope.LoginPassword = { color: 'red' };
            GetErrors += '3' + '\n';
        }
        if (GetErrors == null || GetErrors == '') {
            var AddPatientModule = { Emailaddress: email, Password: password }
            $http({
                method: 'POST',
                url: '/NewHome/index',
                data: AddPatientModule
            })
                .success(function (data, status, headers, config) {
                    UserType = data;
                    if (UserType == "\"SuccessUser\"") {
                        location.href = '/Home/DashBoard';
                    }
                    else if (UserType == "\"SuccessPatient\"") {
                        location.href = '/Patient/PatientDashboard';
                    }
                    else if (UserType == "\"unsuccess\"") {
                        $scope.Patientmodel = '';
                        $("#divLoading").hide();
                        alert("Invalid Email-id or Password!");
                    }
                }).error(function (serverResponse, status, headers, config) {
                    $scope.Patientmodel = '';
                    $("#divLoading").hide();
                    alert("Invalid Email-id or Password!");
                }
                );
        } else {
            $("#divLoading").hide();
        }
    };
}]);

app.controller('Patientregistercontroller', ['$scope', '$http', function ($scope, $http) {
    $scope.xyz = 'Error';
    $scope.submitted = false;
    $scope.Patientmodel = {}
    $scope.onsubmit = function (alldetails) {
        $("#divLoading").show();
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $scope.FirstName = false;
            $scope.LastName = false;
            $scope.Email = false;
            $scope.Password = false;
            $scope.PasswordLength = false;
            $scope.Confirmpwd = false;
            $scope.MatchPassword = false;
            var GetErrors = '';
            var firstname = data.Firstname;
            var lastname = data.Lastname;
            var email = data.Email;
            var password = data.Password;
            var confirmpwd = data.Confirmpwd;
            $('.errorMsg').remove();
            if (firstname == null || firstname == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (lastname == null || lastname == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (email != null || email != undefined) {
                var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                if (!re.test(email)) {
                    $('#EmailId1').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                    GetErrors += '3' + '\n';
                }
            }
            if (email == null || email == '') {
                $scope.Email = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (password == null || password == '') {
                $scope.Password = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (confirmpwd == null || confirmpwd == '') {
                $scope.Confirmpwd = { color: 'red' };
                GetErrors += '6' + '\n';
            }
            if (password != null && password != undefined && password.length < 8) {
                $('#PwdLength').append('<div class="errorMsg" style="color:red">Password Lenght must be Minimum 8 character</div>');
                GetErrors += '7' + '\n';
            }
            if (password != confirmpwd) {
                $('#MatchPassword').append('<div class="errorMsg" style="color:red">Password and Confirm Password Should be Same</div>');
                GetErrors += '7' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = { Firstname: firstname, Lastname: lastname, Email: email, Password: password }
                $http({
                    method: 'POST',
                    url: '/Patient/Register',
                    data: AddPatientModule
                }).success(function (data) {
                    $("#divLoading").hide();
                    $scope.ABC = data;
                    var Con = data;
                    console.log(data)
                    if (Con == null || Con == '') {
                        method: 'get',
                        location.href = '/Patient/ThankYou';
                        alert('Register Successfully ! Please check your E-mail');
                        data: AddPatientModule
                    }
                    else if ($scope.ABC == "\"Error\"") {
                        location.href = '/Home/Index';
                        alert('This Email-id is already Registered!. Please enter different Email-id');
                    }
                }).error(function (serverResponse, status, headers, config) {
                    $scope.Patientmodel = '';
                    $("#divLoading").hide();
                });
            }
            else {
                $("#divLoading").hide();
                //alert(GetErrors);
            }
        }
    }
}]);

app.controller('UserLogin', ['$scope', '$http', function ($scope, $http) {
    alert();
    $scope.submitted = false;
    $scope.Patientmodel = {}
    $scope.onsubmit2 = function (data) {
        $("#divLoading").show();
        console.log(data);
        $scope.submitted = true;
        $scope.LoginEmail = false;
        $scope.LoginPassword = false;
        var UserType = '';
        var GetErrors = '';
        var email = data.LoginEmail;
        var password = data.LoginPassword;
        $('.errorMsg').remove();
        if (email != null || email != undefined) {
            var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            if (!re.test(email)) {
                $('#EmailId2').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                GetErrors += '1' + '\n';
            }
        }
        if (email == null || email == '') {
            $scope.LoginEmail = { color: 'red' };
            GetErrors += '2' + '\n';
        }
        if (password == null || password == '') {
            $scope.LoginPassword = { color: 'red' };
            GetErrors += '3' + '\n';
        }
        if (GetErrors == null || GetErrors == '') {
            var AddPatientModule = { Emailaddress: email, Password: password }
            $http({
                method: 'POST',
                url: '/NewHome/index',
                data: AddPatientModule
            })
                .success(function (data, status, headers, config) {
                    UserType = data;
                    alert(data);
                    if (UserType == "\"SuccessUser\"") {
                        location.href = '/Home/DashBoard';
                    }
                    else if (UserType == "\"SuccessPatient\"") {
                        location.href = '/Patient/PatientDashboard';
                    }
                }).error(function (serverResponse, status, headers, config) {
                    $scope.Patientmodel = '';
                    $("#divLoading").hide();
                    alert("Invalid Email-id or Password!");
                }
                );
        } else {
            $("#divLoading").hide();
        }
    };
}]);

