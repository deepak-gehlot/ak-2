﻿var app = angular.module("myapp", []);
app.controller('PatientRegistrationDetailcontroller', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    GetEducationList();
    function GetEducationList() {
        $http({
            method: 'Get',
            url: '/Patient/GetEducationList'
        }).success(function (data, status, headers, config) {
            $scope.GetEducationList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetEthnicityList();
    function GetEthnicityList() {
        $http({
            method: 'Get',
            url: '/Patient/GetEthnicityList'
        }).success(function (data, status, headers, config) {
            $scope.GetEthnicityList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetFailictyList();
    function GetFailictyList() {
        $http({
            method: 'Get',
            url: '/admin/GetFailictyList'
        }).success(function (data, status, headers, config) {
            $scope.GetFailictyList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetStateList();
    function GetStateList() {
        $http({
            method: 'Get',
            url: '/admin/GetStateList'
        }).success(function (data, status, headers, config) {
            $scope.GetStateList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetUserDetail();
    function GetUserDetail() {
        $http({
            method: 'Get',
            url: '/Patient/GetUserDetail'
        }).success(function (data, status, headers, config) {
            $scope.Patientmodel = data
            if (data.Email == "" || data.Email == null) {
                $scope.truefalse = false;
            }
            else {
                $scope.truefalse = true;
            }
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    $scope.onLostFocus = function (Email) {
        if ($scope.truefalse == false) {
            CheckEmailExist(Email);
        }
        function CheckEmailExist(data) {
            var GetErrors = '';
            $('.errorMsg').remove();
            if (data != null || data != undefined) {
                if (data != '') {
                    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                    if (!re.test(data)) {
                        $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                        document.getElementById("EmailAvailable").value = "-1";
                    }
                    else {
                        $http({
                            method: 'Get',
                            url: '/NewHome/GetEmailExist?EmailId=' + data
                        }).success(function (Success, status, headers, config) {
                            if (Success == 1) {
                                // $scope.truefalse = true;
                                document.getElementById("EmailAvailable").value = "1";
                            }
                            else {
                                $('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId Already Register Please Use Different EmailId</div>');
                                document.getElementById("EmailAvailable").value = "0";
                            }
                        }).error(function (data, status, headers, config) {
                            $scope.message = 'Unexpected Error';
                        });
                    }
                }
            }
        }
    }

    $scope.onsubmit = function (alldetails, ButtonType) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            //$("#divLoading").show();
            $scope.Validation = false;
            $scope.FacilityId = false;
            $scope.FirstName = false;
            $scope.LastName = false;
            $scope.DOB = false;
            $scope.Gender = false;
            $scope.Height = false;
            $scope.Weight = false;
            $scope.Ethnicity = false;
            $scope.PIN = false;
            $scope.PINLength = false;
            $scope.PrimaryContactNo = false;
            $scope.SocSec = false;
            $scope.EducationId = false;
            $scope.WorkType = false;
            var GetErrors = '';
            var buttonType = ButtonType;
            var userNameId = data.UserNameId;
            var patientId = data.PatientId;
            var facilityId = data.FacilityId;
            var firstName = data.FirstName;
            var lastname = data.LastName;
            var nickName = data.NickName;
            var dOB = document.getElementById("datepicker").value;
            var gender = data.Gender;
            var street = data.Street;
            var city = data.City;
            var state = data.State;
            var zipCode = data.ZipCode;
            var email = data.Email;
            var pin = data.PIN;
            var heightFeet = data.HeightFeet;
            var heightInch = data.HeightInch;
            var height = data.Height;
            var weight = data.Weight;
            var primaryContactNo = data.PrimaryContactNo;
            var additionalContactNo = data.AdditionalContactNo;
            var socSec = data.SocSec;
            var educationId = data.EducationId;
            var occupation = data.Occupation;
            var workType = data.WorkType;
            var employer = data.Employer;
            var workPhone = data.WorkPhone;
            var contactAtWork = data.ContactAtWork
            var employerStreet = data.EmployerStreet;
            var employerCity = data.EmployerCity;
            var employerState = data.EmployerState;
            var employerZipCode = data.EmployerZipCode;
            var howKnowAboutUs = data.HowKnowAboutUs;
            var mCity = data.MCity;
            var mState = data.MState;
            var mZipCode = data.MZipCode;
            var referral = '';
            if (howKnowAboutUs == 'referral') {
                referral = data.Referral;
            }
            var currentlyHaveCP = data.CurrentlyHaveCP;
            var cPName = '';
            if (currentlyHaveCP == 'True') {
                cPName = data.CPName;
            }
            var currentlyHavePCP = data.CurrentlyHavePCP;
            var pCPName = '';
            if (currentlyHavePCP == 'True') {
                pCPName = data.PCPName;
            }
            var mailingAddress = data.MailingAddress;
            var ethnicityId = data.EthnicityId;
            $('.errorMsg').remove();
            if (document.getElementById("EmailAvailable").value == "0") {
                $('#EmailId').append('<div class="errorMsg" style="color:red">This EmailId Already Register Please Use Different EmailId</div>');
                alert("Email Id already Exist!");
                GetErrors += '1' + '\n';
            }
            if (document.getElementById("EmailAvailable").value == "-1") {
                $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                GetErrors += '1' + '\n';
            }
            if (patientId == null || patientId == '') {
                GetErrors += '1' + '\n';
            }
            if (facilityId == null || facilityId == '') {
                $scope.FacilityId = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (firstName == null || firstName == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (lastname == null || lastname == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (dOB == null || dOB == '') {
                $scope.DOB = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            var today = new Date();
            if (new Date(dOB).getTime() > today) {
                $('#Dateob').append('<div class="errorMsg" style="color:red">date of birth should not be future date</div>');
                $scope.DOB = { color: 'red' };
                GetErrors += '8' + '\n';
            }
            if (gender == null || gender == '') {
                $scope.Gender = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (height == null || height == '') {
                $scope.Height = { color: 'red' };
                GetErrors += '6' + '\n';
            }
            if (height > 100 || height < 24) {
                $('#Height').append('<div class="errorMsg" style="color:red">Invalid Height</div>');
                GetErrors += '7' + '\n';
            }
            if (weight == null || weight == '') {
                $scope.Weight = { color: 'red' };
                GetErrors += '10' + '\n';
            }
            if (ethnicityId == null || ethnicityId == '') {
                $scope.Ethnicity = { color: 'red' };
                GetErrors += '11' + '\n';
            }
            if (pin == null || pin == '') {
                $scope.PIN = { color: 'red' };
                GetErrors += '12' + '\n';
            }
            if (pin != null && pin != '' && pin.length != 4) {
                $('#PINLength').append('<div class="errorMsg" style="color:red">Pin No Lenght Must be 4 Digit</div>');
                GetErrors += '13' + '\n';
            }
            if (primaryContactNo == null || primaryContactNo == '') {
                $scope.PrimaryContactNo = { color: 'red' };
                GetErrors += '14' + '\n';
            }
            if (socSec == null || socSec == '') {
                $scope.SocSec = { color: 'red' };
                GetErrors += '15' + '\n';
            }
            if (workType == null || workType == '') {
                $scope.WorkType = { color: 'red' };
                GetErrors += '10' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = {
                    UserNameId: userNameId, PatientId: patientId, FirstName: firstName, LastName: lastname, NickName: nickName, DOB: dOB, Gender: gender, Street: street, City: city, State: state, ZipCode: zipCode, Email: email, PIN: pin,
                    HeightFeet: heightFeet, HeightInch: heightInch, Height: height, Weight: weight, PrimaryContactNo: primaryContactNo, AdditionalContactNo: additionalContactNo, SocSec: socSec,
                    EducationId: educationId, Occupation: occupation, WorkType: workType, Employer: employer, WorkPhone: workPhone, ContactAtWork: contactAtWork, EmployerStreet: employerStreet,
                    EmployerCity: employerCity, EmployerState: employerState, EmployerZipCode: employerZipCode, HowKnowAboutUs: howKnowAboutUs, CurrentlyHaveCP: currentlyHaveCP, CPName: cPName,
                    CurrentlyHavePCP: currentlyHavePCP, PCPName: pCPName, MailingAddress: mailingAddress, EthnicityId: ethnicityId, FacilityId: facilityId, Referral: referral,
                    MCity: mCity, MState: mState, MZipCode: mZipCode
                }
                $http({
                    method: 'POST',
                    url: '/Patient/PatientRegistrationDetail',
                    data: AddPatientModule
                }).success(function (data) {
                    $("#divLoading").hide();
                    UserType = data;
                    if (buttonType == 1) {
                        if (UserType == "\"-1\"") {
                            location.href = '/Account/LogOut';
                        }
                        else if (UserType == "\"1\"") {
                            alert("Registration Detail Updated Successfully!");
                        }
                        else if (UserType == "\"0\"") {
                            alert('Operation Not Executed Please Check Properly!');
                        }
                    }
                    else if (buttonType == 2) {
                        location.href = '/Patient/PatientInsuranceOne';
                    }
                });
            }
            else {
                $("#divLoading").hide();
                $scope.Validation = true;
            }
        }
    }
}]);

app.controller('PasswordResetController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.Patientmodel = {}
    $scope.onsubmit = function (alldetails) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $scope.Email = false;
            $scope.OldPassword = false;
            $scope.Password = false;
            $scope.Confirmpwd = false;
            $scope.PasswordLength = false;
            $scope.MatchPassword = false;
            var GetErrors = '';
            var userNameId = document.getElementById("UserNameId").value;
            var email = document.getElementById("Email").value;
            var oldPassword = data.OldPassword;
            var password = data.Password;
            var confirmpwd = data.Confirmpwd;
            $('.errorMsg').remove();
            if ((userNameId == null || userNameId == '') && (email == null || email == '')) {
                $scope.Email = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (oldPassword == null || oldPassword == '') {
                $scope.OldPassword = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (password == null || password == '') {
                $scope.Password = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (confirmpwd == null || confirmpwd == '') {
                $scope.Confirmpwd = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (password != null && password != undefined && password.length < 8) {
                $('#PwdLength').append('<div class="errorMsg" style="color:red">Password Lenght must be Minimum 8 character</div>');
                GetErrors += '5' + '\n';
            }
            if (password != confirmpwd) {
                $('#MatchPassword').append('<div class="errorMsg" style="color:red">Password and Confirm Password Should be Same</div>');
                GetErrors += '6' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = { UserNameId: userNameId, Email: email, OldPassword: oldPassword, Password: password, Confirmpwd: confirmpwd }
                $http({
                    method: 'POST',
                    url: '/PatientPlatForm/PasswordReset',
                    data: AddPatientModule
                }).success(function (data) {
                    $scope.Patientmodel = '';
                    if (data == "\"0\"") {
                        alert('UserIdentifire or password not Match!');
                    }
                    else if (data == "\"1\"") {
                        alert('Password Reset Successfully!');
                        location.href = '/Patient/Index?param=Patient Platform Setting';
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }

    }
}]);

app.controller('PINResetController', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.Patientmodel = {}
    $scope.onsubmit = function (alldetails) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $scope.Email = false;
            $scope.Password = false;
            $scope.PIN = false;
            $scope.ConfirmPIN = false;
            $scope.PINLength = false;
            $scope.MatchPIN = false;
            var GetErrors = '';
            var userNameId = document.getElementById("UserNameId").value;
            var email = document.getElementById("Email").value;
            var password = data.Password;
            var pin = data.PIN;
            var confirmPIN = data.ConfirmPIN;
            $('.errorMsg').remove();
            if ((userNameId == null || userNameId == '') && (email == null || email == '')) {
                $scope.Email = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (password == null || password == '') {
                $scope.Password = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (pin == null || pin == '') {
                $scope.PIN = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (confirmPIN == null || confirmPIN == '') {
                $scope.ConfirmPIN = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (pin != null && pin != undefined && pin.length != 4) {
                $('#PINLength').append('<div class="errorMsg" style="color:red">New PIN No Length Must be 4 Digit</div>');
                GetErrors += '6' + '\n';
            }
            if (pin != confirmPIN) {
                $('#MatchPIN').append('<div class="errorMsg" style="color:red">New PIN and Confirm PIN should be same</div>');
                GetErrors += '7' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = { UserNameId: userNameId, Email: email, Password: password, PIN: pin, ConfirmPIN: confirmPIN }
                $http({
                    method: 'POST',
                    url: '/PatientPlatForm/PINReset',
                    data: AddPatientModule
                }).success(function (data) {
                    UserType = data;
                    if (UserType == "\"-1\"") {
                        location.href = '/Account/LogOut';
                    }
                    else if (UserType == "\"1\"") {
                        $scope.Patientmodel = '';
                        alert('PIN Reset Successfully!');
                        location.href = '/Patient/Index?param=Patient Platform Setting';
                    }
                    else if (UserType == "\"0\"") {
                        alert('UserIdentifire or password not Match!');
                    }
                });
            }
            else {
                //alert(GetErrors);
            }
        }

    }
}]);