﻿var app = angular.module("myAdmin", []);
//Delete UserLevel
app.controller('UserLevel', ['$scope', '$http', function ($scope, $http) {
    $scope.onsubmit = function (ButtonType, UserTypeId, UserType) {
        insertonsubmit(ButtonType);
        function insertonsubmit(data) {
            var buttonType = ButtonType;
            var userTypeId = UserTypeId;
            var userTypeName = UserType;
            if (buttonType == 2) {
                if (confirm("Please Click Ok to Confirm the Delete!") == true) {
                    var AddPatientModule = { ButtonType: buttonType, UserTypeId: userTypeId, UserTypeName: userTypeName }
                    $http({
                        method: 'POST',
                        url: '/Admin/UserLevel',
                        data: AddPatientModule
                    }).success(function (data) {
                        var FormId = data;
                        location.href = '/Admin/UserLevel?FormId=' + FormId;
                    });
                } else {
                }
            }
        }
    }
}]);

//Create New user Level
app.controller('UserRoleTypeController', ['$scope', '$http', function ($scope, $http) {
    $scope.UserRoleType = {}
    $scope.x = true;
    $scope.onsubmit = function (alldetails) {
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $scope.UserType = false;
            var GetErrors = '';
            var userType = data.UserType;
            $('.errorMsg').remove();
            if (userType == null || userType == '') {
                $scope.UserType = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddUserRoleType = { UserType: userType }
                if (confirm("Do you want to add New User Type?") == true) {
                    $http({
                        method: 'POST',
                        url: '/Admin/CreateUserLevel',
                        data: AddUserRoleType
                    }).success(function (data) {
                        var SuccessId = data;
                        var FormId = JSON.parse(data);
                        if (SuccessId == "\"0\"") {
                            alert('This User Type Already Exist!');
                        }
                        else if (SuccessId == "\"-1\"") {
                            location.href = '/Account/LogOut';
                        }
                        else if (SuccessId == "\"-2\"") {
                            alert('Operation Not Executed Please Check Properly!');
                        }
                        else {
                            if (confirm("New User Type Added Successfully! \n Do you want to add Another New User Type?") == true) {
                                $scope.UserRoleType = '';
                            } else {
                                location.href = '/Admin/UserLevel?FormId=' + FormId;
                            }
                        }
                    });
                } else {
                    location.href = '/Admin/CreateUserLevel';
                }
            }
            else {
                //alert(GetErrors);
            }
        }
    }
}]);