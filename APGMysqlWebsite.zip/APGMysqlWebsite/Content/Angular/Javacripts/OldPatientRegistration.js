﻿var app = angular.module("myapp", []);

app.controller('OldPatientRegistration', ['$scope', '$http', function ($scope, $http) {
    $scope.Patientmodel = {}
    $scope.submitted = false;
    //GetEducationList();
    //function GetEducationList() {
    //    $http({
    //        method: 'Get',
    //        url: '/Patient/GetEducationList'
    //    }).success(function (data, status, headers, config) {
    //        $scope.GetEducationList = data;
    //    }).error(function (data, status, headers, config) {
    //        $scope.message = 'Unexpected Error';
    //    });
    //};

    GetEthnicityList();
    function GetEthnicityList() {
        $http({
            method: 'Get',
            url: '/Patient/GetEthnicityList'
        }).success(function (data, status, headers, config) {
            $scope.GetEthnicityList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    //GetFailictyList();
    //function GetFailictyList() {
    //    $http({
    //        method: 'Get',
    //        url: '/admin/GetFailictyList'
    //    }).success(function (data, status, headers, config) {
    //        $scope.GetFailictyList = data;
    //    }).error(function (data, status, headers, config) {
    //        $scope.message = 'Unexpected Error';
    //    });
    //};

    //GetStateList();
    //function GetStateList() {
    //    $http({
    //        method: 'Get',
    //        url: '/admin/GetStateList'
    //    }).success(function (data, status, headers, config) {
    //        $scope.GetStateList = data;
    //    }).error(function (data, status, headers, config) {
    //        $scope.message = 'Unexpected Error';
    //    });
    //};

    //GetUserDetail();
    //function GetUserDetail() {
    //    $http({
    //        method: 'Get',
    //        url: '/Patient/GetUserDetail'
    //    }).success(function (data, status, headers, config) {
    //        $scope.Patientmodel = data
    //        console.log(data);
    //    }).error(function (data, status, headers, config) {
    //        $scope.message = 'Unexpected Error';
    //    });
    //};
    $scope.onsubmit = function (alldetails, ButtonType) {
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            // $("#divLoading").show();
            $scope.Validation = false;
            //$scope.FacilityId = false;
            $scope.FirstName = false;
            $scope.LastName = false;
            $scope.DOB = false;
            $scope.Gender = false;
            $scope.Height = false;
            $scope.Weight = false;
            $scope.Ethnicity = false;
            $scope.PIN = false;
            $scope.PINLength = false;
            $scope.PrimaryContactNo = false;
            $scope.SocSec = false;
            $scope.Email = false;
            $scope.Password = false;
            $scope.PasswordLength = false;
            $scope.Confirmpwd = false;
            $scope.MatchPassword = false;
            var GetErrors = '';
            var buttonType = ButtonType;
            //var facilityId = data.FacilityId;
            var firstName = data.FirstName;
            var lastname = data.LastName;
            var dOB = document.getElementById("datepicker").value;
            var gender = data.Gender;
            var email = data.Email;
            var pin = data.PIN;
            var password = data.Password;
            var confirmpwd = data.Confirmpwd;
            var heightFeet = data.HeightFeet;
            var heightInch = data.HeightInch;
            var height = data.Height;
            var weight = data.Weight;
            var primaryContactNo = data.PrimaryContactNo;
            var socSec = data.SocSec;
            var ethnicityId = data.EthnicityId;
            $('.errorMsg').remove();
            //if (facilityId == null || facilityId == '') {
            //    $scope.FacilityId = { color: 'red' };
            //    GetErrors += '1' + '\n';
            //}
            if (firstName == null || firstName == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (lastname == null || lastname == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '3' + '\n';
            }
            if (dOB == null || dOB == '') {
                $scope.DOB = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (gender == null || gender == '') {
                $scope.Gender = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (height == null || height == '') {
                $scope.Height = { color: 'red' };
                GetErrors += '6' + '\n';
            }
            if (height > 100 || height < 24) {
                $('#Height').append('<div class="errorMsg" style="color:red">Invalid Height</div>');
                GetErrors += '8' + '\n';
            }
            if (weight == null || weight == '') {
                $scope.Weight = { color: 'red' };
                GetErrors += '9' + '\n';
            }
            if (ethnicityId == null || ethnicityId == '') {
                $scope.Ethnicity = { color: 'red' };
                GetErrors += '10' + '\n';
            }
            if (pin == null || pin == '') {
                $scope.PIN = { color: 'red' };
                GetErrors += '11' + '\n';
            }
            if (pin != null && pin != '' && pin.length != 4) {
                $('#PINLength').append('<div class="errorMsg" style="color:red">Pin No Lenght Must be 4 Digit</div>');
                GetErrors += '12' + '\n';
            }

            if (email != null || email != '') {
                if (email != null || email != undefined) {
                    var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                    if (!re.test(email)) {
                        $('#EmailId').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                        GetErrors += '3' + '\n';
                    }
                }
            }

            //if (email == null || email == '') {
            //    $scope.Email = { color: 'red' };
            //    GetErrors += '5' + '\n';
            //}
            if (password == null || password == '') {
                $scope.Password = { color: 'red' };
                GetErrors += '13' + '\n';
            }
            if (password != null && password != '' && password.length < 8) {
                $('#PwdLength').append('<div class="errorMsg" style="color:red">Password Lenght must be Minimum 8 character</div>');
                GetErrors += '14' + '\n';
            }
            if (confirmpwd == null || confirmpwd == '') {
                $scope.Confirmpwd = { color: 'red' };
                GetErrors += '15' + '\n';
            }
            if (password != confirmpwd) {
                $('#MatchPassword').append('<div class="errorMsg" style="color:red">Password and Confirm Password not Mached</div>');
                GetErrors += '16' + '\n';
            }
            if (primaryContactNo == null || primaryContactNo == '') {
                $scope.PrimaryContactNo = { color: 'red' };
                GetErrors += '17' + '\n';
            }
            if (primaryContactNo != null || primaryContactNo != undefined) {
                var re = /^\(?[(. ]{1}\)?([0-9]{3})?[). ]{1}?([0-9]{3})?[-. ]{1}?([0-9]{4})$/;
                if (!re.test(primaryContactNo)) {
                    $('#PrimaryContactNo').append('<div class="errorMsg" style="color:red">Format is not valid</div>');
                    GetErrors += '18' + '\n';
                }
            }
            if (socSec == null || socSec == '') {
                $scope.SocSec = { color: 'red' };
                GetErrors += '19' + '\n';
            }
            if (socSec != null || socSec != undefined) {
                var re = /^\ ?([0-9]{3})?[-. ]?([0-9]{2})[-. ]?([0-9]{4})$/;
                if (!re.test(socSec)) {
                    $('#SocSecNo').append('<div class="errorMsg" style="color:red">Format is not valid</div>');
                    GetErrors += '20' + '\n';
                }
            }
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = {
                    FirstName: firstName, LastName: lastname, DOB: dOB, Gender: gender, Height: height, Weight: weight, Email: email, PIN: pin,
                    Password: password, PrimaryContactNo: primaryContactNo, SocSec: socSec, EthnicityId: ethnicityId
                }
                $http({
                    method: 'POST',
                    url: '/OldPatientRegistration/OldPatientRegistration',
                    data: AddPatientModule
                }).success(function () {
                    $("#divLoading").hide();
                    method: 'get',
                    location.href = '/Patient/ThankYou';
                    alert('Register Successfully !');
                    data: AddPatientModule
                });
            }
            else {
                $("#divLoading").hide();
                $scope.Validation = true;
            }
        }
    }
}]);
