'use strict';

var csvImport = angular.module('ngCsvImport', []);
csvImport.factory("XLSXReaderService", ['$q', '$rootScope',
       function ($q, $rootScope) {
           var service = function (data) {
               angular.extend(this, data);
           }

           service.readFile = function (file, readCells, toJSON) {
               var deferred = $q.defer();

               XLSXReader(file, readCells, toJSON, function (data) {
                   $rootScope.$apply(function () {
                       deferred.resolve(data);
                   });
               });

               return deferred.promise;
           }

           return service;
       }
]);

csvImport.directive('ngCsvImport', function ($rootScope, XLSXReaderService) {
   
	return {
		restrict: 'E',
		transclude: true,
		replace: true,
		scope:{
			content:'=?',
			header: '=?',
			headerVisible: '=?',
			separator: '=?',
			separatorVisible: '=?',
			result: '=?',
			encoding: '=?',
			encodingVisible: '=?',
			accept: '=?'
		},
		template: 
			'<div><input class="btn cta gray" type="file" multiple accept="{{accept}}"/>'
           +
           '</div>'+
			'{{result}}',

		link: function (scope, element) {
		    $rootScope.patientrecord = [];
			scope.separatorVisible = scope.separatorVisible || false;
			scope.headerVisible = scope.headerVisible || false;
			var fileExtension = {};
			angular.element(element[0].querySelector('.separator-input')).on('keyup', function(e) {
				if ( scope.content != null ) {
					var content = {
						csv: scope.content,
						header: scope.header,
						separator: e.target.value,
						encoding: scope.encoding
					};
					scope.result = csvToJSON(content);
					scope.$apply();
				}
			});

			element.on('change', function (onChangeEvent) {
			   
			  var reader = new FileReader();
				scope.filename = onChangeEvent.target.files[0].name;
				
				var selectedfile = scope.filename.split('.');
				fileExtension = selectedfile[1];
				if (fileExtension == 'csv') {
				    $("#divLoading").show();
				  //  alert("Please Wait..");
				    reader.onload = function (onLoadEvent) {
				        scope.$apply(function () {
				            var content = {
				                csv: onLoadEvent.target.result.replace(/\r\n|\r/g, '\n'),
				                header: scope.header,
				                separator: scope.separator
				            };
				            scope.content = content.csv;
				            scope.result = csvToJSON(content);
				            scope.result.filename = scope.filename;
				            console.log(scope.content);
				        });
				    };

				    if ((onChangeEvent.target.type === "file") && (onChangeEvent.target.files != null)) {

				        reader.readAsText(onChangeEvent.target.files[0], scope.encoding);
				    } else {
				        if (scope.content != null) {
				            var content = {
				                csv: scope.content,
				                header: !scope.header,
				                separator: scope.separator
				            };
				            scope.result = csvToJSON(content);
				        }
				    }
				    $("#divLoading").hide();
				}
				else if (fileExtension == 'xlsx') {
				    $("#divLoading").show();
				 //  alert("Please Wait..");
				    var alldata = [];
				     var sheets = [];
				     var excelFile = onChangeEvent.target.files[0];
				     var showPreview = true;
				     var showJSONPreview = true;
				    XLSXReaderService.readFile(excelFile, showPreview, showJSONPreview).then(function (xlsxData) {
				        
				        var sheets = xlsxData.sheets;
				        
				        angular.forEach(sheets, function (value) {
				           angular.forEach(value, function (value) {
				               alldata.push(value);
				            });
				        });
				      
				        //console.log(alldata.length);
				      
				      
				        $rootScope.patientrecord = alldata;
				      //  console.log(alldata);
				        $("#divLoading").hide();
				    });
				  
				    return alldata;
				}
				else {
				    alert("Only csv or xlsx file format are allowed.");
				   // $("#divLoading").hide();
				}
			});
            
			//if (fileExtension == 'csv') {
			    var csvToJSON = function (content) {
			        if (fileExtension == 'csv')
			        {
			           
			        var lines = content.csv.split('\n');
			        var result = [];
			        var start = 0;
			        var columnCount = lines[0].split(content.separator).length;

			        var headers = [];
			        if (content.header) {
			            headers = lines[0].split(content.separator);
			            start = 1;
			        }

			        for (var i = start; i < lines.length; i++) {
			            var obj = {};
			            var currentline = lines[i].split(new RegExp(content.separator + '(?![^"]*"(?:(?:[^"]*"){2})*[^"]*$)'));
			            if (currentline.length === columnCount) {
			                if (content.header) {
			                    for (var j = 0; j < headers.length; j++) {
			                        obj[headers[j]] = currentline[j];
			                    }
			                } else {
			                    for (var k = 0; k < currentline.length; k++) {
			                        obj[k] = currentline[k];
			                    }
			                }
			                result.push(obj);
			            }
			        }
			        var jsonresult = [];
			        var headerarray = [];
			        var valuearray = [];
			        var data = {};

			        for (var i = 0; i < result.length - 1; i++) {
			            if (i == 0) {
			                var tempresult = result[i][0]
			                headerarray = tempresult.split(';');
			            }
			            else {
			                var tempresult1 = result[i][0]
			                valuearray = tempresult1.split(';');
			                data = {};
			                for (j = 0; j < headerarray.length; j++) {
			                    data[headerarray[j]] = valuearray[j];
			                }
			                jsonresult.push(data);
			            }
			        }
			       // console.log(jsonresult);
			        $rootScope.patientrecord = jsonresult;
			        return jsonresult;
			    };
		    }
			
		}
	};
  
});