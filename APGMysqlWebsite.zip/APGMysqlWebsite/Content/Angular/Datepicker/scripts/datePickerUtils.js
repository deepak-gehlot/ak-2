﻿'use strict';

angular.module('datePicker').factory('datePickerUtils', function () {
    return {
        getVisibleMinutes: function (date, step) {
            date = new Date(date || new Date());
            date = new Date(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours());
            var minutes = [];
            var stop = date.getTime() + 60 * 60 * 1000;
            while (date.getTime() < stop) {
                minutes.push(date);
                date = new Date(date.getTime() + step * 60 * 1000);
            }
            return minutes;
        },
        getVisibleWeeks: function (date) {
            date = new Date(date || new Date());
            var startMonth = date.getMonth(), startYear = date.getYear();
            date.setDate(1);
            date.setHours(0);
            date.setMinutes(0);
            date.setSeconds(0);
            date.setMilliseconds(0);

            if (date.getDay() === 0) {
                date.setDate(-5);
            } else {
                date.setDate(date.getDate() - (date.getDay() - 1));
            }
            if (date.getDate() === 1) {
                date.setDate(-6);
            }

            var weeks = [];
            while (weeks.length < 6) {
                /*jshint -W116 */
                if (date.getYear() === startYear && date.getMonth() > startMonth) break;
                var week = [];
                for (var i = 0; i < 7; i++) {
                    week.push(new Date(date));
                    date.setDate(date.getDate() + 1);
                }
                weeks.push(week);
            }
            return weeks;
        },
        getVisibleYears: function (date) {
            var years = [];
            date = new Date(date || new Date());
            date.setFullYear(date.getFullYear() - (date.getFullYear() % 10));
            for (var i = 0; i < 12; i++) {
                years.push(new Date(date.getFullYear() + (i - 1), 0, 1));
            }
            return years;
        },
        getDaysOfWeek: function (date) {
            date = new Date(date || new Date());
            date = new Date(date.getFullYear(), date.getMonth(), date.getDate());
            date.setDate(date.getDate() - (date.getDay() - 1));
            var days = [];
            for (var i = 0; i < 7; i++) {
                days.push(new Date(date));
                date.setDate(date.getDate() + 1);
            }
            return days;
        },
        getVisibleMonths: function (date) {
            date = new Date(date || new Date());
            var year = date.getFullYear();
            var months = [];
            for (var month = 0; month < 12; month++) {
                months.push(new Date(year, month, 1));
            }
            return months;
        },
        getVisibleHours: function (date) {
            date = new Date(date || new Date());
            date.setHours(0);
            date.setMinutes(0);
            date.setSeconds(0);
            date.setMilliseconds(0);
            var hours = [];
            for (var i = 0; i < 24; i++) {
                hours.push(date);
                date = new Date(date.getTime() + 60 * 60 * 1000);
            }
            return hours;
        },
        isAfter: function (model, date) {
            return model && model.getTime() <= date.getTime();
        },
        isBefore: function (model, date) {
            return model.getTime() >= date.getTime();
        },
        isSameYear: function (model, date) {
            return model && model.getFullYear() === date.getFullYear();
        },
        isSameMonth: function (model, date) {
            return this.isSameYear(model, date) && model.getMonth() === date.getMonth();
        },
        isSameDay: function (model, date) {
            return this.isSameMonth(model, date) && model.getDate() === date.getDate();
        },
        isSameHour: function (model, date) {
            return this.isSameDay(model, date) && model.getHours() === date.getHours();
        },
        isSameMinutes: function (model, date) {
            return this.isSameHour(model, date) && model.getMinutes() === date.getMinutes();
        }
    };
});