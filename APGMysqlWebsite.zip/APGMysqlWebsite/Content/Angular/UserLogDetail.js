﻿//Appjs
var app = angular.module("userLog", []);
app.controller('UserLogDetails', ['$scope', '$http', function ($scope, $http) {
    $scope.UserLog = {}
    $scope.GetUserDetailList = function (data1, StyleValue) {
        $("#divLoading").show();
        //location.reload();
        UserDetail(data1, StyleValue);
        function UserDetail(data1, StyleValue) {
            var facilityId = data1.FacilityId;
            var UserLogModel = { LocationId: facilityId, FilterId: StyleValue }
            $http({
                method: 'Post',
                url: '/DynamicMenu/UserDetail',
                data: UserLogModel
            }).success(function (data) {
                $("#divLoading").hide();
                $('#UserList').html(data);
                //location.reload();
            });
        };
    }
    var UserTypeId = null;
    var UserId = null;
    GetFailictyList();
    function GetFailictyList() {
        $("#divLoading").show();
        $http({
            method: 'Get',
            url: '/admin/GetFailictyList'
        }).success(function (data, status, headers, config) {
            $("#divLoading").hide();
            $scope.GetFailictyList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetOperationList();
    function GetOperationList() {
        $("#divLoading").show();
        $http({
            method: 'Get',
            url: '/DynamicMenu/GetOperationList'
        }).success(function (data, status, headers, config) {
            $("#divLoading").hide();
            $scope.GetOperationList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetDefaultLogDetailList();
    function GetDefaultLogDetailList() {
        $("#divLoading").show();
        $http({
            method: 'get',
            url: '/DynamicMenu/DefaultLogDetail'
            //data: { UserTypeId: data1, UserId: data2, FilterId: data3 }
        }).success(function (data) {
            $("#divLoading").hide();
            $('#LogDetail').html(data);
        });
    };
    $scope.reloadRoute = function () {
        location.reload();
    }

    $scope.Reload = function () {
        location.reload();
    }
    $scope.GetLogDetailList = function (data1, data2, StyleValue) {
        //StyleValue working as Procedure Value
        $("#divLoading").show();
        GetLogDetailList(data1, data2, StyleValue);
        function GetLogDetailList(data1, data2, StyleValue) {
            var error = null;
            var dateFrom = document.getElementById("DateFrom").value;
            var dateTo = document.getElementById("DateTo").value;
            var operationId = document.getElementById("OPName").value;
            var operation = document.getElementById("OPName");
            var operationName = operation.options[operation.selectedIndex].text;
            if (StyleValue == "4") {
                var UserLogModel = { FilterId: 6 }
                $http({
                    method: 'Post',
                    url: '/DynamicMenu/UserDetail',
                    data: UserLogModel
                }).success(function (data) {
                    $('#UserList').html(data);
                });
                $http({
                    method: 'Post',
                    url: '/DynamicMenu/UserLogDetail',
                    data: { UserTypeId: UserTypeId, UserId: UserId, FilterId: StyleValue }
                }).success(function (data) {
                    alert(StyleValue);
                    $('#LogDetail').html(data);
                });
            }
            if (StyleValue == "5") {
                UserTypeId = data1;
                UserId = data2;
                $http({
                    method: 'Post',
                    url: '/DynamicMenu/UserLogDetail',
                    data: { UserTypeId: UserTypeId, UserId: UserId, FilterId: StyleValue }
                }).success(function (data) {
                    $('#LogDetail').html(data);
                });
            }
            if (StyleValue == "7") {
                if (dateFrom == '' || dateFrom == null) {
                    alert("Please select Date From Value");
                    error = "1";
                }
                if (dateTo == '' || dateTo == null) {
                    alert("Please select Date To Value");
                    error = "2";
                }
                if (error == null || error == '') {
                    $http({
                        method: 'Post',
                        url: '/DynamicMenu/UserLogDetail',
                        data: { DateFrom: dateFrom, DateTo: dateTo, UserTypeId: UserTypeId, UserId: UserId, FilterId: StyleValue }
                    }).success(function (data) {
                        $('#LogDetail').html(data);
                    });
                }
            }
            if (StyleValue == "10") {
                if (operationId == '' || dateFrom == null) {
                    alert("Please select Operation Name");
                    error = "1";
                }
                if (error == null || error == '') {
                    $http({
                        method: 'Post',
                        url: '/DynamicMenu/UserLogDetail',
                        data: { OperationName: operationName, UserTypeId: UserTypeId, UserId: UserId, FilterId: StyleValue }
                    }).success(function (data) {
                        $('#LogDetail').html(data);
                    });
                }
            }
            $("#divLoading").hide();
        };
    }
}]);
