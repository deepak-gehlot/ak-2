var app = angular.module('plunker', ['ngCsvImport']);

app.controller('MainCtrl', function ($http, $scope, $rootScope) {
    $('#format').hide();
    //$scope.name = 'World';
    $('#Calcution_Div').hide();
    $('#Error_Div').hide();
 
    $scope.patientrecorderror = [];
    $scope.totalrecords = [];
    $scope.totalrecords = 0;
    $scope.FailRecords = 0;
    $scope.SuccessRecords = 0;
    var count = 0;
    $scope.submit = function () {
       
        var x = 0;
        var mydata = [];
      //  var halfdata = [];
        var i = count;
        //  console.log($rootScope.patientrecord);
      
     
        for ( i ; i < $rootScope.patientrecord.length; i++) {
            if (i % 25 == 0 && x != 0)
            {
                break;
            }
            mydata.push($rootScope.patientrecord[i]);
            count++;
            x = 1;
        }
        if (mydata.length > 0) {
            $("#divLoading").show();
            $('#Calcution_Div').show();
            $('#Error_Div').show();
         
                    $http({
                        method: 'Post',
                        url: '/Admin/PatientDetailUpaload',
                        data: mydata
                    }).success(function (data) {
                        $scope.patientrecorderror = $scope.patientrecorderror || [];
                        $scope.patientrecorderror.push.apply($scope.patientrecorderror, data);
                 
                        if (count != $rootScope.patientrecord.length)
                        {
                            $scope.submit();
                         }
                         else
                           {
                            $("#divLoading").hide();
                            count = 0;
                            if (data == "0")
                            {
                               // $("#divLoading").hide();
                                location.href = '/Account/LogOut';
                             }
                            else
                            {
                                    if ($scope.patientrecorderror.length == 0) {
                                        alert("file uploaded successfully...........")
                                       // $("#divLoading").hide();
                                   }
                                  else {
                                      
                                  //  $scope.patientrecorderror = data;
                                      }
                                $scope.totalrecords = $rootScope.patientrecord.length;
                                $scope.FailRecords = $scope.patientrecorderror.length;
                                $scope.SuccessRecords = $rootScope.patientrecord.length- $scope.patientrecorderror.length;

                                }
                               }
                }).error(function (data) {
                    $scope.message = 'Unexpected Error';
                    mydata = [];
                    $("#divLoading").hide();
                })
          //  }
         //   }
          
        }
        else {
            if (count == 0)
            {
                alert("Please Choose File. Only csv or xlsx format are allowed.");
            }
            
        }
    }
});
//app.directive('fileReader', function() {
//  return {
//    scope: {
//      fileReader:"="
//    },
//    link: function(scope, element) {
//      $(element).on('change', function(changeEvent) {
//        var files = changeEvent.target.files;
//        if (files.length) {
//          var r = new FileReader();
//          r.onload = function(e) {
//              var contents = e.target.result;
//              scope.$apply(function () {
//                scope.fileReader = contents;
//              });
//          };
          
//          r.readAsText(files[0]);
//        }
//      });
//    }
//  };
//});




