﻿
var app = angular.module("AdminAlertApp", []);

app.controller('CtrlUpdatenote', ['$scope', '$http', function ($scope, $http) {
  
  
    //  var alertid = "";
   
 
    $scope.ActivePatient = function (id, alertid) {
        $scope.PatientDetail= {};
        var patientid = id;
        $http({
            method: 'Get',
            url:'/Admin/GetPatientaltername?id=' + patientid+'&alertid='+alertid
        }).success(function (data) {

            $scope.patientalertlistt = data.patientalertlistt[0];
            $scope.patientalertlistt1 = data.patientalertlistt1[0];
      
          
           document.getElementById('alertid12').value = alertid;
           $("#alertid12 option[value='? undefined:undefined ?']").remove();
      
           
        }).error(function (data) {
            $scope.message = 'Unexpected Error';
        });
       // GetAlertList();
    }
   
    //$scope.GetPatientNotes = function () {
    //    var alertid = value;
    //    alert("patietnotes");
    //    if (alertid) {
    //        $http({
    //            method: 'Post',
    //            url: '/Alert/GetPatientNotes',
    //            data: JSON.stringify({ Alertid: alertid })
    //        }).success(function (data, status, headers, config) {
    //            $scope.PatientDetail = data;
    //        }).error(function (data,status,headers,config) {
    //            $scope.message = 'Unexpected Error';
    //        });
    //    }

    $scope.onsubmit = function () {
      
        var alertid = document.getElementById("alertid12").value;
        var mailbody = $scope.PatientDetail.mailbody;
        var patientid = $scope.patientalertlistt.PatientId;
        var AlertDetail = ({
            ScheduleDay: alertid, mailbody: mailbody, PatientId: patientid
        });
        var note = document.getElementById("note1").value;
      
        if (note == "") {
            alert("Note is Required.");
        }
        else {
            $http({
                method: 'Post',
                url: '/Admin/CompleteAlertList',
                data: AlertDetail
            }).success(function (data, status, headers, config) {
                alert("Status Complete successfully.");
                location.href = '/Admin/AlertStatus';
            }).error(function (data, status, headers, config) {
                $scope.message = 'Unexpected Error';
            });
        }
    }
   
    $scope.onupdate=function()
    {
        var alertid = document.getElementById("alertid12").value;
        var mailbody = $scope.PatientDetail.mailbody;
        var patientid = $scope.patientalertlistt.PatientId;
        var AlertDetail = ({
            ScheduleDay: alertid, mailbody: mailbody, PatientId: patientid
        });
        var note = document.getElementById("note1").value;
      
        if (note == "") {
            alert("Note is Required.");
        }
        else {
            $http({
                method: 'Post',
                url: '/Alert/UpdateAlertList',
                data: AlertDetail
            }).success(function (data, status, headers, config) {
                alert("Status Complete successfully.");
                location.href = '/Admin/AlertStatus';
            }).error(function (data, status, headers, config) {
                $scope.message = 'Unexpected Error';
            });
        }
    }
} ]);