﻿//Appjs
var app = angular.module("ReportsDetail", []);
app.controller('WomacOutCome', ['$scope', '$http', function ($scope, $http) {
    $scope.Outcome = {}
    var UserTypeId = null;
    var UserId = null;
    GetFailictyList();
    function GetFailictyList() {
        $http({
            method: 'Get',
            url: '/admin/GetFailictyList'
        }).success(function (data, status, headers, config) {
            $scope.GetFailictyList = data;
        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
    };

    GetWOMACOutComeDetail();
    function GetWOMACOutComeDetail() {
        $http({
            method: 'get',
            url: '/Account/GetDefaultWOMACOutComeDetail'
        }).success(function (data) {
            $('#LogDetail').html(data);
        });
    };
    $scope.reloadRoute = function () {
        alert();
        location.reload();
    }

    $scope.Reload = function () {
        location.reload();
    }

    $scope.GetLogDetailList = function (data1, data2, StyleValue) {
        //StyleValue working as Procedure Value
        $("#divLoading").show();
        GetLogDetailList(data1, data2, StyleValue);
        function GetLogDetailList(data1, data2, StyleValue) {
            var error = null;
            var dateFrom = document.getElementById("DateFrom").value;
            var dateTo = document.getElementById("DateTo").value;
            var TestId = document.getElementById("TestId").value;
            var FacilityId = data1.FacilityId;
            var FilterId = data2;
            var Outcome = { DateFrom: dateFrom, DateTo: dateTo, TestId: TestId, FacilityId: FacilityId, FilterId: FilterId }
            $http({
                method: 'Post',
                url: '/Account/WomacOutComeReport',
                data: Outcome
            }).success(function (data) {
                $('#LogDetail').html(data);
            });

            $("#divLoading").hide();
        };
    }

    $scope.GetInjectedList = function (data1, data2) {
        //StyleValue working as Procedure Value
        $("#divLoading").show();
        GetLogDetailList(data1);
        function GetLogDetailList(data1) {
            var error = null;
            var dateFrom = document.getElementById("IDateFrom").value;
            var dateTo = document.getElementById("IDateTo").value;
            var TestId = document.getElementById("InjectionId").value;
            var FacilityId = data1.FacilityId;
            var FilterId = data2;
            var Outcome = { DateFrom: dateFrom, DateTo: dateTo, TestId: TestId, FacilityId: FacilityId, FilterId: FilterId }
            $http({
                method: 'Post',
                url: '/Account/WomacOutComeReport',
                data: Outcome
            }).success(function (data) {
                $('#InjectionDetail').html(data);
            });

            $("#divLoading").hide();
        };
    }
}]);
