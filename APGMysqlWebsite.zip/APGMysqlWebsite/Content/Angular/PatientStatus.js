﻿var app = angular.module("AdminApp", []);

app.controller('CtrlUpdateStatus', ['$scope', '$http', function ($scope, $http) {
  
    $scope.ActivePatient = function (id) {
       
        $scope.ShowUserDetailsModel = {};
        $scope.PatientDetail = {};
        
        var patientid = id;
        $http({
            method: 'Get',
            url: '/Admin/GetPatientName?id=' + patientid
        }).success(function (data) {
            $scope.PatientDetail = data;
         
        }).error(function (data) {
            $scope.message = 'Unexpected Error';
        });
        GetAlertList();
    }

    function GetAlertList() {
     
        $scope.GetAlertList = {};
        var pid = $scope.Pid;
        $http({
            method: 'Get',
            url: '/Admin/GetAlertList'
        }).success(function (data, status, headers, config) {
            $scope.GetAlertList = data;
           

        }).error(function (data, status, headers, config) {
            $scope.message = 'Unexpected Error';
        });
       
    };

  
    $scope.GetPatientStatus = function (value) {
     
        $scope.ShowUserDetailsModel = {};
        var alertid = value;

        if (alertid) {
            $http({
                method: 'Post',
                url: '/Admin/GetPatientStatus',
                data: JSON.stringify({ Alertid: alertid })
            }).success(function (data, status, headers, config) {
                $scope.ShowUserDetailsModel = data;
            }).error(function (data, status, headers,config) {
                $scope.message = 'Unexpected Error';
            });
        }
        else { }

    
   }

    $scope.onsubmit = function () {
        $("#divLoading").show();
        var alerts = $scope.PatientDetail.ScheduleDay;
        var alertid = document.getElementById("alertday").value;
        var status = $scope.PatientDetail.status;
        var mailbody = $scope.ShowUserDetailsModel.SecurityBody;
        var alertto = $scope.ShowUserDetailsModel.AlertTo;
        var patientid = $scope.PatientDetail.Pid;
        var AlertDetail = ({
            Alertid: alerts, Status: status, mailbody: mailbody, AlertTo: alertto, Pid: patientid
        });
       
        var note = document.getElementById("note").value;
        if (status == "2") {
            if (alertid == "") {
                alert("Select Alert.");
            }
            else if (note == "") {
                alert("Note is Required.");
            }
            else {
             
                $http({
                    method: 'Post',
                    url: '/Admin/UpdateAlertList',
                    data: AlertDetail
                }).success(function (data, status, headers, config) {
                    alert("Status update successfully.");
                    location.href = '/Admin/PatientList?FormId=4';
                    $("#divLoading").hide();
                }).error(function (data, status, headers, config) {
                    $scope.message = 'Unexpected Error';
                });
            }
        }
        else {
          
            $http({
                method: 'Post',
                url: '/Admin/UpdateAlertList',
                data: AlertDetail
            }).success(function (data, status, headers, config) {
                alert("Status update successfully.");
                location.href = '/Admin/PatientList?FormId=4';
                $("#divLoading").hide();
            }).error(function (data, status, headers, config) {
                $scope.message = 'Unexpected Error';
            });
        }
    
    }
    //$scope.submit = function () {
    
    //    var patientdetail = $scope.PatientDetail;
    //    $http({
    //        method: 'Post',
    //        url: '/Admin/PatientList?FormId=' + 4,
    //        data: patientdetail
    //    }).success(function (data, status, headers, config) {
    //        Patientlist = $scope.data;
    //    }).error(function (data, status, headers, config) {
    //        $scope.message = 'Unexpected Error';
    //    });

    //}


}]);

