﻿
//Loginjs
var app = angular.module("myAdmin", []);
app.controller('Patientregistercontroller', ['$scope', '$http', function ($scope, $http) {
    $scope.xyz = 'Error';
    $scope.submitted = false;
    $scope.Patientmodel = {}
    $scope.onsubmit = function (alldetails) {
        $("#divLoading").show();
        $scope.submitted = true;
        insertonsubmit(alldetails);
        function insertonsubmit(data) {
            $scope.FirstName = false;
            $scope.LastName = false;
            $scope.Email = false;
            $scope.Password = false;
            $scope.PasswordLength = false;
            $scope.Confirmpwd = false;
            $scope.MatchPassword = false;
            var GetErrors = '';
            var firstname = data.Firstname;
            var lastname = data.Lastname;
            var email = data.Email;
            var password = data.Password;
            var confirmpwd = data.Confirmpwd;
            $('.errorMsg').remove();
            if (firstname == null || firstname == '') {
                $scope.FirstName = { color: 'red' };
                GetErrors += '1' + '\n';
            }
            if (lastname == null || lastname == '') {
                $scope.LastName = { color: 'red' };
                GetErrors += '2' + '\n';
            }
            if (email != null || email != undefined) {
                var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
                if (!re.test(email)) {
                    $('#EmailId1').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                    GetErrors += '3' + '\n';
                }
            }
            if (email == null || email == '') {
                $scope.Email = { color: 'red' };
                GetErrors += '4' + '\n';
            }
            if (password == null || password == '') {
                $scope.Password = { color: 'red' };
                GetErrors += '5' + '\n';
            }
            if (confirmpwd == null || confirmpwd == '') {
                $scope.Confirmpwd = { color: 'red' };
                GetErrors += '6' + '\n';
            }
            if (password != null && password != undefined && password.length < 8) {
                $('#PwdLength').append('<div class="errorMsg" style="color:red">Password Lenght must be Minimum 8 character</div>');
                GetErrors += '7' + '\n';
            }
            if (password != confirmpwd) {
                $('#MatchPassword').append('<div class="errorMsg" style="color:red">Password and Confirm Password Should be Same</div>');
                GetErrors += '7' + '\n';
            }
            if (GetErrors == null || GetErrors == '') {
                var AddPatientModule = { Firstname: firstname, Lastname: lastname, Email: email, Password: password }
                $http({
                    method: 'POST',
                    url: '/Patient/Register',
                    data: AddPatientModule
                }).success(function (data) {
                    $("#divLoading").hide();
                    $scope.ABC = data;
                    var Con = data;
                    console.log(data)
                    if (Con == null || Con == '') {
                        method: 'get',
                        location.href = '/Patient/ThankYou';
                        alert('Register Successfully ! Please check your E-mail');
                        data: AddPatientModule
                    }
                    else if ($scope.ABC == "\"Error\"") {
                        location.href = '/Home/Index';
                        alert('This Email-id is already Registered!. Please enter different Email-id');
                    }
                }).error(function (serverResponse, status, headers, config) {
                    $scope.Patientmodel = '';
                    $("#divLoading").hide();
                });
            }
            else {
                $("#divLoading").hide();
                //alert(GetErrors);
            }
        }
    }
}]);

app.controller('UserLogin', ['$scope', '$http', function ($scope, $http) {
    $scope.submitted = false;
    $scope.Patientmodel = {}
    $scope.onsubmit2 = function (data) {
        $("#divLoading").show();
        console.log(data);
        $scope.submitted = true;
        $scope.LoginEmail = false;
        $scope.LoginPassword = false;
        var UserType = '';
        var GetErrors = '';
        var email = data.LoginEmail;
        var password = data.LoginPassword;
        $('.errorMsg').remove();
        if (email != null || email != undefined) {
            var re = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
            if (!re.test(email)) {
                $('#EmailId2').append('<div class="errorMsg" style="color:red">Invalid Email-Id</div>');
                GetErrors += '1' + '\n';
            }
        }
        if (email == null || email == '') {
            $scope.LoginEmail = { color: 'red' };
            GetErrors += '2' + '\n';
        }
        if (password == null || password == '') {
            $scope.LoginPassword = { color: 'red' };
            GetErrors += '3' + '\n';
        }
        if (GetErrors == null || GetErrors == '') {
            var AddPatientModule = { Emailaddress: email, Password: password }
            $http({
                method: 'POST',
                url: '/Home/index',
                data: AddPatientModule
            })
                .success(function (data, status, headers, config) {
                    UserType = data;
                    if (UserType == "\"SuccessUser\"") {
                        location.href = '/Home/DashBoard';
                    }
                    else if (UserType == "\"SuccessPatient\"") {
                        location.href = '/Patient/PatientDashboard';
                    }
                }).error(function (serverResponse, status, headers, config) {
                    $scope.Patientmodel = '';
                    $("#divLoading").hide();
                    alert("Invalid Email-id or Password!");
                }
                );
        } else {
            $("#divLoading").hide();
        }
    };
}]);

