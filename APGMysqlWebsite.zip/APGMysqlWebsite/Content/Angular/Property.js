﻿var app = angular.module("myapp", ['angularFileUpload']);

app.controller('ChangeProperty', ['$scope', '$http','$upload', function ($scope, $http,$upload) {
    $scope.model = {};
   

    $scope.UploadCsvProspect = function (model)
    {
        $('.errorMsg').remove();
        if ($("#csv").val() == null || $("#csv").val() == undefined || $("#csv").val() == '')
            tempAlertInformation("Please select CSV file.");
        else {
            $("#divLoading").show();

            $http({
                method: 'POST',
                url: '/Property/Upload/',
              
            }).success(function (result) {
                $("#csv").val(null);
               // alert("result"+result);
                if (result == 1)
                {
                  //  alert('1');
                    $('#Import').append('<div class="errorMsg" style="color:red"><strong>*</strong>No Record Inserted<br> Order of file Must be <br> Company,Street,City,State,Zip Code,Phone,Last Name,First name,Title,Email,Region </div>');
                }
               
                else if (result == 2)
                {
                    $http({
                        method: 'POST',
                        url: '/Admin/UploadSuccess/',
                    }).success(function (result) {
                        $('#sectionContents').html(result);
                    })
                    $("#divLoading").hide();
                    tempAlert("Record imported successfully.");
                   }
                else
                    location.href = '/MyAccount/Login';
               }).error(function (data, status, headers, config) {
                 //  alert(data);
                  // alert(data);
                 //  alert(status);
                //   alert(headers);
                //   alert(config);
            });
 }
           }
    $scope.PropertyCSV = function ($files) {
    
        for (var i = 0; i < $files.length; i++) {
            var file = $files[i];
       
            $scope.upload = $upload.upload({
                method: 'POST',
                url: '/Admin/PropertyCSV/',
                file: file
            }).progress(function (evt) {
              
            }).success(function (data, status, headers, config) {
                if (data == 0) {
                    alert("Please Select CSV  File only");
                    $("#csv").val(null);
                    }
                if (data == 2)
                { location.href = '/MyAccount/Login'; }
                });
        }
    };
    
}]);
